// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/sched.c
/* Instruction scheduling pass.
   Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)
   Enhanced by, and currently maintained by, Jim Wilson (wilson@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int max_reg_num(...) asm("_max_reg_num");
extern int rtx_addr_varies_p(...) asm("_rtx_addr_varies_p");
extern int recog_memoized(...) asm("_recog_memoized");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int dead_or_set_regno_p(...) asm("_dead_or_set_regno_p");
extern int remove_note(...) asm("_remove_note");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int get_max_uid(...) asm("_get_max_uid");
extern int reposition_prologue_and_epilogue_notes(...) asm("_reposition_prologue_and_epilogue_notes");
struct n64_tag_function_unit_desc;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sometimes;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];
static short *sched_reg_n_deaths;
static int *sched_reg_n_calls_crossed;
static int *sched_reg_live_length;





static rtx *reg_last_uses;
static rtx *reg_last_sets;
static regset reg_pending_sets;
static int reg_pending_sets_all;


static int *insn_luid;



static int *insn_priority;


static short *insn_costs;




static short *insn_units;




static unsigned int *insn_blockage;
static int *insn_ref_count;





static rtx *line_note;




static rtx *line_note_head;



static rtx note_list;




static regset bb_dead_regs;
static regset bb_live_regs;





static regset old_live_regs;





static rtx dead_notes;
static rtx insn_queue[128];
static int q_ptr = 0;
static int q_size = 0;






static int *insn_tick;





struct n64_tag_sometimes
{
  short offset; short bit;
  short live_length; short calls_crossed;
};


static rtx canon_rtx (rtx) asm("_canon_rtx");
static int rtx_equal_for_memref_p (rtx, rtx) asm("_rtx_equal_for_memref_p");
static rtx find_symbolic_term (rtx) asm("_find_symbolic_term");
static int memrefs_conflict_p (int, rtx, int, rtx, int) asm("_memrefs_conflict_p")
                           ;
static void add_dependence (rtx, rtx, n64_enum_reg_note) asm("_add_dependence");
static void remove_dependence (rtx, rtx) asm("_remove_dependence");
static rtx find_insn_list (rtx, rtx) asm("_find_insn_list");
static int insn_unit (rtx) asm("_insn_unit");
static unsigned int blockage_range (int, rtx) asm("_blockage_range");
static void clear_units (void) asm("_clear_units");
static void prepare_unit (int) asm("_prepare_unit");
static int actual_hazard_this_instance (int, int, rtx, int, int) asm("_actual_hazard_this_instance");
static void schedule_unit (int, rtx, int) asm("_schedule_unit");
static int actual_hazard (int, rtx, int, int) asm("_actual_hazard");
static int potential_hazard (int, rtx, int) asm("_potential_hazard");
static int insn_cost (rtx, rtx, rtx) asm("_insn_cost");
static int priority (rtx) asm("_priority");
static void free_pending_lists (void) asm("_free_pending_lists");
static void add_insn_mem_dependence (rtx *, rtx *, rtx, rtx) asm("_add_insn_mem_dependence");
static void flush_pending_lists (rtx) asm("_flush_pending_lists");
static void sched_analyze_1 (rtx, rtx) asm("_sched_analyze_1");
static void sched_analyze_2 (rtx, rtx) asm("_sched_analyze_2");
static void sched_analyze_insn (rtx, rtx, rtx) asm("_sched_analyze_insn");
static int sched_analyze (rtx, rtx) asm("_sched_analyze");
static void sched_note_set (int, rtx, int) asm("_sched_note_set");
static int rank_for_schedule (rtx *, rtx *) asm("_rank_for_schedule");
static void swap_sort (rtx *, int) asm("_swap_sort");
static void queue_insn (rtx, int) asm("_queue_insn");
static int birthing_insn (rtx) asm("_birthing_insn");
static void adjust_priority (rtx) asm("_adjust_priority");
static int schedule_insn (rtx, rtx *, int, int) asm("_schedule_insn");
static int schedule_select (rtx *, int, int, FILE *) asm("_schedule_select");
static void create_reg_dead_note (rtx, rtx) asm("_create_reg_dead_note");
static void attach_deaths (rtx, rtx, int) asm("_attach_deaths");
static void attach_deaths_insn (rtx) asm("_attach_deaths_insn");
static rtx unlink_notes (rtx, rtx) asm("_unlink_notes");
static int new_sometimes_live (struct n64_tag_sometimes *, int, int, int) asm("_new_sometimes_live")
                 ;
static void finish_sometimes_live (struct n64_tag_sometimes *, int) asm("_finish_sometimes_live");
static void schedule_block (int, FILE *) asm("_schedule_block");
static rtx regno_use_in (int, rtx) asm("_regno_use_in");
static void split_hard_reg_notes (rtx, rtx, rtx, rtx) asm("_split_hard_reg_notes");
static void new_insn_dead_notes (rtx, rtx, rtx, rtx) asm("_new_insn_dead_notes");
static void update_n_sets (rtx, int) asm("_update_n_sets");
static void update_flow_info (rtx, rtx, rtx, rtx) asm("_update_flow_info");


void schedule_insns (FILE *) asm("_schedule_insns");







static rtx *reg_known_value;
static char *reg_known_equiv_p;


static int reg_known_value_size;

static rtx
canon_rtx(rtx x) asm("_canon_rtx");
static rtx
canon_rtx(rtx x)
{
  if (((x)->code) == REG && ((x)->fld[0].rtint) >= 68
      && ((x)->fld[0].rtint) <= reg_known_value_size)
    return reg_known_value[((x)->fld[0].rtint)];
  else if (((x)->code) == PLUS)
    {
      rtx x0 = canon_rtx (((x)->fld[0].rtx));
      rtx x1 = canon_rtx (((x)->fld[1].rtx));

      if (x0 != ((x)->fld[0].rtx) || x1 != ((x)->fld[1].rtx))
 {


   if (((x0)->code) == CONST_INT)
     return plus_constant_for_output_wide (x1, (int) (((x0)->fld[0].rtwint)));
   else if (((x1)->code) == CONST_INT)
     return plus_constant_for_output_wide (x0, (int) (((x1)->fld[0].rtwint)));
   return gen_rtx (PLUS, ((x)->mode), x0, x1);
 }
    }
  return x;
}



void
init_alias_analysis(void) asm("_init_alias_analysis");
void
init_alias_analysis(void)
{
  int maxreg = max_reg_num ();
  rtx insn;
  rtx note;
  rtx set;

  reg_known_value_size = maxreg;

  reg_known_value
    = (rtx *) oballoc ((maxreg-68) * sizeof (rtx))
      - 68;
  memset ((char *) (reg_known_value + 68),0,(maxreg-68) * sizeof (rtx))
                                                ;

  reg_known_equiv_p
    = (char *) oballoc ((maxreg -68) * sizeof (char))
      - 68;
  memset (reg_known_equiv_p + 68,0,(maxreg - 68) * sizeof (char))
                                                   ;


  for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
    if ((set = single_set (insn)) != 0
 && ((((set)->fld[0].rtx))->code) == REG
 && ((((set)->fld[0].rtx))->fld[0].rtint) >= 68
 && (((note = find_reg_note (insn, REG_EQUAL, 0)) != 0
      && reg_n_sets[((((set)->fld[0].rtx))->fld[0].rtint)] == 1)
     || (note = find_reg_note (insn, REG_EQUIV, (rtx) 0)) != 0)
 && ((((note)->fld[0].rtx))->code) != EXPR_LIST)
      {
 int regno = ((((set)->fld[0].rtx))->fld[0].rtint);
 reg_known_value[regno] = ((note)->fld[0].rtx);
 reg_known_equiv_p[regno] = ((n64_enum_reg_note) ((note)->mode)) == REG_EQUIV;
      }


  while (--maxreg >= 68)
    if (reg_known_value[maxreg] == 0)
      reg_known_value[maxreg] = regno_reg_rtx[maxreg];
}






static int
rtx_equal_for_memref_p(rtx x, rtx y) asm("_rtx_equal_for_memref_p");
static int
rtx_equal_for_memref_p(rtx x, rtx y)
{
  register int i;
  register int j;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0 && y == 0)
    return 1;
  if (x == 0 || y == 0)
    return 0;
  x = canon_rtx (x);
  y = canon_rtx (y);

  if (x == y)
    return 1;

  code = ((x)->code);

  if (code != ((y)->code))
    return 0;




  if (((x)->mode) != ((y)->mode))
    return 0;



  if (code == REG)
    return ((x)->fld[0].rtint) == ((y)->fld[0].rtint);
  if (code == LABEL_REF)
    return ((x)->fld[0].rtx) == ((y)->fld[0].rtx);
  if (code == SYMBOL_REF)
    return ((x)->fld[0].rtstr) == ((y)->fld[0].rtstr);



  if (code == EQ || code == NE || (rtx_class[(int)(code)]) == 'c')
    return ((rtx_equal_for_memref_p (((x)->fld[0].rtx), ((y)->fld[0].rtx))
      && rtx_equal_for_memref_p (((x)->fld[1].rtx), ((y)->fld[1].rtx)))
     || (rtx_equal_for_memref_p (((x)->fld[0].rtx), ((y)->fld[1].rtx))
  && rtx_equal_for_memref_p (((x)->fld[1].rtx), ((y)->fld[0].rtx))));
  else if ((rtx_class[(int)(code)]) == '<' || (rtx_class[(int)(code)]) == '2')
    return (rtx_equal_for_memref_p (((x)->fld[0].rtx), ((y)->fld[0].rtx))
     && rtx_equal_for_memref_p (((x)->fld[1].rtx), ((y)->fld[1].rtx)));
  else if ((rtx_class[(int)(code)]) == '1')
    return rtx_equal_for_memref_p (((x)->fld[0].rtx), ((y)->fld[0].rtx));




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      switch (fmt[i])
 {
 case 'w':
   if (((x)->fld[i].rtwint) != ((y)->fld[i].rtwint))
     return 0;
   break;

 case 'n':
 case 'i':
   if (((x)->fld[i].rtint) != ((y)->fld[i].rtint))
     return 0;
   break;

 case 'V':
 case 'E':

   if (((x)->fld[i].rtvec->num_elem) != ((y)->fld[i].rtvec->num_elem))
     return 0;


   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     if (rtx_equal_for_memref_p (((x)->fld[i].rtvec->elem[j].rtx), ((y)->fld[i].rtvec->elem[j].rtx)) == 0)
       return 0;
   break;

 case 'e':
   if (rtx_equal_for_memref_p (((x)->fld[i].rtx), ((y)->fld[i].rtx)) == 0)
     return 0;
   break;

 case 'S':
 case 's':
   if (strcmp (((x)->fld[i].rtstr), ((y)->fld[i].rtstr)))
     return 0;
   break;

 case 'u':

   break;

 case '0':
   break;




 default:
   abort ();
 }
    }
  return 1;
}




static rtx
find_symbolic_term(rtx x) asm("_find_symbolic_term");
static rtx
find_symbolic_term(rtx x)
{
  register int i;
  register n64_enum_rtx_code code;
  register char *fmt;

  code = ((x)->code);
  if (code == SYMBOL_REF || code == LABEL_REF)
    return x;
  if ((rtx_class[(int)(code)]) == 'o')
    return 0;

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      rtx t;

      if (fmt[i] == 'e')
 {
   t = find_symbolic_term (((x)->fld[i].rtx));
   if (t != 0)
     return t;
 }
      else if (fmt[i] == 'E')
 break;
    }
  return 0;
}
static int
memrefs_conflict_p(int xsize, rtx x, int ysize, rtx y, int c) asm("_memrefs_conflict_p");
static int
memrefs_conflict_p(int xsize, rtx x, int ysize, rtx y, int c)
{
  if (((x)->code) == HIGH)
    x = ((x)->fld[0].rtx);
  else if (((x)->code) == LO_SUM)
    x = ((x)->fld[1].rtx);
  else
    x = canon_rtx (x);
  if (((y)->code) == HIGH)
    y = ((y)->fld[0].rtx);
  else if (((y)->code) == LO_SUM)
    y = ((y)->fld[1].rtx);
  else
    y = canon_rtx (y);

  if (rtx_equal_for_memref_p (x, y))
    return (xsize == 0 || ysize == 0 ||
     (c >= 0 && xsize > c) || (c < 0 && ysize+c > 0));

  if (y == frame_pointer_rtx || y == hard_frame_pointer_rtx
      || y == stack_pointer_rtx)
    {
      rtx t = y;
      int tsize = ysize;
      y = x; ysize = xsize;
      x = t; xsize = tsize;
    }

  if (x == frame_pointer_rtx || x == hard_frame_pointer_rtx
      || x == stack_pointer_rtx)
    {
      rtx y1;

      if ((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH))
 return 0;

      if (((y)->code) == PLUS
   && canon_rtx (((y)->fld[0].rtx)) == x
   && (y1 = canon_rtx (((y)->fld[1].rtx)))
   && ((y1)->code) == CONST_INT)
 {
   c += ((y1)->fld[0].rtwint);
   return (xsize == 0 || ysize == 0
    || (c >= 0 && xsize > c) || (c < 0 && ysize+c > 0));
 }

      if (((y)->code) == PLUS
   && (y1 = canon_rtx (((y)->fld[0].rtx)))
   && (((y1)->code) == LABEL_REF || ((y1)->code) == SYMBOL_REF || ((y1)->code) == CONST_INT || ((y1)->code) == CONST_DOUBLE || ((y1)->code) == CONST || ((y1)->code) == HIGH))
 return 0;

      return 1;
    }

  if (((x)->code) == PLUS)
    {


      rtx x0 = ((x)->fld[0].rtx);
      rtx x1 = ((x)->fld[1].rtx);

      if (((y)->code) == PLUS)
 {


   rtx y0 = ((y)->fld[0].rtx);
   rtx y1 = ((y)->fld[1].rtx);

   if (rtx_equal_for_memref_p (x1, y1))
     return memrefs_conflict_p (xsize, x0, ysize, y0, c);
   if (rtx_equal_for_memref_p (x0, y0))
     return memrefs_conflict_p (xsize, x1, ysize, y1, c);
   if (((x1)->code) == CONST_INT)
     if (((y1)->code) == CONST_INT)
       return memrefs_conflict_p (xsize, x0, ysize, y0,
      c - ((x1)->fld[0].rtwint) + ((y1)->fld[0].rtwint));
     else
       return memrefs_conflict_p (xsize, x0, ysize, y, c - ((x1)->fld[0].rtwint));
   else if (((y1)->code) == CONST_INT)
     return memrefs_conflict_p (xsize, x, ysize, y0, c + ((y1)->fld[0].rtwint));



   x = find_symbolic_term (x);
   if (x == 0)
     return 1;
   y = find_symbolic_term (y);
   if (y == 0)
     return 1;
   return rtx_equal_for_memref_p (x, y);
 }
      else if (((x1)->code) == CONST_INT)
 return memrefs_conflict_p (xsize, x0, ysize, y, c - ((x1)->fld[0].rtwint));
    }
  else if (((y)->code) == PLUS)
    {


      rtx y0 = ((y)->fld[0].rtx);
      rtx y1 = ((y)->fld[1].rtx);

      if (((y1)->code) == CONST_INT)
 return memrefs_conflict_p (xsize, x, ysize, y0, c + ((y1)->fld[0].rtwint));
      else
 return 1;
    }

  if (((x)->code) == ((y)->code))
    switch (((x)->code))
      {
      case MULT:
 {



   rtx x0, y0;
   rtx x1 = canon_rtx (((x)->fld[1].rtx));
   rtx y1 = canon_rtx (((y)->fld[1].rtx));
   if (! rtx_equal_for_memref_p (x1, y1))
     return 1;
   x0 = canon_rtx (((x)->fld[0].rtx));
   y0 = canon_rtx (((y)->fld[0].rtx));
   if (rtx_equal_for_memref_p (x0, y0))
     return (xsize == 0 || ysize == 0
      || (c >= 0 && xsize > c) || (c < 0 && ysize+c > 0));


   if (((x1)->code) != CONST_INT)
     return 1;
   xsize /= ((x1)->fld[0].rtwint);
   ysize /= ((x1)->fld[0].rtwint);
   c /= ((x1)->fld[0].rtwint);
   return memrefs_conflict_p (xsize, x0, ysize, y0, c);
 }
      }

  if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
    {
      if (((x)->code) == CONST_INT && ((y)->code) == CONST_INT)
 {
   c += (((y)->fld[0].rtwint) - ((x)->fld[0].rtwint));
   return (xsize == 0 || ysize == 0
    || (c >= 0 && xsize > c) || (c < 0 && ysize+c > 0));
 }

      if (((x)->code) == CONST)
 {
   if (((y)->code) == CONST)
     return memrefs_conflict_p (xsize, canon_rtx (((x)->fld[0].rtx)),
           ysize, canon_rtx (((y)->fld[0].rtx)), c);
   else
     return memrefs_conflict_p (xsize, canon_rtx (((x)->fld[0].rtx)),
           ysize, y, c);
 }
      if (((y)->code) == CONST)
 return memrefs_conflict_p (xsize, x, ysize,
       canon_rtx (((y)->fld[0].rtx)), c);

      if ((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == CONST_DOUBLE || ((y)->code) == CONST || ((y)->code) == HIGH))
 return (rtx_equal_for_memref_p (x, y)
  && (xsize == 0 || ysize == 0
      || (c >= 0 && xsize > c) || (c < 0 && ysize+c > 0)));

      return 1;
    }
  return 1;
}
int
read_dependence(rtx mem, rtx x) asm("_read_dependence");
int
read_dependence(rtx mem, rtx x)
{
  return ((x)->volatil) && ((mem)->volatil);
}



int
true_dependence(rtx mem, rtx x) asm("_true_dependence");
int
true_dependence(rtx mem, rtx x)
{







  if (((x)->unchanging) && ! ((mem)->unchanging))
    return 0;

  return ((((x)->volatil) && ((mem)->volatil))
   || (memrefs_conflict_p (((mode_size[(int)(((mem)->mode))])), ((mem)->fld[0].rtx),
      ((mode_size[(int)(((x)->mode))])), ((x)->fld[0].rtx), 0)
       && ! (((mem)->in_struct) && rtx_addr_varies_p (mem)
      && ((mem)->mode) != QImode
      && ! ((x)->in_struct) && ! rtx_addr_varies_p (x))
       && ! (((x)->in_struct) && rtx_addr_varies_p (x)
      && ((x)->mode) != QImode
      && ! ((mem)->in_struct) && ! rtx_addr_varies_p (mem))));
}



int
anti_dependence(rtx mem, rtx x) asm("_anti_dependence");
int
anti_dependence(rtx mem, rtx x)
{



  if (((mem)->unchanging))
    return 0;

  return ((((x)->volatil) && ((mem)->volatil))
   || (memrefs_conflict_p (((mode_size[(int)(((mem)->mode))])), ((mem)->fld[0].rtx),
      ((mode_size[(int)(((x)->mode))])), ((x)->fld[0].rtx), 0)
       && ! (((mem)->in_struct) && rtx_addr_varies_p (mem)
      && ((mem)->mode) != QImode
      && ! ((x)->in_struct) && ! rtx_addr_varies_p (x))
       && ! (((x)->in_struct) && rtx_addr_varies_p (x)
      && ((x)->mode) != QImode
      && ! ((mem)->in_struct) && ! rtx_addr_varies_p (mem))));
}



int
output_dependence(rtx mem, rtx x) asm("_output_dependence");
int
output_dependence(rtx mem, rtx x)
{
  return ((((x)->volatil) && ((mem)->volatil))
   || (memrefs_conflict_p (((mode_size[(int)(((mem)->mode))])), ((mem)->fld[0].rtx),
      ((mode_size[(int)(((x)->mode))])), ((x)->fld[0].rtx), 0)
       && ! (((mem)->in_struct) && rtx_addr_varies_p (mem)
      && ((mem)->mode) != QImode
      && ! ((x)->in_struct) && ! rtx_addr_varies_p (x))
       && ! (((x)->in_struct) && rtx_addr_varies_p (x)
      && ((x)->mode) != QImode
      && ! ((mem)->in_struct) && ! rtx_addr_varies_p (mem))));
}







static void
add_dependence(rtx insn, rtx elem, n64_enum_reg_note dep_type) asm("_add_dependence");
static void
add_dependence(rtx insn, rtx elem, n64_enum_reg_note dep_type)
{
  rtx link, next;


  if (insn == elem)
    return;







  next = ((elem)->fld[2].rtx);






  if (next && ((next)->in_struct))
    {






      while (((next)->fld[2].rtx) && ((((next)->fld[2].rtx))->in_struct)
      && ((((next)->fld[2].rtx))->code) != CODE_LABEL)
 next = ((next)->fld[2].rtx);


      if (insn == next)
 return;



      elem = next;
    }


  for (link = ((insn)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
    if (((link)->fld[0].rtx) == elem)
      {


 if ((int) dep_type < (int) ((n64_enum_reg_note) ((link)->mode)))
   ((link)->mode = ((n64_enum_machine_mode) (dep_type)));
 return;
      }


  link = rtx_alloc (INSN_LIST);

  ((link)->mode = ((n64_enum_machine_mode) (dep_type)));
  ((link)->fld[0].rtx) = elem;
  ((link)->fld[1].rtx) = ((insn)->fld[5].rtx);
  ((insn)->fld[5].rtx) = link;
}




static void
remove_dependence(rtx insn, rtx elem) asm("_remove_dependence");
static void
remove_dependence(rtx insn, rtx elem)
{
  rtx prev, link;
  int found = 0;

  for (prev = 0, link = ((insn)->fld[5].rtx); link;
       prev = link, link = ((link)->fld[1].rtx))
    {
      if (((link)->fld[0].rtx) == elem)
 {
   if (prev)
     ((prev)->fld[1].rtx) = ((link)->fld[1].rtx);
   else
     ((insn)->fld[5].rtx) = ((link)->fld[1].rtx);
   found = 1;
 }
    }

  if (! found)
    abort ();
  return;
}
static rtx pending_read_insns;


static rtx pending_read_mems;


static rtx pending_write_insns;


static rtx pending_write_mems;






static int pending_lists_length;



static rtx unused_insn_list;



static rtx unused_expr_list;
static rtx last_pending_memory_flush;




static rtx last_function_call;






static rtx sched_before_next_call;





static rtx last_scheduled_insn;
 static rtx
find_insn_list(rtx insn, rtx list) asm("_find_insn_list");
 static rtx
find_insn_list(rtx insn, rtx list)
{
  while (list)
    {
      if (((list)->fld[0].rtx) == insn)
 return list;
      list = ((list)->fld[1].rtx);
    }
  return 0;
}







 static int
insn_unit(rtx insn) asm("_insn_unit");
 static int
insn_unit(rtx insn)
{
  register int unit = insn_units[((insn)->fld[0].rtint)];

  if (unit == 0)
    {
      recog_memoized (insn);




      if (((insn)->fld[4].rtint) < 0)
 unit = -1;
      else
 {
   unit = function_units_used (insn);

   if (unit >= 0) unit++;
 }


      if (5 < 16
   || unit >= 0
   || (~unit & ((1 << (16 - 1)) - 1)) == 0)
      insn_units[((insn)->fld[0].rtint)] = unit;
    }
  return (unit > 0 ? unit - 1 : unit);
}






 static unsigned int
blockage_range(int unit, rtx insn) asm("_blockage_range");
 static unsigned int
blockage_range(int unit, rtx insn)
{
  unsigned int blockage = insn_blockage[((insn)->fld[0].rtint)];
  unsigned int range;

  if (((blockage) >> (2 * 8)) != unit + 1)
    {
      range = function_units[unit].blockage_range_function (insn);


      if (32 >= 5 + 2 * 8)
 insn_blockage[((insn)->fld[0].rtint)] = ((((unit + 1) << 5) << 8 | ((range) >> (32 / 2))) << 8 | ((range) & ((1 << (32 / 2)) - 1)));
    }
  else
    range = (((((blockage) >> 8) & ((1 << 8) - 1)) << (32 / 2)) | (blockage) & ((1 << 8) - 1));

  return range;
}




static rtx unit_last_insn[5 * 1];



static int unit_tick[5 * 1];



static int unit_n_insns[5];



static void
clear_units(void) asm("_clear_units");
static void
clear_units(void)
{
  memset ((char *) unit_last_insn,0,sizeof (unit_last_insn));
  memset ((char *) unit_tick,0,sizeof (unit_tick));
  memset ((char *) unit_n_insns,0,sizeof (unit_n_insns));
}



 static void
prepare_unit(int unit) asm("_prepare_unit");
 static void
prepare_unit(int unit)
{
  int i;

  if (unit >= 0)
    unit_n_insns[unit]++;
  else
    for (i = 0, unit = ~unit; unit; i++, unit >>= 1)
      if ((unit & 1) != 0)
 prepare_unit (i);
}





 static int
actual_hazard_this_instance(int unit, int instance, rtx insn, int clock, int cost) asm("_actual_hazard_this_instance");
 static int
actual_hazard_this_instance(int unit, int instance, rtx insn, int clock, int cost)
{
  int tick = unit_tick[instance];

  if (tick - clock > cost)
    {
      if (function_units[unit].blockage_range_function)
 {
   if (function_units[unit].blockage_function)
     tick += (function_units[unit].blockage_function
       (insn, unit_last_insn[instance])
       - function_units[unit].max_blockage);
   else
     tick += ((int) ((blockage_range (unit, insn)) & ((1 << (32 / 2)) - 1))
       - function_units[unit].max_blockage);
 }
      if (tick - clock > cost)
 cost = tick - clock;
    }
  return cost;
}




 static void
schedule_unit(int unit, rtx insn, int clock) asm("_schedule_unit");
 static void
schedule_unit(int unit, rtx insn, int clock)
{
  int i;

  if (unit >= 0)
    {
      int instance = unit;
      unit_last_insn[instance] = insn;
      unit_tick[instance] = (clock + function_units[unit].max_blockage);
    }
  else
    for (i = 0, unit = ~unit; unit; i++, unit >>= 1)
      if ((unit & 1) != 0)
 schedule_unit (i, insn, clock);
}




 static int
actual_hazard(int unit, rtx insn, int clock, int cost) asm("_actual_hazard");
 static int
actual_hazard(int unit, rtx insn, int clock, int cost)
{
  int i;

  if (unit >= 0)
    {

      int instance = unit;
      int best_cost = actual_hazard_this_instance (unit, instance, insn,
         clock, cost);
      int this_cost;
      cost = ((cost) > (best_cost) ? (cost) : (best_cost));
    }
  else
    for (i = 0, unit = ~unit; unit; i++, unit >>= 1)
      if ((unit & 1) != 0)
 cost = actual_hazard (i, insn, clock, cost);

  return cost;
}
 static int
potential_hazard(int unit, rtx insn, int cost) asm("_potential_hazard");
 static int
potential_hazard(int unit, rtx insn, int cost)
{
  int i, ncost;
  unsigned int minb, maxb;

  if (unit >= 0)
    {
      minb = maxb = function_units[unit].max_blockage;
      if (maxb > 1)
 {
   if (function_units[unit].blockage_range_function)
     {
       maxb = minb = blockage_range (unit, insn);
       maxb = ((maxb) & ((1 << (32 / 2)) - 1));
       minb = ((minb) >> (32 / 2));
     }

   if (maxb > 1)
     {




       ncost = minb * 0x40 + maxb;
       ncost *= (unit_n_insns[unit] - 1) * 0x1000 + unit;
       if (ncost > cost)
  cost = ncost;
     }
 }
    }
  else
    for (i = 0, unit = ~unit; unit; i++, unit >>= 1)
      if ((unit & 1) != 0)
 cost = potential_hazard (i, insn, cost);

  return cost;
}





 static int
insn_cost(rtx insn, rtx link, rtx used) asm("_insn_cost");
 static int
insn_cost(rtx insn, rtx link, rtx used)
{
  register int cost = insn_costs[((insn)->fld[0].rtint)];

  if (cost == 0)
    {
      recog_memoized (insn);




      if (((insn)->fld[4].rtint) < 0)
 {
   insn_costs[((insn)->fld[0].rtint)] = 1;
   return 1;
 }
      else
 {
   cost = result_ready_cost (insn);

   if (cost < 1)
     cost = 1;

   insn_costs[((insn)->fld[0].rtint)] = cost;
 }
    }




  recog_memoized (used);
  if (((used)->fld[4].rtint) < 0)
    ((link)->call) = 1;







  if (((link)->call))
    cost = 1;

  else if (! ((link)->jump))
    {
      int ncost = cost;

      if (((n64_enum_reg_note) ((link)->mode)) != 0) (ncost) = 0;;
      if (ncost <= 1)
 ((link)->call) = ncost = 1;
      if (cost == ncost)
 ((link)->jump) = 1;
      cost = ncost;
    }

  return cost;
}



static int
priority(rtx insn) asm("_priority");
static int
priority(rtx insn)
{
  if (insn && (rtx_class[(int)(((insn)->code))]) == 'i')
    {
      int prev_priority;
      int max_priority;
      int this_priority = (insn_priority[((insn)->fld[0].rtint)]);
      rtx prev;

      if (this_priority > 0)
 return this_priority;

      max_priority = 1;


      if (((insn)->in_struct))
 {
   prev = insn;
   while (((prev)->in_struct))
     {
       prev = ((prev)->fld[1].rtx);
       (insn_ref_count[((prev)->fld[0].rtint)]) += 1;
     }
 }

      for (prev = ((insn)->fld[5].rtx); prev; prev = ((prev)->fld[1].rtx))
 {
   rtx x = ((prev)->fld[0].rtx);






   if (((x)->code) == NOTE || ((x)->volatil))
     {
       remove_dependence (insn, x);
       continue;
     }


   ((prev)->call) = 0;

   ((prev)->jump) = 0;
   prev_priority = priority (x) + insn_cost (x, prev, insn) - 1;

   if (prev_priority > max_priority)
     max_priority = prev_priority;
   (insn_ref_count[((x)->fld[0].rtint)]) += 1;
 }

      prepare_unit (insn_unit (insn));
      (insn_priority[((insn)->fld[0].rtint)]) = max_priority;
      return (insn_priority[((insn)->fld[0].rtint)]);
    }
  return 0;
}




static void
free_pending_lists(void) asm("_free_pending_lists");
static void
free_pending_lists(void)
{
  register rtx link, prev_link;

  if (pending_read_insns)
    {
      prev_link = pending_read_insns;
      link = ((prev_link)->fld[1].rtx);

      while (link)
 {
   prev_link = link;
   link = ((link)->fld[1].rtx);
 }

      ((prev_link)->fld[1].rtx) = unused_insn_list;
      unused_insn_list = pending_read_insns;
      pending_read_insns = 0;
    }

  if (pending_write_insns)
    {
      prev_link = pending_write_insns;
      link = ((prev_link)->fld[1].rtx);

      while (link)
 {
   prev_link = link;
   link = ((link)->fld[1].rtx);
 }

      ((prev_link)->fld[1].rtx) = unused_insn_list;
      unused_insn_list = pending_write_insns;
      pending_write_insns = 0;
    }

  if (pending_read_mems)
    {
      prev_link = pending_read_mems;
      link = ((prev_link)->fld[1].rtx);

      while (link)
 {
   prev_link = link;
   link = ((link)->fld[1].rtx);
 }

      ((prev_link)->fld[1].rtx) = unused_expr_list;
      unused_expr_list = pending_read_mems;
      pending_read_mems = 0;
    }

  if (pending_write_mems)
    {
      prev_link = pending_write_mems;
      link = ((prev_link)->fld[1].rtx);

      while (link)
 {
   prev_link = link;
   link = ((link)->fld[1].rtx);
 }

      ((prev_link)->fld[1].rtx) = unused_expr_list;
      unused_expr_list = pending_write_mems;
      pending_write_mems = 0;
    }
}





static void
add_insn_mem_dependence(rtx *insn_list, rtx *mem_list, rtx insn, rtx mem) asm("_add_insn_mem_dependence");
static void
add_insn_mem_dependence(rtx *insn_list, rtx *mem_list, rtx insn, rtx mem)
{
  register rtx link;

  if (unused_insn_list)
    {
      link = unused_insn_list;
      unused_insn_list = ((link)->fld[1].rtx);
    }
  else
    link = rtx_alloc (INSN_LIST);
  ((link)->fld[0].rtx) = insn;
  ((link)->fld[1].rtx) = *insn_list;
  *insn_list = link;

  if (unused_expr_list)
    {
      link = unused_expr_list;
      unused_expr_list = ((link)->fld[1].rtx);
    }
  else
    link = rtx_alloc (EXPR_LIST);
  ((link)->fld[0].rtx) = mem;
  ((link)->fld[1].rtx) = *mem_list;
  *mem_list = link;

  pending_lists_length++;
}




static void
flush_pending_lists(rtx insn) asm("_flush_pending_lists");
static void
flush_pending_lists(rtx insn)
{
  rtx link;

  while (pending_read_insns)
    {
      add_dependence (insn, ((pending_read_insns)->fld[0].rtx), REG_DEP_ANTI);

      link = pending_read_insns;
      pending_read_insns = ((pending_read_insns)->fld[1].rtx);
      ((link)->fld[1].rtx) = unused_insn_list;
      unused_insn_list = link;

      link = pending_read_mems;
      pending_read_mems = ((pending_read_mems)->fld[1].rtx);
      ((link)->fld[1].rtx) = unused_expr_list;
      unused_expr_list = link;
    }
  while (pending_write_insns)
    {
      add_dependence (insn, ((pending_write_insns)->fld[0].rtx), REG_DEP_ANTI);

      link = pending_write_insns;
      pending_write_insns = ((pending_write_insns)->fld[1].rtx);
      ((link)->fld[1].rtx) = unused_insn_list;
      unused_insn_list = link;

      link = pending_write_mems;
      pending_write_mems = ((pending_write_mems)->fld[1].rtx);
      ((link)->fld[1].rtx) = unused_expr_list;
      unused_expr_list = link;
    }
  pending_lists_length = 0;

  if (last_pending_memory_flush)
    add_dependence (insn, last_pending_memory_flush, REG_DEP_ANTI);

  last_pending_memory_flush = insn;
}




static void
sched_analyze_1(rtx x, rtx insn) asm("_sched_analyze_1");
static void
sched_analyze_1(rtx x, rtx insn)
{
  register int regno;
  register rtx dest = ((x)->fld[0].rtx);

  if (dest == 0)
    return;

  while (((dest)->code) == STRICT_LOW_PART || ((dest)->code) == SUBREG
  || ((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SIGN_EXTRACT)
    {
      if (((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SIGN_EXTRACT)
 {

   sched_analyze_2 (((dest)->fld[1].rtx), insn);
   sched_analyze_2 (((dest)->fld[2].rtx), insn);
 }
      dest = ((dest)->fld[0].rtx);
    }

  if (((dest)->code) == REG)
    {
      register int i;

      regno = ((dest)->fld[0].rtint);



      if (regno < 68)
 {
   i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   while (--i >= 0)
     {
       rtx u;

       for (u = reg_last_uses[regno+i]; u; u = ((u)->fld[1].rtx))
  add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
       reg_last_uses[regno + i] = 0;
       if (reg_last_sets[regno + i])
  add_dependence (insn, reg_last_sets[regno + i],
    REG_DEP_OUTPUT);
       reg_pending_sets[(regno + i) / 32]
  |= (unsigned int) 1 << ((regno + i) % 32);
       if ((call_used_regs[i] || global_regs[i])
    && last_function_call)

  add_dependence (insn, last_function_call, REG_DEP_ANTI);
     }
 }
      else
 {
   rtx u;

   for (u = reg_last_uses[regno]; u; u = ((u)->fld[1].rtx))
     add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
   reg_last_uses[regno] = 0;
   if (reg_last_sets[regno])
     add_dependence (insn, reg_last_sets[regno], REG_DEP_OUTPUT);
   reg_pending_sets[regno / 32]
     |= (unsigned int) 1 << (regno % 32);




   if (! reload_completed
       && reg_known_equiv_p[regno]
       && ((reg_known_value[regno])->code) == MEM)
     sched_analyze_2 (((reg_known_value[regno])->fld[0].rtx), insn);



   if (reg_n_calls_crossed[regno] == 0 && last_function_call)
     add_dependence (insn, last_function_call, REG_DEP_ANTI);
 }
    }
  else if (((dest)->code) == MEM)
    {


      if (pending_lists_length > 32)
 {






   flush_pending_lists (insn);
 }
      else
 {
   rtx pending, pending_mem;

   pending = pending_read_insns;
   pending_mem = pending_read_mems;
   while (pending)
     {

       if (! find_insn_list (((pending)->fld[0].rtx), ((insn)->fld[5].rtx)))
  if (anti_dependence (((pending_mem)->fld[0].rtx), dest))
    add_dependence (insn, ((pending)->fld[0].rtx), REG_DEP_ANTI);

       pending = ((pending)->fld[1].rtx);
       pending_mem = ((pending_mem)->fld[1].rtx);
     }

   pending = pending_write_insns;
   pending_mem = pending_write_mems;
   while (pending)
     {

       if (! find_insn_list (((pending)->fld[0].rtx), ((insn)->fld[5].rtx)))
  if (output_dependence (((pending_mem)->fld[0].rtx), dest))
    add_dependence (insn, ((pending)->fld[0].rtx), REG_DEP_OUTPUT);

       pending = ((pending)->fld[1].rtx);
       pending_mem = ((pending_mem)->fld[1].rtx);
     }

   if (last_pending_memory_flush)
     add_dependence (insn, last_pending_memory_flush, REG_DEP_ANTI);

   add_insn_mem_dependence (&pending_write_insns, &pending_write_mems,
       insn, dest);
 }
      sched_analyze_2 (((dest)->fld[0].rtx), insn);
    }


  if (((x)->code) == SET)
    sched_analyze_2 (((x)->fld[1].rtx), insn);
}



static void
sched_analyze_2(rtx x, rtx insn) asm("_sched_analyze_2");
static void
sched_analyze_2(rtx x, rtx insn)
{
  register int i;
  register int j;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0)
    return;

  code = ((x)->code);

  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CONST:
    case LABEL_REF:



      return;
    case REG:
      {
 int regno = ((x)->fld[0].rtint);
 if (regno < 68)
   {
     int i;

     i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
     while (--i >= 0)
       {
  reg_last_uses[regno + i]
    = gen_rtx (INSN_LIST, VOIDmode,
        insn, reg_last_uses[regno + i]);
  if (reg_last_sets[regno + i])
    add_dependence (insn, reg_last_sets[regno + i], 0);
  if ((call_used_regs[regno + i] || global_regs[regno + i])
      && last_function_call)

    add_dependence (insn, last_function_call, REG_DEP_ANTI);
       }
   }
 else
   {
     reg_last_uses[regno]
       = gen_rtx (INSN_LIST, VOIDmode, insn, reg_last_uses[regno]);
     if (reg_last_sets[regno])
       add_dependence (insn, reg_last_sets[regno], 0);




     if (! reload_completed
  && reg_known_equiv_p[regno]
  && ((reg_known_value[regno])->code) == MEM)
       sched_analyze_2 (((reg_known_value[regno])->fld[0].rtx), insn);




     if (reg_n_calls_crossed[regno] == 0)
       add_dependence (sched_before_next_call, insn, REG_DEP_ANTI);
   }
 return;
      }

    case MEM:
      {


 rtx pending, pending_mem;

 pending = pending_read_insns;
 pending_mem = pending_read_mems;
 while (pending)
   {

     if (! find_insn_list (((pending)->fld[0].rtx), ((insn)->fld[5].rtx)))
       if (read_dependence (((pending_mem)->fld[0].rtx), x))
  add_dependence (insn, ((pending)->fld[0].rtx), REG_DEP_ANTI);

     pending = ((pending)->fld[1].rtx);
     pending_mem = ((pending_mem)->fld[1].rtx);
   }

 pending = pending_write_insns;
 pending_mem = pending_write_mems;
 while (pending)
   {

     if (! find_insn_list (((pending)->fld[0].rtx), ((insn)->fld[5].rtx)))
       if (true_dependence (((pending_mem)->fld[0].rtx), x))
  add_dependence (insn, ((pending)->fld[0].rtx), 0);

     pending = ((pending)->fld[1].rtx);
     pending_mem = ((pending_mem)->fld[1].rtx);
   }
 if (last_pending_memory_flush)
   add_dependence (insn, last_pending_memory_flush, REG_DEP_ANTI);



 add_insn_mem_dependence (&pending_read_insns, &pending_read_mems,
     insn, x);


 sched_analyze_2 (((x)->fld[0].rtx), insn);
 return;
      }

    case ASM_OPERANDS:
    case ASM_INPUT:
    case UNSPEC_VOLATILE:
    case TRAP_IF:
      {
 rtx u;
 if (code != ASM_OPERANDS || ((x)->volatil))
   {
     int max_reg = max_reg_num ();
     for (i = 0; i < max_reg; i++)
       {
  for (u = reg_last_uses[i]; u; u = ((u)->fld[1].rtx))
    add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
  reg_last_uses[i] = 0;
  if (reg_last_sets[i])
    add_dependence (insn, reg_last_sets[i], 0);
       }
     reg_pending_sets_all = 1;

     flush_pending_lists (insn);
   }






 if (code == ASM_OPERANDS)
   {
     for (j = 0; j < (((x))->fld[3].rtvec->num_elem); j++)
       sched_analyze_2 ((((x))->fld[3].rtvec->elem[(j)].rtx), insn);
     return;
   }
 break;
      }

    case PRE_DEC:
    case POST_DEC:
    case PRE_INC:
    case POST_INC:






      sched_analyze_2 (((x)->fld[0].rtx), insn);
      sched_analyze_1 (x, insn);
      return;
    }


  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 sched_analyze_2 (((x)->fld[i].rtx), insn);
      else if (fmt[i] == 'E')
 for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
   sched_analyze_2 (((x)->fld[i].rtvec->elem[j].rtx), insn);
    }
}



static void
sched_analyze_insn(rtx x, rtx insn, rtx loop_notes) asm("_sched_analyze_insn");
static void
sched_analyze_insn(rtx x, rtx insn, rtx loop_notes)
{
  register n64_enum_rtx_code code = ((x)->code);
  rtx link;
  int maxreg = max_reg_num ();
  int i;

  if (code == SET || code == CLOBBER)
    sched_analyze_1 (x, insn);
  else if (code == PARALLEL)
    {
      register int i;
      for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   code = ((((x)->fld[0].rtvec->elem[i].rtx))->code);
   if (code == SET || code == CLOBBER)
     sched_analyze_1 (((x)->fld[0].rtvec->elem[i].rtx), insn);
   else
     sched_analyze_2 (((x)->fld[0].rtvec->elem[i].rtx), insn);
 }
    }
  else
    sched_analyze_2 (x, insn);


  if (((insn)->code) == CALL_INSN)
    for (link = ((insn)->fld[7].rtx); link; link = ((link)->fld[1].rtx))
      {
 if (((((link)->fld[0].rtx))->code) == CLOBBER)
   sched_analyze_1 (((link)->fld[0].rtx), insn);
 else
   sched_analyze_2 (((link)->fld[0].rtx), insn);
      }






  if (loop_notes)
    {
      int max_reg = max_reg_num ();
      rtx link;

      for (i = 0; i < max_reg; i++)
 {
   rtx u;
   for (u = reg_last_uses[i]; u; u = ((u)->fld[1].rtx))
     add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
   reg_last_uses[i] = 0;
   if (reg_last_sets[i])
     add_dependence (insn, reg_last_sets[i], 0);
 }
      reg_pending_sets_all = 1;

      flush_pending_lists (insn);

      link = loop_notes;
      while (((link)->fld[1].rtx))
 link = ((link)->fld[1].rtx);
      ((link)->fld[1].rtx) = ((insn)->fld[6].rtx);
      ((insn)->fld[6].rtx) = loop_notes;
    }
  if (reload_completed)
    {
      rtx note;

      for (note = ((insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
 if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD)
   sched_analyze_2 (((note)->fld[0].rtx), insn);
    }

  for (i = 0; i < regset_size; i++)
    {
      unsigned int sets = reg_pending_sets[i];
      if (sets)
 {
   register int bit;
   for (bit = 0; bit < 32; bit++)
     if (sets & ((unsigned int) 1 << bit))
       reg_last_sets[i * 32 + bit] = insn;
   reg_pending_sets[i] = 0;
 }
    }
  if (reg_pending_sets_all)
    {
      for (i = 0; i < maxreg; i++)
 reg_last_sets[i] = insn;
      reg_pending_sets_all = 0;
    }



  if (((insn)->code) == CALL_INSN || ((insn)->code) == JUMP_INSN)
    {
      rtx dep_insn;
      rtx prev_dep_insn;
      prev_dep_insn = insn;
      dep_insn = ((insn)->fld[1].rtx);
      while (((dep_insn)->code) == INSN
      && ((((dep_insn)->fld[3].rtx))->code) == USE
      && ((((((dep_insn)->fld[3].rtx))->fld[0].rtx))->code) == REG)
 {
   ((prev_dep_insn)->in_struct) = 1;





   for (link = ((dep_insn)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
     add_dependence (insn, ((link)->fld[0].rtx), ((n64_enum_reg_note) ((link)->mode)));

   prev_dep_insn = dep_insn;
   dep_insn = ((dep_insn)->fld[1].rtx);
 }
    }
}




static int
sched_analyze(rtx head, rtx tail) asm("_sched_analyze");
static int
sched_analyze(rtx head, rtx tail)
{
  register rtx insn;
  register int n_insns = 0;
  register rtx u;
  register int luid = 0;
  rtx loop_notes = 0;

  for (insn = head; ; insn = ((insn)->fld[2].rtx))
    {
      (insn_luid[((insn)->fld[0].rtint)]) = luid++;

      if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN)
 {
   sched_analyze_insn (((insn)->fld[3].rtx), insn, loop_notes);
   loop_notes = 0;
   n_insns += 1;
 }
      else if (((insn)->code) == CALL_INSN)
 {
   rtx x;
   register int i;
   if (((insn)->fld[2].rtx) && ((((insn)->fld[2].rtx))->code) == NOTE
       && ((((insn)->fld[2].rtx))->fld[4].rtint) == -7)
     {
       int max_reg = max_reg_num ();
       for (i = 0; i < max_reg; i++)
  {
    for (u = reg_last_uses[i]; u; u = ((u)->fld[1].rtx))
      add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
    reg_last_uses[i] = 0;
    if (reg_last_sets[i])
      add_dependence (insn, reg_last_sets[i], 0);
  }
       reg_pending_sets_all = 1;



       ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_DEAD,
       gen_rtx (CONST_INT, VOIDmode, (int) (-7)),
       ((insn)->fld[6].rtx));
     }
   else
     {
       for (i = 0; i < 68; i++)
  if (call_used_regs[i] || global_regs[i])
    {
      for (u = reg_last_uses[i]; u; u = ((u)->fld[1].rtx))
        add_dependence (insn, ((u)->fld[0].rtx), REG_DEP_ANTI);
      reg_last_uses[i] = 0;
      if (reg_last_sets[i])
        add_dependence (insn, reg_last_sets[i], REG_DEP_ANTI);
      reg_pending_sets[i / 32]
        |= (unsigned int) 1 << (i % 32);
    }
     }



   x = ((sched_before_next_call)->fld[5].rtx);
   while (x)
     {
       add_dependence (insn, ((x)->fld[0].rtx), REG_DEP_ANTI);
       x = ((x)->fld[1].rtx);
     }
   ((sched_before_next_call)->fld[5].rtx) = 0;

   sched_analyze_insn (((insn)->fld[3].rtx), insn, loop_notes);
   loop_notes = 0;



   if (! ((insn)->unchanging))
     {



       flush_pending_lists (insn);
     }



   last_function_call = insn;
   n_insns += 1;
 }
      else if (((insn)->code) == NOTE
        && (((insn)->fld[4].rtint) == -4
     || ((insn)->fld[4].rtint) == -5))
 loop_notes = gen_rtx (EXPR_LIST, REG_DEAD,
         gen_rtx (CONST_INT, VOIDmode, (int) (((insn)->fld[4].rtint))), loop_notes);

      if (insn == tail)
 return n_insns;
    }
}






static void
sched_note_set(int b, rtx x, int death) asm("_sched_note_set");
static void
sched_note_set(int b, rtx x, int death)
{
  register int regno;
  register rtx reg = ((x)->fld[0].rtx);
  int subreg_p = 0;

  if (reg == 0)
    return;

  while (((reg)->code) == SUBREG || ((reg)->code) == STRICT_LOW_PART
  || ((reg)->code) == SIGN_EXTRACT || ((reg)->code) == ZERO_EXTRACT)
    {




      if (((reg)->code) != SUBREG
   || ((mode_size[(int) ((((reg)->fld[0].rtx))->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) > ((mode_size[(int) ((reg)->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)))
 subreg_p = 1;

      reg = ((reg)->fld[0].rtx);
    }

  if (((reg)->code) != REG)
    return;




  regno = ((reg)->fld[0].rtint);
  if (regno >= 68 || ! global_regs[regno])
    {
      register int offset = regno / 32;
      register unsigned int bit
 = (unsigned int) 1 << (regno % 32);

      if (death)
 {


   if (subreg_p)
     return;


   if (regno < 68)
     {
       int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       while (--j >= 0)
  {
    offset = (regno + j) / 32;
    bit = (unsigned int) 1 << ((regno + j) % 32);

    bb_live_regs[offset] &= ~bit;
    bb_dead_regs[offset] |= bit;
  }
     }
   else
     {
       bb_live_regs[offset] &= ~bit;
       bb_dead_regs[offset] |= bit;
     }
 }
      else
 {

   if (regno < 68)
     {
       int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       while (--j >= 0)
  {
    offset = (regno + j) / 32;
    bit = (unsigned int) 1 << ((regno + j) % 32);

    bb_live_regs[offset] |= bit;
    bb_dead_regs[offset] &= ~bit;
  }
     }
   else
     {
       bb_live_regs[offset] |= bit;
       bb_dead_regs[offset] &= ~bit;
     }
 }
    }
}
static int
rank_for_schedule(rtx *x, rtx *y) asm("_rank_for_schedule");
static int
rank_for_schedule(rtx *x, rtx *y)
{
  rtx tmp = *y;
  rtx tmp2 = *x;
  rtx link;
  int tmp_class, tmp2_class;
  int value;


  if (value = (insn_priority[((tmp)->fld[0].rtint)]) - (insn_priority[((tmp2)->fld[0].rtint)]))
    return value;

  if (last_scheduled_insn)
    {





      link = find_insn_list (tmp, ((last_scheduled_insn)->fld[5].rtx));
      if (link == 0 || insn_cost (tmp, link, last_scheduled_insn) == 1)
 tmp_class = 3;
      else if (((n64_enum_reg_note) ((link)->mode)) == 0)
 tmp_class = 1;
      else
 tmp_class = 2;

      link = find_insn_list (tmp2, ((last_scheduled_insn)->fld[5].rtx));
      if (link == 0 || insn_cost (tmp2, link, last_scheduled_insn) == 1)
 tmp2_class = 3;
      else if (((n64_enum_reg_note) ((link)->mode)) == 0)
 tmp2_class = 1;
      else
 tmp2_class = 2;

      if (value = tmp_class - tmp2_class)
 return value;
    }




  return (insn_luid[((tmp)->fld[0].rtint)]) - (insn_luid[((tmp2)->fld[0].rtint)]);
}



 static void
swap_sort(rtx *a, int n) asm("_swap_sort");
 static void
swap_sort(rtx *a, int n)
{
  rtx insn = a[n-1];
  int i = n-2;

  while (i >= 0 && rank_for_schedule (a+i, &insn) >= 0)
    {
      a[i+1] = a[i];
      i -= 1;
    }
  a[i+1] = insn;
}

static int max_priority;




 static void
queue_insn(rtx insn, int n_cycles) asm("_queue_insn");
 static void
queue_insn(rtx insn, int n_cycles)
{
  int next_q = (((q_ptr)+n_cycles) & (128 -1));
  ((insn)->fld[2].rtx) = insn_queue[next_q];
  insn_queue[next_q] = insn;
  q_size += 1;
}




 static int
birthing_insn_p(rtx pat) asm("_birthing_insn_p");
 static int
birthing_insn_p(rtx pat)
{
  int j;

  if (reload_completed == 1)
    return 0;

  if (((pat)->code) == SET
      && ((((pat)->fld[0].rtx))->code) == REG)
    {
      rtx dest = ((pat)->fld[0].rtx);
      int i = ((dest)->fld[0].rtint);
      int offset = i / 32;
      unsigned int bit = (unsigned int) 1 << (i % 32);





      if (bb_live_regs[offset] & bit)
 return (reg_n_sets[i] == 1);

      return 0;
    }
  if (((pat)->code) == PARALLEL)
    {
      for (j = 0; j < ((pat)->fld[0].rtvec->num_elem); j++)
 if (birthing_insn_p (((pat)->fld[0].rtvec->elem[j].rtx)))
   return 1;
    }
  return 0;
}




 static void
adjust_priority(rtx prev) asm("_adjust_priority");
 static void
adjust_priority(rtx prev)
{


  if (reload_completed == 0)
    {
      rtx note;
      int n_deaths = 0;



      for (note = ((prev)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
 if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD)
   n_deaths += 1;




      switch (n_deaths)
 {
 default:
   (insn_priority[((prev)->fld[0].rtint)]) >>= 3;
   break;
 case 3:
   (insn_priority[((prev)->fld[0].rtint)]) >>= 2;
   break;
 case 2:
 case 1:
   (insn_priority[((prev)->fld[0].rtint)]) >>= 1;
   break;
 case 0:
   if (birthing_insn_p (((prev)->fld[3].rtx)))
     {
       int max = max_priority;

       if (max > (insn_priority[((prev)->fld[0].rtint)]))
  (insn_priority[((prev)->fld[0].rtint)]) = max;
     }
   break;
 }
    }
}






static int
schedule_insn(rtx insn, rtx *ready, int n_ready, int clock) asm("_schedule_insn");
static int
schedule_insn(rtx insn, rtx *ready, int n_ready, int clock)
{
  rtx link;
  int new_ready = n_ready;

  if (112 > 1)
    schedule_unit (insn_unit (insn), insn, clock);

  if (((insn)->fld[5].rtx) == 0)
    return n_ready;


  if (n_ready > 0)
    max_priority = (((insn_priority[((ready[0])->fld[0].rtint)])) > ((insn_priority[((insn)->fld[0].rtint)])) ? ((insn_priority[((ready[0])->fld[0].rtint)])) : ((insn_priority[((insn)->fld[0].rtint)])));
  else
    max_priority = (insn_priority[((insn)->fld[0].rtint)]);

  for (link = ((insn)->fld[5].rtx); link != 0; link = ((link)->fld[1].rtx))
    {
      rtx prev = ((link)->fld[0].rtx);
      int cost = insn_cost (prev, link, insn);

      if (((insn_ref_count[((prev)->fld[0].rtint)]) -= 1) != 0)
 {



   if (cost > 1)
     (insn_tick[((prev)->fld[0].rtint)]) = (((insn_tick[((prev)->fld[0].rtint)])) > (clock + cost) ? ((insn_tick[((prev)->fld[0].rtint)])) : (clock + cost));
 }
      else
 {


   if ((insn_tick[((prev)->fld[0].rtint)]) - clock > cost)
     cost = (insn_tick[((prev)->fld[0].rtint)]) - clock;



   adjust_priority (prev);
   if (cost <= 1)
     ready[new_ready++] = prev;
   else
     queue_insn (prev, cost);
 }
    }

  return new_ready;
}





static int
schedule_select(rtx *ready, int n_ready, int clock, FILE *file) asm("_schedule_select");
static int
schedule_select(rtx *ready, int n_ready, int clock, FILE *file)
{
  int pri = (insn_priority[((ready[0])->fld[0].rtint)]);
  int i, j, k, q, cost, best_cost, best_insn = 0, new_ready = n_ready;
  rtx insn;





  for (i = 0; i < n_ready; i = j)
    {
      int opri = pri;
      for (j = i + 1; j < n_ready; j++)
 if ((pri = (insn_priority[((ready[j])->fld[0].rtint)])) != opri)
   break;


      for (k = i, q = 0; k < j; k++)
 {
   insn = ready[k];
   if ((cost = actual_hazard (insn_unit (insn), insn, clock, 0)) != 0)
     {
       q++;
       ready[k] = 0;
       queue_insn (insn, cost);
       if (file)
  fprintf (file, "\n;; blocking insn %d for %d cycles",
    ((insn)->fld[0].rtint), cost);
     }
 }
      new_ready -= q;


      if (j - i - q == 0)
 continue;



      else if (j - i - q > 1)
 {
   best_cost = -1;
   for (k = i; k < j; k++)
     {
       if ((insn = ready[k]) == 0)
  continue;
       if ((cost = potential_hazard (insn_unit (insn), insn, 0))
    > best_cost)
  {
    best_cost = cost;
    best_insn = k;
  }
     }
 }

      break;
    }


  if (best_insn != 0)
    {
      if (file)
 {
   fprintf (file, ", now");
   for (i = 0; i < n_ready; i++)
     if (ready[i])
       fprintf (file, " %d", ((ready[i])->fld[0].rtint));
   fprintf (file, "\n;; insn %d has a greater potential hazard",
     ((ready[best_insn])->fld[0].rtint));
 }
      for (i = best_insn; i > 0; i--)
 {
   insn = ready[i-1];
   ready[i-1] = ready[i];
   ready[i] = insn;
 }
    }


  if (new_ready < n_ready)
    for (i = j = 0; i < n_ready; i++)
      if (ready[i])
 ready[j++] = ready[i];

  return new_ready;
}




static void
create_reg_dead_note(rtx reg, rtx insn) asm("_create_reg_dead_note");
static void
create_reg_dead_note(rtx reg, rtx insn)
{
  rtx link;
  if (dead_notes == 0)
    {

      abort ();




    }
  else
    {

      int regs_killed = (((reg)->fld[0].rtint) >= 68 ? 1
    : (! ((unsigned) ((((reg)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))));

      int reg_note_regs;

      link = dead_notes;
      reg_note_regs = (((((link)->fld[0].rtx))->fld[0].rtint) >= 68 ? 1
         : (! ((unsigned) ((((((link)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                  );
      while (reg_note_regs < regs_killed)
 {
   link = ((link)->fld[1].rtx);
   reg_note_regs += (((((link)->fld[0].rtx))->fld[0].rtint) >= 68 ? 1
       : (! ((unsigned) ((((((link)->fld[0].rtx))->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                );
 }
      dead_notes = ((link)->fld[1].rtx);


      while (reg_note_regs > regs_killed)
 {
   rtx temp_reg, temp_link;

   temp_reg = gen_rtx (REG, word_mode, 0);
   temp_link = rtx_alloc (EXPR_LIST);
   ((temp_link)->mode = ((n64_enum_machine_mode) (REG_DEAD)));
   ((temp_link)->fld[0].rtx) = temp_reg;
   ((temp_link)->fld[1].rtx) = dead_notes;
   dead_notes = temp_link;
   reg_note_regs--;
 }
    }

  ((link)->fld[0].rtx) = reg;
  ((link)->fld[1].rtx) = ((insn)->fld[6].rtx);
  ((insn)->fld[6].rtx) = link;
}




static void
attach_deaths(rtx x, rtx insn, int set_p) asm("_attach_deaths");
static void
attach_deaths(rtx x, rtx insn, int set_p)
{
  register int i;
  register int j;
  register n64_enum_rtx_code code;
  register char *fmt;

  if (x == 0)
    return;

  code = ((x)->code);

  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST:
    case CODE_LABEL:
    case PC:
    case CC0:

      return;

    case REG:
      {





 register int regno = ((x)->fld[0].rtint);
 register int offset = regno / 32;
 register unsigned int bit
   = (unsigned int) 1 << (regno % 32);
 unsigned int all_needed = (old_live_regs[offset] & bit);
 unsigned int some_needed = (old_live_regs[offset] & bit);

 if (set_p)
   return;

 if (regno < 68)
   {
     int n;

     n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
     while (--n > 0)
       {
  some_needed |= (old_live_regs[(regno + n) / 32]
    & ((unsigned int) 1
       << ((regno + n) % 32)));
  all_needed &= (old_live_regs[(regno + n) / 32]
          & ((unsigned int) 1
      << ((regno + n) % 32)));
       }
   }
 if (regno >= 68 || ! global_regs[regno])
   {



     if (regno != (0 + 30)




  && ! (regno == 0 && fixed_regs[regno])

  && regno != (0 + 29))
       {




  if (! all_needed && ! dead_or_set_p (insn, x)
      && ! find_reg_note (insn, REG_UNUSED, x))
    {


      if (regno < 68
   && (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > 1)
        {
   int n = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   while (--n >= 0)
     some_needed |= dead_or_set_regno_p (insn, regno + n);
        }




      if (! some_needed)
        create_reg_dead_note (x, insn);
      else
        {
   int i;



   for (i = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1;
        i >= 0; i--)
     if ((old_live_regs[(regno + i) / 32]
          & ((unsigned int) 1
      << ((regno +i) % 32))) == 0
         && ! dead_or_set_regno_p (insn, regno + i))
       create_reg_dead_note (gen_rtx (REG,
          reg_raw_mode[regno + i],
          regno + i),
        insn);
        }
    }
       }

     if (regno < 68)
       {
  int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  while (--j >= 0)
    {
      offset = (regno + j) / 32;
      bit
        = (unsigned int) 1 << ((regno + j) % 32);

      bb_dead_regs[offset] &= ~bit;
      bb_live_regs[offset] |= bit;
    }
       }
     else
       {
  bb_dead_regs[offset] &= ~bit;
  bb_live_regs[offset] |= bit;
       }
   }
 return;
      }

    case MEM:

      attach_deaths (((x)->fld[0].rtx), insn, 0);
      return;

    case SUBREG:
    case STRICT_LOW_PART:


      attach_deaths (((x)->fld[0].rtx), insn, set_p);
      return;

    case ZERO_EXTRACT:
    case SIGN_EXTRACT:


      attach_deaths (((x)->fld[0].rtx), insn, set_p);
      attach_deaths (((x)->fld[1].rtx), insn, 0);
      attach_deaths (((x)->fld[2].rtx), insn, 0);
      return;

    default:

      fmt = (rtx_format[(int)(code)]);
      for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
 {
   if (fmt[i] == 'e')
     attach_deaths (((x)->fld[i].rtx), insn, 0);
   else if (fmt[i] == 'E')
     for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
       attach_deaths (((x)->fld[i].rtvec->elem[j].rtx), insn, 0);
 }
    }
}




static void
attach_deaths_insn(rtx insn) asm("_attach_deaths_insn");
static void
attach_deaths_insn(rtx insn)
{
  rtx x = ((insn)->fld[3].rtx);
  register n64_enum_rtx_code code = ((x)->code);
  rtx link;

  if (code == SET)
    {
      attach_deaths (((x)->fld[1].rtx), insn, 0);




      attach_deaths (((x)->fld[0].rtx), insn, 1);
    }
  else if (code == PARALLEL)
    {
      register int i;
      for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   code = ((((x)->fld[0].rtvec->elem[i].rtx))->code);
   if (code == SET)
     {
       attach_deaths (((((x)->fld[0].rtvec->elem[i].rtx))->fld[1].rtx), insn, 0);

       attach_deaths (((((x)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx), insn, 1);
     }


   else if (code != CLOBBER)
     attach_deaths (((x)->fld[0].rtvec->elem[i].rtx), insn, 0);
 }
    }


  else if (code == CLOBBER && ((((x)->fld[0].rtx))->code) == MEM)
    attach_deaths (((((x)->fld[0].rtx))->fld[0].rtx), insn, 0);

  else if (code != CLOBBER)
    attach_deaths (x, insn, 0);


  if (((insn)->code) == CALL_INSN)
    for (link = ((insn)->fld[7].rtx); link; link = ((link)->fld[1].rtx))
      attach_deaths (((((link)->fld[0].rtx))->fld[0].rtx), insn,
       ((((link)->fld[0].rtx))->code) == CLOBBER);
}





static rtx
unlink_notes(rtx insn, rtx tail) asm("_unlink_notes");
static rtx
unlink_notes(rtx insn, rtx tail)
{
  rtx prev = ((insn)->fld[1].rtx);

  while (insn != tail && ((insn)->code) == NOTE)
    {
      rtx next = ((insn)->fld[2].rtx);

      if (prev)
 ((prev)->fld[2].rtx) = next;
      if (next)
 ((next)->fld[1].rtx) = prev;

      if (write_symbols != NO_DEBUG && ((insn)->fld[4].rtint) > 0)

 (line_note[((insn)->fld[0].rtint)]) = insn;





      else if (((insn)->fld[4].rtint) != -7
        && ((insn)->fld[4].rtint) != -4
        && ((insn)->fld[4].rtint) != -5)
 {

   ((insn)->fld[1].rtx) = note_list;
   if (note_list)
     ((note_list)->fld[2].rtx) = insn;
   note_list = insn;
 }

      insn = next;
    }
  return insn;
}



static int
new_sometimes_live(struct n64_tag_sometimes *regs_sometimes_live, int offset, int bit, int sometimes_max) asm("_new_sometimes_live");
static int
new_sometimes_live(struct n64_tag_sometimes *regs_sometimes_live, int offset, int bit, int sometimes_max)
{
  register struct n64_tag_sometimes *p;
  register int regno = offset * 32 + bit;





  if (regno >= max_regno)
    abort ();

  p = &regs_sometimes_live[sometimes_max];
  p->offset = offset;
  p->bit = bit;
  p->live_length = 0;
  p->calls_crossed = 0;
  sometimes_max++;
  return sometimes_max;
}




static void
finish_sometimes_live(struct n64_tag_sometimes *regs_sometimes_live, int sometimes_max) asm("_finish_sometimes_live");
static void
finish_sometimes_live(struct n64_tag_sometimes *regs_sometimes_live, int sometimes_max)
{
  int i;

  for (i = 0; i < sometimes_max; i++)
    {
      register struct n64_tag_sometimes *p = &regs_sometimes_live[i];
      int regno;

      regno = p->offset * 32 + p->bit;

      sched_reg_live_length[regno] += p->live_length;
      sched_reg_n_calls_crossed[regno] += p->calls_crossed;
    }
}






static rtx
reemit_notes(rtx insn, rtx last) asm("_reemit_notes");
static rtx
reemit_notes(rtx insn, rtx last)
{
  rtx note;

  for (note = ((insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
    {
      if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
   && ((((note)->fld[0].rtx))->code) == CONST_INT)
 {
   if (((((note)->fld[0].rtx))->fld[0].rtwint) == -7)
     emit_note_after (((((note)->fld[0].rtx))->fld[0].rtwint), insn);
   else
     last = emit_note_before (((((note)->fld[0].rtx))->fld[0].rtwint), last);
   remove_note (insn, note);
 }
    }
  return last;
}





static void
schedule_block(int b, FILE *file) asm("_schedule_block");
static void
schedule_block(int b, FILE *file)
{
  rtx insn, last;
  rtx *ready, link;
  int i, j, n_ready = 0, new_ready, n_insns = 0;
  int sched_n_insns = 0;
  int clock;



  int new_needs;


  rtx head = basic_block_head[b];
  rtx tail = basic_block_end[b];




  rtx next_tail;
  rtx prev_head;


  register struct n64_tag_sometimes *regs_sometimes_live;
  int sometimes_max;

  if (file)
    fprintf (file, ";;\t -- basic block number %d from %d to %d --\n",
      b, ((basic_block_head[b])->fld[0].rtint), ((basic_block_end[b])->fld[0].rtint));

  i = max_reg_num ();
  reg_last_uses = (rtx *) 
                         __builtin_alloca((
                         i * sizeof (rtx)
                         ))
                                                  ;
  memset ((char *) reg_last_uses,0,i * sizeof (rtx));
  reg_last_sets = (rtx *) 
                         __builtin_alloca((
                         i * sizeof (rtx)
                         ))
                                                  ;
  memset ((char *) reg_last_sets,0,i * sizeof (rtx));
  reg_pending_sets = (regset) 
                             __builtin_alloca((
                             regset_bytes
                             ))
                                                  ;
  memset ((char *) reg_pending_sets,0,regset_bytes);
  reg_pending_sets_all = 0;
  clear_units ();






  if (reload_completed == 0 && b == 0)
    {
      while (head != tail
      && ((head)->code) == NOTE
      && ((head)->fld[4].rtint) != -13)
 head = ((head)->fld[2].rtx);
      while (head != tail
      && ((head)->code) == INSN
      && ((((head)->fld[3].rtx))->code) == SET)
 {
   rtx src = ((((head)->fld[3].rtx))->fld[1].rtx);
   while (((src)->code) == SUBREG
   || ((src)->code) == SIGN_EXTEND
   || ((src)->code) == ZERO_EXTEND
   || ((src)->code) == SIGN_EXTRACT
   || ((src)->code) == ZERO_EXTRACT)
     src = ((src)->fld[0].rtx);
   if (((src)->code) != REG
       || ((src)->fld[0].rtint) >= 68)
     break;

   (insn_ref_count[((head)->fld[0].rtint)]) = 1;
   head = ((head)->fld[2].rtx);
 }
    }



  while (head != tail)
    {
      if (((head)->code) == NOTE)
 head = ((head)->fld[2].rtx);
      else if (((tail)->code) == NOTE)
 tail = ((tail)->fld[1].rtx);
      else if (((head)->code) == CODE_LABEL)
 head = ((head)->fld[2].rtx);
      else break;
    }


  if (head == tail
      && (((head)->code) == NOTE || ((head)->code) == CODE_LABEL))
    return;
  prev_head = ((head)->fld[1].rtx);
  next_tail = ((tail)->fld[2].rtx);


  dead_notes = 0;
  pending_read_insns = 0;
  pending_read_mems = 0;
  pending_write_insns = 0;
  pending_write_mems = 0;
  pending_lists_length = 0;
  last_pending_memory_flush = 0;
  last_function_call = 0;
  last_scheduled_insn = 0;

  ((sched_before_next_call)->fld[5].rtx) = 0;

  n_insns += sched_analyze (head, tail);
  if (n_insns == 0)
    {
      free_pending_lists ();
      return;
    }





  ready = (rtx *) 
                 __builtin_alloca((
                 (n_insns+1) * sizeof (rtx)
                 ))
                                                    ;



  insn = tail;
  last = 0;
  while (((insn)->code) == CALL_INSN || ((insn)->code) == JUMP_INSN
  || (((insn)->code) == INSN
      && (((((insn)->fld[3].rtx))->code) == USE



   ))
  || ((insn)->code) == NOTE)
    {
      if (((insn)->code) != NOTE)
 {
   priority (insn);
   if (last == 0)
     {
       ready[n_ready++] = insn;
       (insn_priority[((insn)->fld[0].rtint)]) = 0x7ffffffe - i;
       (insn_ref_count[((insn)->fld[0].rtint)]) = 0;
     }
   else if (! find_insn_list (insn, ((last)->fld[5].rtx)))
     {
       add_dependence (last, insn, REG_DEP_ANTI);
       (insn_ref_count[((insn)->fld[0].rtint)])++;
     }
   last = insn;


   while (((insn)->in_struct))
     {
       insn = prev_nonnote_insn (insn);
       priority (insn);
     }
 }

      insn = ((insn)->fld[1].rtx);

      if (insn == prev_head)
 break;
    }
  for (; insn != prev_head; insn = ((insn)->fld[1].rtx))
    {
      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   priority (insn);
   if ((insn_ref_count[((insn)->fld[0].rtint)]) == 0)
     {
       if (last == 0)
  ready[n_ready++] = insn;
       else
  {


    add_dependence (last, insn, REG_DEP_ANTI);
    (insn_ref_count[((insn)->fld[0].rtint)]) = 1;
  }
     }
   if (((insn)->in_struct))
     {
       while (((insn)->in_struct))
  {
    insn = ((insn)->fld[1].rtx);
    while (((insn)->code) == NOTE)
      insn = ((insn)->fld[1].rtx);
    priority (insn);
  }
       continue;
     }
 }
    }
  if (reload_completed == 0)
    {
      memcpy ((char *) bb_live_regs,(char *) basic_block_live_at_start[b],regset_bytes)
                   ;
      memset ((char *) bb_dead_regs,0,regset_bytes);

      if (b == 0)
 {







   for (insn = basic_block_head[b]; insn != head;
        insn = ((insn)->fld[2].rtx))
     if ((rtx_class[(int)(((insn)->code))]) == 'i')
       {






  if (((((insn)->fld[3].rtx))->code) == SET
      || ((((insn)->fld[3].rtx))->code) == CLOBBER)
    sched_note_set (b, ((insn)->fld[3].rtx), 0);
  else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
    {
      int j;
      for (j = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
        if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == SET
     || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == CLOBBER)
   sched_note_set (b, ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx), 0);



      for (j = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
        if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == USE)
   sched_note_set (b, ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx), 0);
    }

  for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
    {
      if ((((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
    || ((n64_enum_reg_note) ((link)->mode)) == REG_UNUSED)

   && ((((link)->fld[0].rtx))->code) == REG)
        {
   register int regno = ((((link)->fld[0].rtx))->fld[0].rtint);
   register int offset = regno / 32;
   register unsigned int bit
     = (unsigned int) 1 << (regno % 32);

   if (regno < 68)
     {
       int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                      ;
       while (--j >= 0)
         {
    offset = (regno + j) / 32;
    bit = ((unsigned int) 1
           << ((regno + j) % 32));

    bb_live_regs[offset] &= ~bit;
    bb_dead_regs[offset] |= bit;
         }
     }
   else
     {
       bb_live_regs[offset] &= ~bit;
       bb_dead_regs[offset] |= bit;
     }
        }
    }
       }
 }
    }



  if (write_symbols != NO_DEBUG)
    {




      rtx line = line_note_head[b];

      for (insn = basic_block_head[b];
    insn != next_tail;
    insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) > 0)
   line = insn;
 else
   (line_note[((insn)->fld[0].rtint)]) = line;
    }

  for (insn = head; insn != next_tail; insn = ((insn)->fld[2].rtx))
    {
      rtx prev, next, link;



      if (((insn)->code) == NOTE)
 {
   prev = insn;
   insn = unlink_notes (insn, next_tail);
   if (prev == tail)
     abort ();
   if (prev == head)
     abort ();
   if (insn == next_tail)
     abort ();
 }

      if (reload_completed == 0
   && (rtx_class[(int)(((insn)->code))]) == 'i')
 {






   if (((((insn)->fld[3].rtx))->code) == SET
       || ((((insn)->fld[3].rtx))->code) == CLOBBER)
     sched_note_set (b, ((insn)->fld[3].rtx), 0);
   else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
     {
       int j;
       for (j = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
  if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == SET
      || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == CLOBBER)
    sched_note_set (b, ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx), 0);



       for (j = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
  if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == USE)
    sched_note_set (b, ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx), 0);
     }


   for (prev = 0, link = ((insn)->fld[6].rtx); link; link = next)
     {
       next = ((link)->fld[1].rtx);
       if ((((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
     || ((n64_enum_reg_note) ((link)->mode)) == REG_UNUSED)

    && ((((link)->fld[0].rtx))->code) == REG)
  {
    register int regno = ((((link)->fld[0].rtx))->fld[0].rtint);
    register int offset = regno / 32;
    register unsigned int bit
      = (unsigned int) 1 << (regno % 32);



    if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD)
      {
        if (prev)
   ((prev)->fld[1].rtx) = next;
        else
   ((insn)->fld[6].rtx) = next;
        ((link)->fld[1].rtx) = dead_notes;
        dead_notes = link;
      }
    else
      prev = link;

    if (regno < 68)
      {
        int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((((link)->fld[0].rtx))->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                ;
        while (--j >= 0)
   {
     offset = (regno + j) / 32;
     bit = ((unsigned int) 1
     << ((regno + j) % 32));

     bb_live_regs[offset] &= ~bit;
     bb_dead_regs[offset] |= bit;
   }
      }
    else
      {
        bb_live_regs[offset] &= ~bit;
        bb_dead_regs[offset] |= bit;
      }
  }
       else
  prev = link;
     }
 }
    }

  if (reload_completed == 0)
    {

      old_live_regs = (regset) 
                              __builtin_alloca((
                              regset_bytes
                              ))
                                                   ;
      regs_sometimes_live
 = (struct n64_tag_sometimes *) 
                       __builtin_alloca((
                       max_regno * sizeof (struct n64_tag_sometimes)
                       ))
                                                                     ;
      sometimes_max = 0;


      for (j = 0; j < regset_size; j++)
 {
   unsigned int live = bb_live_regs[j];
   old_live_regs[j] = live;
   if (live)
     {
       register int bit;
       for (bit = 0; bit < 32; bit++)
  if (live & ((unsigned int) 1 << bit))
    sometimes_max = new_sometimes_live (regs_sometimes_live, j,
            bit, sometimes_max);
     }
 }
    }

  do { if ((n_ready) - (1) == 1) swap_sort (ready, n_ready); else if ((n_ready) - (1) > 1) qsort (ready, n_ready, sizeof (rtx), rank_for_schedule); } while (0);

  if (file)
    {
      fprintf (file, ";; ready list initially:\n;; ");
      for (i = 0; i < n_ready; i++)
 fprintf (file, "%d ", ((ready[i])->fld[0].rtint));
      fprintf (file, "\n\n");

      for (insn = head; insn != next_tail; insn = ((insn)->fld[2].rtx))
 if ((insn_priority[((insn)->fld[0].rtint)]) > 0)
   fprintf (file, ";; insn[%4d]: priority = %4d, ref_count = %4d\n",
     ((insn)->fld[0].rtint), (insn_priority[((insn)->fld[0].rtint)]),
     (insn_ref_count[((insn)->fld[0].rtint)]));
    }



  tail = 0;


  q_ptr = 0; clock = 0;
  memset ((char *) insn_queue,0,sizeof (insn_queue));




  last = next_tail;

  new_needs = (((prev_head)->fld[2].rtx) == basic_block_head[b]
        ? 1 : 0);
  if (((next_tail)->fld[1].rtx) == basic_block_end[b])
    new_needs |= 2;

  new_ready = n_ready;
  while (sched_n_insns < n_insns)
    {
      q_ptr = (((q_ptr)+1) & (128 -1)); clock++;



      for (insn = insn_queue[q_ptr]; insn; insn = ((insn)->fld[2].rtx))
 {
   if (file)
     fprintf (file, ";; launching %d before %d with no stalls at T-%d\n",
       ((insn)->fld[0].rtint), ((last)->fld[0].rtint), clock);
   ready[new_ready++] = insn;
   q_size -= 1;
 }
      insn_queue[q_ptr] = 0;



      if (new_ready == 0)
 {
   register int stalls;

   for (stalls = 1; stalls < 128; stalls++)
     if (insn = insn_queue[(((q_ptr)+stalls) & (128 -1))])
       {
  for (; insn; insn = ((insn)->fld[2].rtx))
    {
      if (file)
        fprintf (file, ";; launching %d before %d with %d stalls at T-%d\n",
          ((insn)->fld[0].rtint), ((last)->fld[0].rtint), stalls, clock);
      ready[new_ready++] = insn;
      q_size -= 1;
    }
  insn_queue[(((q_ptr)+stalls) & (128 -1))] = 0;
  break;
       }

   q_ptr = (((q_ptr)+stalls) & (128 -1)); clock += stalls;
 }


      if (new_ready == 0)
 abort ();

      if (file)
 {
   fprintf (file, ";; ready list at T-%d:", clock);
   for (i = 0; i < new_ready; i++)
     fprintf (file, " %d (%x)",
       ((ready[i])->fld[0].rtint), (insn_priority[((ready[i])->fld[0].rtint)]));
 }
      do { if ((new_ready) - (n_ready) == 1) swap_sort (ready, new_ready); else if ((new_ready) - (n_ready) > 1) qsort (ready, new_ready, sizeof (rtx), rank_for_schedule); } while (0);
      if (112 > 1)
 {
   new_ready = schedule_select (ready, new_ready, clock, file);
   if (new_ready == 0)
     {
       if (file)
  fprintf (file, "\n");


       n_ready = 0;
       continue;
     }
 }
      n_ready = new_ready;
      last_scheduled_insn = insn = ready[0];


      if (tail == 0)
 tail = insn;

      if (file)
 {
   fprintf (file, ", now");
   for (i = 0; i < n_ready; i++)
     fprintf (file, " %d", ((ready[i])->fld[0].rtint));
   fprintf (file, "\n");
 }

      if (((insn_priority[((insn)->fld[0].rtint)]) < 0))
 abort ();

      if (reload_completed == 0)
 {


   do
     {
       if (((((insn)->fld[3].rtx))->code) == SET
    || ((((insn)->fld[3].rtx))->code) == CLOBBER)
  sched_note_set (b, ((insn)->fld[3].rtx), 1);
       else if (((((insn)->fld[3].rtx))->code) == PARALLEL)
  {
    int j;
    for (j = ((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
      if (((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == SET
   || ((((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx))->code) == CLOBBER)
        sched_note_set (b, ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[j].rtx), 1);
  }


       if (((insn)->code) == CALL_INSN)
  {
    register struct n64_tag_sometimes *p;




    for (i = 0; i < 68; i++)
      if (call_used_regs[i] || global_regs[i])
        {
   register int offset = i / 32;
   register unsigned int bit
     = (unsigned int) 1 << (i % 32);

   bb_live_regs[offset] &= ~bit;
   bb_dead_regs[offset] |= bit;
        }







    p = regs_sometimes_live;
    for (i = 0; i < sometimes_max; i++, p++)
      if (bb_live_regs[p->offset]
   & ((unsigned int) 1 << p->bit))
        p->calls_crossed += 1;
  }



       attach_deaths_insn (insn);


       for (i = 0; i < regset_size; i++)
  {
    unsigned int diff = bb_live_regs[i] & ~old_live_regs[i];
    if (diff)
      {
        register int bit;
        old_live_regs[i] |= diff;
        for (bit = 0; bit < 32; bit++)
   if (diff & ((unsigned int) 1 << bit))
     sometimes_max
       = new_sometimes_live (regs_sometimes_live, i, bit,
        sometimes_max);
      }
  }




       for (i = 0; i < sometimes_max; i++)
  {
    register struct n64_tag_sometimes *p = &regs_sometimes_live[i];
    int regno = p->offset*32 + p->bit;

    p->live_length += 1;

    if ((bb_live_regs[p->offset]
         & ((unsigned int) 1 << p->bit)) == 0)
      {



        sched_reg_live_length[regno] += p->live_length;
        sched_reg_n_calls_crossed[regno] += p->calls_crossed;
        old_live_regs[p->offset]
   &= ~((unsigned int) 1 << p->bit);



        *p = regs_sometimes_live[--sometimes_max];


        i--;
      }
  }

       link = insn;
       insn = ((insn)->fld[1].rtx);
     }
   while (((link)->in_struct));


   insn = ready[0];
 }


      ready += 1;
      n_ready -= 1;

      sched_n_insns += 1;
      ((insn)->fld[2].rtx) = last;
      ((last)->fld[1].rtx) = insn;
      last = insn;


      last = reemit_notes (insn, last);







      (insn_priority[((insn)->fld[0].rtint)]) = 0x7f000001;
      new_ready = schedule_insn (insn, ready, n_ready, clock);
      (insn_priority[((insn)->fld[0].rtint)]) = -1;


      if (((insn)->in_struct))
 {


   link = insn;
   while (((link)->in_struct))
     {

       link = ((link)->fld[1].rtx);
       (insn_ref_count[((link)->fld[0].rtint)]) = 0;
     }



   while (((insn)->in_struct))
     {
       insn = ((insn)->fld[1].rtx);

       sched_n_insns += 1;
       ((insn)->fld[2].rtx) = last;
       ((last)->fld[1].rtx) = insn;
       last = insn;

       last = reemit_notes (insn, last);


       new_ready = schedule_insn (insn, ready, new_ready, clock);
       (insn_priority[((insn)->fld[0].rtint)]) = -1;
     }
 }
    }
  if (q_size != 0)
    abort ();

  if (reload_completed == 0)
    finish_sometimes_live (regs_sometimes_live, sometimes_max);




  head = insn;



  if (note_list != 0)
    {
      rtx note_head = note_list;
      while (((note_head)->fld[1].rtx))
 note_head = ((note_head)->fld[1].rtx);

      ((head)->fld[1].rtx) = note_list;
      ((note_list)->fld[2].rtx) = head;
      head = note_head;
    }






  if (dead_notes != 0)
    abort ();


  if (new_needs & 1)
    basic_block_head[b] = head;
  ((head)->fld[1].rtx) = prev_head;
  ((prev_head)->fld[2].rtx) = head;

  if (new_needs & 2)
    basic_block_end[b] = tail;
  ((tail)->fld[2].rtx) = next_tail;
  ((next_tail)->fld[1].rtx) = tail;


  if (write_symbols != NO_DEBUG)
    {
      rtx line, note, prev, cxx_new;
      int notes = 0;

      head = basic_block_head[b];
      next_tail = ((basic_block_end[b])->fld[2].rtx);







      for (line = head; line; line = ((line)->fld[1].rtx))
 if (((line)->code) == NOTE && ((line)->fld[4].rtint) > 0)
   break;



      for (insn = head; insn != next_tail; insn = ((insn)->fld[2].rtx))
 if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) > 0)
   line = insn;




 else if (((insn)->code) != NOTE
   && (note = (line_note[((insn)->fld[0].rtint)])) != 0
   && note != line
   && (line == 0
       || ((note)->fld[4].rtint) != ((line)->fld[4].rtint)
       || ((note)->fld[3].rtstr) != ((line)->fld[3].rtstr)))
   {
     line = note;
     prev = ((insn)->fld[1].rtx);
     if ((line_note[((note)->fld[0].rtint)]))
       {

  (line_note[((note)->fld[0].rtint)]) = 0;
  ((note)->fld[1].rtx) = prev;
  ((prev)->fld[2].rtx) = note;
  ((insn)->fld[1].rtx) = note;
  ((note)->fld[2].rtx) = insn;
       }
     else
       {
  notes++;
  cxx_new = emit_note_after (((note)->fld[4].rtint), prev);
  ((cxx_new)->fld[3].rtstr) = ((note)->fld[3].rtstr);
       }
   }
      if (file && notes)
 fprintf (file, ";; added %d line-number notes\n", notes);
    }

  if (file)
    {
      fprintf (file, ";; total time = %d\n;; new basic block head = %d\n;; new basic block end = %d\n\n",
        clock, ((basic_block_head[b])->fld[0].rtint), ((basic_block_end[b])->fld[0].rtint));
    }


  free_pending_lists ();

  return;
}





static rtx
regno_use_in(int regno, rtx x) asm("_regno_use_in");
static rtx
regno_use_in(int regno, rtx x)
{
  register char *fmt;
  int i, j;
  rtx tem;

  if (((x)->code) == REG && ((x)->fld[0].rtint) == regno)
    return x;

  fmt = (rtx_format[(int)(((x)->code))]);
  for (i = (rtx_length[(int)(((x)->code))]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   if (tem = regno_use_in (regno, ((x)->fld[i].rtx)))
     return tem;
 }
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   if (tem = regno_use_in (regno , ((x)->fld[i].rtvec->elem[j].rtx)))
     return tem;
    }

  return 0;
}






static void
split_hard_reg_notes(rtx note, rtx first, rtx last, rtx orig_insn) asm("_split_hard_reg_notes");
static void
split_hard_reg_notes(rtx note, rtx first, rtx last, rtx orig_insn)
{
  rtx reg, temp, link;
  int n_regs, i, new_reg;
  rtx insn;


  if (((n64_enum_reg_note) ((note)->mode)) != REG_DEAD)
    abort ();

  reg = ((note)->fld[0].rtx);

  n_regs = (! ((unsigned) ((((reg)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reg)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

  for (i = 0; i < n_regs; i++)
    {
      new_reg = ((reg)->fld[0].rtint) + i;


      for (insn = last; ; insn = ((insn)->fld[1].rtx))
 {
   if ((rtx_class[(int)(((insn)->code))]) == 'i'
       && (temp = regno_use_in (new_reg, ((insn)->fld[3].rtx))))
     {

       link = rtx_alloc (EXPR_LIST);
       ((link)->mode = ((n64_enum_machine_mode) (REG_DEAD)));
       ((link)->fld[0].rtx) = temp;
       ((link)->fld[1].rtx) = ((insn)->fld[6].rtx);
       ((insn)->fld[6].rtx) = link;


       i += (! ((unsigned) ((((temp)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((temp)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((temp)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1;

       break;
     }


   if (insn == first)
     break;
 }
    }
}




static void
new_insn_dead_notes(rtx pat, rtx insn, rtx last, rtx orig_insn) asm("_new_insn_dead_notes");
static void
new_insn_dead_notes(rtx pat, rtx insn, rtx last, rtx orig_insn)
{
  rtx dest, tem, set;


  dest = ((pat)->fld[0].rtx);

  while (((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SUBREG
  || ((dest)->code) == STRICT_LOW_PART
  || ((dest)->code) == SIGN_EXTRACT)
    dest = ((dest)->fld[0].rtx);

  if (((dest)->code) == REG)
    {
      for (tem = last; tem != insn; tem = ((tem)->fld[1].rtx))
 {
   if ((rtx_class[(int)(((tem)->code))]) == 'i'
       && reg_overlap_mentioned_p (dest, ((tem)->fld[3].rtx))
       && (set = single_set (tem)))
     {
       rtx tem_dest = ((set)->fld[0].rtx);

       while (((tem_dest)->code) == ZERO_EXTRACT
       || ((tem_dest)->code) == SUBREG
       || ((tem_dest)->code) == STRICT_LOW_PART
       || ((tem_dest)->code) == SIGN_EXTRACT)
  tem_dest = ((tem_dest)->fld[0].rtx);

       if (! rtx_equal_p (tem_dest, dest))
  {


    if (! find_regno_note (tem, REG_UNUSED, ((dest)->fld[0].rtint))
        && ! find_regno_note (tem, REG_DEAD, ((dest)->fld[0].rtint)))
      {
        rtx note = rtx_alloc (EXPR_LIST);
        ((note)->mode = ((n64_enum_machine_mode) (REG_DEAD)));
        ((note)->fld[0].rtx) = dest;
        ((note)->fld[1].rtx) = ((tem)->fld[6].rtx);
        ((tem)->fld[6].rtx) = note;
      }


    break;
  }
       else if (reg_overlap_mentioned_p (dest, ((set)->fld[1].rtx)))


  break;
     }
 }





      if (tem == insn)
 {
   int live_after_orig_insn = 0;
   rtx pattern = ((orig_insn)->fld[3].rtx);
   int i;

   if (((pat)->code) == CLOBBER)
     {
       rtx note = rtx_alloc (EXPR_LIST);
       ((note)->mode = ((n64_enum_machine_mode) (REG_UNUSED)));
       ((note)->fld[0].rtx) = dest;
       ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
       ((insn)->fld[6].rtx) = note;
       return;
     }



   if (((pattern)->code) == SET)
     {
       if (reg_overlap_mentioned_p (dest, ((pattern)->fld[0].rtx)))
  live_after_orig_insn = 1;
     }
   else if (((pattern)->code) == PARALLEL)
     {
       for (i = 0; i < ((pattern)->fld[0].rtvec->num_elem); i++)
  if (((((pattern)->fld[0].rtvec->elem[i].rtx))->code) == SET
      && reg_overlap_mentioned_p (dest,
      ((((pattern)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx)
                 ))
    live_after_orig_insn = 1;
     }

   if (! live_after_orig_insn)
     abort ();
 }
    }
}





static void
update_n_sets(rtx x, int inc) asm("_update_n_sets");
static void
update_n_sets(rtx x, int inc)
{
  rtx dest = ((x)->fld[0].rtx);

  while (((dest)->code) == STRICT_LOW_PART || ((dest)->code) == SUBREG
  || ((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SIGN_EXTRACT)
    dest = ((dest)->fld[0].rtx);

  if (((dest)->code) == REG)
    {
      int regno = ((dest)->fld[0].rtint);

      if (regno < 68)
 {
   register int i;
   int endregno = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((dest)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

   for (i = regno; i < endregno; i++)
     reg_n_sets[i] += inc;
 }
      else
 reg_n_sets[regno] += inc;
    }
}





static void
update_flow_info(rtx notes, rtx first, rtx last, rtx orig_insn) asm("_update_flow_info");
static void
update_flow_info(rtx notes, rtx first, rtx last, rtx orig_insn)
{
  rtx insn, note;
  rtx next;
  rtx orig_dest, temp;
  rtx set;



  orig_dest = single_set (orig_insn);
  if (orig_dest)
    orig_dest = ((orig_dest)->fld[0].rtx);



  for (note = notes; note; note = next)
    {
      next = ((note)->fld[1].rtx);
      switch (((n64_enum_reg_note) ((note)->mode)))
 {
 case REG_DEAD:
 case REG_UNUSED:



   for (insn = last; ; insn = ((insn)->fld[1].rtx))
     {
       if ((rtx_class[(int)(((insn)->code))]) == 'i'
    && reg_mentioned_p (((note)->fld[0].rtx), ((insn)->fld[3].rtx)))
  {



    temp = ((note)->fld[0].rtx);
    if (((n64_enum_reg_note) ((note)->mode)) == REG_DEAD
        && ((temp)->code) == REG
        && ((temp)->fld[0].rtint) < 68
        && (! ((unsigned) ((((temp)->fld[0].rtint)) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((temp)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((temp)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) > 1)
      split_hard_reg_notes (note, first, last, orig_insn);
    else
      {
        ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
        ((insn)->fld[6].rtx) = note;
      }





    if (((n64_enum_reg_note) ((note)->mode)) == REG_UNUSED
        && ! dead_or_set_p (insn, ((note)->fld[0].rtx)))
      ((note)->mode = ((n64_enum_machine_mode) (REG_DEAD)));



    break;
  }





       if (insn == first)
  {
    if (((n64_enum_reg_note) ((note)->mode)) != REG_UNUSED)
      abort ();

    break;
  }
     }
   break;

 case REG_WAS_0:




   if (! orig_dest)
     abort ();

   for (insn = first; ; insn = ((insn)->fld[2].rtx))
     {
       if ((rtx_class[(int)(((insn)->code))]) == 'i'
    && (temp = single_set (insn))
    && rtx_equal_p (((temp)->fld[0].rtx), orig_dest))
  {
    ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
    ((insn)->fld[6].rtx) = note;


    break;
  }


       if (insn == last)
  abort ();
     }
   break;

 case REG_EQUAL:
 case REG_EQUIV:


   if (! orig_dest)
     break;

 case REG_NO_CONFLICT:



   if (! orig_dest)
     abort ();

   for (insn = last; ; insn = ((insn)->fld[1].rtx))
     {
       if ((rtx_class[(int)(((insn)->code))]) == 'i'
    && (temp = single_set (insn))
    && rtx_equal_p (((temp)->fld[0].rtx), orig_dest))
  {
    ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
    ((insn)->fld[6].rtx) = note;

    break;
  }



       if (insn == first)
  abort ();
     }
   break;

 case REG_LIBCALL:


   ((note)->fld[1].rtx) = ((first)->fld[6].rtx);
   ((first)->fld[6].rtx) = note;

   insn = ((note)->fld[0].rtx);
   note = find_reg_note (insn, REG_RETVAL, (rtx) 0);
   if (note)
     ((note)->fld[0].rtx) = first;
   break;

 case REG_RETVAL:


   ((note)->fld[1].rtx) = ((last)->fld[6].rtx);
   ((last)->fld[6].rtx) = note;

   insn = ((note)->fld[0].rtx);
   note = find_reg_note (insn, REG_LIBCALL, (rtx) 0);
   if (note)
     ((note)->fld[0].rtx) = last;
   break;

 case REG_NONNEG:


   for (insn = last; ; insn = ((insn)->fld[1].rtx))
     {
       if (((insn)->code) == JUMP_INSN)
  {
    ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
    ((insn)->fld[6].rtx) = note;

    break;
  }

       if (insn == first)
  abort ();
     }
   break;

 case REG_INC:


   abort ();

 case REG_LABEL:

   for (insn = first; insn != ((last)->fld[2].rtx); insn = ((insn)->fld[2].rtx))
     if ((rtx_class[(int)(((insn)->code))]) == 'i'
  && reg_mentioned_p (((note)->fld[0].rtx), ((insn)->fld[3].rtx)))
       ((insn)->fld[6].rtx) = gen_rtx (EXPR_LIST, REG_LABEL,
       ((note)->fld[0].rtx), ((insn)->fld[6].rtx));
   break;

 case REG_CC_SETTER:
 case REG_CC_USER:


 default:
   abort ();
 }
    }
  for (insn = first; insn != last; insn = ((insn)->fld[2].rtx))
    {
      rtx pat;
      int i;

      pat = ((insn)->fld[3].rtx);
      if (((pat)->code) == SET || ((pat)->code) == CLOBBER)
 new_insn_dead_notes (pat, insn, last, orig_insn);
      else if (((pat)->code) == PARALLEL)
 {
   for (i = 0; i < ((pat)->fld[0].rtvec->num_elem); i++)
     if (((((pat)->fld[0].rtvec->elem[i].rtx))->code) == SET
  || ((((pat)->fld[0].rtvec->elem[i].rtx))->code) == CLOBBER)
       new_insn_dead_notes (((pat)->fld[0].rtvec->elem[i].rtx), insn, last, orig_insn);
 }
    }
  set = single_set (last);
  if (set)
    {
      rtx dest = ((set)->fld[0].rtx);

      while (((dest)->code) == ZERO_EXTRACT || ((dest)->code) == SUBREG
      || ((dest)->code) == STRICT_LOW_PART
      || ((dest)->code) == SIGN_EXTRACT)
 dest = ((dest)->fld[0].rtx);

      if (((dest)->code) == REG
   && ! reg_overlap_mentioned_p (dest, ((set)->fld[1].rtx)))
 {
   for (insn = ((last)->fld[1].rtx); ; insn = ((insn)->fld[1].rtx))
     {
       if ((rtx_class[(int)(((insn)->code))]) == 'i'
    && reg_mentioned_p (dest, ((insn)->fld[3].rtx))
    && (set = single_set (insn)))
  {
    rtx insn_dest = ((set)->fld[0].rtx);

    while (((insn_dest)->code) == ZERO_EXTRACT
    || ((insn_dest)->code) == SUBREG
    || ((insn_dest)->code) == STRICT_LOW_PART
    || ((insn_dest)->code) == SIGN_EXTRACT)
      insn_dest = ((insn_dest)->fld[0].rtx);

    if (insn_dest != dest)
      {
        note = rtx_alloc (EXPR_LIST);
        ((note)->mode = ((n64_enum_machine_mode) (REG_DEAD)));
        ((note)->fld[0].rtx) = dest;
        ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
        ((insn)->fld[6].rtx) = note;


        break;
      }
  }
       if (insn == first)
  break;
     }
 }
    }
  if (orig_dest && ((orig_dest)->code) == REG)
    {
      int found_orig_dest = 0;
      int found_split_dest = 0;

      for (insn = first; ; insn = ((insn)->fld[2].rtx))
 {
   set = single_set (insn);
   if (set)
     {
       if (((((set)->fld[0].rtx))->code) == REG
    && ((((set)->fld[0].rtx))->fld[0].rtint) == ((orig_dest)->fld[0].rtint))
  {
    found_orig_dest = 1;
    break;
  }
       else if (((((set)->fld[0].rtx))->code) == SUBREG
         && ((((set)->fld[0].rtx))->fld[0].rtx) == orig_dest)
  {
    found_split_dest = 1;
    break;
  }
     }

   if (insn == last)
     break;
 }

      if (found_split_dest)
 {





   for (insn = first; insn; insn = ((insn)->fld[1].rtx))
     {
       if (((insn)->code) == CODE_LABEL
    || ((insn)->code) == JUMP_INSN)
  break;
       else if ((rtx_class[(int)(((insn)->code))]) == 'i'
         && reg_mentioned_p (orig_dest, insn))
  {
    note = find_regno_note (insn, REG_DEAD, ((orig_dest)->fld[0].rtint));
    if (note)
      remove_note (insn, note);
  }
     }
 }
      else if (! found_orig_dest)
 {

   abort ();
 }
    }





  {
    rtx x = ((orig_insn)->fld[3].rtx);
    n64_enum_rtx_code code = ((x)->code);

    if (code == SET || code == CLOBBER)
      update_n_sets (x, -1);
    else if (code == PARALLEL)
      {
 int i;
 for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
   {
     code = ((((x)->fld[0].rtvec->elem[i].rtx))->code);
     if (code == SET || code == CLOBBER)
       update_n_sets (((x)->fld[0].rtvec->elem[i].rtx), -1);
   }
      }

    for (insn = first; ; insn = ((insn)->fld[2].rtx))
      {
 x = ((insn)->fld[3].rtx);
 code = ((x)->code);

 if (code == SET || code == CLOBBER)
   update_n_sets (x, 1);
 else if (code == PARALLEL)
   {
     int i;
     for (i = ((x)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
       {
  code = ((((x)->fld[0].rtvec->elem[i].rtx))->code);
  if (code == SET || code == CLOBBER)
    update_n_sets (((x)->fld[0].rtvec->elem[i].rtx), 1);
       }
   }

 if (insn == last)
   break;
      }
  }
}




void
schedule_insns(FILE *dump_file) asm("_schedule_insns");
void
schedule_insns(FILE *dump_file)
{
  int max_uid = 4 * (get_max_uid () + 1);
  int b;
  rtx insn;



  if (n_basic_blocks == 0)
    return;


  sched_before_next_call
    = gen_rtx (INSN, VOIDmode, 0, (rtx) 0, (rtx) 0,
        (rtx) 0, 0, (rtx) 0, 0);







  if (reload_completed == 0 || ! flag_schedule_insns)
    {
      unused_insn_list = 0;
      unused_expr_list = 0;
    }






  insn_luid = (int *) 
                     __builtin_alloca((
                     max_uid * sizeof (int)
                     ))
                                                    ;
  insn_priority = (int *) 
                         __builtin_alloca((
                         max_uid * sizeof (int)
                         ))
                                                        ;
  insn_tick = (int *) 
                     __builtin_alloca((
                     max_uid * sizeof (int)
                     ))
                                                    ;
  insn_costs = (short *) 
                        __builtin_alloca((
                        max_uid * sizeof (short)
                        ))
                                                         ;
  insn_units = (short *) 
                        __builtin_alloca((
                        max_uid * sizeof (short)
                        ))
                                                         ;
  insn_blockage = (unsigned int *) 
                                  __builtin_alloca((
                                  max_uid * sizeof (unsigned int)
                                  ))
                                                                          ;
  insn_ref_count = (int *) 
                          __builtin_alloca((
                          max_uid * sizeof (int)
                          ))
                                                         ;

  if (reload_completed == 0)
    {
      sched_reg_n_deaths = (short *) 
                                    __builtin_alloca((
                                    max_regno * sizeof (short)
                                    ))
                                                                       ;
      sched_reg_n_calls_crossed = (int *) 
                                         __builtin_alloca((
                                         max_regno * sizeof (int)
                                         ))
                                                                          ;
      sched_reg_live_length = (int *) 
                                     __builtin_alloca((
                                     max_regno * sizeof (int)
                                     ))
                                                                      ;
      bb_dead_regs = (regset) 
                             __builtin_alloca((
                             regset_bytes
                             ))
                                                  ;
      bb_live_regs = (regset) 
                             __builtin_alloca((
                             regset_bytes
                             ))
                                                  ;
      memset ((char *) sched_reg_n_calls_crossed,0,max_regno * sizeof (int));
      memset ((char *) sched_reg_live_length,0,max_regno * sizeof (int));
      memcpy ((char *) sched_reg_n_deaths,(char *) reg_n_deaths,max_regno * sizeof (short))
                                 ;
      init_alias_analysis ();
    }
  else
    {
      sched_reg_n_deaths = 0;
      sched_reg_n_calls_crossed = 0;
      sched_reg_live_length = 0;
      bb_dead_regs = 0;
      bb_live_regs = 0;
      if (! flag_schedule_insns)
 init_alias_analysis ();
    }

  if (write_symbols != NO_DEBUG)
    {
      rtx line;

      line_note = (rtx *) 
                         __builtin_alloca((
                         max_uid * sizeof (rtx)
                         ))
                                                        ;
      memset ((char *) line_note,0,max_uid * sizeof (rtx));
      line_note_head = (rtx *) 
                              __builtin_alloca((
                              n_basic_blocks * sizeof (rtx)
                              ))
                                                                    ;
      memset ((char *) line_note_head,0,n_basic_blocks * sizeof (rtx));






      for (b = 0; b < n_basic_blocks; b++)
 for (line = basic_block_head[b]; line; line = ((line)->fld[1].rtx))
   if (((line)->code) == NOTE && ((line)->fld[4].rtint) > 0)
     {
       line_note_head[b] = line;
       break;
     }
    }

  memset ((char *) insn_luid,0,max_uid * sizeof (int));
  memset ((char *) insn_priority,0,max_uid * sizeof (int));
  memset ((char *) insn_tick,0,max_uid * sizeof (int));
  memset ((char *) insn_costs,0,max_uid * sizeof (short));
  memset ((char *) insn_units,0,max_uid * sizeof (short));
  memset ((char *) insn_blockage,0,max_uid * sizeof (unsigned int));
  memset ((char *) insn_ref_count,0,max_uid * sizeof (int));






  insn = basic_block_end[n_basic_blocks-1];
  if (((insn)->fld[2].rtx) == 0
      || (((insn)->code) != NOTE
   && ((insn)->code) != CODE_LABEL


   && ! (((insn)->code) == JUMP_INSN
  && ((((insn)->fld[2].rtx))->code) == BARRIER)))
    emit_note_after (-1, basic_block_end[n_basic_blocks-1]);

  for (b = 0; b < n_basic_blocks; b++)
    {
      rtx insn, next;

      note_list = 0;

      for (insn = basic_block_head[b]; ; insn = next)
 {
   rtx prev;
   rtx set;



   next = ((insn)->fld[2].rtx);
   if (((insn)->code) != INSN)
     {
       if (insn == basic_block_end[b])
  break;

       continue;
     }




   set = single_set (insn);
   if (set && rtx_equal_p (((set)->fld[1].rtx), ((set)->fld[0].rtx)))
     {
       if (insn == basic_block_end[b])
  break;





       if (reload_completed)
  {
    ((insn)->code = (NOTE));
    ((insn)->fld[4].rtint) = -1;
    ((insn)->fld[3].rtstr) = 0;
  }

       continue;
     }


   prev = ((insn)->fld[1].rtx);
   if (reload_completed == 0)
     {
       rtx last, first = ((insn)->fld[1].rtx);
       rtx notes = ((insn)->fld[6].rtx);

       last = try_split (((insn)->fld[3].rtx), insn, 1);
       if (last != insn)
  {

    first = ((first)->fld[2].rtx);
    update_flow_info (notes, first, last, insn);

    ((insn)->code = (NOTE));
    ((insn)->fld[3].rtstr) = 0;
    ((insn)->fld[4].rtint) = -1;
    if (insn == basic_block_head[b])
      basic_block_head[b] = first;
    if (insn == basic_block_end[b])
      {
        basic_block_end[b] = last;
        break;
      }
  }
     }

   if (insn == basic_block_end[b])
     break;
 }

      schedule_block (b, dump_file);




    }



  if (reload_completed)
    reposition_prologue_and_epilogue_notes (get_insns ());

  if (write_symbols != NO_DEBUG)
    {
      rtx line = 0;
      rtx insn = get_insns ();
      int active_insn = 0;
      int notes = 0;




      for (insn = get_last_insn (); insn; insn = ((insn)->fld[1].rtx))
 if (((insn)->code) == NOTE && ((insn)->fld[4].rtint) > 0)
   {

     if (active_insn == 0)
       {
  notes++;
  ((insn)->fld[3].rtstr) = 0;
  ((insn)->fld[4].rtint) = -1;
       }

     else if (line
       && ((line)->fld[4].rtint) == ((insn)->fld[4].rtint)
       && ((line)->fld[3].rtstr) == ((insn)->fld[3].rtstr))
       {
  notes++;
  ((line)->fld[3].rtstr) = 0;
  ((line)->fld[4].rtint) = -1;
  line = insn;
       }
     else
       line = insn;
     active_insn = 0;
   }
 else if (! ((((insn)->code) == NOTE
       && ((insn)->fld[4].rtint) == -1)
      || (((insn)->code) == INSN
   && (((((insn)->fld[3].rtx))->code) == USE
       || ((((insn)->fld[3].rtx))->code) == CLOBBER))))
   active_insn++;

      if (dump_file && notes)
 fprintf (dump_file, ";; deleted %d line-number notes\n", notes);
    }

  if (reload_completed == 0)
    {
      int regno;
      for (regno = 0; regno < max_regno; regno++)
 if (sched_reg_live_length[regno])
   {
     if (dump_file)
       {
  if (reg_live_length[regno] > sched_reg_live_length[regno])
    fprintf (dump_file,
      ";; register %d life shortened from %d to %d\n",
      regno, reg_live_length[regno],
      sched_reg_live_length[regno]);


  else if (reg_live_length[regno] < sched_reg_live_length[regno]
    && reg_live_length[regno] >= 0)
    fprintf (dump_file,
      ";; register %d life extended from %d to %d\n",
      regno, reg_live_length[regno],
      sched_reg_live_length[regno]);

  if (! reg_n_calls_crossed[regno]
      && sched_reg_n_calls_crossed[regno])
    fprintf (dump_file,
      ";; register %d now crosses calls\n", regno);
  else if (reg_n_calls_crossed[regno]
    && ! sched_reg_n_calls_crossed[regno]
    && reg_basic_block[regno] != -2)
    fprintf (dump_file,
      ";; register %d no longer crosses calls\n", regno);

       }


     if (reg_live_length[regno] >= 0)
       reg_live_length[regno] = sched_reg_live_length[regno];
     if (sched_reg_n_calls_crossed[regno]
  || reg_basic_block[regno] != -2)
       reg_n_calls_crossed[regno] = sched_reg_n_calls_crossed[regno];
   }
    }
}

