// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
int
bcmp(char *from, char *to, int count) asm("_bcmp");
int
bcmp(char *from, char *to, int count)
{
  int rtnval = 0;

  while (count-- > 0)
    {
      if (*from++ != *to++)
 {
   rtnval = 1;
   break;
 }
    }
  return (rtnval);
}

