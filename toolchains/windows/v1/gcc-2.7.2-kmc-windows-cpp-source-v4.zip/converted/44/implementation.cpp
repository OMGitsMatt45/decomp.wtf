// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/local-alloc.c
/* Allocate registers within a basic block, for GNU compiler.
   Copyright (C) 1987, 88, 91, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int constrain_operands(...) asm("_constrain_operands");
extern int reg_overlap_mentioned_p(...) asm("_reg_overlap_mentioned_p");
extern int true_dependence(...) asm("_true_dependence");
extern int side_effects_p(...) asm("_side_effects_p");
extern int note_stores(...) asm("_note_stores");
extern int reg_set_p(...) asm("_reg_set_p");
extern int validate_replace_rtx(...) asm("_validate_replace_rtx");
extern int remove_note(...) asm("_remove_note");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int init_alias_analysis(...) asm("_init_alias_analysis");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int remove_death(...) asm("_remove_death");
extern int get_max_uid(...) asm("_get_max_uid");
extern int floor_log2_wide(...) asm("_floor_log2_wide");
extern int reg_class_subset_p(...) asm("_reg_class_subset_p");
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;
static int next_qty;






static short *qty_phys_reg;
static HARD_REG_SET *qty_phys_copy_sugg;




static HARD_REG_SET *qty_phys_sugg;



static short *qty_phys_num_copy_sugg;



static short *qty_phys_num_sugg;



static int *qty_n_refs;





static n64_enum_reg_class *qty_min_class;




static int *qty_birth;







static int *qty_death;
static int *qty_size;




static n64_enum_machine_mode *qty_mode;



static int *qty_n_calls_crossed;




static n64_enum_reg_class *qty_alternate_class;




static rtx *qty_scratch_rtx;




static char *qty_changes_size;





static int *qty_first_reg;





static int *reg_next_in_qty;
static int *reg_qty;





static char *reg_offset;
short *reg_renumber;




static HARD_REG_SET regs_live;
static HARD_REG_SET *regs_live_at;

int *scratch_block;
rtx *scratch_list;
int scratch_list_length;
static int scratch_index;



static int this_insn_number;
static rtx this_insn;

static void alloc_qty (int, n64_enum_machine_mode, int, int) asm("_alloc_qty");
static void alloc_qty_for_scratch (rtx, int, rtx, int, int) asm("_alloc_qty_for_scratch");
static void validate_equiv_mem_from_store (rtx, rtx) asm("_validate_equiv_mem_from_store");
static int validate_equiv_mem (rtx, rtx, rtx) asm("_validate_equiv_mem");
static int memref_referenced_p (rtx, rtx) asm("_memref_referenced_p");
static int memref_used_between_p (rtx, rtx, rtx) asm("_memref_used_between_p");
static void optimize_reg_copy_1 (rtx, rtx, rtx) asm("_optimize_reg_copy_1");
static void optimize_reg_copy_2 (rtx, rtx, rtx) asm("_optimize_reg_copy_2");
static void update_equiv_regs (void) asm("_update_equiv_regs");
static void block_alloc (int) asm("_block_alloc");
static int qty_sugg_compare (int, int) asm("_qty_sugg_compare");
static int qty_sugg_compare_1 (int *, int *) asm("_qty_sugg_compare_1");
static int qty_compare (int, int) asm("_qty_compare");
static int qty_compare_1 (int *, int *) asm("_qty_compare_1");
static int combine_regs (rtx, rtx, int, int, rtx, int) asm("_combine_regs");
static int reg_meets_class_p (int, n64_enum_reg_class) asm("_reg_meets_class_p");
static int reg_classes_overlap_p (n64_enum_reg_class, n64_enum_reg_class, int) asm("_reg_classes_overlap_p")
          ;
static void update_qty_class (int, int) asm("_update_qty_class");
static void reg_is_set (rtx, rtx) asm("_reg_is_set");
static void reg_is_born (rtx, int) asm("_reg_is_born");
static void wipe_dead_reg (rtx, int) asm("_wipe_dead_reg");
static int find_free_reg (n64_enum_reg_class, n64_enum_machine_mode, int, int, int, int, int) asm("_find_free_reg")
                                    ;
static void mark_life (int, n64_enum_machine_mode, int) asm("_mark_life");
static void post_mark_life (int, n64_enum_machine_mode, int, int, int) asm("_post_mark_life");
static int no_conflict_p (rtx, rtx, rtx) asm("_no_conflict_p");
static int requires_inout (char *) asm("_requires_inout");





static void
alloc_qty(int regno, n64_enum_machine_mode mode, int size, int birth) asm("_alloc_qty");
static void
alloc_qty(int regno, n64_enum_machine_mode mode, int size, int birth)
{
  register int qty = next_qty++;

  reg_qty[regno] = qty;
  reg_offset[regno] = 0;
  reg_next_in_qty[regno] = -1;

  qty_first_reg[qty] = regno;
  qty_size[qty] = size;
  qty_mode[qty] = mode;
  qty_birth[qty] = birth;
  qty_n_calls_crossed[qty] = reg_n_calls_crossed[regno];
  qty_min_class[qty] = reg_preferred_class (regno);
  qty_alternate_class[qty] = reg_alternate_class (regno);
  qty_n_refs[qty] = reg_n_refs[regno];
  qty_changes_size[qty] = reg_changes_size[regno];
}





static void
alloc_qty_for_scratch(rtx scratch, int n, rtx insn, int insn_code_num, int insn_number) asm("_alloc_qty_for_scratch");
static void
alloc_qty_for_scratch(rtx scratch, int n, rtx insn, int insn_code_num, int insn_number)
{
  register int qty;
  n64_enum_reg_class cxx_class;
  char *p, c;
  int i;




  if (which_alternative == -1)
    if (! constrain_operands (insn_code_num, 0))
      return;

  for (p = insn_operand_constraint[insn_code_num][n], i = 0;
       *p && i < which_alternative; p++)
    if (*p == ',')
      i++;





  cxx_class = NO_REGS;
  while ((c = *p++) != '\0' && c != ',')
    switch (c)
      {
      case '=': case '+': case '?':
      case '#': case '&': case '!':
      case '*': case '%':
      case '0': case '1': case '2': case '3': case '4':
      case 'm': case '<': case '>': case 'V': case 'o':
      case 'E': case 'F': case 'G': case 'H':
      case 's': case 'i': case 'n':
      case 'I': case 'J': case 'K': case 'L':
      case 'M': case 'N': case 'O': case 'P':

      case 'Q': case 'R': case 'S': case 'T': case 'U':

      case 'p':

 break;

      case 'X':

 return;

      case 'g': case 'r':
 cxx_class = reg_class_subunion[(int) cxx_class][(int) GR_REGS];
 break;

      default:
 cxx_class
   = reg_class_subunion[(int) cxx_class][(int) mips_char_to_class[ (c) ]];
 break;
      }

  if (cxx_class == NO_REGS)
    return;







  qty = next_qty++;

  qty_first_reg[qty] = -1;
  qty_scratch_rtx[qty] = scratch;
  qty_size[qty] = (mode_size[(int)(((scratch)->mode))]);
  qty_mode[qty] = ((scratch)->mode);
  qty_birth[qty] = 2 * insn_number - 1;
  qty_death[qty] = 2 * insn_number + 1;
  qty_n_calls_crossed[qty] = 0;
  qty_min_class[qty] = cxx_class;
  qty_alternate_class[qty] = NO_REGS;
  qty_n_refs[qty] = 1;
  qty_changes_size[qty] = 0;
}



void
local_alloc(void) asm("_local_alloc");
void
local_alloc(void)
{
  register int b, i;
  int max_qty;
  update_equiv_regs ();




  max_qty = (max_regno - 68) + max_scratch;
  scratch_list_length = max_qty;
  scratch_list = (rtx *) xmalloc (scratch_list_length * sizeof (rtx));
  memset ((char *) scratch_list,0,scratch_list_length * sizeof (rtx));
  scratch_block = (int *) xmalloc (scratch_list_length * sizeof (int));
  memset ((char *) scratch_block,0,scratch_list_length * sizeof (int));
  scratch_index = 0;

  qty_phys_reg = (short *) 
                          __builtin_alloca((
                          max_qty * sizeof (short)
                          ))
                                                           ;
  qty_phys_copy_sugg
    = (HARD_REG_SET *) 
                      __builtin_alloca((
                      max_qty * sizeof (HARD_REG_SET)
                      ))
                                                              ;
  qty_phys_num_copy_sugg = (short *) 
                                    __builtin_alloca((
                                    max_qty * sizeof (short)
                                    ))
                                                                     ;
  qty_phys_sugg = (HARD_REG_SET *) 
                                  __builtin_alloca((
                                  max_qty * sizeof (HARD_REG_SET)
                                  ))
                                                                          ;
  qty_phys_num_sugg = (short *) 
                               __builtin_alloca((
                               max_qty * sizeof (short)
                               ))
                                                                ;
  qty_birth = (int *) 
                     __builtin_alloca((
                     max_qty * sizeof (int)
                     ))
                                                    ;
  qty_death = (int *) 
                     __builtin_alloca((
                     max_qty * sizeof (int)
                     ))
                                                    ;
  qty_scratch_rtx = (rtx *) 
                           __builtin_alloca((
                           max_qty * sizeof (rtx)
                           ))
                                                          ;
  qty_first_reg = (int *) 
                         __builtin_alloca((
                         max_qty * sizeof (int)
                         ))
                                                        ;
  qty_size = (int *) 
                    __builtin_alloca((
                    max_qty * sizeof (int)
                    ))
                                                   ;
  qty_mode
    = (n64_enum_machine_mode *) 
                           __builtin_alloca((
                           max_qty * sizeof (n64_enum_machine_mode)
                           ))
                                                                        ;
  qty_n_calls_crossed = (int *) 
                               __builtin_alloca((
                               max_qty * sizeof (int)
                               ))
                                                              ;
  qty_min_class
    = (n64_enum_reg_class *) 
                        __builtin_alloca((
                        max_qty * sizeof (n64_enum_reg_class)
                        ))
                                                                  ;
  qty_alternate_class
    = (n64_enum_reg_class *) 
                        __builtin_alloca((
                        max_qty * sizeof (n64_enum_reg_class)
                        ))
                                                                  ;
  qty_n_refs = (int *) 
                      __builtin_alloca((
                      max_qty * sizeof (int)
                      ))
                                                     ;
  qty_changes_size = (char *) 
                             __builtin_alloca((
                             max_qty * sizeof (char)
                             ))
                                                             ;

  reg_qty = (int *) 
                   __builtin_alloca((
                   max_regno * sizeof (int)
                   ))
                                                    ;
  reg_offset = (char *) 
                       __builtin_alloca((
                       max_regno * sizeof (char)
                       ))
                                                         ;
  reg_next_in_qty = (int *) 
                           __builtin_alloca((
                           max_regno * sizeof (int)
                           ))
                                                            ;

  reg_renumber = (short *) oballoc (max_regno * sizeof (short));
  for (i = 0; i < max_regno; i++)
    reg_renumber[i] = -1;
  for (i = 68; i < max_regno; i++)
    {
      if (reg_basic_block[i] >= 0 && reg_n_deaths[i] == 1
   && (reg_alternate_class (i) == NO_REGS
       || ! (reg_class_size[(int) (reg_preferred_class (i))] == 1)))
 reg_qty[i] = -2;
      else
 reg_qty[i] = -1;
    }


  next_qty = max_qty;



  for (b = 0; b < n_basic_blocks; b++)
    {







      if (next_qty < 6)
 {
   for (i = 0; i < next_qty; i++)
     {
       qty_scratch_rtx[i] = 0;
       do { register HARD_REG_ELT_TYPE *scan_tp_ = (qty_phys_copy_sugg[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
       qty_phys_num_copy_sugg[i] = 0;
       do { register HARD_REG_ELT_TYPE *scan_tp_ = (qty_phys_sugg[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
       qty_phys_num_sugg[i] = 0;
     }
 }
      else
 {



   memset ((char *) (qty_scratch_rtx),0,(sizeof (*(qty_scratch_rtx))) * next_qty);;
   memset ((char *) (qty_phys_copy_sugg),0,(sizeof (*(qty_phys_copy_sugg))) * next_qty);;
   memset ((char *) (qty_phys_num_copy_sugg),0,(sizeof (*(qty_phys_num_copy_sugg))) * next_qty);;
   memset ((char *) (qty_phys_sugg),0,(sizeof (*(qty_phys_sugg))) * next_qty);;
   memset ((char *) (qty_phys_num_sugg),0,(sizeof (*(qty_phys_num_sugg))) * next_qty);;
 }

      next_qty = 0;

      block_alloc (b);



    }
}


static int loop_depth;



static rtx equiv_mem;


static int equiv_mem_modified;




static void
validate_equiv_mem_from_store(rtx dest, rtx set) asm("_validate_equiv_mem_from_store");
static void
validate_equiv_mem_from_store(rtx dest, rtx set)
{
  if ((((dest)->code) == REG
       && reg_overlap_mentioned_p (dest, equiv_mem))
      || (((dest)->code) == MEM
   && true_dependence (dest, equiv_mem)))
    equiv_mem_modified = 1;
}
static int
validate_equiv_mem(rtx start, rtx reg, rtx memref) asm("_validate_equiv_mem");
static int
validate_equiv_mem(rtx start, rtx reg, rtx memref)
{
  rtx insn;
  rtx note;

  equiv_mem = memref;
  equiv_mem_modified = 0;



  if (side_effects_p (memref))
    return 0;

  for (insn = start; insn && ! equiv_mem_modified; insn = ((insn)->fld[2].rtx))
    {
      if ((rtx_class[(int)(((insn)->code))]) != 'i')
 continue;

      if (find_reg_note (insn, REG_DEAD, reg))
 return 1;

      if (((insn)->code) == CALL_INSN && ! ((memref)->unchanging)
   && ! ((insn)->unchanging))
 return 0;

      note_stores (((insn)->fld[3].rtx), validate_equiv_mem_from_store);






      for (note = ((insn)->fld[6].rtx); note; note = ((note)->fld[1].rtx))
 if ((((n64_enum_reg_note) ((note)->mode)) == REG_INC
      || ((n64_enum_reg_note) ((note)->mode)) == REG_DEAD)
     && ((((note)->fld[0].rtx))->code) == REG
     && reg_overlap_mentioned_p (((note)->fld[0].rtx), memref))
   return 0;
    }

  return 0;
}




static int
memref_referenced_p(rtx memref, rtx x) asm("_memref_referenced_p");
static int
memref_referenced_p(rtx memref, rtx x)
{
  int i, j;
  char *fmt;
  n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case REG:
    case CONST_INT:
    case CONST:
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_DOUBLE:
    case PC:
    case CC0:
    case HIGH:
    case LO_SUM:
      return 0;

    case MEM:
      if (true_dependence (memref, x))
 return 1;
      break;

    case SET:


      if (((((x)->fld[0].rtx))->code) == MEM)
 {
   if (memref_referenced_p (memref, ((((x)->fld[0].rtx))->fld[0].rtx)))
     return 1;
 }
      else if (memref_referenced_p (memref, ((x)->fld[0].rtx)))
 return 1;

      return memref_referenced_p (memref, ((x)->fld[1].rtx));
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    switch (fmt[i])
      {
      case 'e':
 if (memref_referenced_p (memref, ((x)->fld[i].rtx)))
   return 1;
 break;
      case 'E':
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   if (memref_referenced_p (memref, ((x)->fld[i].rtvec->elem[j].rtx)))
     return 1;
 break;
      }

  return 0;
}




static int
memref_used_between_p(rtx memref, rtx start, rtx end) asm("_memref_used_between_p");
static int
memref_used_between_p(rtx memref, rtx start, rtx end)
{
  rtx insn;

  for (insn = ((start)->fld[2].rtx); insn != ((end)->fld[2].rtx);
       insn = ((insn)->fld[2].rtx))
    if ((rtx_class[(int)(((insn)->code))]) == 'i'
 && memref_referenced_p (memref, ((insn)->fld[3].rtx)))
      return 1;

  return 0;
}
static void
optimize_reg_copy_1(rtx insn, rtx dest, rtx src) asm("_optimize_reg_copy_1");
static void
optimize_reg_copy_1(rtx insn, rtx dest, rtx src)
{
  rtx p, q;
  rtx note;
  rtx dest_death = 0;
  int sregno = ((src)->fld[0].rtint);
  int dregno = ((dest)->fld[0].rtint);

  if (sregno == dregno






      || sregno == (0 + 29) || dregno == (0 + 29))
    return;

  for (p = ((insn)->fld[2].rtx); p; p = ((p)->fld[2].rtx))
    {
      if (((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN
   || (((p)->code) == NOTE
       && (((p)->fld[4].rtint) == -4
    || ((p)->fld[4].rtint) == -5)))
 break;

      if ((rtx_class[(int)(((p)->code))]) != 'i')
 continue;

      if (reg_set_p (src, p) || reg_set_p (dest, p)

   || (((((p)->fld[3].rtx))->code) == USE
       && reg_overlap_mentioned_p (src, ((((p)->fld[3].rtx))->fld[0].rtx))))
 break;



      if ((note = find_regno_note (p, REG_DEAD, sregno)) != 0
   && ((((note)->fld[0].rtx))->mode) == ((src)->mode))
 {
   int failed = 0;
   int length = 0;
   int d_length = 0;
   int n_calls = 0;
   int d_n_calls = 0;







   for (q = next_real_insn (insn);
        q != next_real_insn (p);
        q = next_real_insn (q))
     {
       if (reg_overlap_mentioned_p (src, ((q)->fld[3].rtx)))
  {





    if (sregno < 68
        && reg_mentioned_p (dest, ((q)->fld[3].rtx)))
      failed = 1;



    else if (validate_replace_rtx (src, dest, q)
      && (sregno >= 68
          || ! reg_overlap_mentioned_p (src,
            ((q)->fld[3].rtx))))
      {



        if (sregno >= 68)
   reg_n_refs[sregno] -= loop_depth;
        if (dregno >= 68)
   reg_n_refs[dregno] += loop_depth;
      }
    else
      {
        validate_replace_rtx (dest, src, q);
        failed = 1;
      }
  }



       length++;
       if (dest_death)
  d_length++;



       if (q != p && ((q)->code) == CALL_INSN)
  {
    n_calls++;
    if (dest_death)
      d_n_calls++;
  }




       if (dest_death == 0
    && (dest_death = find_regno_note (q, REG_DEAD, dregno)) != 0
    && ((((dest_death)->fld[0].rtx))->mode) == ((dest)->mode))
  remove_note (q, dest_death);
     }

   if (! failed)
     {
       if (sregno >= 68)
  {
    reg_live_length[sregno] -= length;



    if (reg_live_length[sregno] < 2)
      reg_live_length[sregno] = 2;
    reg_n_calls_crossed[sregno] -= n_calls;
  }

       if (dregno >= 68)
  {
    reg_live_length[dregno] += d_length;
    reg_n_calls_crossed[dregno] += d_n_calls;
  }


       remove_note (p, note);
       ((note)->fld[1].rtx) = ((insn)->fld[6].rtx);
       ((insn)->fld[6].rtx) = note;
     }


   if (dest_death)
     {
       ((dest_death)->fld[1].rtx) = ((p)->fld[6].rtx);
       ((p)->fld[6].rtx) = dest_death;
     }

   return;
 }



      else if (sregno < 68
        && dead_or_set_p (p, src))
 break;
    }
}
static void
optimize_reg_copy_2(rtx insn, rtx dest, rtx src) asm("_optimize_reg_copy_2");
static void
optimize_reg_copy_2(rtx insn, rtx dest, rtx src)
{
  rtx p, q;
  rtx set;
  int sregno = ((src)->fld[0].rtint);
  int dregno = ((dest)->fld[0].rtint);

  for (p = ((insn)->fld[2].rtx); p; p = ((p)->fld[2].rtx))
    {
      if (((p)->code) == CODE_LABEL || ((p)->code) == JUMP_INSN
   || (((p)->code) == NOTE
       && (((p)->fld[4].rtint) == -4
    || ((p)->fld[4].rtint) == -5)))
 break;

      if ((rtx_class[(int)(((p)->code))]) != 'i')
 continue;

      set = single_set (p);
      if (set && ((set)->fld[1].rtx) == dest && ((set)->fld[0].rtx) == src
   && find_reg_note (p, REG_DEAD, dest))
 {




   for (q = insn; q != ((p)->fld[2].rtx); q = ((q)->fld[2].rtx))
     if ((rtx_class[(int)(((q)->code))]) == 'i')
       {
  if (reg_mentioned_p (dest, ((q)->fld[3].rtx)))
    {
      ((q)->fld[3].rtx) = replace_rtx (((q)->fld[3].rtx), dest, src);




      reg_n_refs[dregno] -= loop_depth;
      reg_n_refs[sregno] += loop_depth;
    }


       if (((q)->code) == CALL_INSN)
  {
    reg_n_calls_crossed[dregno]--;
    reg_n_calls_crossed[sregno]++;
  }
       }

   remove_note (p, find_reg_note (p, REG_DEAD, dest));
   reg_n_deaths[dregno]--;
   remove_note (insn, find_reg_note (insn, REG_DEAD, src));
   reg_n_deaths[sregno]--;
   return;
 }

      if (reg_set_p (src, p)
   || (((p)->code) == CALL_INSN && reg_n_calls_crossed[sregno] == 0))
 break;
    }
}
static void
update_equiv_regs(void) asm("_update_equiv_regs");
static void
update_equiv_regs(void)
{
  rtx *reg_equiv_init_insn = (rtx *) 
                                    __builtin_alloca((
                                    max_regno * sizeof (rtx *)
                                    ))
                                                                       ;
  rtx *reg_equiv_replacement = (rtx *) 
                                      __builtin_alloca((
                                      max_regno * sizeof (rtx *)
                                      ))
                                                                         ;
  rtx insn;

  memset ((char *) reg_equiv_init_insn,0,max_regno * sizeof (rtx *));
  memset ((char *) reg_equiv_replacement,0,max_regno * sizeof (rtx *));

  init_alias_analysis ();

  loop_depth = 1;




  for (insn = get_insns (); insn; insn = ((insn)->fld[2].rtx))
    {
      rtx note;
      rtx set = single_set (insn);
      rtx dest;
      int regno;

      if (((insn)->code) == NOTE)
 {
   if (((insn)->fld[4].rtint) == -4)
     loop_depth++;
   else if (((insn)->fld[4].rtint) == -5)
     loop_depth--;
 }


      if (set == 0)
 continue;

      dest = ((set)->fld[0].rtx);







      if (((dest)->code) == MEM && ((((set)->fld[1].rtx))->code) == REG
   && (regno = ((((set)->fld[1].rtx))->fld[0].rtint)) >= 68
   && reg_basic_block[regno] >= 0
   && reg_equiv_init_insn[regno] != 0
   && validate_equiv_mem (reg_equiv_init_insn[regno], ((set)->fld[1].rtx),
     dest)
   && ! memref_used_between_p (((set)->fld[0].rtx),
          reg_equiv_init_insn[regno], insn))
 ((reg_equiv_init_insn[regno])->fld[6].rtx)
   = gen_rtx (EXPR_LIST, REG_EQUIV, dest,
       ((reg_equiv_init_insn[regno])->fld[6].rtx));



      if (flag_expensive_optimizations && ((dest)->code) == REG
   && ((((set)->fld[1].rtx))->code) == REG
   && ! find_reg_note (insn, REG_DEAD, ((set)->fld[1].rtx)))
 optimize_reg_copy_1 (insn, dest, ((set)->fld[1].rtx));


      else if (flag_expensive_optimizations && ((dest)->code) == REG
        && ((dest)->fld[0].rtint) >= 68
        && ((((set)->fld[1].rtx))->code) == REG
        && ((((set)->fld[1].rtx))->fld[0].rtint) >= 68
        && find_reg_note (insn, REG_DEAD, ((set)->fld[1].rtx)))
 optimize_reg_copy_2 (insn, dest, ((set)->fld[1].rtx));



      if (((dest)->code) != REG
   || (regno = ((dest)->fld[0].rtint)) < 68
   || reg_n_sets[regno] != 1)
 continue;

      note = find_reg_note (insn, REG_EQUAL, (rtx) 0);


      reg_equiv_init_insn[regno] = insn;



      if (note && (((((note)->fld[0].rtx))->code) == LABEL_REF || ((((note)->fld[0].rtx))->code) == SYMBOL_REF || ((((note)->fld[0].rtx))->code) == CONST_INT || ((((note)->fld[0].rtx))->code) == CONST_DOUBLE || ((((note)->fld[0].rtx))->code) == CONST || ((((note)->fld[0].rtx))->code) == HIGH))
 ((note)->mode = ((n64_enum_machine_mode) REG_EQUIV));
      note = find_reg_note (insn, REG_EQUIV, (rtx) 0);

      if (note == 0 && reg_basic_block[regno] >= 0
   && ((((set)->fld[1].rtx))->code) == MEM
   && validate_equiv_mem (insn, dest, ((set)->fld[1].rtx)))
 ((insn)->fld[6].rtx) = note = gen_rtx (EXPR_LIST, REG_EQUIV, ((set)->fld[1].rtx),
        ((insn)->fld[6].rtx));


      if (note && reg_live_length[regno] >= 0)
 {
   int regno = ((dest)->fld[0].rtint);



   reg_live_length[regno] *= 2;
   if (reg_n_refs[regno] == 2
       && reg_basic_block[regno] < 0
       && rtx_equal_p (((note)->fld[0].rtx), ((set)->fld[1].rtx)))
     reg_equiv_replacement[regno] = ((set)->fld[1].rtx);
 }
    }





  for (insn = next_active_insn (get_insns ());
       insn;
       insn = next_active_insn (insn))
    {
      rtx link;

      for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
 if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD

     && reg_mentioned_p (((link)->fld[0].rtx), ((insn)->fld[3].rtx)))
   {
     int regno = ((((link)->fld[0].rtx))->fld[0].rtint);

     if (reg_equiv_replacement[regno]
  && validate_replace_rtx (regno_reg_rtx[regno],
      reg_equiv_replacement[regno], insn))
       {
  rtx equiv_insn = reg_equiv_init_insn[regno];

  remove_death (regno, insn);
  reg_n_refs[regno] = 0;
  ((equiv_insn)->code = (NOTE));
  ((equiv_insn)->fld[4].rtint) = -1;
  ((equiv_insn)->fld[3].rtstr) = 0;
       }
   }
    }
}




static void
block_alloc(int b) asm("_block_alloc");
static void
block_alloc(int b)
{
  register int i, q;
  register rtx insn;
  rtx note;
  int insn_number = 0;
  int insn_count = 0;
  int max_uid = get_max_uid ();
  int *qty_order;
  int no_conflict_combined_regno = -1;


  int scratches_allocated = scratch_index;



  insn = basic_block_end[b];
  while (1)
    {
      if (((insn)->code) != NOTE)
 if (++insn_count > max_uid)
   abort ();
      if (insn == basic_block_head[b])
 break;
      insn = ((insn)->fld[1].rtx);
    }



  regs_live_at = (HARD_REG_SET *) 
                                 __builtin_alloca((
                                 (2 * insn_count + 2) * sizeof (HARD_REG_SET)
                                 ))
                               
                              ;
  memset ((char *) regs_live_at,0,(2 * insn_count + 2) * sizeof (HARD_REG_SET));






  do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_live), *scan_fp_ = (basic_block_live_at_start[b]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);






  insn = basic_block_head[b];
  while (1)
    {
      register rtx body = ((insn)->fld[3].rtx);

      if (((insn)->code) != NOTE)
 insn_number++;

      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   register rtx link, set;
   register int win = 0;
   register rtx r0, r1;
   int combined_regno = -1;
   int i;
   int insn_code_number = recog_memoized (insn);

   this_insn_number = insn_number;
   this_insn = insn;

   if (insn_code_number >= 0)
     insn_extract (insn);
   which_alternative = -1;
   if (insn_code_number >= 0

       && insn_n_operands[insn_code_number] > 1
       && insn_operand_constraint[insn_code_number][0][0] == '='
       && insn_operand_constraint[insn_code_number][0][1] != '&'




       )
     {


       int must_match_0 = -1;


       int n_matching_alts = 0;

       for (i = 1; i < insn_n_operands[insn_code_number]; i++)
  {
    char *p = insn_operand_constraint[insn_code_number][i];
    int this_match = (requires_inout (p));

    n_matching_alts += this_match;
    if (this_match == insn_n_alternatives[insn_code_number])
      must_match_0 = i;
  }


       r0 = recog_operand[0];
       for (i = 1; i < insn_n_operands[insn_code_number]; i++)
  {





    if (must_match_0 >= 0 && i != must_match_0
        && ! (i == must_match_0 + 1
       && insn_operand_constraint[insn_code_number][i-1][0] == '%')
        && ! (i == must_match_0 - 1
       && insn_operand_constraint[insn_code_number][i][0] == '%'))
      continue;






    if (n_matching_alts == insn_n_alternatives[insn_code_number]
        && (0 == requires_inout
     (insn_operand_constraint[insn_code_number][i])))
      continue;


    r1 = recog_operand[i];




    if (

        insn_operand_constraint[insn_code_number][i][0] == 'p'



        )
      while (((r1)->code) == PLUS || ((r1)->code) == MULT)
        r1 = ((r1)->fld[0].rtx);

    if (((r0)->code) == REG || ((r0)->code) == SUBREG)
      {




        int may_save_copy
   = ((((body)->fld[0].rtx) == r0 && ((body)->fld[1].rtx) == r1)

      || (r1 == recog_operand[i] && must_match_0 >= 0)

      );

        if (((r1)->code) == REG || ((r1)->code) == SUBREG)
   win = combine_regs (r1, r0, may_save_copy,
         insn_number, insn, 0);
      }
    if (win)
      break;
  }
     }
   if (((((insn)->fld[3].rtx))->code) == CLOBBER
       && (r0 = ((((insn)->fld[3].rtx))->fld[0].rtx),
    ((r0)->code) == REG)
       && (link = find_reg_note (insn, REG_LIBCALL, (rtx) 0)) != 0
       && ((link)->fld[0].rtx) != 0
       && ((((link)->fld[0].rtx))->code) == INSN
       && (set = single_set (((link)->fld[0].rtx))) != 0
       && ((set)->fld[0].rtx) == r0 && ((set)->fld[1].rtx) == r0
       && (note = find_reg_note (((link)->fld[0].rtx), REG_EQUAL,
     (rtx) 0)) != 0)
     {
       if (r1 = ((note)->fld[0].rtx), ((r1)->code) == REG

    && no_conflict_p (insn, r0, r1))
  win = combine_regs (r1, r0, 1, insn_number, insn, 1);
       else if ((rtx_format[(int)(((((note)->fld[0].rtx))->code))])[0] == 'e'
         && (r1 = ((((note)->fld[0].rtx))->fld[0].rtx),
      ((r1)->code) == REG || ((r1)->code) == SUBREG)
         && no_conflict_p (insn, r0, r1))
  win = combine_regs (r1, r0, 0, insn_number, insn, 1);



       else if ((((((note)->fld[0].rtx))->code) == EQ
   || ((((note)->fld[0].rtx))->code) == NE
   || (rtx_class[(int)(((((note)->fld[0].rtx))->code))]) == 'c')
         && (r1 = ((((note)->fld[0].rtx))->fld[1].rtx),
      (((r1)->code) == REG || ((r1)->code) == SUBREG))
         && no_conflict_p (insn, r0, r1))
  win = combine_regs (r1, r0, 0, insn_number, insn, 1);



       if (win)
  no_conflict_combined_regno = ((r1)->fld[0].rtint);
     }






   if (win)
     {
       while (((r1)->code) == SUBREG)
  r1 = ((r1)->fld[0].rtx);
       combined_regno = ((r1)->fld[0].rtint);
     }




   for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
     if (((n64_enum_reg_note) ((link)->mode)) == REG_DEAD
  && ((((link)->fld[0].rtx))->code) == REG
  && combined_regno != ((((link)->fld[0].rtx))->fld[0].rtint)
  && (no_conflict_combined_regno != ((((link)->fld[0].rtx))->fld[0].rtint)
      || ! find_reg_note (insn, REG_NO_CONFLICT, ((link)->fld[0].rtx))))
       wipe_dead_reg (((link)->fld[0].rtx), 0);





   note_stores (((insn)->fld[3].rtx), reg_is_set);







   for (link = ((insn)->fld[6].rtx); link; link = ((link)->fld[1].rtx))
     if (((n64_enum_reg_note) ((link)->mode)) == REG_UNUSED
  && ((((link)->fld[0].rtx))->code) == REG)
       wipe_dead_reg (((link)->fld[0].rtx), 1);



   if (insn_code_number >= 0)
     for (i = 0; i < insn_n_operands[insn_code_number]; i++)
       if (((recog_operand[i])->code) == SCRATCH
    && scratches_allocated++ < scratch_list_length)
  alloc_qty_for_scratch (recog_operand[i], i, insn,
           insn_code_number, insn_number);




   if ((note = find_reg_note (insn, REG_RETVAL, (rtx) 0)) != 0
       && ((((note)->fld[0].rtx))->code) == INSN
       && ((((((note)->fld[0].rtx))->fld[3].rtx))->code) == CLOBBER)
     no_conflict_combined_regno = -1;
 }





      do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_live_at[2 * insn_number]), *scan_fp_ = (regs_live); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_live_at[2 * insn_number + 1]), *scan_fp_ = (regs_live); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

      if (insn == basic_block_end[b])
 break;

      insn = ((insn)->fld[2].rtx);
    }
  qty_order = (int *) 
                     __builtin_alloca((
                     next_qty * sizeof (int)
                     ))
                                                     ;
  for (i = 0; i < next_qty; i++)
    qty_order[i] = i;




  switch (next_qty)
    {
    case 3:

      if (qty_sugg_compare (0, 1) > 0)
 { i = qty_order[0]; qty_order[0] = qty_order[1]; qty_order[1] = i; };
      if (qty_sugg_compare (1, 2) > 0)
 { i = qty_order[2]; qty_order[2] = qty_order[1]; qty_order[1] = i; };


    case 2:

      if (qty_sugg_compare (0, 1) > 0)
 { i = qty_order[0]; qty_order[0] = qty_order[1]; qty_order[1] = i; };



    case 1:
    case 0:

      break;

    default:
      qsort (qty_order, next_qty, sizeof (int), qty_sugg_compare_1);
    }




  for (i = 0; i < next_qty; i++)
    {
      q = qty_order[i];
      if (qty_phys_num_sugg[q] != 0 || qty_phys_num_copy_sugg[q] != 0)
 qty_phys_reg[q] = find_free_reg (qty_min_class[q], qty_mode[q], q,
      0, 1, qty_birth[q], qty_death[q]);
      else
 qty_phys_reg[q] = -1;
    }





  for (i = 0; i < next_qty; i++)
    qty_order[i] = i;




  switch (next_qty)
    {
    case 3:

      if (qty_compare (0, 1) > 0)
 { i = qty_order[0]; qty_order[0] = qty_order[1]; qty_order[1] = i; };
      if (qty_compare (1, 2) > 0)
 { i = qty_order[2]; qty_order[2] = qty_order[1]; qty_order[1] = i; };


    case 2:

      if (qty_compare (0, 1) > 0)
 { i = qty_order[0]; qty_order[0] = qty_order[1]; qty_order[1] = i; };



    case 1:
    case 0:

      break;

    default:
      qsort (qty_order, next_qty, sizeof (int), qty_compare_1);
    }






  for (i = 0; i < next_qty; i++)
    {
      q = qty_order[i];
      if (qty_phys_reg[q] < 0)
 {
   if ((int) LIM_REG_CLASSES > 1)
     {
       qty_phys_reg[q] = find_free_reg (qty_min_class[q],
            qty_mode[q], q, 0, 0,
            qty_birth[q], qty_death[q]);
       if (qty_phys_reg[q] >= 0)
  continue;
     }

   if (qty_alternate_class[q] != NO_REGS)
     qty_phys_reg[q] = find_free_reg (qty_alternate_class[q],
          qty_mode[q], q, 0, 0,
          qty_birth[q], qty_death[q]);
 }
    }




  for (q = 0; q < next_qty; q++)
    if (qty_phys_reg[q] >= 0)
      {
 for (i = qty_first_reg[q]; i >= 0; i = reg_next_in_qty[i])
   reg_renumber[i] = qty_phys_reg[q] + reg_offset[i];
 if (qty_scratch_rtx[q])
   {
     if (((qty_scratch_rtx[q])->code) == REG)
       abort ();
     ((qty_scratch_rtx[q])->code = (REG));
     ((qty_scratch_rtx[q])->fld[0].rtint) = qty_phys_reg[q];

     scratch_block[scratch_index] = b;
     scratch_list[scratch_index++] = qty_scratch_rtx[q];





     qty_scratch_rtx[q]->used = 0;
   }
      }
}
static int
qty_compare(int q1, int q2) asm("_qty_compare");
static int
qty_compare(int q1, int q2)
{




  register int pri1
    = (((double) (floor_log2_wide ((int) (qty_n_refs[q1])) * qty_n_refs[q1] * qty_size[q1])
 / (qty_death[q1] - qty_birth[q1]))
       * 10000);
  register int pri2
    = (((double) (floor_log2_wide ((int) (qty_n_refs[q2])) * qty_n_refs[q2] * qty_size[q2])
 / (qty_death[q2] - qty_birth[q2]))
       * 10000);
  return pri2 - pri1;
}

static int
qty_compare_1(int *q1, int *q2) asm("_qty_compare_1");
static int
qty_compare_1(int *q1, int *q2)
{
  register int tem;





  register int pri1
    = (((double) (floor_log2_wide ((int) (qty_n_refs[*q1])) * qty_n_refs[*q1]
    * qty_size[*q1])
 / (qty_death[*q1] - qty_birth[*q1]))
       * 10000);
  register int pri2
    = (((double) (floor_log2_wide ((int) (qty_n_refs[*q2])) * qty_n_refs[*q2]
    * qty_size[*q2])
 / (qty_death[*q2] - qty_birth[*q2]))
       * 10000);

  tem = pri2 - pri1;
  if (tem != 0) return tem;


  return *q1 - *q2;
}
static int
qty_sugg_compare(int q1, int q2) asm("_qty_sugg_compare");
static int
qty_sugg_compare(int q1, int q2)
{
  register int sugg1 = (qty_phys_num_copy_sugg[q1]
   ? qty_phys_num_copy_sugg[q1]
   : qty_phys_num_sugg[q1] * 68);
  register int sugg2 = (qty_phys_num_copy_sugg[q2]
   ? qty_phys_num_copy_sugg[q2]
   : qty_phys_num_sugg[q2] * 68);




  register int pri1
    = (((double) (floor_log2_wide ((int) (qty_n_refs[q1])) * qty_n_refs[q1] * qty_size[q1])
 / (qty_death[q1] - qty_birth[q1]))
       * 10000);
  register int pri2
    = (((double) (floor_log2_wide ((int) (qty_n_refs[q2])) * qty_n_refs[q2] * qty_size[q2])
 / (qty_death[q2] - qty_birth[q2]))
       * 10000);

  if (sugg1 != sugg2)
    return sugg1 - sugg2;

  return pri2 - pri1;
}

static int
qty_sugg_compare_1(int *q1, int *q2) asm("_qty_sugg_compare_1");
static int
qty_sugg_compare_1(int *q1, int *q2)
{
  register int sugg1 = (qty_phys_num_copy_sugg[*q1]
   ? qty_phys_num_copy_sugg[*q1]
   : qty_phys_num_sugg[*q1] * 68);
  register int sugg2 = (qty_phys_num_copy_sugg[*q2]
   ? qty_phys_num_copy_sugg[*q2]
   : qty_phys_num_sugg[*q2] * 68);





  register int pri1
    = (((double) (floor_log2_wide ((int) (qty_n_refs[*q1])) * qty_n_refs[*q1]
    * qty_size[*q1])
 / (qty_death[*q1] - qty_birth[*q1]))
       * 10000);
  register int pri2
    = (((double) (floor_log2_wide ((int) (qty_n_refs[*q2])) * qty_n_refs[*q2]
    * qty_size[*q2])
 / (qty_death[*q2] - qty_birth[*q2]))
       * 10000);

  if (sugg1 != sugg2)
    return sugg1 - sugg2;

  if (pri1 != pri2)
    return pri2 - pri1;



  return *q1 - *q2;
}
static int
combine_regs(rtx usedreg, rtx setreg, int may_save_copy, int insn_number, rtx insn, int already_dead) asm("_combine_regs");
static int
combine_regs(rtx usedreg, rtx setreg, int may_save_copy, int insn_number, rtx insn, int already_dead)
{
  register int ureg, sreg;
  register int offset = 0;
  int usize, ssize;
  register int sqty;





  while (((usedreg)->code) == SUBREG)
    {
      if ((mode_size[(int)(((((usedreg)->fld[0].rtx))->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 may_save_copy = 0;
      offset += ((usedreg)->fld[1].rtint);
      usedreg = ((usedreg)->fld[0].rtx);
    }
  if (((usedreg)->code) != REG)
    return 0;
  ureg = ((usedreg)->fld[0].rtint);
  usize = ((mode_size[(int) ((usedreg)->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4));

  while (((setreg)->code) == SUBREG)
    {
      if ((mode_size[(int)(((((setreg)->fld[0].rtx))->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 may_save_copy = 0;
      offset -= ((setreg)->fld[1].rtint);
      setreg = ((setreg)->fld[0].rtx);
    }
  if (((setreg)->code) != REG)
    return 0;
  sreg = ((setreg)->fld[0].rtint);
  ssize = ((mode_size[(int) ((setreg)->mode)] + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4));




  if ((ureg >= 68 && reg_qty[ureg] < 0)

      || (offset > 0 && usize + offset > ssize)
      || (offset < 0 && usize + offset < ssize)


      || (ssize > usize && ureg >= 68
   && usize < qty_size[reg_qty[ureg]])

      || (sreg >= 68 && reg_qty[sreg] == -1)



      || (ureg >= 68
   && find_reg_note (insn, REG_NO_CONFLICT, usedreg))



      || ureg == sreg

      || (ureg < 68 && sreg < 68)


      || !(((mode_class[(int)(((usedreg)->mode))]) == MODE_FLOAT || (mode_class[(int)(((usedreg)->mode))]) == MODE_COMPLEX_FLOAT) == ((mode_class[(int)(((setreg)->mode))]) == MODE_FLOAT || (mode_class[(int)(((setreg)->mode))]) == MODE_COMPLEX_FLOAT)))
    return 0;
  if (ureg < 68)
    {


      if (reg_qty[sreg] == -2)
 reg_is_born (setreg, 2 * insn_number);

      if (reg_qty[sreg] >= 0)
 {
   if (may_save_copy
       && ! ((qty_phys_copy_sugg[reg_qty[sreg]])[(ureg) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((ureg) % ((unsigned) 32)))))
     {
       ((qty_phys_copy_sugg[reg_qty[sreg]])[(ureg) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((ureg) % ((unsigned) 32)));
       qty_phys_num_copy_sugg[reg_qty[sreg]]++;
     }
   else if (! ((qty_phys_sugg[reg_qty[sreg]])[(ureg) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((ureg) % ((unsigned) 32)))))
     {
       ((qty_phys_sugg[reg_qty[sreg]])[(ureg) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((ureg) % ((unsigned) 32)));
       qty_phys_num_sugg[reg_qty[sreg]]++;
     }
 }
      return 0;
    }



  if (sreg < 68)
    {
      if (may_save_copy
   && ! ((qty_phys_copy_sugg[reg_qty[ureg]])[(sreg) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((sreg) % ((unsigned) 32)))))
 {
   ((qty_phys_copy_sugg[reg_qty[ureg]])[(sreg) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((sreg) % ((unsigned) 32)));
   qty_phys_num_copy_sugg[reg_qty[ureg]]++;
 }
      else if (! ((qty_phys_sugg[reg_qty[ureg]])[(sreg) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((sreg) % ((unsigned) 32)))))
 {
   ((qty_phys_sugg[reg_qty[ureg]])[(sreg) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((sreg) % ((unsigned) 32)));
   qty_phys_num_sugg[reg_qty[ureg]]++;
 }
      return 0;
    }




  if (reg_qty[sreg] >= -1


      || (current_function_has_nonlocal_label
   && ((reg_n_calls_crossed[ureg] > 0)
       != (reg_n_calls_crossed[sreg] > 0))))
    return 0;





  if ((already_dead || find_regno_note (insn, REG_DEAD, ureg))
      && reg_meets_class_p (sreg, qty_min_class[reg_qty[ureg]]))
    {

      sqty = reg_qty[ureg];
      reg_qty[sreg] = sqty;
      reg_offset[sreg] = reg_offset[ureg] + offset;
      reg_next_in_qty[sreg] = qty_first_reg[sqty];
      qty_first_reg[sqty] = sreg;


      update_qty_class (sqty, sreg);


      qty_n_calls_crossed[sqty] += reg_n_calls_crossed[sreg];
      qty_n_refs[sqty] += reg_n_refs[sreg];
      if (usize < ssize)
 {
   register int i;

   for (i = qty_first_reg[sqty]; i >= 0; i = reg_next_in_qty[i])
     reg_offset[i] -= offset;

   qty_size[sqty] = ssize;
   qty_mode[sqty] = ((setreg)->mode);
 }
    }
  else
    return 0;

  return 1;
}





static int
reg_meets_class_p(int reg, n64_enum_reg_class cxx_class) asm("_reg_meets_class_p");
static int
reg_meets_class_p(int reg, n64_enum_reg_class cxx_class)
{
  register n64_enum_reg_class rclass = reg_preferred_class (reg);
  return (reg_class_subset_p (rclass, cxx_class)
   || reg_class_subset_p (cxx_class, rclass));
}




static int
reg_classes_overlap_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2, int call_saved) asm("_reg_classes_overlap_p");
static int
reg_classes_overlap_p(register n64_enum_reg_class c1, register n64_enum_reg_class c2, int call_saved)
{
  HARD_REG_SET c;
  int i;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[(int) c1]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (c), *scan_fp_ = (reg_class_contents[(int) c2]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= *scan_fp_++; } while (0);

  for (i = 0; i < 68; i++)
    if (((c)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
 && (! call_saved || ! call_used_regs[i]))
      return 1;

  return 0;
}



static void
update_qty_class(int qty, int reg) asm("_update_qty_class");
static void
update_qty_class(int qty, int reg)
{
  n64_enum_reg_class rclass = reg_preferred_class (reg);
  if (reg_class_subset_p (rclass, qty_min_class[qty]))
    qty_min_class[qty] = rclass;

  rclass = reg_alternate_class (reg);
  if (reg_class_subset_p (rclass, qty_alternate_class[qty]))
    qty_alternate_class[qty] = rclass;

  if (reg_changes_size[reg])
    qty_changes_size[qty] = 1;
}
static void
reg_is_set(rtx reg, rtx setter) asm("_reg_is_set");
static void
reg_is_set(rtx reg, rtx setter)
{



  if (((reg)->code) != SUBREG
      && ((reg)->code) != REG)
    return;





  reg_is_born (reg, 2 * this_insn_number - (((setter)->code) == CLOBBER));
}




static void
reg_is_born(rtx reg, int birth) asm("_reg_is_born");
static void
reg_is_born(rtx reg, int birth)
{
  register int regno;

  if (((reg)->code) == SUBREG)
    regno = ((((reg)->fld[0].rtx))->fld[0].rtint) + ((reg)->fld[1].rtint);
  else
    regno = ((reg)->fld[0].rtint);

  if (regno < 68)
    {
      mark_life (regno, ((reg)->mode), 1);



      if (birth < 2 * this_insn_number)
 post_mark_life (regno, ((reg)->mode), 1, birth, 2 * this_insn_number);
    }
  else
    {
      if (reg_qty[regno] == -2)
 alloc_qty (regno, ((reg)->mode), (((mode_size[(int)(((regno_reg_rtx[regno])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)), birth);


      if (reg_qty[regno] >= 0)
 qty_death[reg_qty[regno]] = -1;
    }
}






static void
wipe_dead_reg(register rtx reg, int output_p) asm("_wipe_dead_reg");
static void
wipe_dead_reg(register rtx reg, int output_p)
{
  register int regno = ((reg)->fld[0].rtint);





  if (((((this_insn)->fld[3].rtx))->code) == PARALLEL
      && !single_set (this_insn))
    {
      int i;
      for (i = ((((this_insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
 {
   rtx set = ((((this_insn)->fld[3].rtx))->fld[0].rtvec->elem[i].rtx);
   if (((set)->code) == SET
       && ((((set)->fld[0].rtx))->code) != REG
       && !rtx_equal_p (reg, ((set)->fld[0].rtx))
       && reg_overlap_mentioned_p (reg, ((set)->fld[0].rtx)))
     output_p = 1;
 }
    }




  if (! output_p && find_regno_note (this_insn, REG_INC, regno))
    output_p = 1;

  if (regno < 68)
    {
      mark_life (regno, ((reg)->mode), 0);




      if (output_p)
 post_mark_life (regno, ((reg)->mode), 1,
   2 * this_insn_number, 2 * this_insn_number+ 1);
    }

  else if (reg_qty[regno] >= 0)
    qty_death[reg_qty[regno]] = 2 * this_insn_number + output_p;
}
static int
find_free_reg(n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, int qty, int accept_call_clobbered, int just_try_suggested, int born_index, int dead_index) asm("_find_free_reg");
static int
find_free_reg(n64_enum_reg_class cxx_class, n64_enum_machine_mode mode, int qty, int accept_call_clobbered, int just_try_suggested, int born_index, int dead_index)
{
  register int i, ins;



    HARD_REG_SET used, first_used;

  static struct {int from, to; } eliminables[] = {{ 0, (0 + 29)}, { 0, (0 + 30)}, { (0 + 30), (0 + 29)}};



  if (born_index < 0 || born_index > dead_index)
    abort ();



  if (current_function_has_nonlocal_label
      && qty_n_calls_crossed[qty] > 0)
    return -1;

  if (accept_call_clobbered)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (call_fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  else if (qty_n_calls_crossed[qty] == 0)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (fixed_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  else
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (call_used_reg_set); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);

  for (ins = born_index; ins < dead_index; ins++)
    do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (regs_live_at[ins]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (used), *scan_fp_ = (reg_class_contents[(int) cxx_class]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0);
  for (i = 0; i < sizeof eliminables / sizeof eliminables[0]; i++)
    ((used)[(eliminables[i].from) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((eliminables[i].from) % ((unsigned) 32)));
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (first_used), *scan_fp_ = (used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);

  if (just_try_suggested)
    {
      if (qty_phys_num_copy_sugg[qty] != 0)
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (first_used), *scan_fp_ = (qty_phys_copy_sugg[qty]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0);
      else
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (first_used), *scan_fp_ = (qty_phys_sugg[qty]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= ~ *scan_fp_++; } while (0);
    }


  do { register HARD_REG_ELT_TYPE *scan_xp_ = (reg_class_contents[(int) ALL_REGS]), *scan_yp_ = (first_used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) if (0 != (*scan_xp_++ & ~ *scan_yp_++)) break; if (i == ((68 + 32 - 1) / 32)) goto fail; } while (0);



  for (i = 0; i < 68; i++)
    {



      int regno = i;

      if (! ((first_used)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
   && mips_hard_regno_mode_ok[ (int)(mode) ][ (regno) ])
 {
   register int j;
   register int size1 = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   for (j = 1; j < size1 && ! ((used)[(regno + j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + j) % ((unsigned) 32)))); j++);
   if (j == size1)
     {


       post_mark_life (regno, mode, 1, born_index, dead_index);
       return regno;
     }

   i += j;

 }
    }

 fail:







  if (just_try_suggested && qty_phys_num_copy_sugg[qty] != 0
      && qty_phys_num_sugg[qty] != 0)
    {

      qty_phys_num_copy_sugg[qty] = 0;
      return find_free_reg (cxx_class, mode, qty, accept_call_clobbered, 1,
       born_index, dead_index);
    }





  if (! accept_call_clobbered
      && flag_caller_saves
      && ! just_try_suggested
      && qty_n_calls_crossed[qty] != 0
      && (4 * (qty_n_calls_crossed[qty]) < (qty_n_refs[qty])))
    {
      i = find_free_reg (cxx_class, mode, qty, 1, 0, born_index, dead_index);
      if (i >= 0)
 caller_save_needed = 1;
      return i;
    }
  return -1;
}





static void
mark_life(register int regno, n64_enum_machine_mode mode, int life) asm("_mark_life");
static void
mark_life(register int regno, n64_enum_machine_mode mode, int life)
{
  register int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  if (life)
    while (--j >= 0)
      ((regs_live)[(regno + j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno + j) % ((unsigned) 32)));
  else
    while (--j >= 0)
      ((regs_live)[(regno + j) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((regno + j) % ((unsigned) 32))));
}





static void
post_mark_life(int regno, n64_enum_machine_mode mode, int life, int birth, int death) asm("_post_mark_life");
static void
post_mark_life(int regno, n64_enum_machine_mode mode, int life, int birth, int death)
{
  register int j = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));



    HARD_REG_SET this_reg;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (this_reg); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  while (--j >= 0)
    ((this_reg)[(regno + j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno + j) % ((unsigned) 32)));

  if (life)
    while (birth < death)
      {
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_live_at[birth]), *scan_fp_ = (this_reg); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ |= *scan_fp_++; } while (0);
 birth++;
      }
  else
    while (birth < death)
      {
 do { register HARD_REG_ELT_TYPE *scan_tp_ = (regs_live_at[birth]), *scan_fp_ = (this_reg); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ &= ~ *scan_fp_++; } while (0);
 birth++;
      }
}
static int
no_conflict_p(rtx insn, rtx r0, rtx r1) asm("_no_conflict_p");
static int
no_conflict_p(rtx insn, rtx r0, rtx r1)
{
  int ok = 0;
  rtx note = find_reg_note (insn, REG_LIBCALL, (rtx) 0);
  rtx p, last;




  if (note == 0
      || (((r1)->code) == REG && ((r1)->fld[0].rtint) < 68)
      || (((r1)->code) == SUBREG && ((((r1)->fld[0].rtx))->code) == REG
   && ((((r1)->fld[0].rtx))->fld[0].rtint) < 68))
    return 0;

  last = ((note)->fld[0].rtx);

  for (p = ((insn)->fld[2].rtx); p && p != last; p = ((p)->fld[2].rtx))
    if ((rtx_class[(int)(((p)->code))]) == 'i')
      {
 if (find_reg_note (p, REG_DEAD, r1))
   ok = 1;

 if (reg_mentioned_p (r1, ((p)->fld[3].rtx))
     && ! find_reg_note (p, REG_NO_CONFLICT, r1))
   return 0;
      }

  return ok;
}







static int
requires_inout(char *p) asm("_requires_inout");
static int
requires_inout(char *p)
{
  char c;
  int found_zero = 0;
  int reg_allowed = 0;
  int num_matching_alts = 0;

  while (c = *p++)
    switch (c)
      {
      case '=': case '+': case '?':
      case '#': case '&': case '!':
      case '*': case '%':
      case '1': case '2': case '3': case '4':
      case 'm': case '<': case '>': case 'V': case 'o':
      case 'E': case 'F': case 'G': case 'H':
      case 's': case 'i': case 'n':
      case 'I': case 'J': case 'K': case 'L':
      case 'M': case 'N': case 'O': case 'P':

      case 'Q': case 'R': case 'S': case 'T': case 'U':

      case 'X':

 break;

      case ',':
 if (found_zero && ! reg_allowed)
   num_matching_alts++;

 found_zero = reg_allowed = 0;
 break;

      case '0':
 found_zero = 1;
 break;

      case 'p':
      case 'g': case 'r':
      default:
 reg_allowed = 1;
 break;
      }

  if (found_zero && ! reg_allowed)
    num_matching_alts++;

  return num_matching_alts;
}


void
dump_local_alloc(FILE *file) asm("_dump_local_alloc");
void
dump_local_alloc(FILE *file)
{
  register int i;
  for (i = 68; i < max_regno; i++)
    if (reg_renumber[i] != -1)
      fprintf (file, ";; Register %d in %d.\n", i, reg_renumber[i]);
}

