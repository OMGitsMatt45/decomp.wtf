// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/ecofflink.c
/* Routines to link ECOFF debugging information.
   Copyright 1993 Free Software Foundation, Inc.
   Written by Ian Lance Taylor, Cygnus Support, <ian@cygnus.com>.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__IMAGE_DATA_DIRECTORY;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_accumulate;
struct n64_tag_areltdata;
struct n64_tag_artdata;
union n64_tag_aux_ext;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_ecoff_fdrtab_entry;
struct n64_tag_ecoff_find_line;
struct n64_tag_ecoff_value_adjust;
struct n64_tag_fdr;
struct n64_tag_internal_aouthdr;
union n64_tag_internal_auxent;
struct n64_tag_internal_extra_pe_aouthdr;
struct n64_tag_internal_extra_pe_filehdr;
struct n64_tag_internal_filehdr;
struct n64_tag_internal_lineno;
struct n64_tag_internal_reloc;
struct n64_tag_internal_scnhdr;
struct n64_tag_internal_syment;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_pdr;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_rndx_ext;
struct n64_tag_sec;
struct n64_tag_shuffle;
struct n64_tag_string_hash_entry;
struct n64_tag_string_hash_table;
struct n64_tag_symbol_cache_entry;
struct n64_tag_tir_ext;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_ecoff_debug_info *input_debug, const struct n64_tag_ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct n64_tag_ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, const char *name, struct n64_tag_ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct n64_tag_ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct n64_tag_ecoff_debug_info * const, const struct n64_tag_ecoff_debug_swap * const, struct n64_tag_ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");

enum n64_cpp_enum___stab_debug_code{
N_GSYM=0x20,



N_FNAME=0x22,




N_FUN=0x24,



N_STSYM=0x26,


N_LCSYM=0x28,


N_MAIN=0x2a,


N_ROSYM=0x2c,



N_PC=0x30,


N_NSYMS=0x32,


N_NOMAP=0x34,






N_OBJ=0x38,




N_OPT=0x3c,


N_RSYM=0x40,


N_M2C=0x42,




N_SLINE=0x44,


N_DSLINE=0x46,


N_BSLINE=0x48,




N_BROWS=0x48,





N_DEFD=0x4a,


N_FLINE=0x4C,




N_EHDECL=0x50,

N_MOD2=0x50,






N_CATCH=0x54,


N_SSYM=0x60,


N_ENDM=0x62,
N_SO=0x64,



N_LSYM=0x80,




N_BINCL=0x82,



N_SOL=0x84,



N_PSYM=0xa0,





N_EINCL=0xa2,


N_ENTRY=0xa4,






N_LBRAC=0xc0,





N_EXCL=0xc2,


N_SCOPE=0xc4,




N_RBRAC=0xe0,


N_BCOMM=0xe2,



N_ECOMM=0xe4,



N_ECOML=0xe8,


N_WITH=0xea,




N_NBTEXT=0xF0,
N_NBDATA=0xF2,
N_NBBSS=0xF4,
N_NBSTS=0xF6,
N_NBLCS=0xF8,



N_LENG=0xfe,
LAST_UNUSED_STAB_CODE
};
typedef __underlying_type(enum n64_cpp_enum___stab_debug_code) n64_enum___stab_debug_code;

struct n64_tag_internal_extra_pe_filehdr
{

  unsigned short e_magic;
  unsigned short e_cblp;
  unsigned short e_cp;
  unsigned short e_crlc;
  unsigned short e_cparhdr;
  unsigned short e_minalloc;
  unsigned short e_maxalloc;
  unsigned short e_ss;
  unsigned short e_sp;
  unsigned short e_csum;
  unsigned short e_ip;
  unsigned short e_cs;
  unsigned short e_lfarlc;
  unsigned short e_ovno;
  unsigned short e_res[4];
  unsigned short e_oemid;
  unsigned short e_oeminfo;
  unsigned short e_res2[10];
  bfd_vma e_lfanew;
  unsigned long dos_message[16];
  bfd_vma nt_signature;
};

struct n64_tag_internal_filehdr
{
  struct n64_tag_internal_extra_pe_filehdr pe;


  unsigned short f_magic;
  unsigned short f_nscns;
  long f_timdat;
  bfd_vma f_symptr;
  long f_nsyms;
  unsigned short f_opthdr;
  unsigned short f_flags;
};
typedef struct n64_tag__IMAGE_DATA_DIRECTORY
{
  bfd_vma VirtualAddress;
  long Size;
} IMAGE_DATA_DIRECTORY;
struct n64_tag_internal_extra_pe_aouthdr
{

  bfd_vma ImageBase;


  bfd_vma SectionAlignment;
  bfd_vma FileAlignment;
  short MajorOperatingSystemVersion;
  short MinorOperatingSystemVersion;
  short MajorImageVersion;
  short MinorImageVersion;
  short MajorSubsystemVersion;
  short MinorSubsystemVersion;
  long Reserved1;
  long SizeOfImage;
  long SizeOfHeaders;
  long CheckSum;
  short Subsystem;
  short DllCharacteristics;
  bfd_vma SizeOfStackReserve;
  bfd_vma SizeOfStackCommit;

  bfd_vma SizeOfHeapReserve;
  bfd_vma SizeOfHeapCommit;
  long LoaderFlags;
  long NumberOfRvaAndSizes;
  IMAGE_DATA_DIRECTORY DataDirectory[16];
};


struct n64_tag_internal_aouthdr
{
  short magic;
  short vstamp;
  bfd_vma tsize;
  bfd_vma dsize;
  bfd_vma bsize;
  bfd_vma entry;
  bfd_vma text_start;
  bfd_vma data_start;


  unsigned long tagentries;


  unsigned long o_toc;
  short o_snentry;
  short o_sntext;
  short o_sndata;
  short o_sntoc;
  short o_snloader;
  short o_snbss;
  short o_algntext;
  short o_algndata;
  short o_modtype;
  short o_cputype;
  unsigned long o_maxstack;
  unsigned long o_maxdata;


  bfd_vma bss_start;
  bfd_vma gp_value;
  unsigned long gprmask;
  unsigned long cprmask[4];
  unsigned long fprmask;


  long o_inlib;
  long o_sri;
  long vid[2];


  struct n64_tag_internal_extra_pe_aouthdr pe;

};
struct n64_tag_internal_scnhdr
{
  char s_name[8];
  bfd_vma s_paddr;
  bfd_vma s_vaddr;
  bfd_vma s_size;
  bfd_vma s_scnptr;
  bfd_vma s_relptr;
  bfd_vma s_lnnoptr;
  unsigned long s_nreloc;
  unsigned long s_nlnno;
  long s_flags;
  long s_align;
};
struct n64_tag_internal_lineno
{
  union
  {
    long l_symndx;
    long l_paddr;
  } l_addr;
  unsigned long l_lnno;
};







struct n64_tag_internal_syment
{
  union
  {
    char _n_name[8];
    struct
    {
      long _n_zeroes;
      long _n_offset;
    } _n_n;
    char *_n_nptr[2];
  } _n;
  long n_value;
  short n_scnum;
  unsigned short n_flags;
  unsigned short n_type;
  unsigned char n_sclass;
  unsigned char n_numaux;
};
union n64_tag_internal_auxent
{
  struct
  {

    union
    {
      long l;
      struct coff_ptr_struct *p;
    } x_tagndx;

    union
    {
      struct
      {
 unsigned short x_lnno;
 unsigned short x_size;
      } x_lnsz;
      long x_fsize;
    } x_misc;

    union
    {
      struct
      {
 long x_lnnoptr;
 union
 {
   long l;
   struct coff_ptr_struct *p;
 } x_endndx;
      } x_fcn;

      struct
      {
 unsigned short x_dimen[4];
      } x_ary;
    } x_fcnary;

    unsigned short x_tvndx;
  } x_sym;

  union
  {
    char x_fname[14];
    struct
    {
      long x_zeroes;
      long x_offset;
    } x_n;
  } x_file;

  struct
  {
    long x_scnlen;
    unsigned short x_nreloc;
    unsigned short x_nlinno;
  } x_scn;

  struct
  {
    long x_tvfill;
    unsigned short x_tvlen;
    unsigned short x_tvran[2];
  } x_tv;




  struct
  {
    union
      {
 long l;
 struct coff_ptr_struct *p;
      } x_scnlen;
    long x_parmhash;
    unsigned short x_snhash;
    unsigned char x_smtyp;


    unsigned char x_smclas;
    long x_stab;
    unsigned short x_snstab;
  } x_csect;
  struct
  {


    long x_stindx;
  } x_sc;

  struct
  {
    unsigned long x_balntry;
  } x_bal;

  struct
  {
    unsigned long x_timestamp;
    char x_idstring[20];
  } x_ident;

};



struct n64_tag_internal_reloc
{
  bfd_vma r_vaddr;
  long r_symndx;
  unsigned short r_type;
  unsigned char r_size;
  unsigned char r_extern;
  unsigned long r_offset;
};
typedef struct {
 short magic;
 short vstamp;
 long ilineMax;
 bfd_vma cbLine;
 bfd_vma cbLineOffset;
 long idnMax;
 bfd_vma cbDnOffset;
 long ipdMax;
 bfd_vma cbPdOffset;
 long isymMax;
 bfd_vma cbSymOffset;
 long ioptMax;
 bfd_vma cbOptOffset;
 long iauxMax;
 bfd_vma cbAuxOffset;
 long issMax;
 bfd_vma cbSsOffset;
 long issExtMax;
 bfd_vma cbSsExtOffset;
 long ifdMax;
 bfd_vma cbFdOffset;
 long crfd;
 bfd_vma cbRfdOffset;
 long iextMax;
 bfd_vma cbExtOffset;

 } HDRR, *pHDRR;
typedef struct n64_tag_fdr {
 bfd_vma adr;
 long rss;
 long issBase;
 bfd_vma cbSs;
 long isymBase;
 long csym;
 long ilineBase;
 long cline;
 long ioptBase;
 long copt;
 unsigned short ipdFirst;
 short cpd;
 long iauxBase;
 long caux;
 long rfdBase;
 long crfd;
 unsigned lang: 5;
 unsigned fMerge : 1;
 unsigned fReadin : 1;
 unsigned fBigendian : 1;

 unsigned glevel : 2;
 unsigned reserved : 22;
 bfd_vma cbLineOffset;
 bfd_vma cbLine;
 } FDR, *pFDR;
typedef struct n64_tag_pdr {
 bfd_vma adr;
 long isym;
 long iline;
 long regmask;
 long regoffset;
 long iopt;
 long fregmask;
 long fregoffset;
 long frameoffset;
 short framereg;
 short pcreg;
 long lnLow;
 long lnHigh;
 bfd_vma cbLineOffset;

 unsigned gp_prologue : 8;
 unsigned gp_used : 1;
 unsigned reg_frame : 1;
 unsigned prof : 1;
 unsigned reserved : 13;
 unsigned localoff : 8;
 } PDR, *pPDR;
typedef long LINER, *pLINER;
typedef struct {
 long iss;
 bfd_vma value;
 unsigned st : 6;
 unsigned sc : 5;
 unsigned reserved : 1;
 unsigned index : 20;
 } SYMR, *pSYMR;
typedef struct n64_tag_ecoff_extr {
 unsigned jmptbl:1;
 unsigned cobol_main:1;
 unsigned weakext:1;
 unsigned reserved:13;
 int ifd;
 SYMR asym;
 } EXTR, *pEXTR;
typedef struct {
 unsigned fBitfield : 1;
 unsigned continued : 1;
 unsigned bt : 6;
 unsigned tq4 : 4;
 unsigned tq5 : 4;

 unsigned tq0 : 4;
 unsigned tq1 : 4;
 unsigned tq2 : 4;
 unsigned tq3 : 4;
 } TIR, *pTIR;
typedef struct {
 unsigned rfd : 12;
 unsigned index : 20;
 } RNDXR, *pRNDXR;






typedef struct {
 unsigned long rfd;
 unsigned long index;
 } DNR, *pDNR;
typedef union {
 TIR ti;
 RNDXR rndx;
 long dnLow;
 long dnHigh;
 long isym;
 long iss;
 long width;
 long count;
 } AUXU, *pAUXU;
typedef struct {
 unsigned ot: 8;
 unsigned value: 24;
 RNDXR rndx;
 unsigned long offset;
 } OPTR, *pOPTR;
typedef long RFDT, *pRFDT;
typedef long FIT, *pFIT;
struct n64_tag_tir_ext {
 unsigned char t_bits1[1];
 unsigned char t_tq45[1];
 unsigned char t_tq01[1];
 unsigned char t_tq23[1];
};
struct n64_tag_rndx_ext {
 unsigned char r_bits[4];
};
union n64_tag_aux_ext {
 struct n64_tag_tir_ext a_ti;
 struct n64_tag_rndx_ext a_rndx;
 unsigned char a_dnLow[4];
 unsigned char a_dnHigh[4];
 unsigned char a_isym[4];
 unsigned char a_iss[4];
 unsigned char a_width[4];
 unsigned char a_count[4];
};
struct n64_tag_ecoff_debug_info
{

  HDRR symbolic_header;
  unsigned char *line;
  void * external_dnr;
  void * external_pdr;
  void * external_sym;
  void * external_opt;
  union n64_tag_aux_ext *external_aux;
  char *ss;
  char *ssext;
  void * external_fdr;
  void * external_rfd;
  void * external_ext;



  char *ssext_end;
  void * external_ext_end;




  RFDT *ifdmap;





  FDR *fdr;







  struct n64_tag_ecoff_value_adjust *adjust;
};






struct n64_tag_ecoff_value_adjust
{

  struct n64_tag_ecoff_value_adjust *next;



  bfd_vma start;

  bfd_vma end;


  long adjust;
};



struct n64_tag_ecoff_fdrtab_entry
{

  bfd_vma base_addr;
  FDR *fdr;
};

struct n64_tag_ecoff_find_line
{

  char *find_buffer;


  long fdrtab_len;
  struct n64_tag_ecoff_fdrtab_entry *fdrtab;
};
struct n64_tag_ecoff_debug_swap
{

  int sym_magic;

  bfd_size_type debug_align;

  bfd_size_type external_hdr_size;
  bfd_size_type external_dnr_size;
  bfd_size_type external_pdr_size;
  bfd_size_type external_sym_size;
  bfd_size_type external_opt_size;
  bfd_size_type external_fdr_size;
  bfd_size_type external_rfd_size;
  bfd_size_type external_ext_size;

  void (*swap_hdr_in) (bfd *, void *, HDRR *);
  void (*swap_dnr_in) (bfd *, void *, DNR *);
  void (*swap_pdr_in) (bfd *, void *, PDR *);
  void (*swap_sym_in) (bfd *, void *, SYMR *);
  void (*swap_opt_in) (bfd *, void *, OPTR *);
  void (*swap_fdr_in) (bfd *, void *, FDR *);
  void (*swap_rfd_in) (bfd *, void *, RFDT *);
  void (*swap_ext_in) (bfd *, void *, EXTR *);
  void (*swap_tir_in) (int, const struct n64_tag_tir_ext *, TIR *);
  void (*swap_rndx_in) (int, const struct n64_tag_rndx_ext *, RNDXR *);

  void (*swap_hdr_out) (bfd *, const HDRR *, void *);
  void (*swap_dnr_out) (bfd *, const DNR *, void *);
  void (*swap_pdr_out) (bfd *, const PDR *, void *);
  void (*swap_sym_out) (bfd *, const SYMR *, void *);
  void (*swap_opt_out) (bfd *, const OPTR *, void *);
  void (*swap_fdr_out) (bfd *, const FDR *, void *);
  void (*swap_rfd_out) (bfd *, const RFDT *, void *);
  void (*swap_ext_out) (bfd *, const EXTR *, void *);
  void (*swap_tir_out) (int, const TIR *, struct n64_tag_tir_ext *);
  void (*swap_rndx_out) (int, const RNDXR *, struct n64_tag_rndx_ext *);



  boolean (*read_debug_info) (bfd *, asection *, struct n64_tag_ecoff_debug_info *)
                                     ;
};

static boolean ecoff_add_bytes (char **buf, char **bufend, size_t need) asm("_ecoff_add_bytes")
                  ;
static struct n64_tag_bfd_hash_entry *string_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_string_hash_newfunc")
                  ;
static void ecoff_align_debug (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_ecoff_align_debug")

                                                ;
static boolean ecoff_write_symhdr (bfd *, struct n64_tag_ecoff_debug_info *, const struct n64_tag_ecoff_debug_swap *, file_ptr where) asm("_ecoff_write_symhdr")

                        ;
static int cmp_fdrtab_entry (const void *, const void *) asm("_cmp_fdrtab_entry");
static boolean mk_fdrtab (bfd *, struct n64_tag_ecoff_debug_info * const, const struct n64_tag_ecoff_debug_swap * const, struct n64_tag_ecoff_find_line *) asm("_mk_fdrtab")


                                ;
static long fdrtab_lookup (struct n64_tag_ecoff_find_line *, bfd_vma) asm("_fdrtab_lookup");
void
_bfd_ecoff_swap_tir_in(int bigend, const struct n64_tag_tir_ext *ext_copy, TIR *intern) asm("__bfd_ecoff_swap_tir_in");
void
_bfd_ecoff_swap_tir_in(int bigend, const struct n64_tag_tir_ext *ext_copy, TIR *intern)
{
  struct n64_tag_tir_ext ext[1];

  *ext = *ext_copy;


  if (bigend) {
    intern->fBitfield = 0 != (ext->t_bits1[0] & ((unsigned int) 0x80));
    intern->continued = 0 != (ext->t_bits1[0] & ((unsigned int) 0x40));
    intern->bt = (ext->t_bits1[0] & ((unsigned int) 0x3F))
   >> 0;
    intern->tq4 = (ext->t_tq45[0] & ((unsigned int) 0xF0))
   >> 4;
    intern->tq5 = (ext->t_tq45[0] & ((unsigned int) 0x0F))
   >> 0;
    intern->tq0 = (ext->t_tq01[0] & ((unsigned int) 0xF0))
   >> 4;
    intern->tq1 = (ext->t_tq01[0] & ((unsigned int) 0x0F))
   >> 0;
    intern->tq2 = (ext->t_tq23[0] & ((unsigned int) 0xF0))
   >> 4;
    intern->tq3 = (ext->t_tq23[0] & ((unsigned int) 0x0F))
   >> 0;
  } else {
    intern->fBitfield = 0 != (ext->t_bits1[0] & ((unsigned int) 0x01));
    intern->continued = 0 != (ext->t_bits1[0] & ((unsigned int) 0x02));
    intern->bt = (ext->t_bits1[0] & ((unsigned int) 0xFC))
   >> 2;
    intern->tq4 = (ext->t_tq45[0] & ((unsigned int) 0x0F))
   >> 0;
    intern->tq5 = (ext->t_tq45[0] & ((unsigned int) 0xF0))
   >> 4;
    intern->tq0 = (ext->t_tq01[0] & ((unsigned int) 0x0F))
   >> 0;
    intern->tq1 = (ext->t_tq01[0] & ((unsigned int) 0xF0))
   >> 4;
    intern->tq2 = (ext->t_tq23[0] & ((unsigned int) 0x0F))
   >> 0;
    intern->tq3 = (ext->t_tq23[0] & ((unsigned int) 0xF0))
   >> 4;
  }





}





void
_bfd_ecoff_swap_tir_out(int bigend, const TIR *intern_copy, struct n64_tag_tir_ext *ext) asm("__bfd_ecoff_swap_tir_out");
void
_bfd_ecoff_swap_tir_out(int bigend, const TIR *intern_copy, struct n64_tag_tir_ext *ext)
{
  TIR intern[1];

  *intern = *intern_copy;


  if (bigend) {
    ext->t_bits1[0] = ((intern->fBitfield ? ((unsigned int) 0x80) : 0)
         | (intern->continued ? ((unsigned int) 0x40) : 0)
         | ((intern->bt << 0)
     & ((unsigned int) 0x3F)));
    ext->t_tq45[0] = (((intern->tq4 << 4)
         & ((unsigned int) 0xF0))
        | ((intern->tq5 << 0)
    & ((unsigned int) 0x0F)));
    ext->t_tq01[0] = (((intern->tq0 << 4)
         & ((unsigned int) 0xF0))
        | ((intern->tq1 << 0)
    & ((unsigned int) 0x0F)));
    ext->t_tq23[0] = (((intern->tq2 << 4)
         & ((unsigned int) 0xF0))
        | ((intern->tq3 << 0)
    & ((unsigned int) 0x0F)));
  } else {
    ext->t_bits1[0] = ((intern->fBitfield ? ((unsigned int) 0x01) : 0)
         | (intern->continued ? ((unsigned int) 0x02) : 0)
         | ((intern->bt << 2)
     & ((unsigned int) 0xFC)));
    ext->t_tq45[0] = (((intern->tq4 << 0)
         & ((unsigned int) 0x0F))
        | ((intern->tq5 << 4)
    & ((unsigned int) 0xF0)));
    ext->t_tq01[0] = (((intern->tq0 << 0)
         & ((unsigned int) 0x0F))
        | ((intern->tq1 << 4)
    & ((unsigned int) 0xF0)));
    ext->t_tq23[0] = (((intern->tq2 << 0)
         & ((unsigned int) 0x0F))
        | ((intern->tq3 << 4)
    & ((unsigned int) 0xF0)));
  }





}




void
_bfd_ecoff_swap_rndx_in(int bigend, const struct n64_tag_rndx_ext *ext_copy, RNDXR *intern) asm("__bfd_ecoff_swap_rndx_in");
void
_bfd_ecoff_swap_rndx_in(int bigend, const struct n64_tag_rndx_ext *ext_copy, RNDXR *intern)
{
  struct n64_tag_rndx_ext ext[1];

  *ext = *ext_copy;


  if (bigend) {
    intern->rfd = (ext->r_bits[0] << 4)
    | ((ext->r_bits[1] & ((unsigned int) 0xF0))
            >> 4);
    intern->index = ((ext->r_bits[1] & ((unsigned int) 0x0F))
            << 16)
    | (ext->r_bits[2] << 8)
    | (ext->r_bits[3] << 0);
  } else {
    intern->rfd = (ext->r_bits[0] << 0)
    | ((ext->r_bits[1] & ((unsigned int) 0x0F))
            << 8);
    intern->index = ((ext->r_bits[1] & ((unsigned int) 0xF0))
            >> 4)
    | (ext->r_bits[2] << 4)
    | ((unsigned int) ext->r_bits[3]
       << 12);
  }





}




void
_bfd_ecoff_swap_rndx_out(int bigend, const RNDXR *intern_copy, struct n64_tag_rndx_ext *ext) asm("__bfd_ecoff_swap_rndx_out");
void
_bfd_ecoff_swap_rndx_out(int bigend, const RNDXR *intern_copy, struct n64_tag_rndx_ext *ext)
{
  RNDXR intern[1];

  *intern = *intern_copy;


  if (bigend) {
    ext->r_bits[0] = intern->rfd >> 4;
    ext->r_bits[1] = (((intern->rfd << 4)
         & ((unsigned int) 0xF0))
        | ((intern->index >> 16)
    & ((unsigned int) 0x0F)));
    ext->r_bits[2] = intern->index >> 8;
    ext->r_bits[3] = intern->index >> 0;
  } else {
    ext->r_bits[0] = intern->rfd >> 0;
    ext->r_bits[1] = (((intern->rfd >> 8)
         & ((unsigned int) 0x0F))
        | ((intern->index << 4)
    & ((unsigned int) 0xF0)));
    ext->r_bits[2] = intern->index >> 4;
    ext->r_bits[3] = intern->index >> 12;
  }





}






static boolean
ecoff_add_bytes(char **buf, char **bufend, size_t need) asm("_ecoff_add_bytes");
static boolean
ecoff_add_bytes(char **buf, char **bufend, size_t need)
{
  size_t have;
  size_t want;
  char *newbuf;

  have = *bufend - *buf;
  if (have > need)
    want = (4064);
  else
    {
      want = need - have;
      if (want < (4064))
 want = (4064);
    }
  if (*buf == 
             ((void *)0)
                 )
    newbuf = (char *) malloc (have + want);
  else
    newbuf = (char *) realloc (*buf, have + want);
  if (newbuf == 
               ((void *)0)
                   )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  *buf = newbuf;
  *bufend = *buf + have + want;
  return cxx_true;
}





struct n64_tag_string_hash_entry
{
  struct n64_tag_bfd_hash_entry root;

  long val;

  struct n64_tag_string_hash_entry *next;
};

struct n64_tag_string_hash_table
{
  struct n64_tag_bfd_hash_table table;
};



static struct n64_tag_bfd_hash_entry *
string_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("_string_hash_newfunc");
static struct n64_tag_bfd_hash_entry *
string_hash_newfunc(struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string)
{
  struct n64_tag_string_hash_entry *ret = (struct n64_tag_string_hash_entry *) entry;



  if (ret == (struct n64_tag_string_hash_entry *) 
                                         ((void *)0)
                                             )
    ret = ((struct n64_tag_string_hash_entry *)
    bfd_hash_allocate (table, sizeof (struct n64_tag_string_hash_entry)));
  if (ret == (struct n64_tag_string_hash_entry *) 
                                         ((void *)0)
                                             )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }


  ret = ((struct n64_tag_string_hash_entry *)
  bfd_hash_newfunc ((struct n64_tag_bfd_hash_entry *) ret, table, string));

  if (ret)
    {

      ret->val = -1;
      ret->next = 
                 ((void *)0)
                     ;
    }

  return (struct n64_tag_bfd_hash_entry *) ret;
}
struct n64_tag_shuffle
{

  struct n64_tag_shuffle *next;

  unsigned long size;

  boolean filep;
  union
    {
      struct
 {

   bfd *input_bfd;

   file_ptr offset;
 } file;

      void * memory;
    } u;
};




struct n64_tag_accumulate
{

  struct n64_tag_string_hash_table fdr_hash;

  struct n64_tag_string_hash_table str_hash;



  struct n64_tag_shuffle *line;
  struct n64_tag_shuffle *line_end;
  struct n64_tag_shuffle *pdr;
  struct n64_tag_shuffle *pdr_end;
  struct n64_tag_shuffle *sym;
  struct n64_tag_shuffle *sym_end;
  struct n64_tag_shuffle *opt;
  struct n64_tag_shuffle *opt_end;
  struct n64_tag_shuffle *aux;
  struct n64_tag_shuffle *aux_end;
  struct n64_tag_shuffle *ss;
  struct n64_tag_shuffle *ss_end;
  struct n64_tag_string_hash_entry *ss_hash;
  struct n64_tag_string_hash_entry *ss_hash_end;
  struct n64_tag_shuffle *fdr;
  struct n64_tag_shuffle *fdr_end;
  struct n64_tag_shuffle *rfd;
  struct n64_tag_shuffle *rfd_end;

  unsigned long largest_file_shuffle;

  struct n64_tag_obstack memory;
};



static boolean add_file_shuffle (struct n64_tag_accumulate *, struct n64_tag_shuffle **, struct n64_tag_shuffle **, bfd *, file_ptr, unsigned long) asm("_add_file_shuffle")


                         ;

static boolean
add_file_shuffle(struct n64_tag_accumulate *ainfo, struct n64_tag_shuffle **head, struct n64_tag_shuffle **tail, bfd *input_bfd, file_ptr offset, long unsigned int size) asm("_add_file_shuffle");
static boolean
add_file_shuffle(struct n64_tag_accumulate *ainfo, struct n64_tag_shuffle **head, struct n64_tag_shuffle **tail, bfd *input_bfd, file_ptr offset, long unsigned int size)
{
  struct n64_tag_shuffle *n;

  if (*tail != (struct n64_tag_shuffle *) 
                                 ((void *)0)
      
     && (*tail)->filep
      && (*tail)->u.file.input_bfd == input_bfd
      && (*tail)->u.file.offset + (*tail)->size == (unsigned long) offset)
    {

      (*tail)->size += size;
      if ((*tail)->size > ainfo->largest_file_shuffle)
 ainfo->largest_file_shuffle = (*tail)->size;
      return cxx_true;
    }

  n = (struct n64_tag_shuffle *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_shuffle))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                             ;
  if (!n)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  n->next = 
           ((void *)0)
               ;
  n->size = size;
  n->filep = cxx_true;
  n->u.file.input_bfd = input_bfd;
  n->u.file.offset = offset;
  if (*head == (struct n64_tag_shuffle *) 
                                 ((void *)0)
                                     )
    *head = n;
  if (*tail != (struct n64_tag_shuffle *) 
                                 ((void *)0)
                                     )
    (*tail)->next = n;
  *tail = n;
  if (size > ainfo->largest_file_shuffle)
    ainfo->largest_file_shuffle = size;
  return cxx_true;
}



static boolean add_memory_shuffle (struct n64_tag_accumulate *, struct n64_tag_shuffle **head, struct n64_tag_shuffle **tail, bfd_byte *data, unsigned long size) asm("_add_memory_shuffle")


                                            ;

static boolean
add_memory_shuffle(struct n64_tag_accumulate *ainfo, struct n64_tag_shuffle **head, struct n64_tag_shuffle **tail, bfd_byte *data, long unsigned int size) asm("_add_memory_shuffle");
static boolean
add_memory_shuffle(struct n64_tag_accumulate *ainfo, struct n64_tag_shuffle **head, struct n64_tag_shuffle **tail, bfd_byte *data, long unsigned int size)
{
  struct n64_tag_shuffle *n;

  n = (struct n64_tag_shuffle *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_shuffle))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                             ;
  if (!n)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  n->next = 
           ((void *)0)
               ;
  n->size = size;
  n->filep = cxx_false;
  n->u.memory = (void *) data;
  if (*head == (struct n64_tag_shuffle *) 
                                 ((void *)0)
                                     )
    *head = n;
  if (*tail != (struct n64_tag_shuffle *) 
                                 ((void *)0)
                                     )
    (*tail)->next = n;
  *tail = n;
  return cxx_true;
}





void *
bfd_ecoff_debug_init(bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *info) asm("_bfd_ecoff_debug_init");
void *
bfd_ecoff_debug_init(bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *info)
{
  struct n64_tag_accumulate *ainfo;

  ainfo = (struct n64_tag_accumulate *) malloc (sizeof (struct n64_tag_accumulate));
  if (!ainfo)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  if (! bfd_hash_table_init_n (&ainfo->fdr_hash.table, string_hash_newfunc,
          1021))
    return 
          ((void *)0)
              ;

  ainfo->line = 
               ((void *)0)
                   ;
  ainfo->line_end = 
                   ((void *)0)
                       ;
  ainfo->pdr = 
              ((void *)0)
                  ;
  ainfo->pdr_end = 
                  ((void *)0)
                      ;
  ainfo->sym = 
              ((void *)0)
                  ;
  ainfo->sym_end = 
                  ((void *)0)
                      ;
  ainfo->opt = 
              ((void *)0)
                  ;
  ainfo->opt_end = 
                  ((void *)0)
                      ;
  ainfo->aux = 
              ((void *)0)
                  ;
  ainfo->aux_end = 
                  ((void *)0)
                      ;
  ainfo->ss = 
             ((void *)0)
                 ;
  ainfo->ss_end = 
                 ((void *)0)
                     ;
  ainfo->ss_hash = 
                  ((void *)0)
                      ;
  ainfo->ss_hash_end = 
                      ((void *)0)
                          ;
  ainfo->fdr = 
              ((void *)0)
                  ;
  ainfo->fdr_end = 
                  ((void *)0)
                      ;
  ainfo->rfd = 
              ((void *)0)
                  ;
  ainfo->rfd_end = 
                  ((void *)0)
                      ;

  ainfo->largest_file_shuffle = 0;

  if (! info->relocateable)
    {
      if (! bfd_hash_table_init (&ainfo->str_hash.table, string_hash_newfunc))
 return 
       ((void *)0)
           ;


      output_debug->symbolic_header.issMax = 1;
    }

  if (!_obstack_begin ((&ainfo->memory), (4050), 0, (void *(*)(...)) malloc, (void (*)(...)) free))
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }

  return (void *) ainfo;
}




void
bfd_ecoff_debug_free(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *info) asm("_bfd_ecoff_debug_free");
void
bfd_ecoff_debug_free(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *info)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;

  bfd_hash_table_free (&ainfo->fdr_hash.table);

  if (! info->relocateable)
    bfd_hash_table_free (&ainfo->str_hash.table);

  __extension__ ({ struct n64_tag_obstack *__o = (&ainfo->memory); void *__obj = ((void *) 
 ((void *)0)
 ); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });

  free (ainfo);
}
boolean
bfd_ecoff_debug_accumulate(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_ecoff_debug_info *input_debug, const struct n64_tag_ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *info) asm("_bfd_ecoff_debug_accumulate");
boolean
bfd_ecoff_debug_accumulate(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_ecoff_debug_info *input_debug, const struct n64_tag_ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *info)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;
  void (* const swap_sym_in) (bfd *, void *, SYMR *)
    = input_swap->swap_sym_in;
  void (* const swap_rfd_in) (bfd *, void *, RFDT *)
    = input_swap->swap_rfd_in;
  void (* const swap_sym_out) (bfd *, const SYMR *, void *)
    = output_swap->swap_sym_out;
  void (* const swap_fdr_out) (bfd *, const FDR *, void *)
    = output_swap->swap_fdr_out;
  void (* const swap_rfd_out) (bfd *, const RFDT *, void *)
    = output_swap->swap_rfd_out;
  bfd_size_type external_pdr_size = output_swap->external_pdr_size;
  bfd_size_type external_sym_size = output_swap->external_sym_size;
  bfd_size_type external_opt_size = output_swap->external_opt_size;
  bfd_size_type external_fdr_size = output_swap->external_fdr_size;
  bfd_size_type external_rfd_size = output_swap->external_rfd_size;
  HDRR * const output_symhdr = &output_debug->symbolic_header;
  HDRR * const input_symhdr = &input_debug->symbolic_header;
  bfd_vma section_adjust[32];
  asection *sec;
  bfd_byte *fdr_start;
  bfd_byte *fdr_ptr;
  bfd_byte *fdr_end;
  bfd_size_type fdr_add;
  unsigned int copied;
  RFDT i;
  unsigned long sz;
  bfd_byte *rfd_out;
  bfd_byte *rfd_in;
  bfd_byte *rfd_end;
  long newrfdbase = 0;
  long oldrfdbase = 0;
  bfd_byte *fdr_out;



  memset ((void *) section_adjust, 0, sizeof section_adjust);
  sec = bfd_get_section_by_name (input_bfd, ".text"); if (sec != 
 ((void *)0)
 ) section_adjust[1] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".data"); if (sec != 
 ((void *)0)
 ) section_adjust[2] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".bss"); if (sec != 
 ((void *)0)
 ) section_adjust[3] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".sdata"); if (sec != 
 ((void *)0)
 ) section_adjust[13] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".sbss"); if (sec != 
 ((void *)0)
 ) section_adjust[14] = (sec->output_section->vma + sec->output_offset - sec->vma);;

  sec = bfd_get_section_by_name (input_bfd, ".rdata"); if (sec != 
 ((void *)0)
 ) section_adjust[15] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".rodata"); if (sec != 
 ((void *)0)
 ) section_adjust[15] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".init"); if (sec != 
 ((void *)0)
 ) section_adjust[22] = (sec->output_section->vma + sec->output_offset - sec->vma);;
  sec = bfd_get_section_by_name (input_bfd, ".fini"); if (sec != 
 ((void *)0)
 ) section_adjust[26] = (sec->output_section->vma + sec->output_offset - sec->vma);;





  if (input_debug->fdr != (FDR *) 
                                 ((void *)0)
                                     )
    {
      fdr_start = (bfd_byte *) input_debug->fdr;
      fdr_add = sizeof (FDR);
    }
  else
    {
      fdr_start = (bfd_byte *) input_debug->external_fdr;
      fdr_add = input_swap->external_fdr_size;
    }
  fdr_end = fdr_start + input_symhdr->ifdMax * fdr_add;

  input_debug->ifdmap = (RFDT *) bfd_alloc (input_bfd,
         (input_symhdr->ifdMax
          * sizeof (RFDT)));

  sz = (input_symhdr->crfd + input_symhdr->ifdMax) * external_rfd_size;
  rfd_out = (bfd_byte *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sz)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  if (!input_debug->ifdmap || !rfd_out)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  if (!add_memory_shuffle (ainfo, &ainfo->rfd, &ainfo->rfd_end, rfd_out, sz))
    return cxx_false;

  copied = 0;
  for (fdr_ptr = fdr_start, i = 0;
       fdr_ptr < fdr_end;
       fdr_ptr += fdr_add, i++, rfd_out += external_rfd_size)
    {
      FDR fdr;

      if (input_debug->fdr != (FDR *) 
                                     ((void *)0)
                                         )
 fdr = *(FDR *) fdr_ptr;
      else
 (*input_swap->swap_fdr_in) (input_bfd, (void *) fdr_ptr, &fdr);


      if (fdr.cbLine == 0 && fdr.rss != -1 && fdr.fMerge)
 {
   const char *name;
   char *lookup;
   struct n64_tag_string_hash_entry *fh;







   name = input_debug->ss + fdr.issBase + fdr.rss;

   lookup = (char *) malloc (strlen (name) + 20);
   if (lookup == 
                ((void *)0)
                    )
     {
       bfd_set_error (bfd_error_no_memory);
       return cxx_false;
     }
   sprintf (lookup, "%s %lx", name, fdr.csym);

   fh = ((struct n64_tag_string_hash_entry *) bfd_hash_lookup (&(&ainfo->fdr_hash)->table, (lookup), (cxx_true), (cxx_true)));
   free (lookup);
   if (fh == (struct n64_tag_string_hash_entry *) 
                                         ((void *)0)
                                             )
     return cxx_false;

   if (fh->val != -1)
     {
       input_debug->ifdmap[i] = fh->val;
       (*swap_rfd_out) (output_bfd, input_debug->ifdmap + i,
          (void *) rfd_out);


       continue;
     }

   fh->val = output_symhdr->ifdMax + copied;
 }

      input_debug->ifdmap[i] = output_symhdr->ifdMax + copied;
      (*swap_rfd_out) (output_bfd, input_debug->ifdmap + i, (void *) rfd_out);
      ++copied;
    }

  newrfdbase = output_symhdr->crfd;
  output_symhdr->crfd += input_symhdr->ifdMax;




  rfd_in = (bfd_byte *) input_debug->external_rfd;
  rfd_end = rfd_in + input_symhdr->crfd * input_swap->external_rfd_size;
  for (;
       rfd_in < rfd_end;
       rfd_in += input_swap->external_rfd_size)
    {
      RFDT rfd;

      (*swap_rfd_in) (input_bfd, (void *) rfd_in, &rfd);
      { if (!(rfd >= 0 && rfd < input_symhdr->ifdMax)) bfd_assert("ecofflink.c",771); };
      rfd = input_debug->ifdmap[rfd];
      (*swap_rfd_out) (output_bfd, &rfd, (void *) rfd_out);
      rfd_out += external_rfd_size;
    }

  oldrfdbase = output_symhdr->crfd;
  output_symhdr->crfd += input_symhdr->crfd;



  sz = copied * external_fdr_size;
  fdr_out = (bfd_byte *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sz)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  if (!fdr_out)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  if (!add_memory_shuffle (ainfo, &ainfo->fdr, &ainfo->fdr_end, fdr_out, sz))
    return cxx_false;
  for (fdr_ptr = fdr_start, i = 0;
       fdr_ptr < fdr_end;
       fdr_ptr += fdr_add, i++)
    {
      FDR fdr;
      bfd_vma fdr_adr;
      bfd_byte *sym_out;
      bfd_byte *lraw_src;
      bfd_byte *lraw_end;
      boolean fgotfilename;

      if (input_debug->ifdmap[i] < output_symhdr->ifdMax)
 {

   continue;
 }

      if (input_debug->fdr != (FDR *) 
                                     ((void *)0)
                                         )
 fdr = *(FDR *) fdr_ptr;
      else
 (*input_swap->swap_fdr_in) (input_bfd, (void *) fdr_ptr, &fdr);

      fdr_adr = fdr.adr;



      if (input_debug->adjust != (struct n64_tag_ecoff_value_adjust *) 
                                                              ((void *)0)
                                                                  )
 {
   struct n64_tag_ecoff_value_adjust *adjust;

   for (adjust = input_debug->adjust;
        adjust != (struct n64_tag_ecoff_value_adjust *) 
                                               ((void *)0)
                                                   ;
        adjust = adjust->next)
     if (fdr_adr >= adjust->start
  && fdr_adr < adjust->end)
       fdr.adr += adjust->adjust;
 }




      fdr.adr += section_adjust[1];



      fgotfilename = cxx_false;
      sz = fdr.csym * external_sym_size;
      sym_out = (bfd_byte *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sz)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
      if (!sym_out)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      if (!add_memory_shuffle (ainfo, &ainfo->sym, &ainfo->sym_end, sym_out,
          sz))
 return cxx_false;
      lraw_src = ((bfd_byte *) input_debug->external_sym
    + fdr.isymBase * input_swap->external_sym_size);
      lraw_end = lraw_src + fdr.csym * input_swap->external_sym_size;
      for (; lraw_src < lraw_end; lraw_src += input_swap->external_sym_size)
 {
   SYMR internal_sym;

   (*swap_sym_in) (input_bfd, (void *) lraw_src, &internal_sym);

   { if (!(internal_sym.sc != 17 && internal_sym.sc != 18)) bfd_assert("ecofflink.c",856); }
                                        ;


   switch (internal_sym.st)
     {
     case 0:
       if ((((&internal_sym)->index & 0xFFF00) == 0x8F300))
  break;

     case 1:
     case 2:
     case 5:
     case 6:
     case 14:
       if (input_debug->adjust != (struct n64_tag_ecoff_value_adjust *) 
                                                               ((void *)0)
                                                                   )
  {
    bfd_vma value;
    struct n64_tag_ecoff_value_adjust *adjust;

    value = internal_sym.value;
    for (adjust = input_debug->adjust;
         adjust != (struct n64_tag_ecoff_value_adjust *) 
                                                ((void *)0)
                                                    ;
         adjust = adjust->next)
      if (value >= adjust->start
   && value < adjust->end)
        internal_sym.value += adjust->adjust;
  }
       internal_sym.value += section_adjust[internal_sym.sc];
       break;

     default:
       break;
     }






   if (! info->relocateable)
     {
       boolean ffilename;
       const char *name;

       if (! fgotfilename && internal_sym.iss == fdr.rss)
  ffilename = cxx_true;
       else
  ffilename = cxx_false;


       name = input_debug->ss + fdr.issBase + internal_sym.iss;
       if (*name == '\0')
  internal_sym.iss = 0;
       else
  {
    struct n64_tag_string_hash_entry *sh;

    sh = ((struct n64_tag_string_hash_entry *) bfd_hash_lookup (&(&ainfo->str_hash)->table, (name), (cxx_true), (cxx_true)));
    if (sh == (struct n64_tag_string_hash_entry *) 
                                          ((void *)0)
                                              )
      return cxx_false;
    if (sh->val == -1)
      {
        sh->val = output_symhdr->issMax;
        output_symhdr->issMax += strlen (name) + 1;
        if (ainfo->ss_hash == (struct n64_tag_string_hash_entry *) 
                                                          ((void *)0)
                                                              )
   ainfo->ss_hash = sh;
        if (ainfo->ss_hash_end
     != (struct n64_tag_string_hash_entry *) 
                                    ((void *)0)
                                        )
   ainfo->ss_hash_end->next = sh;
        ainfo->ss_hash_end = sh;
      }
    internal_sym.iss = sh->val;
  }

       if (ffilename)
  {
    fdr.rss = internal_sym.iss;
    fgotfilename = cxx_true;
  }
     }

   (*swap_sym_out) (output_bfd, &internal_sym, sym_out);
   sym_out += external_sym_size;
 }

      fdr.isymBase = output_symhdr->isymMax;
      output_symhdr->isymMax += fdr.csym;







      if (fdr.cbLine > 0)
 {
   if (!add_file_shuffle (ainfo, &ainfo->line, &ainfo->line_end,
     input_bfd,
     input_symhdr->cbLineOffset + fdr.cbLineOffset,
     fdr.cbLine))
     return cxx_false;
   fdr.ilineBase = output_symhdr->ilineMax;
   fdr.cbLineOffset = output_symhdr->cbLine;
   output_symhdr->ilineMax += fdr.cline;
   output_symhdr->cbLine += fdr.cbLine;
 }
      if (fdr.caux > 0)
 {
   if (!add_file_shuffle (ainfo, &ainfo->aux, &ainfo->aux_end,
     input_bfd,
     (input_symhdr->cbAuxOffset
      + fdr.iauxBase * sizeof (union n64_tag_aux_ext)),
     fdr.caux * sizeof (union n64_tag_aux_ext)))
     return cxx_false;
   fdr.iauxBase = output_symhdr->iauxMax;
   output_symhdr->iauxMax += fdr.caux;
 }
      if (! info->relocateable)
 {





   fdr.issBase = 0;
   fdr.cbSs = output_symhdr->issMax;
 }
      else if (fdr.cbSs > 0)
 {
   if (!add_file_shuffle (ainfo, &ainfo->ss, &ainfo->ss_end,
     input_bfd,
     input_symhdr->cbSsOffset + fdr.issBase,
     fdr.cbSs))
     return cxx_false;
   fdr.issBase = output_symhdr->issMax;
   output_symhdr->issMax += fdr.cbSs;
 }

      if ((output_bfd->xvec->header_byteorder_big_p
    == input_bfd->xvec->header_byteorder_big_p)
   && input_debug->adjust == (struct n64_tag_ecoff_value_adjust *) 
                                                          ((void *)0)
                                                              )
 {



   { if (!(external_pdr_size == input_swap->external_pdr_size)) bfd_assert("ecofflink.c",1002); };
   if (fdr.cpd > 0)
     {
       if (!add_file_shuffle (ainfo, &ainfo->pdr, &ainfo->pdr_end,
         input_bfd,
         (input_symhdr->cbPdOffset
          + fdr.ipdFirst * external_pdr_size),
         fdr.cpd * external_pdr_size))
  return cxx_false;
     }
   { if (!(external_opt_size == input_swap->external_opt_size)) bfd_assert("ecofflink.c",1012); };
   if (fdr.copt > 0)
     {
       if (!add_file_shuffle (ainfo, &ainfo->opt, &ainfo->opt_end,
         input_bfd,
         (input_symhdr->cbOptOffset
          + fdr.ioptBase * external_opt_size),
         fdr.copt * external_opt_size))
  return cxx_false;
     }
 }
      else
 {
   bfd_size_type outsz, insz;
   bfd_byte *in;
   bfd_byte *end;
   bfd_byte *out;




   outsz = external_pdr_size;
   insz = input_swap->external_pdr_size;
   in = ((bfd_byte *) input_debug->external_pdr
  + fdr.ipdFirst * insz);
   end = in + fdr.cpd * insz;
   sz = fdr.cpd * outsz;
   out = (bfd_byte *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sz)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
   if (!out)
     {
       bfd_set_error (bfd_error_no_memory);
       return cxx_false;
     }
   if (!add_memory_shuffle (ainfo, &ainfo->pdr, &ainfo->pdr_end, out,
       sz))
     return cxx_false;
   for (; in < end; in += insz, out += outsz)
     {
       PDR pdr;

       (*input_swap->swap_pdr_in) (input_bfd, (void *) in, &pdr);



       if (input_debug->adjust != (struct n64_tag_ecoff_value_adjust *) 
                                                               ((void *)0)
                                                                   )
  {
    bfd_vma adr;
    struct n64_tag_ecoff_value_adjust *adjust;

    adr = fdr_adr + pdr.adr;
    for (adjust = input_debug->adjust;
         adjust != (struct n64_tag_ecoff_value_adjust *) 
                                                ((void *)0)
                                                    ;
         adjust = adjust->next)
      if (adr >= adjust->start
   && adr < adjust->end)
        pdr.adr += adjust->adjust;
  }

       (*output_swap->swap_pdr_out) (output_bfd, &pdr, (void *) out);
     }


   outsz = external_opt_size;
   insz = input_swap->external_opt_size;
   in = ((bfd_byte *) input_debug->external_opt
  + fdr.ioptBase * insz);
   end = in + fdr.copt * insz;
   sz = fdr.copt * outsz;
   out = (bfd_byte *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sz)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
   if (!out)
     {
       bfd_set_error (bfd_error_no_memory);
       return cxx_false;
     }
   if (!add_memory_shuffle (ainfo, &ainfo->opt, &ainfo->opt_end, out,
       sz))
     return cxx_false;
   for (; in < end; in += insz, out += outsz)
     {
       OPTR opt;

       (*input_swap->swap_opt_in) (input_bfd, (void *) in, &opt);
       (*output_swap->swap_opt_out) (output_bfd, &opt, (void *) out);
     }
 }

      fdr.ipdFirst = output_symhdr->ipdMax;
      output_symhdr->ipdMax += fdr.cpd;
      fdr.ioptBase = output_symhdr->ioptMax;
      output_symhdr->ioptMax += fdr.copt;

      if (fdr.crfd <= 0)
 {

   fdr.rfdBase = newrfdbase;
   fdr.crfd = input_symhdr->ifdMax;
 }
      else
 {

   fdr.rfdBase += oldrfdbase;
 }

      (*swap_fdr_out) (output_bfd, &fdr, fdr_out);
      fdr_out += external_fdr_size;
      ++output_symhdr->ifdMax;
    }

  return cxx_true;
}




static long ecoff_add_string (struct n64_tag_accumulate *, struct n64_tag_bfd_link_info *, struct n64_tag_ecoff_debug_info *, FDR *fdr, const char *string) asm("_ecoff_add_string")


                                        ;

static long
ecoff_add_string(struct n64_tag_accumulate *ainfo, struct n64_tag_bfd_link_info *info, struct n64_tag_ecoff_debug_info *debug, FDR *fdr, const char *string) asm("_ecoff_add_string");
static long
ecoff_add_string(struct n64_tag_accumulate *ainfo, struct n64_tag_bfd_link_info *info, struct n64_tag_ecoff_debug_info *debug, FDR *fdr, const char *string)
{
  HDRR *symhdr;
  size_t len;
  bfd_size_type ret;

  symhdr = &debug->symbolic_header;
  len = strlen (string);
  if (info->relocateable)
    {
      if (!add_memory_shuffle (ainfo, &ainfo->ss, &ainfo->ss_end, (void *) string,
          len + 1))
 return -1;
      ret = symhdr->issMax;
      symhdr->issMax += len + 1;
      fdr->cbSs += len + 1;
    }
  else
    {
      struct n64_tag_string_hash_entry *sh;

      sh = ((struct n64_tag_string_hash_entry *) bfd_hash_lookup (&(&ainfo->str_hash)->table, (string), (cxx_true), (cxx_true)));
      if (sh == (struct n64_tag_string_hash_entry *) 
                                            ((void *)0)
                                                )
 return -1;
      if (sh->val == -1)
 {
   sh->val = symhdr->issMax;
   symhdr->issMax += len + 1;
   if (ainfo->ss_hash == (struct n64_tag_string_hash_entry *) 
                                                     ((void *)0)
                                                         )
     ainfo->ss_hash = sh;
   if (ainfo->ss_hash_end
       != (struct n64_tag_string_hash_entry *) 
                                      ((void *)0)
                                          )
     ainfo->ss_hash_end->next = sh;
   ainfo->ss_hash_end = sh;
 }
      ret = sh->val;
    }

  return ret;
}



boolean
bfd_ecoff_debug_accumulate_other(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *info) asm("_bfd_ecoff_debug_accumulate_other");
boolean
bfd_ecoff_debug_accumulate_other(void *handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *info)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;
  void (* const swap_sym_out) (bfd *, const SYMR *, void *)
    = output_swap->swap_sym_out;
  HDRR *output_symhdr = &output_debug->symbolic_header;
  FDR fdr;
  asection *sec;
  asymbol **symbols;
  asymbol **sym_ptr;
  asymbol **sym_end;
  long symsize;
  long symcount;
  void * external_fdr;

  memset ((void *) &fdr, 0, sizeof fdr);

  sec = bfd_get_section_by_name (input_bfd, ".text");
  if (sec != 
            ((void *)0)
                )
    fdr.adr = sec->output_section->vma + sec->output_offset;
  else
    {

      fdr.adr = 0;
    }

  fdr.issBase = output_symhdr->issMax;
  fdr.cbSs = 0;
  fdr.rss = ecoff_add_string (ainfo, info, output_debug, &fdr,
         ((char *) (input_bfd)->filename));
  if (fdr.rss == -1)
    return cxx_false;
  fdr.isymBase = output_symhdr->isymMax;


  symsize = ((*((input_bfd)->xvec->_bfd_get_symtab_upper_bound)) (input_bfd));
  if (symsize < 0)
    return cxx_false;
  symbols = (asymbol **) bfd_alloc (output_bfd, symsize);
  if (symbols == (asymbol **) 
                             ((void *)0)
                                 )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  symcount = ((*((input_bfd)->xvec->_bfd_canonicalize_symtab)) (input_bfd, symbols));
  if (symcount < 0)
    return cxx_false;
  sym_end = symbols + symcount;



  fdr.csym = 0;
  for (sym_ptr = symbols; sym_ptr != sym_end; sym_ptr++)
    {
      SYMR internal_sym;
      void * external_sym;

      if (((*sym_ptr)->flags & 0x02) != 0)
 continue;
      memset ((void *) &internal_sym, 0, sizeof internal_sym);
      internal_sym.iss = ecoff_add_string (ainfo, info, output_debug, &fdr,
        (*sym_ptr)->name);

      if (internal_sym.iss == -1)
 return cxx_false;
      if (((((*sym_ptr)->section)->flags & 0x8000) != 0)
   || (((*sym_ptr)->section) == ((asection *) &bfd_und_section)))
 internal_sym.value = (*sym_ptr)->value;
      else
 internal_sym.value = ((*sym_ptr)->value
         + (*sym_ptr)->section->output_offset
         + (*sym_ptr)->section->output_section->vma);
      internal_sym.st = 0;
      internal_sym.sc = 6;
      internal_sym.index = 0xfffff;

      external_sym = (void *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((output_swap->external_sym_size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                      ;
      if (!external_sym)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      (*swap_sym_out) (output_bfd, &internal_sym, external_sym);
      add_memory_shuffle (ainfo, &ainfo->sym, &ainfo->sym_end,
     external_sym, output_swap->external_sym_size);
      ++fdr.csym;
      ++output_symhdr->isymMax;
    }

  (void) __extension__ ({ struct n64_tag_obstack *__o = (&(output_bfd->memory)); void *__obj = ((void *) symbols); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });





  external_fdr = (void *) __extension__ ({ struct n64_tag_obstack *__h = (&ainfo->memory); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((output_swap->external_fdr_size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                         ;
  if (!external_fdr)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  (*output_swap->swap_fdr_out) (output_bfd, &fdr, external_fdr);
  add_memory_shuffle (ainfo, &ainfo->fdr, &ainfo->fdr_end,
        external_fdr, output_swap->external_fdr_size);

  ++output_symhdr->ifdMax;

  return cxx_true;
}






boolean
bfd_ecoff_debug_externals(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (asymbol *, EXTR *), void (*set_index) (asymbol *, bfd_size_type)) asm("_bfd_ecoff_debug_externals");
boolean
bfd_ecoff_debug_externals(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (asymbol *, EXTR *), void (*set_index) (asymbol *, bfd_size_type))
{
  HDRR * const symhdr = &debug->symbolic_header;
  asymbol **sym_ptr_ptr;
  size_t c;

  sym_ptr_ptr = ((abfd)->outsymbols);
  if (sym_ptr_ptr == 
                    ((void *)0)
                        )
    return cxx_true;

  for (c = ((abfd)->symcount); c > 0; c--, sym_ptr_ptr++)
    {
      asymbol *sym_ptr;
      EXTR esym;

      sym_ptr = *sym_ptr_ptr;


      if ((*get_extr) (sym_ptr, &esym) == cxx_false)
 continue;



      if (relocateable == cxx_false)
 {
   if (esym.asym.sc == 17)
     esym.asym.sc = 3;
   else if (esym.asym.sc == 18)
     esym.asym.sc = 14;
 }

      if ((((sym_ptr->section)->flags & 0x8000) != 0)
   || ((sym_ptr->section) == ((asection *) &bfd_und_section))
   || sym_ptr->section->output_section == (asection *) 
                                                      ((void *)0)
                                                          )
 {



   if (esym.asym.sc != 21
       || esym.asym.value == 0
       || sym_ptr->value != 0)
     esym.asym.value = sym_ptr->value;
 }
      else
 esym.asym.value = (sym_ptr->value
      + sym_ptr->section->output_offset
      + sym_ptr->section->output_section->vma);

      if (set_index)
 (*set_index) (sym_ptr, (bfd_size_type) symhdr->iextMax);

      if (! bfd_ecoff_debug_one_external (abfd, debug, swap,
       sym_ptr->name, &esym))
 return cxx_false;
    }

  return cxx_true;
}



boolean
bfd_ecoff_debug_one_external(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, const char *name, EXTR *esym) asm("_bfd_ecoff_debug_one_external");
boolean
bfd_ecoff_debug_one_external(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, const char *name, EXTR *esym)
{
  const bfd_size_type external_ext_size = swap->external_ext_size;
  void (* const swap_ext_out) (bfd *, const EXTR *, void *)
    = swap->swap_ext_out;
  HDRR * const symhdr = &debug->symbolic_header;
  size_t namelen;

  namelen = strlen (name);

  if ((size_t) (debug->ssext_end - debug->ssext)
      < symhdr->issExtMax + namelen + 1)
    {
      if (ecoff_add_bytes ((char **) &debug->ssext,
      (char **) &debug->ssext_end,
      symhdr->issExtMax + namelen + 1)
   == cxx_false)
 return cxx_false;
    }
  if ((size_t) ((char *) debug->external_ext_end
  - (char *) debug->external_ext)
      < (symhdr->iextMax + 1) * external_ext_size)
    {
      if (ecoff_add_bytes ((char **) &debug->external_ext,
      (char **) &debug->external_ext_end,
      (symhdr->iextMax + 1) * external_ext_size)
   == cxx_false)
 return cxx_false;
    }

  esym->asym.iss = symhdr->issExtMax;

  (*swap_ext_out) (abfd, esym,
     ((char *) debug->external_ext
      + symhdr->iextMax * swap->external_ext_size));

  ++symhdr->iextMax;

  strcpy (debug->ssext + symhdr->issExtMax, name);
  symhdr->issExtMax += namelen + 1;

  return cxx_true;
}




static void
ecoff_align_debug(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_ecoff_align_debug");
static void
ecoff_align_debug(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap)
{
  HDRR * const symhdr = &debug->symbolic_header;
  bfd_size_type debug_align, aux_align, rfd_align;
  size_t add;


  debug_align = swap->debug_align;
  aux_align = debug_align / sizeof (union n64_tag_aux_ext);
  rfd_align = debug_align / swap->external_rfd_size;

  add = debug_align - (symhdr->cbLine & (debug_align - 1));
  if (add != debug_align)
    {
      if (debug->line != (unsigned char *) 
                                          ((void *)0)
                                              )
 memset ((void *) (debug->line + symhdr->cbLine), 0, add);
      symhdr->cbLine += add;
    }

  add = debug_align - (symhdr->issMax & (debug_align - 1));
  if (add != debug_align)
    {
      if (debug->ss != (char *) 
                               ((void *)0)
                                   )
 memset ((void *) (debug->ss + symhdr->issMax), 0, add);
      symhdr->issMax += add;
    }

  add = debug_align - (symhdr->issExtMax & (debug_align - 1));
  if (add != debug_align)
    {
      if (debug->ssext != (char *) 
                                  ((void *)0)
                                      )
 memset ((void *) (debug->ssext + symhdr->issExtMax), 0, add);
      symhdr->issExtMax += add;
    }

  add = aux_align - (symhdr->iauxMax & (aux_align - 1));
  if (add != aux_align)
    {
      if (debug->external_aux != (union n64_tag_aux_ext *) 
                                                  ((void *)0)
                                                      )
 memset ((void *) (debug->external_aux + symhdr->iauxMax), 0,
  add * sizeof (union n64_tag_aux_ext));
      symhdr->iauxMax += add;
    }

  add = rfd_align - (symhdr->crfd & (rfd_align - 1));
  if (add != rfd_align)
    {
      if (debug->external_rfd != (void *) 
                                      ((void *)0)
                                          )
 memset ((void *) ((char *) debug->external_rfd
         + symhdr->crfd * swap->external_rfd_size),
  0, (size_t) (add * swap->external_rfd_size));
      symhdr->crfd += add;
    }
}



bfd_size_type
bfd_ecoff_debug_size(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size");
bfd_size_type
bfd_ecoff_debug_size(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap)
{
  bfd_size_type tot;

  ecoff_align_debug (abfd, debug, swap);
  tot = swap->external_hdr_size;




  tot += debug->symbolic_header.cbLine * sizeof (unsigned char);
  tot += debug->symbolic_header.idnMax * swap->external_dnr_size;
  tot += debug->symbolic_header.ipdMax * swap->external_pdr_size;
  tot += debug->symbolic_header.isymMax * swap->external_sym_size;
  tot += debug->symbolic_header.ioptMax * swap->external_opt_size;
  tot += debug->symbolic_header.iauxMax * sizeof (union n64_tag_aux_ext);
  tot += debug->symbolic_header.issMax * sizeof (char);
  tot += debug->symbolic_header.issExtMax * sizeof (char);
  tot += debug->symbolic_header.ifdMax * swap->external_fdr_size;
  tot += debug->symbolic_header.crfd * swap->external_rfd_size;
  tot += debug->symbolic_header.iextMax * swap->external_ext_size;



  return tot;
}





static boolean
ecoff_write_symhdr(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where) asm("_ecoff_write_symhdr");
static boolean
ecoff_write_symhdr(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where)
{
  HDRR * const symhdr = &debug->symbolic_header;
  char *buff = 
              ((void *)0)
                  ;

  ecoff_align_debug (abfd, debug, swap);


  if (bfd_seek (abfd, where, 
                            0
                                    ) != 0)
    return cxx_false;

  where += swap->external_hdr_size;

  symhdr->magic = swap->sym_magic;
  if (symhdr->cbLine == 0) symhdr->cbLineOffset = 0; else { symhdr->cbLineOffset = where; where += symhdr->cbLine * sizeof (unsigned char); };
  if (symhdr->idnMax == 0) symhdr->cbDnOffset = 0; else { symhdr->cbDnOffset = where; where += symhdr->idnMax * swap->external_dnr_size; };
  if (symhdr->ipdMax == 0) symhdr->cbPdOffset = 0; else { symhdr->cbPdOffset = where; where += symhdr->ipdMax * swap->external_pdr_size; };
  if (symhdr->isymMax == 0) symhdr->cbSymOffset = 0; else { symhdr->cbSymOffset = where; where += symhdr->isymMax * swap->external_sym_size; };
  if (symhdr->ioptMax == 0) symhdr->cbOptOffset = 0; else { symhdr->cbOptOffset = where; where += symhdr->ioptMax * swap->external_opt_size; };
  if (symhdr->iauxMax == 0) symhdr->cbAuxOffset = 0; else { symhdr->cbAuxOffset = where; where += symhdr->iauxMax * sizeof (union n64_tag_aux_ext); };
  if (symhdr->issMax == 0) symhdr->cbSsOffset = 0; else { symhdr->cbSsOffset = where; where += symhdr->issMax * sizeof (char); };
  if (symhdr->issExtMax == 0) symhdr->cbSsExtOffset = 0; else { symhdr->cbSsExtOffset = where; where += symhdr->issExtMax * sizeof (char); };
  if (symhdr->ifdMax == 0) symhdr->cbFdOffset = 0; else { symhdr->cbFdOffset = where; where += symhdr->ifdMax * swap->external_fdr_size; };
  if (symhdr->crfd == 0) symhdr->cbRfdOffset = 0; else { symhdr->cbRfdOffset = where; where += symhdr->crfd * swap->external_rfd_size; };
  if (symhdr->iextMax == 0) symhdr->cbExtOffset = 0; else { symhdr->cbExtOffset = where; where += symhdr->iextMax * swap->external_ext_size; };


  buff = (void *) malloc ((size_t) swap->external_hdr_size);
  if (buff == 
             ((void *)0) 
                  && swap->external_hdr_size != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }

  (*swap->swap_hdr_out) (abfd, symhdr, buff);
  if (bfd_write (buff, 1, swap->external_hdr_size, abfd)
      != swap->external_hdr_size)
    goto error_return;

  if (buff != 
             ((void *)0)
                 )
    free (buff);
  return cxx_true;
 error_return:
  if (buff != 
             ((void *)0)
                 )
    free (buff);
  return cxx_false;
}







boolean
bfd_ecoff_write_debug(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug");
boolean
bfd_ecoff_write_debug(bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where)
{
  HDRR * const symhdr = &debug->symbolic_header;

  if (! ecoff_write_symhdr (abfd, debug, swap, where))
    return cxx_false;
  { if (!(symhdr->cbLineOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbLineOffset)) bfd_assert("ecofflink.c",1612); }; if (bfd_write ((void *) debug->line, sizeof (unsigned char), symhdr->cbLine, abfd) != sizeof (unsigned char) * symhdr->cbLine) return cxx_false;;
  { if (!(symhdr->cbDnOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbDnOffset)) bfd_assert("ecofflink.c",1613); }; if (bfd_write ((void *) debug->external_dnr, swap->external_dnr_size, symhdr->idnMax, abfd) != swap->external_dnr_size * symhdr->idnMax) return cxx_false;;
  { if (!(symhdr->cbPdOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbPdOffset)) bfd_assert("ecofflink.c",1614); }; if (bfd_write ((void *) debug->external_pdr, swap->external_pdr_size, symhdr->ipdMax, abfd) != swap->external_pdr_size * symhdr->ipdMax) return cxx_false;;
  { if (!(symhdr->cbSymOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbSymOffset)) bfd_assert("ecofflink.c",1615); }; if (bfd_write ((void *) debug->external_sym, swap->external_sym_size, symhdr->isymMax, abfd) != swap->external_sym_size * symhdr->isymMax) return cxx_false;;
  { if (!(symhdr->cbOptOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbOptOffset)) bfd_assert("ecofflink.c",1616); }; if (bfd_write ((void *) debug->external_opt, swap->external_opt_size, symhdr->ioptMax, abfd) != swap->external_opt_size * symhdr->ioptMax) return cxx_false;;
  { if (!(symhdr->cbAuxOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbAuxOffset)) bfd_assert("ecofflink.c",1617); }; if (bfd_write ((void *) debug->external_aux, sizeof (union n64_tag_aux_ext), symhdr->iauxMax, abfd) != sizeof (union n64_tag_aux_ext) * symhdr->iauxMax) return cxx_false;;
  { if (!(symhdr->cbSsOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbSsOffset)) bfd_assert("ecofflink.c",1618); }; if (bfd_write ((void *) debug->ss, sizeof (char), symhdr->issMax, abfd) != sizeof (char) * symhdr->issMax) return cxx_false;;
  { if (!(symhdr->cbSsExtOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbSsExtOffset)) bfd_assert("ecofflink.c",1619); }; if (bfd_write ((void *) debug->ssext, sizeof (char), symhdr->issExtMax, abfd) != sizeof (char) * symhdr->issExtMax) return cxx_false;;
  { if (!(symhdr->cbFdOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbFdOffset)) bfd_assert("ecofflink.c",1620); }; if (bfd_write ((void *) debug->external_fdr, swap->external_fdr_size, symhdr->ifdMax, abfd) != swap->external_fdr_size * symhdr->ifdMax) return cxx_false;;
  { if (!(symhdr->cbRfdOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbRfdOffset)) bfd_assert("ecofflink.c",1621); }; if (bfd_write ((void *) debug->external_rfd, swap->external_rfd_size, symhdr->crfd, abfd) != swap->external_rfd_size * symhdr->crfd) return cxx_false;;
  { if (!(symhdr->cbExtOffset == 0 || (bfd_vma) bfd_tell (abfd) == symhdr->cbExtOffset)) bfd_assert("ecofflink.c",1622); }; if (bfd_write ((void *) debug->external_ext, swap->external_ext_size, symhdr->iextMax, abfd) != swap->external_ext_size * symhdr->iextMax) return cxx_false;;


  return cxx_true;
}



static boolean ecoff_write_shuffle (bfd *, const struct n64_tag_ecoff_debug_swap *, struct n64_tag_shuffle *, void * space) asm("_ecoff_write_shuffle")

                                      ;

static boolean
ecoff_write_shuffle(bfd *abfd, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_shuffle *shuffle, void *space) asm("_ecoff_write_shuffle");
static boolean
ecoff_write_shuffle(bfd *abfd, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_shuffle *shuffle, void *space)
{
  register struct n64_tag_shuffle *l;
  unsigned long total;

  total = 0;
  for (l = shuffle; l != (struct n64_tag_shuffle *) 
                                           ((void *)0)
                                               ; l = l->next)
    {
      if (! l->filep)
 {
   if (bfd_write (l->u.memory, 1, l->size, abfd) != l->size)
     return cxx_false;
 }
      else
 {
   if (bfd_seek (l->u.file.input_bfd, l->u.file.offset, 
                                                       0
                                                               ) != 0
       || bfd_read (space, 1, l->size, l->u.file.input_bfd) != l->size
       || bfd_write (space, 1, l->size, abfd) != l->size)
     return cxx_false;
 }
      total += l->size;
    }

  if ((total & (swap->debug_align - 1)) != 0)
    {
      unsigned int i;
      bfd_byte *s;

      i = swap->debug_align - (total & (swap->debug_align - 1));
      s = (bfd_byte *) malloc (i);
      if (s == 
              ((void *)0) 
                   && i != 0)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }

      memset ((void *) s, 0, i);
      if (bfd_write ((void *) s, 1, i, abfd) != i)
 {
   free (s);
   return cxx_false;
 }
      free (s);
    }

  return cxx_true;
}




boolean
bfd_ecoff_write_accumulated_debug(void *handle, bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug");
boolean
bfd_ecoff_write_accumulated_debug(void *handle, bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;
  void * space = 
             ((void *)0)
                 ;

  if (! ecoff_write_symhdr (abfd, debug, swap, where))
    goto error_return;

  space = (void *) malloc (ainfo->largest_file_shuffle);
  if (space == 
              ((void *)0) 
                   && ainfo->largest_file_shuffle != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }

  if (! ecoff_write_shuffle (abfd, swap, ainfo->line, space)
      || ! ecoff_write_shuffle (abfd, swap, ainfo->pdr, space)
      || ! ecoff_write_shuffle (abfd, swap, ainfo->sym, space)
      || ! ecoff_write_shuffle (abfd, swap, ainfo->opt, space)
      || ! ecoff_write_shuffle (abfd, swap, ainfo->aux, space))
    goto error_return;



  if (info->relocateable)
    {
      { if (!(ainfo->ss_hash == (struct n64_tag_string_hash_entry *) 
     ((void *)0)
     )) bfd_assert("ecofflink.c",1723); };
      if (! ecoff_write_shuffle (abfd, swap, ainfo->ss, space))
 goto error_return;
    }
  else
    {
      unsigned long total;
      bfd_byte null;
      struct n64_tag_string_hash_entry *sh;

      { if (!(ainfo->ss == (struct n64_tag_shuffle *) 
     ((void *)0)
     )) bfd_assert("ecofflink.c",1733); };
      null = 0;
      if (bfd_write ((void *) &null, 1, 1, abfd) != 1)
 goto error_return;
      total = 1;
      { if (!(ainfo->ss_hash == 
     ((void *)0) 
     || ainfo->ss_hash->val == 1)) bfd_assert("ecofflink.c",1738); };
      for (sh = ainfo->ss_hash;
    sh != (struct n64_tag_string_hash_entry *) 
                                      ((void *)0)
                                          ;
    sh = sh->next)
 {
   size_t len;

   len = strlen (sh->root.string);
   if (bfd_write ((void *) sh->root.string, 1, len + 1, abfd) != len + 1)
     goto error_return;
   total += len + 1;
 }

      if ((total & (swap->debug_align - 1)) != 0)
 {
   unsigned int i;
   bfd_byte *s;

   i = swap->debug_align - (total & (swap->debug_align - 1));
   s = (bfd_byte *) malloc (i);
   if (s == 
           ((void *)0) 
                && i != 0)
     {
       bfd_set_error (bfd_error_no_memory);
       goto error_return;
     }
   memset ((void *) s, 0, i);
   if (bfd_write ((void *) s, 1, i, abfd) != i)
     {
       free (s);
       goto error_return;
     }
   free (s);
 }
    }



  if (bfd_write (debug->ssext, 1, debug->symbolic_header.issExtMax, abfd)
      != (bfd_size_type) debug->symbolic_header.issExtMax)
    goto error_return;
  if ((debug->symbolic_header.issExtMax & (swap->debug_align - 1)) != 0)
    {
      unsigned int i;
      bfd_byte *s;

      i = (swap->debug_align
    - (debug->symbolic_header.issExtMax & (swap->debug_align - 1)));
      s = (bfd_byte *) malloc (i);
      if (s == 
              ((void *)0) 
                   && i != 0)
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }
      memset ((void *) s, 0, i);
      if (bfd_write ((void *) s, 1, i, abfd) != i)
 {
   free (s);
   goto error_return;
 }
      free (s);
    }

  if (! ecoff_write_shuffle (abfd, swap, ainfo->fdr, space)
      || ! ecoff_write_shuffle (abfd, swap, ainfo->rfd, space))
    goto error_return;

  { if (!(debug->symbolic_header.cbExtOffset == 0 || (debug->symbolic_header.cbExtOffset == (bfd_vma) bfd_tell (abfd)))) bfd_assert("ecofflink.c",1804); }

                                  ;

  if (bfd_write (debug->external_ext, swap->external_ext_size,
   debug->symbolic_header.iextMax, abfd)
      != debug->symbolic_header.iextMax * swap->external_ext_size)
    goto error_return;

  if (space != 
              ((void *)0)
                  )
    free (space);
  return cxx_true;

 error_return:
  if (space != 
              ((void *)0)
                  )
    free (space);
  return cxx_false;
}






static int
cmp_fdrtab_entry(const void *leftp, const void *rightp) asm("_cmp_fdrtab_entry");
static int
cmp_fdrtab_entry(const void *leftp, const void *rightp)
{
  const struct n64_tag_ecoff_fdrtab_entry *lp =
    (const struct n64_tag_ecoff_fdrtab_entry *) leftp;
  const struct n64_tag_ecoff_fdrtab_entry *rp =
    (const struct n64_tag_ecoff_fdrtab_entry *) rightp;

  if (lp->base_addr < rp->base_addr)
    return -1;
  if (lp->base_addr > rp->base_addr)
    return 1;
  return 0;
}







static boolean
mk_fdrtab(bfd *abfd, struct n64_tag_ecoff_debug_info *const debug_info, const struct n64_tag_ecoff_debug_swap *const debug_swap, struct n64_tag_ecoff_find_line *line_info) asm("_mk_fdrtab");
static boolean
mk_fdrtab(bfd *abfd, struct n64_tag_ecoff_debug_info *const debug_info, const struct n64_tag_ecoff_debug_swap *const debug_swap, struct n64_tag_ecoff_find_line *line_info)
{
  struct n64_tag_ecoff_fdrtab_entry *tab;
  FDR *fdr_ptr;
  FDR *fdr_start;
  FDR *fdr_end;
  boolean stabs;
  long len;

  fdr_start = debug_info->fdr;
  fdr_end = fdr_start + debug_info->symbolic_header.ifdMax;


  for (len = 0, fdr_ptr = fdr_start; fdr_ptr < fdr_end; fdr_ptr++)
    {
      if (fdr_ptr->cpd == 0)
 continue;
      ++len;
    }



  line_info->fdrtab = ((struct n64_tag_ecoff_fdrtab_entry*)
         bfd_zalloc (abfd,
       len * sizeof (struct n64_tag_ecoff_fdrtab_entry)));
  if (line_info->fdrtab == 
                          ((void *)0)
                              )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  line_info->fdrtab_len = len;

  tab = line_info->fdrtab;
  for (fdr_ptr = fdr_start; fdr_ptr < fdr_end; fdr_ptr++)
    {
      if (fdr_ptr->cpd == 0)
 continue;




      stabs = cxx_false;
      if (fdr_ptr->csym >= 2)
 {
   char *sym_ptr;
   SYMR sym;

   sym_ptr = ((char *) debug_info->external_sym
       + (fdr_ptr->isymBase + 1)*debug_swap->external_sym_size);
   (*debug_swap->swap_sym_in) (abfd, sym_ptr, &sym);
   if (strcmp (debug_info->ss + fdr_ptr->issBase + sym.iss,
        "@stabs") == 0)
     stabs = cxx_true;
 }

      if (!stabs)
 {
   bfd_size_type external_pdr_size;
   char *pdr_ptr;
   PDR pdr;

   external_pdr_size = debug_swap->external_pdr_size;

   pdr_ptr = ((char *) debug_info->external_pdr
       + fdr_ptr->ipdFirst * external_pdr_size);
   (*debug_swap->swap_pdr_in) (abfd, (void *) pdr_ptr, &pdr);


   tab->base_addr = fdr_ptr->adr - pdr.adr;
 }
      else
 {


   tab->base_addr = fdr_ptr->adr;
 }
      tab->fdr = fdr_ptr;
      ++tab;
    }





  qsort ((void *) line_info->fdrtab, len,
  sizeof (struct n64_tag_ecoff_fdrtab_entry), cmp_fdrtab_entry);

  return cxx_true;
}



static long
fdrtab_lookup(struct n64_tag_ecoff_find_line *line_info, bfd_vma offset) asm("_fdrtab_lookup");
static long
fdrtab_lookup(struct n64_tag_ecoff_find_line *line_info, bfd_vma offset)
{
  long low, high, len;
  long mid = -1;
  struct n64_tag_ecoff_fdrtab_entry *tab;

  len = line_info->fdrtab_len;
  if (len == 0)
    return -1;

  tab = line_info->fdrtab;
  for (low = 0, high = len - 1 ; low != high ;)
    {
      mid = (high + low) / 2;
      if (offset >= tab[mid].base_addr && offset < tab[mid + 1].base_addr)
 goto find_min;

      if (tab[mid].base_addr > offset)
 high = mid;
      else
 low = mid + 1;
    }
  ++mid;


  if (offset < tab[mid].base_addr)
    return -1;

 find_min:

  while (mid > 0 && tab[mid - 1].base_addr == tab[mid].base_addr)
    --mid;

  return mid;
}



boolean
_bfd_ecoff_locate_line(bfd *abfd, asection *section, bfd_vma offset, struct n64_tag_ecoff_debug_info *const debug_info, const struct n64_tag_ecoff_debug_swap *const debug_swap, struct n64_tag_ecoff_find_line *line_info, const char **filename_ptr, const char **functionname_ptr, unsigned int *retline_ptr) asm("__bfd_ecoff_locate_line");
boolean
_bfd_ecoff_locate_line(bfd *abfd, asection *section, bfd_vma offset, struct n64_tag_ecoff_debug_info *const debug_info, const struct n64_tag_ecoff_debug_swap *const debug_swap, struct n64_tag_ecoff_find_line *line_info, const char **filename_ptr, const char **functionname_ptr, unsigned int *retline_ptr)
{
  struct n64_tag_ecoff_fdrtab_entry *tab;
  boolean stabs;
  FDR *fdr_ptr;
  int i;

  offset += section->vma;



  if (line_info->fdrtab == 
                          ((void *)0)
      
     && !mk_fdrtab (abfd, debug_info, debug_swap, line_info))
    return cxx_false;

  tab = line_info->fdrtab;


  i = fdrtab_lookup (line_info, offset);
  if (i < 0)
    return cxx_false;
  fdr_ptr = tab[i].fdr;




  stabs = cxx_false;
  if (fdr_ptr->csym >= 2)
    {
      char *sym_ptr;
      SYMR sym;

      sym_ptr = ((char *) debug_info->external_sym
   + (fdr_ptr->isymBase + 1) * debug_swap->external_sym_size);
      (*debug_swap->swap_sym_in) (abfd, sym_ptr, &sym);
      if (strcmp (debug_info->ss + fdr_ptr->issBase + sym.iss,
    "@stabs") == 0)
 stabs = cxx_true;
    }

  if (!stabs)
    {
      bfd_size_type external_pdr_size;
      char *pdr_ptr;
      char *best_pdr = 
                      ((void *)0)
                          ;
      FDR *best_fdr;
      bfd_vma best_dist = ~0;
      PDR pdr;
      unsigned char *line_ptr;
      unsigned char *line_end;
      int lineno;
      external_pdr_size = debug_swap->external_pdr_size;


      offset -= tab[i].base_addr;


      best_fdr = 
                ((void *)0)
                    ;
      do
 {
   bfd_vma dist, min_dist = 0;
   char *pdr_hold;
   char *pdr_end;

   fdr_ptr = tab[i].fdr;

   pdr_ptr = ((char *) debug_info->external_pdr
       + fdr_ptr->ipdFirst * external_pdr_size);
   pdr_end = pdr_ptr + fdr_ptr->cpd * external_pdr_size;
   (*debug_swap->swap_pdr_in) (abfd, (void *) pdr_ptr, &pdr);





   for (pdr_hold = 
                  ((void *)0)
                      ;
        pdr_ptr < pdr_end;
        (pdr_ptr += external_pdr_size,
  (*debug_swap->swap_pdr_in) (abfd, (void *) pdr_ptr, &pdr)))
     {
       if (offset >= (pdr.adr - 0x10 * pdr.prof))
  {
    dist = offset - (pdr.adr - 0x10 * pdr.prof);
    if (!pdr_hold || dist < min_dist)
      {
        min_dist = dist;
        pdr_hold = pdr_ptr;
      }
  }
     }

   if (!best_pdr || min_dist < best_dist)
     {
       best_dist = min_dist;
       best_fdr = fdr_ptr;
       best_pdr = pdr_hold;
     }

 }
      while (++i < line_info->fdrtab_len
      && tab[i].base_addr == tab[i - 1].base_addr);

      if (!best_fdr || !best_pdr)
 return cxx_false;


      fdr_ptr = best_fdr;
      pdr_ptr = best_pdr;
      (*debug_swap->swap_pdr_in) (abfd, (void *) pdr_ptr, &pdr);




      line_end = debug_info->line + fdr_ptr->cbLineOffset + fdr_ptr->cbLine;


      offset -= pdr.adr - 0x10 * pdr.prof;
      lineno = pdr.lnLow;
      line_ptr = debug_info->line + fdr_ptr->cbLineOffset + pdr.cbLineOffset;
      while (line_ptr < line_end)
 {
   int delta;
   unsigned int count;

   delta = *line_ptr >> 4;
   if (delta >= 0x8)
     delta -= 0x10;
   count = (*line_ptr & 0xf) + 1;
   ++line_ptr;
   if (delta == -8)
     {
       delta = (((line_ptr[0]) & 0xff) << 8) + ((line_ptr[1]) & 0xff);
       if (delta >= 0x8000)
  delta -= 0x10000;
       line_ptr += 2;
     }
   lineno += delta;
   if (offset < count * 4)
     break;
   offset -= count * 4;
 }



      if (fdr_ptr->rss == -1)
 {
   *filename_ptr = 
                  ((void *)0)
                      ;
   if (pdr.isym == -1)
     *functionname_ptr = 
                        ((void *)0)
                            ;
   else
     {
       EXTR proc_ext;

       (*debug_swap->swap_ext_in)
  (abfd,
   ((char *) debug_info->external_ext
    + pdr.isym * debug_swap->external_ext_size),
   &proc_ext);
       *functionname_ptr = debug_info->ssext + proc_ext.asym.iss;
     }
 }
      else
 {
   SYMR proc_sym;

   *filename_ptr = debug_info->ss + fdr_ptr->issBase + fdr_ptr->rss;
   (*debug_swap->swap_sym_in)
     (abfd,
      ((char *) debug_info->external_sym
       + (fdr_ptr->isymBase + pdr.isym) * debug_swap->external_sym_size),
      &proc_sym);
   *functionname_ptr = debug_info->ss + fdr_ptr->issBase + proc_sym.iss;
 }
      if (lineno == -1)
 lineno = 0;
      *retline_ptr = lineno;
    }
  else
    {
      bfd_size_type external_sym_size;
      const char *directory_name;
      const char *main_file_name;
      const char *current_file_name;
      const char *function_name;
      const char *line_file_name;
      bfd_vma low_func_vma;
      bfd_vma low_line_vma;
      boolean past_line;
      boolean past_fn;
      char *sym_ptr, *sym_ptr_end;
      size_t len, funclen;
      char *buffer = 
                    ((void *)0)
                        ;
      *filename_ptr = 
                     ((void *)0)
                         ;
      *functionname_ptr = 
                         ((void *)0)
                             ;
      *retline_ptr = 0;

      directory_name = 
                      ((void *)0)
                          ;
      main_file_name = 
                      ((void *)0)
                          ;
      current_file_name = 
                         ((void *)0)
                             ;
      function_name = 
                     ((void *)0)
                         ;
      line_file_name = 
                      ((void *)0)
                          ;
      low_func_vma = 0;
      low_line_vma = 0;
      past_line = cxx_false;
      past_fn = cxx_false;

      external_sym_size = debug_swap->external_sym_size;

      sym_ptr = ((char *) debug_info->external_sym
   + (fdr_ptr->isymBase + 2) * external_sym_size);
      sym_ptr_end = sym_ptr + (fdr_ptr->csym - 2) * external_sym_size;
      for (;
    sym_ptr < sym_ptr_end && (! past_line || ! past_fn);
    sym_ptr += external_sym_size)
 {
   SYMR sym;

   (*debug_swap->swap_sym_in) (abfd, sym_ptr, &sym);

   if ((((&sym)->index & 0xFFF00) == 0x8F300))
     {
       switch (((sym.index)-0x8F300))
  {
  case N_SO:
    main_file_name = current_file_name =
      debug_info->ss + fdr_ptr->issBase + sym.iss;



    if (sym_ptr + external_sym_size < sym_ptr_end)
      {
        SYMR nextsym;

        (*debug_swap->swap_sym_in) (abfd,
        sym_ptr + external_sym_size,
        &nextsym);
        if ((((&nextsym)->index & 0xFFF00) == 0x8F300)
     && ((nextsym.index)-0x8F300) == N_SO)
   {
      directory_name = current_file_name;
     main_file_name = current_file_name =
       debug_info->ss + fdr_ptr->issBase + nextsym.iss;
     sym_ptr += external_sym_size;
   }
      }
    break;

  case N_SOL:
    current_file_name =
      debug_info->ss + fdr_ptr->issBase + sym.iss;
    break;

  case N_FUN:
    if (sym.value > offset)
      past_fn = cxx_true;
    else if (sym.value >= low_func_vma)
      {
        low_func_vma = sym.value;
        function_name =
   debug_info->ss + fdr_ptr->issBase + sym.iss;
      }
    break;
  }
     }
   else if (sym.st == 5 && sym.index != 0xfffff)
     {
       if (sym.value > offset)
  past_line = cxx_true;
       else if (sym.value >= low_line_vma)
  {
    low_line_vma = sym.value;
    line_file_name = current_file_name;
    *retline_ptr = sym.index;
  }
     }
 }

      if (*retline_ptr != 0)
 main_file_name = line_file_name;




      if (function_name == 
                          ((void *)0)
                              )
 len = funclen = 0;
      else
 len = funclen = strlen (function_name) + 1;

      if (main_file_name != 
                           ((void *)0)
   
  && directory_name != 
                       ((void *)0)
   
  && main_file_name[0] != '/')
 len += strlen (directory_name) + strlen (main_file_name) + 1;

      if (len != 0)
 {
   if (line_info->find_buffer != 
                                ((void *)0)
                                    )
     free (line_info->find_buffer);
   buffer = (char *) malloc (len);
   if (buffer == 
                ((void *)0)
                    )
     {
       bfd_set_error (bfd_error_no_memory);
       return cxx_false;
     }
   line_info->find_buffer = buffer;
 }

      if (function_name != 
                          ((void *)0)
                              )
 {
   char *colon;

   strcpy (buffer, function_name);
   colon = strchr (buffer, ':');
   if (colon != 
               ((void *)0)
                   )
     *colon = '\0';
   *functionname_ptr = buffer;
 }

      if (main_file_name != 
                           ((void *)0)
                               )
 {
   if (directory_name == 
                        ((void *)0) 
                             || main_file_name[0] == '/')
     *filename_ptr = main_file_name;
   else
     {
       sprintf (buffer + funclen, "%s%s", directory_name,
         main_file_name);
       *filename_ptr = buffer + funclen;
     }
 }
    }

  return cxx_true;
}
static boolean ecoff_collect_shuffle (struct n64_tag_shuffle *, bfd_byte *) asm("_ecoff_collect_shuffle");

static boolean
ecoff_collect_shuffle(struct n64_tag_shuffle *l, bfd_byte *buff) asm("_ecoff_collect_shuffle");
static boolean
ecoff_collect_shuffle(struct n64_tag_shuffle *l, bfd_byte *buff)
{
  unsigned long total;

  total = 0;
  for (; l != (struct n64_tag_shuffle *) 
                                ((void *)0)
                                    ; l = l->next)
    {
      if (! l->filep)
 memcpy (buff, l->u.memory, l->size);
      else
 {
   if (bfd_seek (l->u.file.input_bfd, l->u.file.offset, 
                                                       0
                                                               ) != 0
       || bfd_read (buff, 1, l->size, l->u.file.input_bfd) != l->size)
     return cxx_false;
 }
      total += l->size;
      buff += l->size;
    }

  return cxx_true;
}



boolean
_bfd_ecoff_get_accumulated_pdr(void *handle, bfd_byte *buff) asm("__bfd_ecoff_get_accumulated_pdr");
boolean
_bfd_ecoff_get_accumulated_pdr(void *handle, bfd_byte *buff)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;

  return ecoff_collect_shuffle (ainfo->pdr, buff);
}



boolean
_bfd_ecoff_get_accumulated_sym(void *handle, bfd_byte *buff) asm("__bfd_ecoff_get_accumulated_sym");
boolean
_bfd_ecoff_get_accumulated_sym(void *handle, bfd_byte *buff)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;

  return ecoff_collect_shuffle (ainfo->sym, buff);
}



boolean
_bfd_ecoff_get_accumulated_ss(void *handle, bfd_byte *buff) asm("__bfd_ecoff_get_accumulated_ss");
boolean
_bfd_ecoff_get_accumulated_ss(void *handle, bfd_byte *buff)
{
  struct n64_tag_accumulate *ainfo = (struct n64_tag_accumulate *) handle;
  struct n64_tag_string_hash_entry *sh;
  unsigned long total;



  { if (!(ainfo->ss == (struct n64_tag_shuffle *) 
 ((void *)0)
 )) bfd_assert("ecofflink.c",2473); };
  *buff++ = '\0';
  total = 1;
  { if (!(ainfo->ss_hash == 
 ((void *)0) 
 || ainfo->ss_hash->val == 1)) bfd_assert("ecofflink.c",2476); };
  for (sh = ainfo->ss_hash;
       sh != (struct n64_tag_string_hash_entry *) 
                                         ((void *)0)
                                             ;
       sh = sh->next)
    {
      size_t len;

      len = strlen (sh->root.string);
      memcpy (buff, (void *) sh->root.string, len + 1);
      total += len + 1;
      buff += len + 1;
    }

  return cxx_true;
}

