// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/flonum-mult.c
/* flonum_mult.c - multiply two flonums
   Copyright (C) 1987, 1990, 1991, 1992 Free Software Foundation, Inc.

   This file is part of Gas, the GNU Assembler.

   The GNU assembler is distributed in the hope that it will be
   useful, but WITHOUT ANY WARRANTY.  No author or distributor
   accepts responsibility to anyone for the consequences of using it
   or for whether it serves any particular purpose or works at all,
   unless he says so in writing.  Refer to the GNU Assembler General
   Public License for full details.

   Everyone is granted permission to copy, modify and redistribute
   the GNU Assembler, but only under the conditions described in the
   GNU Assembler General Public License.  A copy of this license is
   supposed to have been given to you along with the GNU Assembler
   so you can know your rights and responsibilities.  It should be
   in a file named COPYING.  Among other things, the copyright
   notice and this notice must be preserved on all copies.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_FLONUM_STRUCT;
typedef unsigned short LITTLENUM_TYPE;







int bignum_copy (LITTLENUM_TYPE * in, int in_length, LITTLENUM_TYPE * out, int out_length) asm("_bignum_copy")
                                          ;
struct n64_tag_FLONUM_STRUCT
{
  LITTLENUM_TYPE *low;
  LITTLENUM_TYPE *high;
  LITTLENUM_TYPE *leader;

  long exponent;
  char sign;
};

typedef struct n64_tag_FLONUM_STRUCT FLONUM_TYPE;
extern const FLONUM_TYPE flonum_positive_powers_of_ten[];
extern const FLONUM_TYPE flonum_negative_powers_of_ten[];
extern const int table_size_of_flonum_powers_of_ten;
int atof_generic (char **address_of_string_pointer, const char *string_of_decimal_marks, const char *string_of_decimal_exponent_marks, FLONUM_TYPE * address_of_generic_floating_point_number) asm("_atof_generic")


                                                             ;

void flonum_copy (FLONUM_TYPE * in, FLONUM_TYPE * out) asm("_flonum_copy");
void flonum_multip (const FLONUM_TYPE * a, const FLONUM_TYPE * b, FLONUM_TYPE * product) asm("_flonum_multip")
                              ;
void
flonum_multip(const FLONUM_TYPE *a, const FLONUM_TYPE *b, FLONUM_TYPE *product) asm("_flonum_multip");
void
flonum_multip(const FLONUM_TYPE *a, const FLONUM_TYPE *b, FLONUM_TYPE *product)
{
  int size_of_a;
  int size_of_b;
  int size_of_product;
  int size_of_sum;
  int extra_product_positions;
  unsigned long work;
  unsigned long carry;
  long exponent;
  LITTLENUM_TYPE *q;
  long significant;

  int P;
  int N;
  int A;
  int B;

  if ((a->sign != '-' && a->sign != '+') || (b->sign != '-' && b->sign != '+'))
    {


      product->sign = 0;
      return;
    }
  product->sign = (a->sign == b->sign) ? '+' : '-';
  size_of_a = a->leader - a->low;
  size_of_b = b->leader - b->low;
  exponent = a->exponent + b->exponent;
  size_of_product = product->high - product->low;
  size_of_sum = size_of_a + size_of_b;
  extra_product_positions = size_of_product - size_of_sum;
  if (extra_product_positions < 0)
    {
      P = extra_product_positions;
      exponent -= extra_product_positions;
    }
  else
    {
      P = 0;
    }
  carry = 0;
  significant = 0;
  for (N = 0; N <= size_of_sum; N++)
    {
      work = carry;
      carry = 0;
      for (A = 0; A <= N; A++)
 {
   B = N - A;
   if (A <= size_of_a && B <= size_of_b && B >= 0)
     {







       work += (unsigned long) a->low[A] * (unsigned long) b->low[B];
       carry += work >> (16);
       work &= (0xFFFF);



     }
 }
      significant |= work;
      if (significant || P < 0)
 {
   if (P >= 0)
     {
       product->low[P] = work;



     }
   P++;
 }
      else
 {
   extra_product_positions++;
   exponent++;
 }
    }







  if (carry)
    {
      if (extra_product_positions > 0)
 {
   product->low[P] = carry;
 }
      else
 {


   exponent++;
   P--;
   for (q = product->low + P; q >= product->low; q--)
     {
       work = *q;
       *q = carry;
       carry = work;
     }
 }
    }
  else
    {
      P--;
    }
  product->leader = product->low + P;
  product->exponent = exponent;
}

