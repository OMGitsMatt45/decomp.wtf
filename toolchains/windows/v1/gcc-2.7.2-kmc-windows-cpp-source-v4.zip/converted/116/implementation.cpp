// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/elf32.c
/* ELF 32-bit executable support for BFD.
   Copyright 1993 Free Software Foundation, Inc.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_areltdata;
struct n64_tag_artdata;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_final_link_info;
struct n64_tag_elf_finfo_failed;
struct n64_tag_elf_info_failed;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct ecoff_debug_info;
struct ecoff_debug_swap;
struct ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct ecoff_debug_info *input_debug, const struct ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct ecoff_debug_info *output_debug, const struct ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, const char *name, struct ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct ecoff_debug_info *debug, const struct ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");




















enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct ecoff_debug_info * const, const struct ecoff_debug_swap * const, struct ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct n64_tag_elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");
typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");
extern struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");

extern boolean bfd_section_from_phdr (bfd *, Elf_Internal_Phdr *, int) asm("_bfd_section_from_phdr")
                ;

 int _bfd_elf_section_from_bfd_section (bfd *, struct n64_tag_sec *) asm("__bfd_elf_section_from_bfd_section");

static long elf_slurp_symbol_table (bfd *, asymbol **, boolean) asm("_elf_slurp_symbol_table");

static boolean elf_slurp_reloc_table (bfd *, asection *, asymbol **) asm("_elf_slurp_reloc_table");

 int _bfd_elf_symbol_from_bfd_symbol (bfd *, struct n64_tag_symbol_cache_entry **) asm("__bfd_elf_symbol_from_bfd_symbol")
                                        ;

static void write_relocs (bfd *, asection *, void *) asm("_write_relocs");

 boolean bfd_section_from_shdr (bfd *, unsigned int shindex) asm("_bfd_section_from_shdr");
void
bfd_elf32_swap_symbol_in(bfd *abfd, Elf32_External_Sym *src, Elf_Internal_Sym *dst) asm("_bfd_elf32_swap_symbol_in");
void
bfd_elf32_swap_symbol_in(bfd *abfd, Elf32_External_Sym *src, Elf_Internal_Sym *dst)
{
  dst->st_name = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->st_name));
  dst->st_value = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->st_value));
  dst->st_size = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->st_size));
  dst->st_info = (*(unsigned char *)((bfd_byte *) src->st_info));
  dst->st_other = (*(unsigned char *)((bfd_byte *) src->st_other));
  dst->st_shndx = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->st_shndx));
}




void
bfd_elf32_swap_symbol_out(bfd *abfd, Elf_Internal_Sym *src, void *cdst) asm("_bfd_elf32_swap_symbol_out");
void
bfd_elf32_swap_symbol_out(bfd *abfd, Elf_Internal_Sym *src, void *cdst)
{
  Elf32_External_Sym *dst = (Elf32_External_Sym *) cdst;
  ((*((abfd)->xvec->bfd_h_putx32)) (src->st_name,dst->st_name));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->st_value,dst->st_value));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->st_size,dst->st_size));
  (*((unsigned char *)(dst->st_info)) = (unsigned char)(src->st_info));
  (*((unsigned char *)(dst->st_other)) = (unsigned char)(src->st_other));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->st_shndx,dst->st_shndx));
}





static void
elf_swap_ehdr_in(bfd *abfd, Elf32_External_Ehdr *src, Elf_Internal_Ehdr *dst) asm("_elf_swap_ehdr_in");
static void
elf_swap_ehdr_in(bfd *abfd, Elf32_External_Ehdr *src, Elf_Internal_Ehdr *dst)
{
  memcpy (dst->e_ident, src->e_ident, 16);
  dst->e_type = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_type));
  dst->e_machine = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_machine));
  dst->e_version = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->e_version));
  dst->e_entry = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->e_entry));
  dst->e_phoff = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->e_phoff));
  dst->e_shoff = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->e_shoff));
  dst->e_flags = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->e_flags));
  dst->e_ehsize = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_ehsize));
  dst->e_phentsize = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_phentsize));
  dst->e_phnum = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_phnum));
  dst->e_shentsize = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_shentsize));
  dst->e_shnum = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_shnum));
  dst->e_shstrndx = ((*((abfd)->xvec->bfd_h_getx16)) ((bfd_byte *) src->e_shstrndx));
}




static void
elf_swap_ehdr_out(bfd *abfd, Elf_Internal_Ehdr *src, Elf32_External_Ehdr *dst) asm("_elf_swap_ehdr_out");
static void
elf_swap_ehdr_out(bfd *abfd, Elf_Internal_Ehdr *src, Elf32_External_Ehdr *dst)
{
  memcpy (dst->e_ident, src->e_ident, 16);

  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_type,dst->e_type));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_machine,dst->e_machine));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->e_version,dst->e_version));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->e_entry,dst->e_entry));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->e_phoff,dst->e_phoff));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->e_shoff,dst->e_shoff));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->e_flags,dst->e_flags));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_ehsize,dst->e_ehsize));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_phentsize,dst->e_phentsize));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_phnum,dst->e_phnum));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_shentsize,dst->e_shentsize));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_shnum,dst->e_shnum));
  ((*((abfd)->xvec->bfd_h_putx16)) (src->e_shstrndx,dst->e_shstrndx));
}





static void
elf_swap_shdr_in(bfd *abfd, Elf32_External_Shdr *src, Elf_Internal_Shdr *dst) asm("_elf_swap_shdr_in");
static void
elf_swap_shdr_in(bfd *abfd, Elf32_External_Shdr *src, Elf_Internal_Shdr *dst)
{
  dst->sh_name = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_name));
  dst->sh_type = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_type));
  dst->sh_flags = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_flags));
  dst->sh_addr = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_addr));
  dst->sh_offset = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_offset));
  dst->sh_size = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_size));
  dst->sh_link = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_link));
  dst->sh_info = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_info));
  dst->sh_addralign = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_addralign));
  dst->sh_entsize = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->sh_entsize));
  dst->bfd_section = 
                    ((void *)0)
                        ;
  dst->contents = 
                 ((void *)0)
                     ;
}




static void
elf_swap_shdr_out(bfd *abfd, Elf_Internal_Shdr *src, Elf32_External_Shdr *dst) asm("_elf_swap_shdr_out");
static void
elf_swap_shdr_out(bfd *abfd, Elf_Internal_Shdr *src, Elf32_External_Shdr *dst)
{

  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_name,dst->sh_name));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_type,dst->sh_type));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_flags,dst->sh_flags));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_addr,dst->sh_addr));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_offset,dst->sh_offset));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_size,dst->sh_size));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_link,dst->sh_link));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_info,dst->sh_info));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_addralign,dst->sh_addralign));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->sh_entsize,dst->sh_entsize));
}





void
bfd_elf32_swap_phdr_in(bfd *abfd, Elf32_External_Phdr *src, Elf_Internal_Phdr *dst) asm("_bfd_elf32_swap_phdr_in");
void
bfd_elf32_swap_phdr_in(bfd *abfd, Elf32_External_Phdr *src, Elf_Internal_Phdr *dst)
{
  dst->p_type = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_type));
  dst->p_flags = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_flags));
  dst->p_offset = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_offset));
  dst->p_vaddr = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_vaddr));
  dst->p_paddr = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_paddr));
  dst->p_filesz = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_filesz));
  dst->p_memsz = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_memsz));
  dst->p_align = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->p_align));
}

void
bfd_elf32_swap_phdr_out(bfd *abfd, Elf_Internal_Phdr *src, Elf32_External_Phdr *dst) asm("_bfd_elf32_swap_phdr_out");
void
bfd_elf32_swap_phdr_out(bfd *abfd, Elf_Internal_Phdr *src, Elf32_External_Phdr *dst)
{

  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_type,dst->p_type));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_offset,dst->p_offset));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_vaddr,dst->p_vaddr));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_paddr,dst->p_paddr));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_filesz,dst->p_filesz));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_memsz,dst->p_memsz));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_flags,dst->p_flags));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->p_align,dst->p_align));
}


 void
bfd_elf32_swap_reloc_in(bfd *abfd, Elf32_External_Rel *src, Elf_Internal_Rel *dst) asm("_bfd_elf32_swap_reloc_in");
 void
bfd_elf32_swap_reloc_in(bfd *abfd, Elf32_External_Rel *src, Elf_Internal_Rel *dst)
{
  dst->r_offset = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->r_offset));
  dst->r_info = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->r_info));
}

 void
bfd_elf32_swap_reloca_in(bfd *abfd, Elf32_External_Rela *src, Elf_Internal_Rela *dst) asm("_bfd_elf32_swap_reloca_in");
 void
bfd_elf32_swap_reloca_in(bfd *abfd, Elf32_External_Rela *src, Elf_Internal_Rela *dst)
{
  dst->r_offset = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->r_offset));
  dst->r_info = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->r_info));
  dst->r_addend = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) src->r_addend));
}


 void
bfd_elf32_swap_reloc_out(bfd *abfd, Elf_Internal_Rel *src, Elf32_External_Rel *dst) asm("_bfd_elf32_swap_reloc_out");
 void
bfd_elf32_swap_reloc_out(bfd *abfd, Elf_Internal_Rel *src, Elf32_External_Rel *dst)
{
  ((*((abfd)->xvec->bfd_h_putx32)) (src->r_offset,dst->r_offset));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->r_info,dst->r_info));
}

 void
bfd_elf32_swap_reloca_out(bfd *abfd, Elf_Internal_Rela *src, Elf32_External_Rela *dst) asm("_bfd_elf32_swap_reloca_out");
 void
bfd_elf32_swap_reloca_out(bfd *abfd, Elf_Internal_Rela *src, Elf32_External_Rela *dst)
{
  ((*((abfd)->xvec->bfd_h_putx32)) (src->r_offset,dst->r_offset));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->r_info,dst->r_info));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->r_addend,dst->r_addend));
}

 void
bfd_elf32_swap_dyn_in(bfd *abfd, const Elf32_External_Dyn *src, Elf_Internal_Dyn *dst) asm("_bfd_elf32_swap_dyn_in");
 void
bfd_elf32_swap_dyn_in(bfd *abfd, const Elf32_External_Dyn *src, Elf_Internal_Dyn *dst)
{
  dst->d_tag = ((*((abfd)->xvec->bfd_h_getx32)) (src->d_tag));
  dst->d_un.d_val = ((*((abfd)->xvec->bfd_h_getx32)) (src->d_un.d_val));
}

 void
bfd_elf32_swap_dyn_out(bfd *abfd, const Elf_Internal_Dyn *src, Elf32_External_Dyn *dst) asm("_bfd_elf32_swap_dyn_out");
 void
bfd_elf32_swap_dyn_out(bfd *abfd, const Elf_Internal_Dyn *src, Elf32_External_Dyn *dst)
{
  ((*((abfd)->xvec->bfd_h_putx32)) (src->d_tag,dst->d_tag));
  ((*((abfd)->xvec->bfd_h_putx32)) (src->d_un.d_val,dst->d_un.d_val));
}
static  boolean
elf_file_p(Elf32_External_Ehdr *x_ehdrp) asm("_elf_file_p");
static  boolean
elf_file_p(Elf32_External_Ehdr *x_ehdrp)
{
  return ((x_ehdrp->e_ident[0] == 0x7F)
   && (x_ehdrp->e_ident[1] == 'E')
   && (x_ehdrp->e_ident[2] == 'L')
   && (x_ehdrp->e_ident[3] == 'F'));
}
const bfd_target *
bfd_elf32_object_p(bfd *abfd) asm("_bfd_elf32_object_p");
const bfd_target *
bfd_elf32_object_p(bfd *abfd)
{
  Elf32_External_Ehdr x_ehdr;
  Elf_Internal_Ehdr *i_ehdrp;
  Elf32_External_Shdr x_shdr;
  Elf_Internal_Shdr *i_shdrp = 
                              ((void *)0)
                                  ;
  unsigned int shindex;
  char *shstrtab;
  struct n64_tag_elf_backend_data *ebd;
  struct n64_tag_elf_obj_tdata *preserved_tdata = ((abfd) -> tdata.elf_obj_data);
  struct n64_tag_elf_obj_tdata *new_tdata = 
                                   ((void *)0)
                                       ;



  if (bfd_read ((void *) & x_ehdr, sizeof (x_ehdr), 1, abfd) != sizeof (x_ehdr))
    {
      if (bfd_get_error () != bfd_error_system_call)
 goto got_wrong_format_error;
      else
 goto got_no_match;
    }







  if ((elf_file_p (&x_ehdr) == cxx_false) ||
      (x_ehdr.e_ident[6] != 1) ||
      (x_ehdr.e_ident[4] != 1))
    goto got_wrong_format_error;


  switch (x_ehdr.e_ident[5])
    {
    case 2:
      if (!abfd->xvec->header_byteorder_big_p)
 goto got_wrong_format_error;
      break;
    case 1:
      if (abfd->xvec->header_byteorder_big_p)
 goto got_wrong_format_error;
      break;
    case 0:
    default:
      goto got_wrong_format_error;
    }




  new_tdata = ((struct n64_tag_elf_obj_tdata *)
        bfd_zalloc (abfd, sizeof (struct n64_tag_elf_obj_tdata)));
  if (new_tdata == 
                  ((void *)0)
                      )
    goto got_no_memory_error;
  ((abfd) -> tdata.elf_obj_data) = new_tdata;


  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  elf_swap_ehdr_in (abfd, &x_ehdr, i_ehdrp);





  if (i_ehdrp->e_shoff == 0)
    goto got_wrong_format_error;




  if (i_ehdrp->e_shentsize != sizeof (x_shdr))
    goto got_wrong_format_error;

  ebd = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);



  if (ebd->elf_machine_code != i_ehdrp->e_machine
      && (ebd->elf_machine_alt1 == 0 || i_ehdrp->e_machine != ebd->elf_machine_alt1)
      && (ebd->elf_machine_alt2 == 0 || i_ehdrp->e_machine != ebd->elf_machine_alt2))
    {
      const bfd_target * const *target_ptr;

      if (ebd->elf_machine_code != 0)
 goto got_wrong_format_error;



      for (target_ptr = bfd_target_vector; *target_ptr != 
                                                         ((void *)0)
                                                             ; target_ptr++)
 {
   struct n64_tag_elf_backend_data *back;

   if ((*target_ptr)->flavour != bfd_target_elf_flavour)
     continue;
   back = (struct n64_tag_elf_backend_data *) (*target_ptr)->backend_data;
   if (back->elf_machine_code == i_ehdrp->e_machine)
     {


       goto got_wrong_format_error;
     }
 }
    }

  if (i_ehdrp->e_type == 2)
    abfd->flags |= 0x02;
  else if (i_ehdrp->e_type == 3)
    abfd->flags |= 0x40;

  if (i_ehdrp->e_phnum > 0)
    abfd->flags |= 0x100;

  if (! bfd_default_set_arch_mach (abfd, ebd->arch, 0))
    goto got_no_match;


  ((abfd)->start_address) = i_ehdrp->e_entry;




  i_shdrp = ((Elf_Internal_Shdr *)
      bfd_alloc (abfd, sizeof (*i_shdrp) * i_ehdrp->e_shnum));
  (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr) = ((Elf_Internal_Shdr **)
       bfd_alloc (abfd,
           sizeof (i_shdrp) * i_ehdrp->e_shnum));
  if (!i_shdrp || !(((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr))
    goto got_no_memory_error;
  if (bfd_seek (abfd, i_ehdrp->e_shoff, 
                                       0
                                               ) != 0)
    goto got_no_match;
  for (shindex = 0; shindex < i_ehdrp->e_shnum; shindex++)
    {
      if (bfd_read ((void *) & x_shdr, sizeof x_shdr, 1, abfd) != sizeof (x_shdr))
 goto got_no_match;
      elf_swap_shdr_in (abfd, &x_shdr, i_shdrp + shindex);
      (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[shindex] = i_shdrp + shindex;
    }
  if (i_ehdrp->e_shstrndx)
    {
      if (! bfd_section_from_shdr (abfd, i_ehdrp->e_shstrndx))
 goto got_no_match;
    }


  if (i_ehdrp->e_phnum == 0)
    ((abfd) -> tdata.elf_obj_data)->phdr = 
                            ((void *)0)
                                ;
  else
    {
      Elf_Internal_Phdr *i_phdr;
      unsigned int i;

      ((abfd) -> tdata.elf_obj_data)->phdr = ((Elf_Internal_Phdr *)
    bfd_alloc (abfd,
        (i_ehdrp->e_phnum
         * sizeof (Elf_Internal_Phdr))));
      if (((abfd) -> tdata.elf_obj_data)->phdr == 
                                   ((void *)0)
                                       )
 goto got_no_memory_error;
      if (bfd_seek (abfd, i_ehdrp->e_phoff, 
                                           0
                                                   ) != 0)
 goto got_no_match;
      i_phdr = ((abfd) -> tdata.elf_obj_data)->phdr;
      for (i = 0; i < i_ehdrp->e_phnum; i++, i_phdr++)
 {
   Elf32_External_Phdr x_phdr;

   if (bfd_read ((void *) &x_phdr, sizeof x_phdr, 1, abfd)
       != sizeof x_phdr)
     goto got_no_match;
   bfd_elf32_swap_phdr_in (abfd, &x_phdr, i_phdr);
 }
    }







  shstrtab = bfd_elf_get_str_section (abfd, i_ehdrp->e_shstrndx);
  if (!shstrtab)
    goto got_no_match;





  for (shindex = 1; shindex < i_ehdrp->e_shnum; shindex++)
    {
      if (! bfd_section_from_shdr (abfd, shindex))
 goto got_no_match;
    }



  if (ebd->elf_backend_object_p)
    {
      if ((*ebd->elf_backend_object_p) (abfd) == cxx_false)
 goto got_wrong_format_error;
    }

  return (abfd->xvec);

got_wrong_format_error:
  bfd_set_error (bfd_error_wrong_format);
  goto got_no_match;
got_no_memory_error:
  bfd_set_error (bfd_error_no_memory);
  goto got_no_match;
got_no_match:
  if (new_tdata != 
                  ((void *)0)
      
     && new_tdata->elf_sect_ptr != 
                                   ((void *)0)
                                       )
    (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (new_tdata->elf_sect_ptr); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  if (i_shdrp != 
                ((void *)0)
                    )
    (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (i_shdrp); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  if (new_tdata != 
                  ((void *)0)
                      )
    (void) __extension__ ({ struct n64_tag_obstack *__o = (&(abfd->memory)); void *__obj = (new_tdata); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  ((abfd) -> tdata.elf_obj_data) = preserved_tdata;
  return (
         ((void *)0)
             );
}




static void
write_relocs(bfd *abfd, asection *sec, void *data) asm("_write_relocs");
static void
write_relocs(bfd *abfd, asection *sec, void *data)
{
  boolean *failedp = (boolean *) data;
  Elf_Internal_Shdr *rela_hdr;
  Elf32_External_Rela *outbound_relocas;
  Elf32_External_Rel *outbound_relocs;
  unsigned int idx;
  int use_rela_p = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->use_rela_p;
  asymbol *last_sym = 0;
  int last_sym_idx = 9999999;


  if (*failedp)
    return;

  if ((sec->flags & 0x004) == 0)
    return;





  if (sec->reloc_count == 0)
    return;

  rela_hdr = &((struct n64_tag_bfd_elf_section_data*)sec->used_by_bfd)->rel_hdr;

  rela_hdr->sh_size = rela_hdr->sh_entsize * sec->reloc_count;
  rela_hdr->contents = (void *) bfd_alloc (abfd, rela_hdr->sh_size);
  if (rela_hdr->contents == 
                           ((void *)0)
                               )
    {
      bfd_set_error (bfd_error_no_memory);
      *failedp = cxx_true;
      return;
    }


  if (use_rela_p)
    {
      outbound_relocas = (Elf32_External_Rela *) rela_hdr->contents;

      for (idx = 0; idx < sec->reloc_count; idx++)
 {
   Elf_Internal_Rela dst_rela;
   Elf32_External_Rela *src_rela;
   arelent *ptr;
   asymbol *sym;
   int n;

   ptr = sec->orelocation[idx];
   src_rela = outbound_relocas + idx;




   if ((abfd->flags & (0x02 | 0x40)) == 0)
     dst_rela.r_offset = ptr->address;
   else
     dst_rela.r_offset = ptr->address + sec->vma;

   sym = *ptr->sym_ptr_ptr;
   if (sym == last_sym)
     n = last_sym_idx;
   else
     {
       last_sym = sym;
       last_sym_idx = n = _bfd_elf_symbol_from_bfd_symbol (abfd, &sym);
     }
   dst_rela.r_info = (((n) << 8) + ((ptr->howto->type) & 0xff));

   dst_rela.r_addend = ptr->addend;
   bfd_elf32_swap_reloca_out (abfd, &dst_rela, src_rela);
 }
    }
  else

    {
      outbound_relocs = (Elf32_External_Rel *) rela_hdr->contents;

      for (idx = 0; idx < sec->reloc_count; idx++)
 {
   Elf_Internal_Rel dst_rel;
   Elf32_External_Rel *src_rel;
   arelent *ptr;
   int n;
   asymbol *sym;

   ptr = sec->orelocation[idx];
   sym = *ptr->sym_ptr_ptr;
   src_rel = outbound_relocs + idx;




   if ((abfd->flags & (0x02 | 0x40)) == 0)
     dst_rel.r_offset = ptr->address;
   else
     dst_rel.r_offset = ptr->address + sec->vma;

   if (sym == last_sym)
     n = last_sym_idx;
   else
     {
       last_sym = sym;
       last_sym_idx = n = _bfd_elf_symbol_from_bfd_symbol (abfd, &sym);
     }
   dst_rel.r_info = (((n) << 8) + ((ptr->howto->type) & 0xff));

   bfd_elf32_swap_reloc_out (abfd, &dst_rel, src_rel);
 }
    }
}

static int
write_out_phdrs(bfd *abfd, Elf_Internal_Phdr *phdr, int count) asm("_write_out_phdrs");
static int
write_out_phdrs(bfd *abfd, Elf_Internal_Phdr *phdr, int count)
{
  while (count--)
    {
      Elf32_External_Phdr extphdr;
      bfd_elf32_swap_phdr_out (abfd, phdr, &extphdr);
      if (bfd_write (&extphdr, sizeof (Elf32_External_Phdr), 1, abfd)
   != sizeof (Elf32_External_Phdr))
 return -1;
      phdr++;
    }
  return 0;
}

static boolean
write_shdrs_and_ehdr(bfd *abfd) asm("_write_shdrs_and_ehdr");
static boolean
write_shdrs_and_ehdr(bfd *abfd)
{
  Elf32_External_Ehdr x_ehdr;
  Elf_Internal_Ehdr *i_ehdrp;
  Elf32_External_Shdr *x_shdrp;
  Elf_Internal_Shdr **i_shdrp;
  unsigned int count;

  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  i_shdrp = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr);






  elf_swap_ehdr_out (abfd, i_ehdrp, &x_ehdr);
  if (bfd_seek (abfd, (file_ptr) 0, 
                                   0
                                           ) != 0
      || (bfd_write ((void *) & x_ehdr, sizeof (x_ehdr), 1, abfd)
   != sizeof (x_ehdr)))
    return cxx_false;


  x_shdrp = (Elf32_External_Shdr *)
    bfd_alloc (abfd, sizeof (*x_shdrp) * (i_ehdrp->e_shnum));
  if (!x_shdrp)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  for (count = 0; count < i_ehdrp->e_shnum; count++)
    {



      elf_swap_shdr_out (abfd, i_shdrp[count], x_shdrp + count);
    }
  if (bfd_seek (abfd, (file_ptr) i_ehdrp->e_shoff, 
                                                  0
                                                          ) != 0
      || (bfd_write ((void *) x_shdrp, sizeof (*x_shdrp), i_ehdrp->e_shnum, abfd)
   != sizeof (*x_shdrp) * i_ehdrp->e_shnum))
    return cxx_false;



  return cxx_true;
}

static long
elf_slurp_symbol_table(bfd *abfd, asymbol **symptrs, boolean dynamic) asm("_elf_slurp_symbol_table");
static long
elf_slurp_symbol_table(bfd *abfd, asymbol **symptrs, boolean dynamic)
{
  Elf_Internal_Shdr *hdr;
  long symcount;
  elf_symbol_type *sym;
  elf_symbol_type *symbase;
  Elf_Internal_Sym i_sym;
  Elf32_External_Sym *x_symp = 
                            ((void *)0)
                                ;
  if (dynamic)
    hdr = &((abfd) -> tdata.elf_obj_data)->dynsymtab_hdr;
  else
    hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;
  if (bfd_seek (abfd, hdr->sh_offset, 
                                     0
                                             ) == -1)
    return -1;

  symcount = hdr->sh_size / sizeof (Elf32_External_Sym);

  if (symcount == 0)
    sym = symbase = 
                   ((void *)0)
                       ;
  else
    {
      long i;

      if (bfd_seek (abfd, hdr->sh_offset, 
                                         0
                                                 ) == -1)
 return -1;

      symbase = ((elf_symbol_type *)
   bfd_zalloc (abfd, symcount * sizeof (elf_symbol_type)));
      if (symbase == (elf_symbol_type *) 
                                        ((void *)0)
                                            )
 {
   bfd_set_error (bfd_error_no_memory);
   return -1;
 }
      sym = symbase;


      x_symp = ((Elf32_External_Sym *)
  malloc (symcount * sizeof (Elf32_External_Sym)));
      if (x_symp == 
                   ((void *)0) 
                        && symcount != 0)
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }

      if (bfd_read ((void *) x_symp, sizeof (Elf32_External_Sym), symcount, abfd)
   != symcount * sizeof (Elf32_External_Sym))
 goto error_return;

      for (i = 1; i < symcount; i++)
 {
   bfd_elf32_swap_symbol_in (abfd, x_symp + i, &i_sym);
   memcpy (&sym->internal_elf_sym, &i_sym, sizeof (Elf_Internal_Sym));



   sym->symbol.the_bfd = abfd;

   sym->symbol.name = bfd_elf_string_from_elf_section (abfd,
             hdr->sh_link,
             i_sym.st_name);

   sym->symbol.value = i_sym.st_value;

   if (i_sym.st_shndx > 0 && i_sym.st_shndx < 0xFF00)
     {
       sym->symbol.section = bfd_section_from_elf_index (abfd,
           i_sym.st_shndx);
       if (sym->symbol.section == 
                                 ((void *)0)
                                     )
  {



    sym->symbol.section = ((asection *) &bfd_abs_section);
  }
     }
   else if (i_sym.st_shndx == 0xFFF1)
     {
       sym->symbol.section = ((asection *) &bfd_abs_section);
     }
   else if (i_sym.st_shndx == 0xFFF2)
     {
       sym->symbol.section = ((asection *) &bfd_com_section);




       sym->symbol.value = i_sym.st_size;
     }
   else if (i_sym.st_shndx == 0)
     {
       sym->symbol.section = ((asection *) &bfd_und_section);
     }
   else
     sym->symbol.section = ((asection *) &bfd_abs_section);

   sym->symbol.value -= sym->symbol.section->vma;

   switch ((((unsigned int)(i_sym.st_info)) >> 4))
     {
     case 0:
       sym->symbol.flags |= 0x01;
       break;
     case 1:
       if (i_sym.st_shndx != 0
    && i_sym.st_shndx != 0xFFF2)
  sym->symbol.flags |= 0x02;
       break;
     case 2:
       sym->symbol.flags |= 0x80;
       break;
     }

   switch (((i_sym.st_info) & 0xF))
     {
     case 3:
       sym->symbol.flags |= 0x100 | 0x08;
       break;
     case 4:
       sym->symbol.flags |= 0x4000 | 0x08;
       break;
     case 2:
       sym->symbol.flags |= 0x10;
       break;
     }

   if (dynamic)
     sym->symbol.flags |= 0x8000;


   {
     struct n64_tag_elf_backend_data *ebd = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
     if (ebd->elf_backend_symbol_processing)
       (*ebd->elf_backend_symbol_processing) (abfd, &sym->symbol);
   }

   sym++;
 }
    }


  {
    struct n64_tag_elf_backend_data *ebd = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
    if (ebd->elf_backend_symbol_table_processing)
      (*ebd->elf_backend_symbol_table_processing) (abfd, symbase, symcount);
  }



  symcount = sym - symbase;


  if (symptrs)
    {
      long l = symcount;

      sym = symbase;
      while (l-- > 0)
 {
   *symptrs++ = &sym->symbol;
   sym++;
 }
      *symptrs = 0;
    }

  if (x_symp != 
               ((void *)0)
                   )
    free (x_symp);
  return symcount;
error_return:
  if (x_symp != 
               ((void *)0)
                   )
    free (x_symp);
  return -1;
}



static boolean
elf_slurp_reloc_table(bfd *abfd, asection *asect, asymbol **symbols) asm("_elf_slurp_reloc_table");
static boolean
elf_slurp_reloc_table(bfd *abfd, asection *asect, asymbol **symbols)
{
  struct n64_tag_elf_backend_data * const ebd = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  struct n64_tag_bfd_elf_section_data * const d = ((struct n64_tag_bfd_elf_section_data*)asect->used_by_bfd);
  void * allocated = 
                 ((void *)0)
                     ;
  bfd_byte *native_relocs;
  arelent *relents;
  arelent *relent;
  unsigned int i;
  int entsize;

  if (asect->relocation != 
                          ((void *)0)
      
     || (asect->flags & 0x004) == 0
      || asect->reloc_count == 0)
    return cxx_true;

  { if (!(asect->rel_filepos == d->rel_hdr.sh_offset && (asect->reloc_count == d->rel_hdr.sh_size / d->rel_hdr.sh_entsize))) bfd_assert("elfcode.h",1062); }

                                                   ;

  allocated = (void *) malloc ((size_t) d->rel_hdr.sh_size);
  if (allocated == 
                  ((void *)0)
                      )
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }

  if (bfd_seek (abfd, asect->rel_filepos, 
                                         0
                                                 ) != 0
      || (bfd_read (allocated, 1, d->rel_hdr.sh_size, abfd)
   != d->rel_hdr.sh_size))
    goto error_return;

  native_relocs = (bfd_byte *) allocated;

  relents = ((arelent *)
      bfd_alloc (abfd, asect->reloc_count * sizeof (arelent)));
  if (relents == 
                ((void *)0)
                    )
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }

  entsize = d->rel_hdr.sh_entsize;
  { if (!(entsize == sizeof (Elf32_External_Rel) || entsize == sizeof (Elf32_External_Rela))) bfd_assert("elfcode.h",1089); }
                                                ;

  for (i = 0, relent = relents;
       i < asect->reloc_count;
       i++, relent++, native_relocs += entsize)
    {
      Elf_Internal_Rela rela;
      Elf_Internal_Rel rel;

      if (entsize == sizeof (Elf32_External_Rela))
 bfd_elf32_swap_reloca_in (abfd, (Elf32_External_Rela *) native_relocs, &rela);
      else
 {
   bfd_elf32_swap_reloc_in (abfd, (Elf32_External_Rel *) native_relocs, &rel);
   rela.r_offset = rel.r_offset;
   rela.r_info = rel.r_info;
   rela.r_addend = 0;
 }




      if ((abfd->flags & (0x02 | 0x40)) == 0)
 relent->address = rela.r_offset;
      else
 relent->address = rela.r_offset - asect->vma;

      if (((rela.r_info) >> 8) == 0)
 relent->sym_ptr_ptr = ((asection *) &bfd_abs_section)->symbol_ptr_ptr;
      else
 {
   asymbol **ps, *s;

   ps = symbols + ((rela.r_info) >> 8) - 1;
   s = *ps;


   if ((s->flags & 0x100) == 0)
     relent->sym_ptr_ptr = ps;
   else
     relent->sym_ptr_ptr = s->section->symbol_ptr_ptr;
 }

      relent->addend = rela.r_addend;

      if (entsize == sizeof (Elf32_External_Rela))
 (*ebd->elf_info_to_howto) (abfd, relent, &rela);
      else
 (*ebd->elf_info_to_howto_rel) (abfd, relent, &rel);
    }

  asect->relocation = relents;

  if (allocated != 
                  ((void *)0)
                      )
    free (allocated);

  return cxx_true;

 error_return:
  if (allocated != 
                  ((void *)0)
                      )
    free (allocated);
  return cxx_false;
}
char *
bfd_elf32_core_file_failing_command(bfd *abfd) asm("_bfd_elf32_core_file_failing_command");
char *
bfd_elf32_core_file_failing_command(bfd *abfd)
{
  return 
        ((void *)0)
            ;
}






int
bfd_elf32_core_file_failing_signal(bfd *abfd) asm("_bfd_elf32_core_file_failing_signal");
int
bfd_elf32_core_file_failing_signal(bfd *abfd)
{






  return -1;
}







boolean
bfd_elf32_core_file_matches_executable_p(bfd *core_bfd, bfd *exec_bfd) asm("_bfd_elf32_core_file_matches_executable_p");
boolean
bfd_elf32_core_file_matches_executable_p(bfd *core_bfd, bfd *exec_bfd)
{







  if (core_bfd->xvec != exec_bfd->xvec)
    {
      bfd_set_error (bfd_error_system_call);
      return cxx_false;
    }
  return cxx_true;


}
static boolean
elf_corefile_note(bfd *abfd, Elf_Internal_Phdr *hdr) asm("_elf_corefile_note");
static boolean
elf_corefile_note(bfd *abfd, Elf_Internal_Phdr *hdr)
{
  Elf_External_Note *x_note_p;
  Elf_Internal_Note i_note;
  char *buf = 
             ((void *)0)
                 ;
  char *namedata;
  char *descdata;
  char *sectname;
  long filepos;
  asection *newsect;

  if (hdr->p_filesz > 0
      && (buf = (char *) malloc ((size_t) hdr->p_filesz)) != 
                                                            ((void *)0)
      
     && bfd_seek (abfd, hdr->p_offset, 
                                       0
                                               ) != -1
      && bfd_read ((void *) buf, hdr->p_filesz, 1, abfd) == hdr->p_filesz)
    {
      x_note_p = (Elf_External_Note *) buf;
      while ((char *) x_note_p < (buf + hdr->p_filesz))
 {
   i_note.namesz = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) x_note_p->namesz));
   i_note.descsz = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) x_note_p->descsz));
   i_note.type = ((*((abfd)->xvec->bfd_h_getx32)) ((bfd_byte *) x_note_p->type));
   namedata = x_note_p->name;
   descdata = namedata + ((( (i_note.namesz) + ((4) -1)) & (~((4)-1))));
   filepos = hdr->p_offset + (descdata - buf);
   switch (i_note.type)
     {
     case 1:

       if (! cxx_true)
  return cxx_false;
       sectname = ".prstatus";
       break;
     case 2:

       if (! cxx_true)
  return cxx_false;
       sectname = ".fpregset";
       break;
     case 3:

       if (! cxx_true)
  return cxx_false;
       sectname = ".prpsinfo";
       break;
     default:

       sectname = 
                 ((void *)0)
                     ;
       break;
     }
   if (sectname != 
                  ((void *)0)
                      )
     {
       newsect = bfd_make_section (abfd, sectname);
       if (newsect == 
                     ((void *)0)
                         )
  return cxx_false;
       newsect->_raw_size = i_note.descsz;
       newsect->filepos = filepos;
       newsect->flags = 0x001 | 0x200;
       newsect->alignment_power = 2;
     }
   x_note_p = (Elf_External_Note *)
     (descdata + ((( (i_note.descsz) + ((4) -1)) & (~((4)-1)))));
 }
    }
  if (buf != 
            ((void *)0)
                )
    {
      free (buf);
    }
  else if (hdr->p_filesz > 0)
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }
  return cxx_true;

}
const bfd_target *
bfd_elf32_core_file_p(bfd *abfd) asm("_bfd_elf32_core_file_p");
const bfd_target *
bfd_elf32_core_file_p(bfd *abfd)
{
  Elf32_External_Ehdr x_ehdr;
  Elf_Internal_Ehdr *i_ehdrp;
  Elf32_External_Phdr x_phdr;
  Elf_Internal_Phdr *i_phdrp;
  unsigned int phindex;
  struct n64_tag_elf_backend_data *ebd;



  if (bfd_read ((void *) & x_ehdr, sizeof (x_ehdr), 1, abfd) != sizeof (x_ehdr))
    {
      if (bfd_get_error () != bfd_error_system_call)
 bfd_set_error (bfd_error_wrong_format);
      return 
            ((void *)0)
                ;
    }







  if (elf_file_p (&x_ehdr) == cxx_false)
    {
    wrong:
      bfd_set_error (bfd_error_wrong_format);
      return 
            ((void *)0)
                ;
    }



  {

    int desired_address_size = 1;





    if (x_ehdr.e_ident[4] != desired_address_size)
      goto wrong;
  }


  switch (x_ehdr.e_ident[5])
    {
    case 2:
      if (abfd->xvec->byteorder_big_p == cxx_false)
 goto wrong;
      break;
    case 1:
      if (abfd->xvec->byteorder_big_p == cxx_true)
 goto wrong;
      break;
    case 0:
    default:
      goto wrong;
    }




  ((abfd) -> tdata.elf_obj_data) =
    (struct n64_tag_elf_obj_tdata *) bfd_zalloc (abfd, sizeof (struct n64_tag_elf_obj_tdata));
  if (((abfd) -> tdata.elf_obj_data) == 
                         ((void *)0)
                             )
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }




  i_ehdrp = (((abfd) -> tdata.elf_obj_data) -> elf_header);
  elf_swap_ehdr_in (abfd, &x_ehdr, i_ehdrp);




  ebd = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);



  if (ebd->elf_machine_code != i_ehdrp->e_machine
      && (ebd->elf_machine_alt1 == 0 || i_ehdrp->e_machine != ebd->elf_machine_alt1)
      && (ebd->elf_machine_alt2 == 0 || i_ehdrp->e_machine != ebd->elf_machine_alt2))
    {
      const bfd_target * const *target_ptr;

      if (ebd->elf_machine_code != 0)
 goto wrong;



      for (target_ptr = bfd_target_vector; *target_ptr != 
                                                         ((void *)0)
                                                             ; target_ptr++)
 {
   struct n64_tag_elf_backend_data *back;

   if ((*target_ptr)->flavour != bfd_target_elf_flavour)
     continue;
   back = (struct n64_tag_elf_backend_data *) (*target_ptr)->backend_data;
   if (back->elf_machine_code == i_ehdrp->e_machine)
     {


       goto wrong;
     }
 }
    }



  if (i_ehdrp->e_phoff == 0 || i_ehdrp->e_type != 4)
    goto wrong;







  if (i_ehdrp->e_phentsize != sizeof (x_phdr))
    goto wrong;
  i_phdrp = (Elf_Internal_Phdr *)
    bfd_alloc (abfd, sizeof (*i_phdrp) * i_ehdrp->e_phnum);
  if (!i_phdrp)
    {
      bfd_set_error (bfd_error_no_memory);
      return 
            ((void *)0)
                ;
    }
  if (bfd_seek (abfd, i_ehdrp->e_phoff, 
                                       0
                                               ) == -1)
    return 
          ((void *)0)
              ;
  for (phindex = 0; phindex < i_ehdrp->e_phnum; phindex++)
    {
      if (bfd_read ((void *) & x_phdr, sizeof (x_phdr), 1, abfd)
   != sizeof (x_phdr))
 return 
       ((void *)0)
           ;
      bfd_elf32_swap_phdr_in (abfd, &x_phdr, i_phdrp + phindex);
    }




  for (phindex = 0; phindex < i_ehdrp->e_phnum; phindex++)
    {
      bfd_section_from_phdr (abfd, i_phdrp + phindex, phindex);
      if ((i_phdrp + phindex)->p_type == 4)
 {
   if (! elf_corefile_note (abfd, i_phdrp + phindex))
     return 
           ((void *)0)
               ;
 }
    }



  ((abfd)->start_address) = i_ehdrp->e_entry;

  return abfd->xvec;
}
static boolean elf_link_add_object_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_elf_link_add_object_symbols");
static boolean elf_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_elf_link_add_archive_symbols");
static Elf_Internal_Rela *elf_link_read_relocs
  (bfd *, asection *, void *, Elf_Internal_Rela *, boolean) asm("_elf_link_read_relocs");
static boolean elf_export_symbol
  (struct n64_tag_elf_link_hash_entry *, void *) asm("_elf_export_symbol");
static boolean elf_adjust_dynamic_symbol
  (struct n64_tag_elf_link_hash_entry *, void *) asm("_elf_adjust_dynamic_symbol");




struct n64_tag_elf_info_failed
{
  boolean failed;
  struct n64_tag_bfd_link_info *info;
};




boolean
bfd_elf32_bfd_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_bfd_elf32_bfd_link_add_symbols");
boolean
bfd_elf32_bfd_link_add_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  switch (((abfd)->format))
    {
    case bfd_object:
      return elf_link_add_object_symbols (abfd, info);
    case bfd_archive:
      return elf_link_add_archive_symbols (abfd, info);
    default:
      bfd_set_error (bfd_error_wrong_format);
      return cxx_false;
    }
}
static boolean
elf_link_add_archive_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_elf_link_add_archive_symbols");
static boolean
elf_link_add_archive_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  symindex c;
  boolean *defined = 
                    ((void *)0)
                        ;
  boolean *included = 
                     ((void *)0)
                         ;
  carsym *symdefs;
  boolean loop;

  if (! ((abfd)->has_armap))
    {

      if (bfd_openr_next_archived_file (abfd, (bfd *) 
                                                     ((void *)0)
                                                         ) == 
                                                              ((void *)0)
                                                                  )
 return cxx_true;
      bfd_set_error (bfd_error_no_armap);
      return cxx_false;
    }




  c = ((abfd)->tdata.aout_ar_data)->symdef_count;
  if (c == 0)
    return cxx_true;
  defined = (boolean *) malloc (c * sizeof (boolean));
  included = (boolean *) malloc (c * sizeof (boolean));
  if (defined == (boolean *) 
                            ((void *)0) 
                                 || included == (boolean *) 
                                                            ((void *)0)
                                                                )
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }
  memset (defined, 0, c * sizeof (boolean));
  memset (included, 0, c * sizeof (boolean));

  symdefs = ((abfd)->tdata.aout_ar_data)->symdefs;

  do
    {
      file_ptr last;
      symindex i;
      carsym *symdef;
      carsym *symdefend;

      loop = cxx_false;
      last = -1;

      symdef = symdefs;
      symdefend = symdef + c;
      for (i = 0; symdef < symdefend; symdef++, i++)
 {
   struct n64_tag_elf_link_hash_entry *h;
   bfd *element;
   struct n64_tag_bfd_link_hash_entry *undefs_tail;
   symindex mark;

   if (defined[i] || included[i])
     continue;
   if (symdef->file_offset == last)
     {
       included[i] = cxx_true;
       continue;
     }

   h = ((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (symdef->name), (cxx_false), (cxx_false), (cxx_false)))
                            ;
   if (h == (struct n64_tag_elf_link_hash_entry *) 
                                          ((void *)0)
                                              )
     continue;
   if (h->root.type != bfd_link_hash_undefined)
     {
       if (h->root.type != bfd_link_hash_undefweak)
  defined[i] = cxx_true;
       continue;
     }



   element = _bfd_get_elt_at_filepos (abfd, symdef->file_offset);
   if (element == (bfd *) 
                         ((void *)0)
                             )
     goto error_return;

   if (! bfd_check_format (element, bfd_object))
     goto error_return;




   if (element->archive_pass != 0)
     {
       bfd_set_error (bfd_error_bad_value);
       goto error_return;
     }
   element->archive_pass = 1;

   undefs_tail = info->hash->undefs_tail;

   if (! (*info->callbacks->add_archive_element) (info, element,
        symdef->name))
     goto error_return;
   if (! elf_link_add_object_symbols (element, info))
     goto error_return;
   if (undefs_tail != info->hash->undefs_tail)
     loop = cxx_true;



   mark = i;
   do
     {
       included[mark] = cxx_true;
       if (mark == 0)
  break;
       --mark;
     }
   while (symdefs[mark].file_offset == symdef->file_offset);



   last = symdef->file_offset;
 }
    }
  while (loop);

  free (defined);
  free (included);

  return cxx_true;

 error_return:
  if (defined != (boolean *) 
                            ((void *)0)
                                )
    free (defined);
  if (included != (boolean *) 
                             ((void *)0)
                                 )
    free (included);
  return cxx_false;
}



static boolean
elf_link_add_object_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_elf_link_add_object_symbols");
static boolean
elf_link_add_object_symbols(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  boolean (*add_symbol_hook) (bfd *, struct n64_tag_bfd_link_info *, const Elf_Internal_Sym *, const char **, flagword *, asection **, bfd_vma *)


                                  ;
  boolean (*check_relocs) (bfd *, struct n64_tag_bfd_link_info *, asection *, const Elf_Internal_Rela *)
                                              ;
  boolean collect;
  Elf_Internal_Shdr *hdr;
  size_t symcount;
  size_t extsymcount;
  size_t extsymoff;
  Elf32_External_Sym *buf = 
                         ((void *)0)
                             ;
  struct n64_tag_elf_link_hash_entry **sym_hash;
  boolean dynamic;
  Elf32_External_Dyn *dynbuf = 
                            ((void *)0)
                                ;
  struct n64_tag_elf_link_hash_entry *weaks;
  Elf32_External_Sym *esym;
  Elf32_External_Sym *esymend;

  add_symbol_hook = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->elf_add_symbol_hook;
  collect = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->collect;





  if (! info->shared)
    {
      asection *s;

      for (s = abfd->sections; s != 
                                   ((void *)0)
                                       ; s = s->next)
 {
   const char *name;

   name = ((s)->name + 0);
   if (strncmp (name, ".gnu.warning.", sizeof ".gnu.warning." - 1) == 0)
     {
       char *msg;
       bfd_size_type sz;

       sz = ((s->reloc_done ? (abort(),1): (s)->_raw_size));
       msg = (char *) bfd_alloc (abfd, sz);
       if (msg == 
                 ((void *)0)
                     )
  {
    bfd_set_error (bfd_error_no_memory);
    goto error_return;
  }

       if (! bfd_get_section_contents (abfd, s, msg, (file_ptr) 0, sz))
  goto error_return;

       if (! (_bfd_generic_link_add_one_symbol
       (info, abfd,
        name + sizeof ".gnu.warning." - 1,
        0x1000, s, (bfd_vma) 0, msg, cxx_false, collect,
        (struct n64_tag_bfd_link_hash_entry **) 
                                       ((void *)0)
                                           )))
  goto error_return;

       if (! info->relocateable)
  {


    s->_raw_size = 0;
  }
     }
 }
    }




  if ((((abfd) -> tdata.elf_obj_data) -> symtab_section) == 0
      && (((abfd) -> tdata.elf_obj_data) -> dynsymtab_section) != 0)
    {
      (((abfd) -> tdata.elf_obj_data) -> symtab_section) = (((abfd) -> tdata.elf_obj_data) -> dynsymtab_section);
      ((abfd) -> tdata.elf_obj_data)->symtab_hdr = ((abfd) -> tdata.elf_obj_data)->dynsymtab_hdr;
    }

  hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;
  symcount = hdr->sh_size / sizeof (Elf32_External_Sym);




  if ((((abfd) -> tdata.elf_obj_data) -> bad_symtab))
    {
      extsymcount = symcount;
      extsymoff = 0;
    }
  else
    {
      extsymcount = symcount - hdr->sh_info;
      extsymoff = hdr->sh_info;
    }

  buf = (Elf32_External_Sym *) malloc (extsymcount * sizeof (Elf32_External_Sym));
  if (buf == 
            ((void *)0) 
                 && extsymcount != 0)
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }



  sym_hash = ((struct n64_tag_elf_link_hash_entry **)
       bfd_alloc (abfd,
    extsymcount * sizeof (struct n64_tag_elf_link_hash_entry *)));
  if (sym_hash == 
                 ((void *)0)
                     )
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }
  (((abfd) -> tdata.elf_obj_data) -> sym_hashes) = sym_hash;

  if ((((abfd) -> tdata.elf_obj_data) -> elf_header)->e_type != 3)
    {
      dynamic = cxx_false;






      if (info->shared
   && ! ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created
   && abfd->xvec == info->hash->creator)
 {
   if (! bfd_elf32_link_create_dynamic_sections (abfd, info))
     goto error_return;
 }
    }
  else
    {
      asection *s;
      boolean add_needed;
      const char *name;
      bfd_size_type oldsize;
      bfd_size_type strindex;

      dynamic = cxx_true;




      if (info->relocateable
   || info->hash->creator != abfd->xvec)
 {
   bfd_set_error (bfd_error_invalid_operation);
   goto error_return;
 }
      add_needed = cxx_true;
      name = ((char *) (abfd)->filename);
      if ((((abfd) -> tdata.elf_obj_data) -> dt_needed_name) != 
                                      ((void *)0)
                                          )
 {
   name = (((abfd) -> tdata.elf_obj_data) -> dt_needed_name);
   if (*name == '\0')
     add_needed = cxx_false;
 }
      s = bfd_get_section_by_name (abfd, ".dynamic");
      if (s != 
              ((void *)0)
                  )
 {
   Elf32_External_Dyn *extdyn;
   Elf32_External_Dyn *extdynend;
   int elfsec;
   unsigned long link;

   dynbuf = (Elf32_External_Dyn *) malloc ((size_t) s->_raw_size);
   if (dynbuf == 
                ((void *)0)
                    )
     {
       bfd_set_error (bfd_error_no_memory);
       goto error_return;
     }

   if (! bfd_get_section_contents (abfd, s, (void *) dynbuf,
       (file_ptr) 0, s->_raw_size))
     goto error_return;

   elfsec = _bfd_elf_section_from_bfd_section (abfd, s);
   if (elfsec == -1)
     goto error_return;
   link = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[elfsec]->sh_link;

   extdyn = dynbuf;
   extdynend = extdyn + s->_raw_size / sizeof (Elf32_External_Dyn);
   for (; extdyn < extdynend; extdyn++)
     {
       Elf_Internal_Dyn dyn;

       bfd_elf32_swap_dyn_in (abfd, extdyn, &dyn);
       if (add_needed && dyn.d_tag == 14)
  {
    name = bfd_elf_string_from_elf_section (abfd, link,
         dyn.d_un.d_val);
    if (name == 
               ((void *)0)
                   )
      goto error_return;
  }
       if (dyn.d_tag == 1)
  {
    struct n64_tag_bfd_link_needed_list *n, **pn;
    char *fnm, *anm;

    n = ((struct n64_tag_bfd_link_needed_list *)
         bfd_alloc (abfd, sizeof (struct n64_tag_bfd_link_needed_list)));
    fnm = bfd_elf_string_from_elf_section (abfd, link,
        dyn.d_un.d_val);
    if (n == 
            ((void *)0) 
                 || fnm == 
                           ((void *)0)
                               )
      goto error_return;
    anm = bfd_alloc (abfd, strlen (fnm) + 1);
    if (anm == 
              ((void *)0)
                  )
      goto error_return;
    strcpy (anm, fnm);
    n->name = anm;
    n->by = abfd;
    n->next = 
             ((void *)0)
                 ;
    for (pn = &((struct n64_tag_elf_link_hash_table *) ((info)->hash))->needed;
         *pn != 
               ((void *)0)
                   ;
         pn = &(*pn)->next)
      ;
    *pn = n;
  }
     }

   free (dynbuf);
   dynbuf = 
           ((void *)0)
               ;
 }
      abfd->sections = 
                      ((void *)0)
                          ;



      if (! ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created)
 {
   if (! bfd_elf32_link_create_dynamic_sections (abfd, info))
     goto error_return;
 }

      if (add_needed)
 {

   oldsize = _bfd_stringtab_size (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr);
   strindex = _bfd_stringtab_add (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr, name,
      cxx_true, cxx_false);
   if (strindex == (bfd_size_type) -1)
     goto error_return;

   if (oldsize == _bfd_stringtab_size (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr))
     {
       asection *sdyn;
       Elf32_External_Dyn *dyncon, *dynconend;






       sdyn = bfd_get_section_by_name (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj,
           ".dynamic");
       { if (!(sdyn != 
      ((void *)0)
      )) bfd_assert("elflink.h",511); };

       dyncon = (Elf32_External_Dyn *) sdyn->contents;
       dynconend = (Elf32_External_Dyn *) (sdyn->contents +
      sdyn->_raw_size);
       for (; dyncon < dynconend; dyncon++)
  {
    Elf_Internal_Dyn dyn;

    bfd_elf32_swap_dyn_in (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj, dyncon,
       &dyn);
    if (dyn.d_tag == 1
        && dyn.d_un.d_val == strindex)
      {
        if (buf != 
                  ((void *)0)
                      )
   free (buf);
        return cxx_true;
      }
  }
     }

   if (! bfd_elf32_add_dynamic_entry (info, 1, strindex))
     goto error_return;
 }
    }

  if (bfd_seek (abfd,
  hdr->sh_offset + extsymoff * sizeof (Elf32_External_Sym),
  
 0
         ) != 0
      || (bfd_read ((void *) buf, sizeof (Elf32_External_Sym), extsymcount, abfd)
   != extsymcount * sizeof (Elf32_External_Sym)))
    goto error_return;

  weaks = 
         ((void *)0)
             ;

  esymend = buf + extsymcount;
  for (esym = buf; esym < esymend; esym++, sym_hash++)
    {
      Elf_Internal_Sym sym;
      int bind;
      bfd_vma value;
      asection *sec;
      flagword flags;
      const char *name;
      struct n64_tag_elf_link_hash_entry *h;
      boolean definition;
      boolean size_change_ok, type_change_ok;
      boolean new_weakdef;

      bfd_elf32_swap_symbol_in (abfd, esym, &sym);

      flags = 0x00;
      sec = 
           ((void *)0)
               ;
      value = sym.st_value;
      *sym_hash = 
                 ((void *)0)
                     ;

      bind = (((unsigned int)(sym.st_info)) >> 4);
      if (bind == 0)
 {




   continue;
 }
      else if (bind == 1)
 {
   if (sym.st_shndx != 0
       && sym.st_shndx != 0xFFF2)
     flags = 0x02;
   else
     flags = 0;
 }
      else if (bind == 2)
 flags = 0x80;
      else
 {

 }

      if (sym.st_shndx == 0)
 sec = ((asection *) &bfd_und_section);
      else if (sym.st_shndx > 0 && sym.st_shndx < 0xFF00)
 {
   sec = bfd_section_from_elf_index (abfd, sym.st_shndx);
   if (sec != 
             ((void *)0)
                 )
     value -= sec->vma;
   else
     sec = ((asection *) &bfd_abs_section);
 }
      else if (sym.st_shndx == 0xFFF1)
 sec = ((asection *) &bfd_abs_section);
      else if (sym.st_shndx == 0xFFF2)
 {
   sec = ((asection *) &bfd_com_section);


   value = sym.st_size;
 }
      else
 {

 }

      name = bfd_elf_string_from_elf_section (abfd, hdr->sh_link, sym.st_name);
      if (name == (const char *) 
                                ((void *)0)
                                    )
 goto error_return;

      if (add_symbol_hook)
 {
   if (! (*add_symbol_hook) (abfd, info, &sym, &name, &flags, &sec,
        &value))
     goto error_return;



   if (name == (const char *) 
                             ((void *)0)
                                 )
     continue;
 }


      if (sec == (asection *) 
                             ((void *)0)
                                 )
 {
   bfd_set_error (bfd_error_bad_value);
   goto error_return;
 }

      if (((sec) == ((asection *) &bfd_und_section))
   || (((sec)->flags & 0x8000) != 0))
 definition = cxx_false;
      else
 definition = cxx_true;

      size_change_ok = cxx_false;
      type_change_ok = cxx_false;
      if (info->hash->creator->flavour == bfd_target_elf_flavour)
 {




   h = ((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (name), (cxx_true), (cxx_false), (cxx_false)))
                           ;
   if (h == 
           ((void *)0)
               )
     goto error_return;
   *sym_hash = h;

   while (h->root.type == bfd_link_hash_indirect
   || h->root.type == bfd_link_hash_warning)
     h = (struct n64_tag_elf_link_hash_entry *) h->root.u.i.link;



   type_change_ok = (h->root.type == bfd_link_hash_defweak
       || h->root.type == bfd_link_hash_undefweak);





   size_change_ok = (type_change_ok
       || h->root.type == bfd_link_hash_undefined);







   if (dynamic && definition)
     {
       if (h->root.type == bfd_link_hash_defined
    || h->root.type == bfd_link_hash_defweak
    || (h->root.type == bfd_link_hash_common
        && bind == 2))
  {
    sec = ((asection *) &bfd_und_section);
    definition = cxx_false;
    size_change_ok = cxx_true;
  }
     }







   if (! dynamic
       && definition
       && (h->root.type == bfd_link_hash_defined
    || h->root.type == bfd_link_hash_defweak)
       && (h->elf_link_hash_flags & 010) != 0
       && (((h->root.u.def.section->owner)->xvec->flavour)
    == bfd_target_elf_flavour)
       && ((((h->root.u.def.section->owner) -> tdata.elf_obj_data) -> elf_header)->e_type
    == 3))
     {



       h->root.type = bfd_link_hash_undefined;
       h->root.u.undef.abfd = h->root.u.def.section->owner;
       size_change_ok = cxx_true;
     }
 }

      if (! (_bfd_generic_link_add_one_symbol
      (info, abfd, name, flags, sec, value, (const char *) 
                                                          ((void *)0)
                                                              ,
       cxx_false, collect, (struct n64_tag_bfd_link_hash_entry **) sym_hash)))
 goto error_return;

      h = *sym_hash;
      while (h->root.type == bfd_link_hash_indirect
      || h->root.type == bfd_link_hash_warning)
 h = (struct n64_tag_elf_link_hash_entry *) h->root.u.i.link;
      *sym_hash = h;

      new_weakdef = cxx_false;
      if (dynamic
   && definition
   && (flags & 0x80) != 0
   && ((sym.st_info) & 0xF) != 2
   && info->hash->creator->flavour == bfd_target_elf_flavour
   && h->weakdef == 
                   ((void *)0)
                       )
 {
   h->weakdef = weaks;
   weaks = h;
   new_weakdef = cxx_true;
 }


      if (sym.st_shndx == 0xFFF2
   && h->root.type == bfd_link_hash_common)
 h->root.u.c.p->alignment_power = bfd_log2 (sym.st_value);

      if (info->hash->creator->flavour == bfd_target_elf_flavour)
 {
   int old_flags;
   boolean dynsym;
   int new_flag;


   if (sym.st_size != 0
       && (definition || h->size == 0))
     {
       if (h->size != 0 && h->size != sym.st_size && ! size_change_ok)
  (*_bfd_error_handler)
    ("Warning: size of symbol `%s' changed from %lu to %lu in %s",
     name, (unsigned long) h->size, (unsigned long) sym.st_size,
     ((char *) (abfd)->filename));

       h->size = sym.st_size;
     }
   if (((sym.st_info) & 0xF) != 0
       && (definition || h->type == 0))
     {
       if (h->type != 0
    && h->type != ((sym.st_info) & 0xF)
    && ! type_change_ok)
  (*_bfd_error_handler)
    ("Warning: type of symbol `%s' changed from %d to %d in %s",
     name, h->type, ((sym.st_info) & 0xF),
     ((char *) (abfd)->filename));

       h->type = ((sym.st_info) & 0xF);
     }







   old_flags = h->elf_link_hash_flags;
   dynsym = cxx_false;
   if (! dynamic)
     {
       if (! definition)
  new_flag = 01;
       else
  new_flag = 02;
       if (info->shared
    || (old_flags & (010
       | 04)) != 0)
  dynsym = cxx_true;
     }
   else
     {
       if (! definition)
  new_flag = 04;
       else
  new_flag = 010;
       if ((old_flags & new_flag) != 0
    || (old_flags & (02
       | 01)) != 0
    || (h->weakdef != 
                     ((void *)0)
        
       && (old_flags & (010
           | 04)) != 0))
  dynsym = cxx_true;
     }

   h->elf_link_hash_flags |= new_flag;
   if (dynsym && h->dynindx == -1)
     {
       if (! _bfd_elf_link_record_dynamic_symbol (info, h))
  goto error_return;
       if (h->weakdef != 
                        ((void *)0)
    
   && ! new_weakdef
    && h->weakdef->dynindx == -1)
  {
    if (! _bfd_elf_link_record_dynamic_symbol (info,
            h->weakdef))
      goto error_return;
  }
     }
 }
    }
  while (weaks != 
                 ((void *)0)
                     )
    {
      struct n64_tag_elf_link_hash_entry *hlook;
      asection *slook;
      bfd_vma vlook;
      struct n64_tag_elf_link_hash_entry **hpp;
      struct n64_tag_elf_link_hash_entry **hppend;

      hlook = weaks;
      weaks = hlook->weakdef;
      hlook->weakdef = 
                      ((void *)0)
                          ;

      { if (!(hlook->root.type == bfd_link_hash_defined || hlook->root.type == bfd_link_hash_defweak || hlook->root.type == bfd_link_hash_common || hlook->root.type == bfd_link_hash_indirect)) bfd_assert("elflink.h",867); }


                                                  ;
      slook = hlook->root.u.def.section;
      vlook = hlook->root.u.def.value;

      hpp = (((abfd) -> tdata.elf_obj_data) -> sym_hashes);
      hppend = hpp + extsymcount;
      for (; hpp < hppend; hpp++)
 {
   struct n64_tag_elf_link_hash_entry *h;

   h = *hpp;
   if (h != 
           ((void *)0) 
                && h != hlook
       && (h->root.type == bfd_link_hash_defined
    || h->root.type == bfd_link_hash_defweak)
       && h->root.u.def.section == slook
       && h->root.u.def.value == vlook)
     {
       hlook->weakdef = h;




       if (hlook->dynindx != -1
    && h->dynindx == -1)
  {
    if (! _bfd_elf_link_record_dynamic_symbol (info, h))
      goto error_return;
  }

       break;
     }
 }
    }

  if (buf != 
            ((void *)0)
                )
    {
      free (buf);
      buf = 
           ((void *)0)
               ;
    }
  check_relocs = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->check_relocs;
  if (! dynamic
      && abfd->xvec == info->hash->creator
      && check_relocs != 
                        ((void *)0)
                            )
    {
      asection *o;

      for (o = abfd->sections; o != 
                                   ((void *)0)
                                       ; o = o->next)
 {
   Elf_Internal_Rela *internal_relocs;
   boolean ok;

   if ((o->flags & 0x004) == 0
       || o->reloc_count == 0)
     continue;




   if ((o->flags & 0x001) == 0)
     continue;

   internal_relocs = elf_link_read_relocs (abfd, o, (void *) 
                                                         ((void *)0)
                                                             ,
        (Elf_Internal_Rela *) 
                             ((void *)0)
                                 ,
        info->keep_memory);
   if (internal_relocs == 
                         ((void *)0)
                             )
     goto error_return;

   ok = (*check_relocs) (abfd, info, o, internal_relocs);

   if (! info->keep_memory)
     free (internal_relocs);

   if (! ok)
     goto error_return;
 }
    }

  return cxx_true;

 error_return:
  if (buf != 
            ((void *)0)
                )
    free (buf);
  if (dynbuf != 
               ((void *)0)
                   )
    free (dynbuf);
  return cxx_false;
}
boolean
bfd_elf32_link_create_dynamic_sections(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_bfd_elf32_link_create_dynamic_sections");
boolean
bfd_elf32_link_create_dynamic_sections(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  flagword flags;
  register asection *s;
  struct n64_tag_elf_link_hash_entry *h;
  struct n64_tag_elf_backend_data *bed;

  if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created)
    return cxx_true;


  if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj == 
                                      ((void *)0)
                                          )
    ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj = abfd;
  else
    abfd = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj;



  flags = 0x001 | 0x002 | 0x200 | 0x20000;



  if (! info->shared)
    {
      s = bfd_make_section (abfd, ".interp");
      if (s == 
              ((void *)0)
   
  || ! bfd_set_section_flags (abfd, s, flags | 0x010))
 return cxx_false;
    }

  s = bfd_make_section (abfd, ".dynsym");
  if (s == 
          ((void *)0)
      
     || ! bfd_set_section_flags (abfd, s, flags | 0x010)
      || ! (((s)->alignment_power = (2)),cxx_true))
    return cxx_false;

  s = bfd_make_section (abfd, ".dynstr");
  if (s == 
          ((void *)0)
      
     || ! bfd_set_section_flags (abfd, s, flags | 0x010))
    return cxx_false;


  if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr == 
                                      ((void *)0)
                                          )
    {
      ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr = _bfd_elf_stringtab_init ();
      if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr == 
                                          ((void *)0)
                                              )
 return cxx_false;
    }

  s = bfd_make_section (abfd, ".dynamic");
  if (s == 
          ((void *)0)
      
     || ! bfd_set_section_flags (abfd, s, flags)
      || ! (((s)->alignment_power = (2)),cxx_true))
    return cxx_false;
  h = 
     ((void *)0)
         ;
  if (! (_bfd_generic_link_add_one_symbol
  (info, abfd, "_DYNAMIC", 0x02, s, (bfd_vma) 0,
   (const char *) 
                 ((void *)0)
                     , cxx_false, ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data)->collect,
   (struct n64_tag_bfd_link_hash_entry **) &h)))
    return cxx_false;
  h->elf_link_hash_flags |= 02;
  h->type = 1;

  if (info->shared
      && ! _bfd_elf_link_record_dynamic_symbol (info, h))
    return cxx_false;

  s = bfd_make_section (abfd, ".hash");
  if (s == 
          ((void *)0)
      
     || ! bfd_set_section_flags (abfd, s, flags | 0x010)
      || ! (((s)->alignment_power = (2)),cxx_true))
    return cxx_false;




  bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  if (! (*bed->elf_backend_create_dynamic_sections) (abfd, info))
    return cxx_false;

  ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created = cxx_true;

  return cxx_true;
}



boolean
bfd_elf32_add_dynamic_entry(struct n64_tag_bfd_link_info *info, bfd_vma tag, bfd_vma val) asm("_bfd_elf32_add_dynamic_entry");
boolean
bfd_elf32_add_dynamic_entry(struct n64_tag_bfd_link_info *info, bfd_vma tag, bfd_vma val)
{
  Elf_Internal_Dyn dyn;
  bfd *dynobj;
  asection *s;
  size_t newsize;
  bfd_byte *newcontents;

  dynobj = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj;

  s = bfd_get_section_by_name (dynobj, ".dynamic");
  { if (!(s != 
 ((void *)0)
 )) bfd_assert("elflink.h",1096); };

  newsize = s->_raw_size + sizeof (Elf32_External_Dyn);
  if (s->contents == 
                    ((void *)0)
                        )
    newcontents = (bfd_byte *) malloc (newsize);
  else
    newcontents = (bfd_byte *) realloc (s->contents, newsize);
  if (newcontents == 
                    ((void *)0)
                        )
    {
      bfd_set_error (bfd_error_no_memory);
      return cxx_false;
    }

  dyn.d_tag = tag;
  dyn.d_un.d_val = val;
  bfd_elf32_swap_dyn_out (dynobj, &dyn,
      (Elf32_External_Dyn *) (newcontents + s->_raw_size));

  s->_raw_size = newsize;
  s->contents = newcontents;

  return cxx_true;
}
static Elf_Internal_Rela *
elf_link_read_relocs(bfd *abfd, asection *o, void *external_relocs, Elf_Internal_Rela *internal_relocs, boolean keep_memory) asm("_elf_link_read_relocs");
static Elf_Internal_Rela *
elf_link_read_relocs(bfd *abfd, asection *o, void *external_relocs, Elf_Internal_Rela *internal_relocs, boolean keep_memory)
{
  Elf_Internal_Shdr *rel_hdr;
  void * alloc1 = 
              ((void *)0)
                  ;
  Elf_Internal_Rela *alloc2 = 
                             ((void *)0)
                                 ;

  if (((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->relocs != 
                                     ((void *)0)
                                         )
    return ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->relocs;

  if (o->reloc_count == 0)
    return 
          ((void *)0)
              ;

  rel_hdr = &((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hdr;

  if (internal_relocs == 
                        ((void *)0)
                            )
    {
      size_t size;

      size = o->reloc_count * sizeof (Elf_Internal_Rela);
      if (keep_memory)
 internal_relocs = (Elf_Internal_Rela *) bfd_alloc (abfd, size);
      else
 internal_relocs = alloc2 = (Elf_Internal_Rela *) malloc (size);
      if (internal_relocs == 
                            ((void *)0)
                                )
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }
    }

  if (external_relocs == 
                        ((void *)0)
                            )
    {
      alloc1 = (void *) malloc ((size_t) rel_hdr->sh_size);
      if (alloc1 == 
                   ((void *)0)
                       )
 {
   bfd_set_error (bfd_error_no_memory);
   goto error_return;
 }
      external_relocs = alloc1;
    }

  if ((bfd_seek (abfd, rel_hdr->sh_offset, 
                                          0
                                                  ) != 0)
      || (bfd_read (external_relocs, 1, rel_hdr->sh_size, abfd)
   != rel_hdr->sh_size))
    goto error_return;




  if (rel_hdr->sh_entsize == sizeof (Elf32_External_Rel))
    {
      Elf32_External_Rel *erel;
      Elf32_External_Rel *erelend;
      Elf_Internal_Rela *irela;

      erel = (Elf32_External_Rel *) external_relocs;
      erelend = erel + o->reloc_count;
      irela = internal_relocs;
      for (; erel < erelend; erel++, irela++)
 {
   Elf_Internal_Rel irel;

   bfd_elf32_swap_reloc_in (abfd, erel, &irel);
   irela->r_offset = irel.r_offset;
   irela->r_info = irel.r_info;
   irela->r_addend = 0;
 }
    }
  else
    {
      Elf32_External_Rela *erela;
      Elf32_External_Rela *erelaend;
      Elf_Internal_Rela *irela;

      { if (!(rel_hdr->sh_entsize == sizeof (Elf32_External_Rela))) bfd_assert("elflink.h",1207); };

      erela = (Elf32_External_Rela *) external_relocs;
      erelaend = erela + o->reloc_count;
      irela = internal_relocs;
      for (; erela < erelaend; erela++, irela++)
 bfd_elf32_swap_reloca_in (abfd, erela, irela);
    }


  if (keep_memory)
    ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->relocs = internal_relocs;

  if (alloc1 != 
               ((void *)0)
                   )
    free (alloc1);




  return internal_relocs;

 error_return:
  if (alloc1 != 
               ((void *)0)
                   )
    free (alloc1);
  if (alloc2 != 
               ((void *)0)
                   )
    free (alloc2);
  return 
        ((void *)0)
            ;
}





boolean
bfd_elf32_record_link_assignment(bfd *output_bfd, struct n64_tag_bfd_link_info *info, const char *name, boolean provide) asm("_bfd_elf32_record_link_assignment");
boolean
bfd_elf32_record_link_assignment(bfd *output_bfd, struct n64_tag_bfd_link_info *info, const char *name, boolean provide)
{
  struct n64_tag_elf_link_hash_entry *h;

  if (info->hash->creator->flavour != bfd_target_elf_flavour)
    return cxx_true;

  h = ((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (name), (cxx_true), (cxx_true), (cxx_false)));
  if (h == 
          ((void *)0)
              )
    return cxx_false;





  if (provide
      && (h->elf_link_hash_flags & 010) != 0
      && (h->elf_link_hash_flags & 02) == 0)
    h->root.type = bfd_link_hash_undefined;

  h->elf_link_hash_flags |= 02;
  h->type = 1;

  if (((h->elf_link_hash_flags & (010
      | 04)) != 0
       || info->shared)
      && h->dynindx == -1)
    {
      if (! _bfd_elf_link_record_dynamic_symbol (info, h))
 return cxx_false;




      if (h->weakdef != 
                       ((void *)0)
   
  && h->weakdef->dynindx == -1)
 {
   if (! _bfd_elf_link_record_dynamic_symbol (info, h->weakdef))
     return cxx_false;
 }
    }

  return cxx_true;
}







static const size_t elf_buckets[] =
{
  1, 3, 17, 37, 67, 97, 131, 197, 263, 521, 0
};






boolean
bfd_elf32_size_dynamic_sections(bfd *output_bfd, const char *soname, const char *rpath, boolean export_dynamic, struct n64_tag_bfd_link_info *info, asection **sinterpptr) asm("_bfd_elf32_size_dynamic_sections");
boolean
bfd_elf32_size_dynamic_sections(bfd *output_bfd, const char *soname, const char *rpath, boolean export_dynamic, struct n64_tag_bfd_link_info *info, asection **sinterpptr)
{
  bfd *dynobj;
  struct n64_tag_elf_backend_data *bed;

  *sinterpptr = 
               ((void *)0)
                   ;

  if (info->hash->creator->flavour != bfd_target_elf_flavour)
    return cxx_true;

  dynobj = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj;



  if (dynobj == 
               ((void *)0)
                   )
    return cxx_true;



  if (export_dynamic)
    {
      struct n64_tag_elf_info_failed eif;

      eif.failed = cxx_false;
      eif.info = info;
      (bfd_link_hash_traverse (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *)) (elf_export_symbol), ((void *) &eif)))
                    ;
      if (eif.failed)
 return cxx_false;
    }

  if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created)
    {
      struct n64_tag_elf_info_failed eif;
      bfd_size_type strsize;

      *sinterpptr = bfd_get_section_by_name (dynobj, ".interp");
      { if (!(*sinterpptr != 
     ((void *)0) 
     || info->shared)) bfd_assert("elflink.h",1351); };

      if (soname != 
                   ((void *)0)
                       )
 {
   bfd_size_type indx;

   indx = _bfd_stringtab_add (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr, soname,
         cxx_true, cxx_true);
   if (indx == (bfd_size_type) -1
       || ! bfd_elf32_add_dynamic_entry (info, 14, indx))
     return cxx_false;
 }

      if (info->symbolic)
 {
   if (! bfd_elf32_add_dynamic_entry (info, 16, 0))
     return cxx_false;
 }

      if (rpath != 
                  ((void *)0)
                      )
 {
   bfd_size_type indx;

   indx = _bfd_stringtab_add (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr, rpath,
         cxx_true, cxx_true);
   if (indx == (bfd_size_type) -1
       || ! bfd_elf32_add_dynamic_entry (info, 15, indx))
     return cxx_false;
 }



      eif.failed = cxx_false;
      eif.info = info;
      (bfd_link_hash_traverse (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *)) (elf_adjust_dynamic_symbol), ((void *) &eif)))

                    ;
      if (eif.failed)
 return cxx_false;




      if (((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, ("_init"), (cxx_false), (cxx_false), (cxx_false)))
                  != 
                    ((void *)0)
                        )
 {
   if (! bfd_elf32_add_dynamic_entry (info, 12, 0))
     return cxx_false;
 }
      if (((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, ("_fini"), (cxx_false), (cxx_false), (cxx_false)))
                  != 
                    ((void *)0)
                        )
 {
   if (! bfd_elf32_add_dynamic_entry (info, 13, 0))
     return cxx_false;
 }
      strsize = _bfd_stringtab_size (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr);
      if (! bfd_elf32_add_dynamic_entry (info, 4, 0)
   || ! bfd_elf32_add_dynamic_entry (info, 5, 0)
   || ! bfd_elf32_add_dynamic_entry (info, 6, 0)
   || ! bfd_elf32_add_dynamic_entry (info, 10, strsize)
   || ! bfd_elf32_add_dynamic_entry (info, 11,
          sizeof (Elf32_External_Sym)))
 return cxx_false;
    }



  bed = ((struct n64_tag_elf_backend_data *) (output_bfd)->xvec->backend_data);
  if (! (*bed->elf_backend_size_dynamic_sections) (output_bfd, info))
    return cxx_false;

  if (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created)
    {
      size_t dynsymcount;
      asection *s;
      size_t i;
      size_t bucketcount = 0;
      Elf_Internal_Sym isym;







      dynsymcount = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynsymcount;
      s = bfd_get_section_by_name (dynobj, ".dynsym");
      { if (!(s != 
     ((void *)0)
     )) bfd_assert("elflink.h",1438); };
      s->_raw_size = dynsymcount * sizeof (Elf32_External_Sym);
      s->contents = (bfd_byte *) bfd_alloc (output_bfd, s->_raw_size);
      if (s->contents == 
                        ((void *)0) 
                             && s->_raw_size != 0)
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }


      isym.st_value = 0;
      isym.st_size = 0;
      isym.st_name = 0;
      isym.st_info = 0;
      isym.st_other = 0;
      isym.st_shndx = 0;
      bfd_elf32_swap_symbol_out (output_bfd, &isym,
      (void *) (Elf32_External_Sym *) s->contents);

      for (i = 0; elf_buckets[i] != 0; i++)
 {
   bucketcount = elf_buckets[i];
   if (dynsymcount < elf_buckets[i + 1])
     break;
 }

      s = bfd_get_section_by_name (dynobj, ".hash");
      { if (!(s != 
     ((void *)0)
     )) bfd_assert("elflink.h",1465); };
      s->_raw_size = (2 + bucketcount + dynsymcount) * (32 / 8);
      s->contents = (bfd_byte *) bfd_alloc (output_bfd, s->_raw_size);
      if (s->contents == 
                        ((void *)0)
                            )
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      memset (s->contents, 0, (size_t) s->_raw_size);

      ((*((output_bfd)->xvec->bfd_h_putx32)) (bucketcount,s->contents));
      ((*((output_bfd)->xvec->bfd_h_putx32)) (dynsymcount,s->contents + (32 / 8)));

      ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->bucketcount = bucketcount;

      s = bfd_get_section_by_name (dynobj, ".dynstr");
      { if (!(s != 
     ((void *)0)
     )) bfd_assert("elflink.h",1481); };
      s->_raw_size = _bfd_stringtab_size (((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr);

      if (! bfd_elf32_add_dynamic_entry (info, 0, 0))
 return cxx_false;
    }

  return cxx_true;
}




static boolean
elf_export_symbol(struct n64_tag_elf_link_hash_entry *h, void *data) asm("_elf_export_symbol");
static boolean
elf_export_symbol(struct n64_tag_elf_link_hash_entry *h, void *data)
{
  struct n64_tag_elf_info_failed *eif = (struct n64_tag_elf_info_failed *) data;

  if (h->dynindx == -1
      && (h->elf_link_hash_flags
   & (02 | 01)) != 0)
    {
      if (! _bfd_elf_link_record_dynamic_symbol (eif->info, h))
 {
   eif->failed = cxx_true;
   return cxx_false;
 }
    }

  return cxx_true;
}





static boolean
elf_adjust_dynamic_symbol(struct n64_tag_elf_link_hash_entry *h, void *data) asm("_elf_adjust_dynamic_symbol");
static boolean
elf_adjust_dynamic_symbol(struct n64_tag_elf_link_hash_entry *h, void *data)
{
  struct n64_tag_elf_info_failed *eif = (struct n64_tag_elf_info_failed *) data;
  bfd *dynobj;
  struct n64_tag_elf_backend_data *bed;





  if ((h->elf_link_hash_flags & 0100) != 0
      && eif->info->shared
      && eif->info->symbolic
      && (h->elf_link_hash_flags & 02) != 0)
    h->elf_link_hash_flags &=~ 0100;
  if ((h->elf_link_hash_flags & 0100) == 0
      && ((h->elf_link_hash_flags & 02) != 0
   || (h->elf_link_hash_flags & 010) == 0
   || ((h->elf_link_hash_flags & 01) == 0
       && (h->weakdef == 
                        ((void *)0) 
                             || h->weakdef->dynindx == -1))))
    return cxx_true;



  if ((h->elf_link_hash_flags & 020) != 0)
    return cxx_true;





  h->elf_link_hash_flags |= 020;
  if (h->weakdef != 
                   ((void *)0)
                       )
    {
      struct n64_tag_elf_link_hash_entry *weakdef;

      { if (!(h->root.type == bfd_link_hash_defined || h->root.type == bfd_link_hash_defweak)) bfd_assert("elflink.h",1595); }
                                             ;
      weakdef = h->weakdef;
      { if (!(weakdef->root.type == bfd_link_hash_defined || weakdef->root.type == bfd_link_hash_defweak)) bfd_assert("elflink.h",1598); }
                                                   ;
      { if (!(weakdef->elf_link_hash_flags & 010)) bfd_assert("elflink.h",1600); };
      if ((weakdef->elf_link_hash_flags & 02) != 0)
 {



   h->weakdef = 
               ((void *)0)
                   ;
 }
      else
 {


   weakdef->elf_link_hash_flags |= 01;
   if (! elf_adjust_dynamic_symbol (weakdef, (void *) eif))
     return cxx_false;
 }
    }

  dynobj = ((struct n64_tag_elf_link_hash_table *) ((eif->info)->hash))->dynobj;
  bed = ((struct n64_tag_elf_backend_data *) (dynobj)->xvec->backend_data);
  if (! (*bed->elf_backend_adjust_dynamic_symbol) (eif->info, h))
    {
      eif->failed = cxx_true;
      return cxx_false;
    }

  return cxx_true;
}





struct n64_tag_elf_final_link_info
{

  struct n64_tag_bfd_link_info *info;

  bfd *output_bfd;

  struct bfd_strtab_hash *symstrtab;

  asection *dynsym_sec;

  asection *hash_sec;

  bfd_byte *contents;

  void * external_relocs;

  Elf_Internal_Rela *internal_relocs;


  Elf32_External_Sym *external_syms;


  Elf_Internal_Sym *internal_syms;


  long *indices;


  asection **sections;

  Elf32_External_Sym *symbuf;

  size_t symbuf_count;

  size_t symbuf_size;
};

static boolean elf_link_output_sym
  (struct n64_tag_elf_final_link_info *, const char *, Elf_Internal_Sym *, asection *) asm("_elf_link_output_sym")
                                    ;
static boolean elf_link_flush_output_syms
  (struct n64_tag_elf_final_link_info *) asm("_elf_link_flush_output_syms");
static boolean elf_link_output_extsym
  (struct n64_tag_elf_link_hash_entry *, void *) asm("_elf_link_output_extsym");
static boolean elf_link_input_bfd
  (struct n64_tag_elf_final_link_info *, bfd *) asm("_elf_link_input_bfd");
static boolean elf_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("_elf_reloc_link_order")
                             ;




struct n64_tag_elf_finfo_failed
{
  boolean failed;
  struct n64_tag_elf_final_link_info *finfo;
};



boolean
bfd_elf32_bfd_final_link(bfd *abfd, struct n64_tag_bfd_link_info *info) asm("_bfd_elf32_bfd_final_link");
boolean
bfd_elf32_bfd_final_link(bfd *abfd, struct n64_tag_bfd_link_info *info)
{
  boolean dynamic;
  bfd *dynobj;
  struct n64_tag_elf_final_link_info finfo;
  register asection *o;
  register struct n64_tag_bfd_link_order *p;
  register bfd *sub;
  size_t max_contents_size;
  size_t max_external_reloc_size;
  size_t max_internal_reloc_count;
  size_t max_sym_count;
  file_ptr off;
  Elf_Internal_Sym elfsym;
  unsigned int i;
  Elf_Internal_Shdr *symtab_hdr;
  Elf_Internal_Shdr *symstrtab_hdr;
  struct n64_tag_elf_backend_data *bed = ((struct n64_tag_elf_backend_data *) (abfd)->xvec->backend_data);
  struct n64_tag_elf_finfo_failed eif;

  if (info->shared)
    abfd->flags |= 0x40;

  dynamic = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynamic_sections_created;
  dynobj = ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynobj;

  finfo.info = info;
  finfo.output_bfd = abfd;
  finfo.symstrtab = _bfd_elf_stringtab_init ();
  if (finfo.symstrtab == 
                        ((void *)0)
                            )
    return cxx_false;
  if (! dynamic)
    {
      finfo.dynsym_sec = 
                        ((void *)0)
                            ;
      finfo.hash_sec = 
                      ((void *)0)
                          ;
    }
  else
    {
      finfo.dynsym_sec = bfd_get_section_by_name (dynobj, ".dynsym");
      finfo.hash_sec = bfd_get_section_by_name (dynobj, ".hash");
      { if (!(finfo.dynsym_sec != 
     ((void *)0) 
     && finfo.hash_sec != 
     ((void *)0)
     )) bfd_assert("elflink.h",1738); };
    }
  finfo.contents = 
                  ((void *)0)
                      ;
  finfo.external_relocs = 
                         ((void *)0)
                             ;
  finfo.internal_relocs = 
                         ((void *)0)
                             ;
  finfo.external_syms = 
                       ((void *)0)
                           ;
  finfo.internal_syms = 
                       ((void *)0)
                           ;
  finfo.indices = 
                 ((void *)0)
                     ;
  finfo.sections = 
                  ((void *)0)
                      ;
  finfo.symbuf = 
                ((void *)0)
                    ;
  finfo.symbuf_count = 0;




  max_contents_size = 0;
  max_external_reloc_size = 0;
  max_internal_reloc_count = 0;
  max_sym_count = 0;
  for (o = abfd->sections; o != (asection *) 
                                            ((void *)0)
                                                ; o = o->next)
    {
      o->reloc_count = 0;

      for (p = o->link_order_head; p != 
                                       ((void *)0)
                                           ; p = p->next)
 {
   if (p->type == bfd_section_reloc_link_order
       || p->type == bfd_symbol_reloc_link_order)
     ++o->reloc_count;
   else if (p->type == bfd_indirect_link_order)
     {
       asection *sec;

       sec = p->u.indirect.section;

       if (info->relocateable)
  o->reloc_count += sec->reloc_count;

       if (sec->_raw_size > max_contents_size)
  max_contents_size = sec->_raw_size;
       if (sec->_cooked_size > max_contents_size)
  max_contents_size = sec->_cooked_size;



       if (((sec->owner)->xvec->flavour) == bfd_target_elf_flavour)
  {
    size_t sym_count;

    if ((((sec->owner) -> tdata.elf_obj_data) -> bad_symtab))
      sym_count = (((sec->owner) -> tdata.elf_obj_data)->symtab_hdr.sh_size
     / sizeof (Elf32_External_Sym));
    else
      sym_count = ((sec->owner) -> tdata.elf_obj_data)->symtab_hdr.sh_info;

    if (sym_count > max_sym_count)
      max_sym_count = sym_count;

    if ((sec->flags & 0x004) != 0)
      {
        size_t ext_size;

        ext_size = ((struct n64_tag_bfd_elf_section_data*)sec->used_by_bfd)->rel_hdr.sh_size;
        if (ext_size > max_external_reloc_size)
   max_external_reloc_size = ext_size;
        if (sec->reloc_count > max_internal_reloc_count)
   max_internal_reloc_count = sec->reloc_count;
      }
  }
     }
 }

      if (o->reloc_count > 0)
 o->flags |= 0x004;
      else
 {



   o->flags &=~ 0x004;
 }





      if ((o->flags & 0x001) == 0)
 o->vma = 0;
    }




  abfd->symcount = info->strip == strip_all ? 0 : 1;
  { if (!(! abfd->output_has_begun)) bfd_assert("elflink.h",1831); };
  if (! _bfd_elf_compute_section_file_positions (abfd, info))
    goto error_return;



  for (o = abfd->sections; o != 
                               ((void *)0)
                                   ; o = o->next)
    {
      if ((o->flags & 0x004) != 0)
 {
   Elf_Internal_Shdr *rel_hdr;
   register struct n64_tag_elf_link_hash_entry **p, **pend;

   rel_hdr = &((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hdr;

   rel_hdr->sh_size = rel_hdr->sh_entsize * o->reloc_count;



   rel_hdr->contents = (void *) bfd_alloc (abfd, rel_hdr->sh_size);
   if (rel_hdr->contents == 
                           ((void *)0) 
                                && rel_hdr->sh_size != 0)
     {
       bfd_set_error (bfd_error_no_memory);
       goto error_return;
     }

   p = ((struct n64_tag_elf_link_hash_entry **)
        malloc (o->reloc_count
         * sizeof (struct n64_tag_elf_link_hash_entry *)));
   if (p == 
           ((void *)0) 
                && o->reloc_count != 0)
     {
       bfd_set_error (bfd_error_no_memory);
       goto error_return;
     }
   ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes = p;
   pend = p + o->reloc_count;
   for (; p < pend; p++)
     *p = 
         ((void *)0)
             ;



   o->reloc_count = 0;
 }
    }

  _bfd_elf_assign_file_positions_for_relocs (abfd);





  abfd->symcount = 0;
  symtab_hdr = &((abfd) -> tdata.elf_obj_data)->symtab_hdr;

  symtab_hdr->sh_type = 2;
  symtab_hdr->sh_flags = 0;
  symtab_hdr->sh_addr = 0;
  symtab_hdr->sh_size = 0;
  symtab_hdr->sh_entsize = sizeof (Elf32_External_Sym);



  symtab_hdr->sh_addralign = 4;

  off = ((abfd) -> tdata.elf_obj_data)->next_file_pos;
  off = _bfd_elf_assign_file_position_for_section (symtab_hdr, off, cxx_true);







  if (! info->keep_memory || max_sym_count < 20)
    finfo.symbuf_size = 20;
  else
    finfo.symbuf_size = max_sym_count;
  finfo.symbuf = ((Elf32_External_Sym *)
    malloc (finfo.symbuf_size * sizeof (Elf32_External_Sym)));
  if (finfo.symbuf == 
                     ((void *)0)
                         )
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }



  elfsym.st_value = 0;
  elfsym.st_size = 0;
  elfsym.st_info = 0;
  elfsym.st_other = 0;
  elfsym.st_shndx = 0;
  if (! elf_link_output_sym (&finfo, (const char *) 
                                                   ((void *)0)
                                                       ,
        &elfsym, ((asection *) &bfd_und_section)))
    goto error_return;
  elfsym.st_value = 0;
  elfsym.st_size = 0;
  elfsym.st_info = (((0) << 4) + ((3) & 0xF));
  elfsym.st_other = 0;
  for (i = 1; i < (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum; i++)
    {
      o = bfd_section_from_elf_index (abfd, i);
      if (o != 
              ((void *)0)
                  )
 o->target_index = abfd->symcount;
      elfsym.st_shndx = i;
      if (! elf_link_output_sym (&finfo, (const char *) 
                                                       ((void *)0)
                                                           ,
     &elfsym, o))
 goto error_return;
    }



  finfo.contents = (bfd_byte *) malloc (max_contents_size);
  finfo.external_relocs = (void *) malloc (max_external_reloc_size);
  finfo.internal_relocs = ((Elf_Internal_Rela *)
      malloc (max_internal_reloc_count
       * sizeof (Elf_Internal_Rela)));
  finfo.external_syms = ((Elf32_External_Sym *)
    malloc (max_sym_count * sizeof (Elf32_External_Sym)));
  finfo.internal_syms = ((Elf_Internal_Sym *)
    malloc (max_sym_count * sizeof (Elf_Internal_Sym)));
  finfo.indices = (long *) malloc (max_sym_count * sizeof (long));
  finfo.sections = (asection **) malloc (max_sym_count * sizeof (asection *));
  if ((finfo.contents == 
                        ((void *)0) 
                             && max_contents_size != 0)
      || (finfo.external_relocs == 
                                  ((void *)0) 
                                       && max_external_reloc_size != 0)
      || (finfo.internal_relocs == 
                                  ((void *)0) 
                                       && max_internal_reloc_count != 0)
      || (finfo.external_syms == 
                                ((void *)0) 
                                     && max_sym_count != 0)
      || (finfo.internal_syms == 
                                ((void *)0) 
                                     && max_sym_count != 0)
      || (finfo.indices == 
                          ((void *)0) 
                               && max_sym_count != 0)
      || (finfo.sections == 
                           ((void *)0) 
                                && max_sym_count != 0))
    {
      bfd_set_error (bfd_error_no_memory);
      goto error_return;
    }
  for (sub = info->input_bfds; sub != 
                                     ((void *)0)
                                         ; sub = sub->next)
    sub->output_has_begun = cxx_false;
  for (o = abfd->sections; o != 
                               ((void *)0)
                                   ; o = o->next)
    {
      for (p = o->link_order_head; p != 
                                       ((void *)0)
                                           ; p = p->next)
 {
   if (p->type == bfd_indirect_link_order
       && (((p->u.indirect.section->owner)->xvec->flavour)
    == bfd_target_elf_flavour))
     {
       sub = p->u.indirect.section->owner;
       if (! sub->output_has_begun)
  {
    if (! elf_link_input_bfd (&finfo, sub))
      goto error_return;
    sub->output_has_begun = cxx_true;
  }
     }
   else if (p->type == bfd_section_reloc_link_order
     || p->type == bfd_symbol_reloc_link_order)
     {
       if (! elf_reloc_link_order (abfd, info, o, p))
  goto error_return;
     }
   else
     {
       if (! _bfd_default_link_order (abfd, info, o, p))
  goto error_return;
     }
 }
    }






  symtab_hdr->sh_info = abfd->symcount;
  if (dynamic)
    ((struct n64_tag_bfd_elf_section_data*)finfo.dynsym_sec->output_section->used_by_bfd)->this_hdr.sh_info = 1;


  eif.failed = cxx_false;
  eif.finfo = &finfo;
  (bfd_link_hash_traverse (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *)) (elf_link_output_extsym), ((void *) &eif)))
                ;
  if (eif.failed)
    return cxx_false;


  if (! elf_link_flush_output_syms (&finfo))
    return cxx_false;


  off += symtab_hdr->sh_size;



  symstrtab_hdr = &((abfd) -> tdata.elf_obj_data)->strtab_hdr;

  symstrtab_hdr->sh_type = 3;
  symstrtab_hdr->sh_flags = 0;
  symstrtab_hdr->sh_addr = 0;
  symstrtab_hdr->sh_size = _bfd_stringtab_size (finfo.symstrtab);
  symstrtab_hdr->sh_entsize = 0;
  symstrtab_hdr->sh_link = 0;
  symstrtab_hdr->sh_info = 0;

  symstrtab_hdr->sh_addralign = 1;

  off = _bfd_elf_assign_file_position_for_section (symstrtab_hdr, off, cxx_true);
  ((abfd) -> tdata.elf_obj_data)->next_file_pos = off;

  if (bfd_seek (abfd, symstrtab_hdr->sh_offset, 
                                               0
                                                       ) != 0
      || ! _bfd_stringtab_emit (abfd, finfo.symstrtab))
    return cxx_false;


  for (o = abfd->sections; o != 
                               ((void *)0)
                                   ; o = o->next)
    {
      struct n64_tag_elf_link_hash_entry **rel_hash;
      Elf_Internal_Shdr *rel_hdr;

      if ((o->flags & 0x004) == 0)
 continue;

      rel_hash = ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes;
      rel_hdr = &((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hdr;
      for (i = 0; i < o->reloc_count; i++, rel_hash++)
 {
   if (*rel_hash == 
                   ((void *)0)
                       )
     continue;

   { if (!((*rel_hash)->indx >= 0)) bfd_assert("elflink.h",2101); };

   if (rel_hdr->sh_entsize == sizeof (Elf32_External_Rel))
     {
       Elf32_External_Rel *erel;
       Elf_Internal_Rel irel;

       erel = (Elf32_External_Rel *) rel_hdr->contents + i;
       bfd_elf32_swap_reloc_in (abfd, erel, &irel);
       irel.r_info = ((((*rel_hash)->indx) << 8) + ((((irel.r_info) & 0xff)) & 0xff))
                              ;
       bfd_elf32_swap_reloc_out (abfd, &irel, erel);
     }
   else
     {
       Elf32_External_Rela *erela;
       Elf_Internal_Rela irela;

       { if (!(rel_hdr->sh_entsize == sizeof (Elf32_External_Rela))) bfd_assert("elflink.h",2119); }
                                   ;

       erela = (Elf32_External_Rela *) rel_hdr->contents + i;
       bfd_elf32_swap_reloca_in (abfd, erela, &irela);
       irela.r_info = ((((*rel_hash)->indx) << 8) + ((((irela.r_info) & 0xff)) & 0xff))
                                ;
       bfd_elf32_swap_reloca_out (abfd, &irela, erela);
     }
 }



      o->reloc_count = 0;
    }



  if (dynamic)
    {
      Elf32_External_Dyn *dyncon, *dynconend;


      o = bfd_get_section_by_name (dynobj, ".dynamic");
      { if (!(o != 
     ((void *)0)
     )) bfd_assert("elflink.h",2143); };

      dyncon = (Elf32_External_Dyn *) o->contents;
      dynconend = (Elf32_External_Dyn *) (o->contents + o->_raw_size);
      for (; dyncon < dynconend; dyncon++)
 {
   Elf_Internal_Dyn dyn;
   const char *name;
   unsigned int type;

   bfd_elf32_swap_dyn_in (dynobj, dyncon, &dyn);

   switch (dyn.d_tag)
     {
     default:
       break;




     case 12:
       name = "_init";
       goto get_sym;
     case 13:
       name = "_fini";
     get_sym:
       {
  struct n64_tag_elf_link_hash_entry *h;

  h = ((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (name), (cxx_false), (cxx_false), (cxx_true)))
                          ;
  if (h != 
          ((void *)0)
      
     && (h->root.type == bfd_link_hash_defined
   || h->root.type == bfd_link_hash_defweak))
    {
      dyn.d_un.d_val = h->root.u.def.value;
      o = h->root.u.def.section;
      if (o->output_section != 
                              ((void *)0)
                                  )
        dyn.d_un.d_val += (o->output_section->vma
      + o->output_offset);
      else
        {


   dyn.d_un.d_val = 0;
        }

      bfd_elf32_swap_dyn_out (dynobj, &dyn, dyncon);
    }
       }
       break;

     case 4:
       name = ".hash";
       goto get_vma;
     case 5:
       name = ".dynstr";
       goto get_vma;
     case 6:
       name = ".dynsym";
     get_vma:
       o = bfd_get_section_by_name (abfd, name);
       { if (!(o != 
      ((void *)0)
      )) bfd_assert("elflink.h",2205); };
       dyn.d_un.d_ptr = o->vma;
       bfd_elf32_swap_dyn_out (dynobj, &dyn, dyncon);
       break;

     case 17:
     case 7:
     case 18:
     case 8:
       if (dyn.d_tag == 17 || dyn.d_tag == 18)
  type = 9;
       else
  type = 4;
       dyn.d_un.d_val = 0;
       for (i = 1; i < (((abfd) -> tdata.elf_obj_data) -> elf_header)->e_shnum; i++)
  {
    Elf_Internal_Shdr *hdr;

    hdr = (((abfd) -> tdata.elf_obj_data) -> elf_sect_ptr)[i];
    if (hdr->sh_type == type
        && (hdr->sh_flags & (1 << 1)) != 0)
      {
        if (dyn.d_tag == 18 || dyn.d_tag == 8)
   dyn.d_un.d_val += hdr->sh_size;
        else
   {
     if (dyn.d_un.d_val == 0
         || hdr->sh_addr < dyn.d_un.d_val)
       dyn.d_un.d_val = hdr->sh_addr;
   }
      }
  }
       bfd_elf32_swap_dyn_out (dynobj, &dyn, dyncon);
       break;
     }
 }
    }


  if (dynobj != 
               ((void *)0)
                   )
    {
      if (! (*bed->elf_backend_finish_dynamic_sections) (abfd, info))
 goto error_return;

      for (o = dynobj->sections; o != 
                                     ((void *)0)
                                         ; o = o->next)
 {
   if ((o->flags & 0x200) == 0
       || o->_raw_size == 0)
     continue;
   if ((o->flags & 0x20000) == 0)
     {



       continue;
     }
   if ((((struct n64_tag_bfd_elf_section_data*)o->output_section->used_by_bfd)->this_hdr.sh_type
        != 3)
       || strcmp (((o)->name + 0), ".dynstr") != 0)
     {
       if (! bfd_set_section_contents (abfd, o->output_section,
           o->contents, o->output_offset,
           o->_raw_size))
  goto error_return;
     }
   else
     {
       file_ptr off;



       off = ((struct n64_tag_bfd_elf_section_data*)o->output_section->used_by_bfd)->this_hdr.sh_offset;
       if (bfd_seek (abfd, off, 
                               0
                                       ) != 0
    || ! _bfd_stringtab_emit (abfd,
         ((struct n64_tag_elf_link_hash_table *) ((info)->hash))->dynstr))
  goto error_return;
     }
 }
    }

  if (finfo.symstrtab != 
                        ((void *)0)
                            )
    _bfd_stringtab_free (finfo.symstrtab);
  if (finfo.contents != 
                       ((void *)0)
                           )
    free (finfo.contents);
  if (finfo.external_relocs != 
                              ((void *)0)
                                  )
    free (finfo.external_relocs);
  if (finfo.internal_relocs != 
                              ((void *)0)
                                  )
    free (finfo.internal_relocs);
  if (finfo.external_syms != 
                            ((void *)0)
                                )
    free (finfo.external_syms);
  if (finfo.internal_syms != 
                            ((void *)0)
                                )
    free (finfo.internal_syms);
  if (finfo.indices != 
                      ((void *)0)
                          )
    free (finfo.indices);
  if (finfo.sections != 
                       ((void *)0)
                           )
    free (finfo.sections);
  if (finfo.symbuf != 
                     ((void *)0)
                         )
    free (finfo.symbuf);
  for (o = abfd->sections; o != 
                               ((void *)0)
                                   ; o = o->next)
    {
      if ((o->flags & 0x004) != 0
   && ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes != 
                                         ((void *)0)
                                             )
 free (((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes);
    }

  ((abfd) -> tdata.elf_obj_data)->linker = cxx_true;

  return cxx_true;

 error_return:
  if (finfo.symstrtab != 
                        ((void *)0)
                            )
    _bfd_stringtab_free (finfo.symstrtab);
  if (finfo.contents != 
                       ((void *)0)
                           )
    free (finfo.contents);
  if (finfo.external_relocs != 
                              ((void *)0)
                                  )
    free (finfo.external_relocs);
  if (finfo.internal_relocs != 
                              ((void *)0)
                                  )
    free (finfo.internal_relocs);
  if (finfo.external_syms != 
                            ((void *)0)
                                )
    free (finfo.external_syms);
  if (finfo.internal_syms != 
                            ((void *)0)
                                )
    free (finfo.internal_syms);
  if (finfo.indices != 
                      ((void *)0)
                          )
    free (finfo.indices);
  if (finfo.sections != 
                       ((void *)0)
                           )
    free (finfo.sections);
  if (finfo.symbuf != 
                     ((void *)0)
                         )
    free (finfo.symbuf);
  for (o = abfd->sections; o != 
                               ((void *)0)
                                   ; o = o->next)
    {
      if ((o->flags & 0x004) != 0
   && ((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes != 
                                         ((void *)0)
                                             )
 free (((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hashes);
    }

  return cxx_false;
}



static boolean
elf_link_output_sym(struct n64_tag_elf_final_link_info *finfo, const char *name, Elf_Internal_Sym *elfsym, asection *input_sec) asm("_elf_link_output_sym");
static boolean
elf_link_output_sym(struct n64_tag_elf_final_link_info *finfo, const char *name, Elf_Internal_Sym *elfsym, asection *input_sec)
{
  boolean (*output_symbol_hook) (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)



                  ;

  output_symbol_hook = ((struct n64_tag_elf_backend_data *) (finfo->output_bfd)->xvec->backend_data)->
    elf_backend_link_output_symbol_hook;
  if (output_symbol_hook != 
                           ((void *)0)
                               )
    {
      if (! ((*output_symbol_hook)
      (finfo->output_bfd, finfo->info, name, elfsym, input_sec)))
 return cxx_false;
    }

  if (name == (const char *) 
                            ((void *)0) 
                                 || *name == '\0')
    elfsym->st_name = 0;
  else
    {
      elfsym->st_name = (unsigned long) _bfd_stringtab_add (finfo->symstrtab,
           name, cxx_true,
           cxx_false);
      if (elfsym->st_name == (unsigned long) -1)
 return cxx_false;
    }

  if (finfo->symbuf_count >= finfo->symbuf_size)
    {
      if (! elf_link_flush_output_syms (finfo))
 return cxx_false;
    }

  bfd_elf32_swap_symbol_out (finfo->output_bfd, elfsym,
         (void *) (finfo->symbuf + finfo->symbuf_count));
  ++finfo->symbuf_count;

  ++finfo->output_bfd->symcount;

  return cxx_true;
}



static boolean
elf_link_flush_output_syms(struct n64_tag_elf_final_link_info *finfo) asm("_elf_link_flush_output_syms");
static boolean
elf_link_flush_output_syms(struct n64_tag_elf_final_link_info *finfo)
{
  Elf_Internal_Shdr *symtab;

  symtab = &((finfo->output_bfd) -> tdata.elf_obj_data)->symtab_hdr;

  if (bfd_seek (finfo->output_bfd, symtab->sh_offset + symtab->sh_size,
  
 0
         ) != 0
      || (bfd_write ((void *) finfo->symbuf, finfo->symbuf_count,
       sizeof (Elf32_External_Sym), finfo->output_bfd)
   != finfo->symbuf_count * sizeof (Elf32_External_Sym)))
    return cxx_false;

  symtab->sh_size += finfo->symbuf_count * sizeof (Elf32_External_Sym);

  finfo->symbuf_count = 0;

  return cxx_true;
}




static boolean
elf_link_output_extsym(struct n64_tag_elf_link_hash_entry *h, void *data) asm("_elf_link_output_extsym");
static boolean
elf_link_output_extsym(struct n64_tag_elf_link_hash_entry *h, void *data)
{
  struct n64_tag_elf_finfo_failed *eif = (struct n64_tag_elf_finfo_failed *) data;
  struct n64_tag_elf_final_link_info *finfo = eif->finfo;
  boolean strip;
  Elf_Internal_Sym sym;
  asection *input_sec;
  if (! finfo->info->relocateable
      && ! finfo->info->shared
      && h->root.type == bfd_link_hash_undefined
      && (h->elf_link_hash_flags & 04) != 0
      && (h->elf_link_hash_flags & 01) == 0)
    {
      if (! ((*finfo->info->callbacks->undefined_symbol)
      (finfo->info, h->root.root.string, h->root.u.undef.abfd,
       (asection *) 
                   ((void *)0)
                       , 0)))
 {
   eif->failed = cxx_true;
   return cxx_false;
 }
    }





  if (h->indx == -2)
    strip = cxx_false;
  else if (((h->elf_link_hash_flags & 010) != 0
     || (h->elf_link_hash_flags & 04) != 0)
    && (h->elf_link_hash_flags & 02) == 0
    && (h->elf_link_hash_flags & 01) == 0)
    strip = cxx_true;
  else if (finfo->info->strip == strip_all
    || (finfo->info->strip == strip_some
        && bfd_hash_lookup (finfo->info->keep_hash,
       h->root.root.string,
       cxx_false, cxx_false) == 
                       ((void *)0)
                           ))
    strip = cxx_true;
  else
    strip = cxx_false;



  if (strip && h->dynindx == -1)
    return cxx_true;

  sym.st_value = 0;
  sym.st_size = h->size;
  sym.st_other = 0;
  if (h->root.type == bfd_link_hash_undefweak
      || h->root.type == bfd_link_hash_defweak)
    sym.st_info = (((2) << 4) + ((h->type) & 0xF));
  else
    sym.st_info = (((1) << 4) + ((h->type) & 0xF));

  switch (h->root.type)
    {
    default:
    case bfd_link_hash_new:
      abort ();
      return cxx_false;

    case bfd_link_hash_undefined:
      input_sec = ((asection *) &bfd_und_section);
      sym.st_shndx = 0;
      break;

    case bfd_link_hash_undefweak:
      input_sec = ((asection *) &bfd_und_section);
      sym.st_shndx = 0;
      break;

    case bfd_link_hash_defined:
    case bfd_link_hash_defweak:
      {
 input_sec = h->root.u.def.section;
 if (input_sec->output_section != 
                                 ((void *)0)
                                     )
   {
     sym.st_shndx =
       _bfd_elf_section_from_bfd_section (finfo->output_bfd,
       input_sec->output_section);
     if (sym.st_shndx == (unsigned short) -1)
       {
  eif->failed = cxx_true;
  return cxx_false;
       }




     sym.st_value = h->root.u.def.value + input_sec->output_offset;
     if (! finfo->info->relocateable)
       sym.st_value += input_sec->output_section->vma;
   }
 else
   {
     { if (!((((input_sec->owner)->xvec->flavour) == bfd_target_elf_flavour) && (((input_sec->owner) -> tdata.elf_obj_data) -> elf_header)->e_type == 3)) bfd_assert("elflink.h",2528); }

                                                         ;
     sym.st_shndx = 0;
     input_sec = ((asection *) &bfd_und_section);
   }
      }
      break;

    case bfd_link_hash_common:
      input_sec = ((asection *) &bfd_com_section);
      sym.st_shndx = 0xFFF2;
      sym.st_value = 1 << h->root.u.c.p->alignment_power;
      break;

    case bfd_link_hash_indirect:
    case bfd_link_hash_warning:
      return (elf_link_output_extsym
       ((struct n64_tag_elf_link_hash_entry *) h->root.u.i.link, data));
    }




  if (h->dynindx != -1
      && ((struct n64_tag_elf_link_hash_table *) ((finfo->info)->hash))->dynamic_sections_created)
    {
      struct n64_tag_elf_backend_data *bed;
      size_t bucketcount;
      size_t bucket;
      bfd_byte *bucketpos;
      bfd_vma chain;

      sym.st_name = h->dynstr_index;




      bed = ((struct n64_tag_elf_backend_data *) (finfo->output_bfd)->xvec->backend_data);
      if (! ((*bed->elf_backend_finish_dynamic_symbol)
      (finfo->output_bfd, finfo->info, h, &sym)))
 {
   eif->failed = cxx_true;
   return cxx_false;
 }

      bfd_elf32_swap_symbol_out (finfo->output_bfd, &sym,
      (void *) (((Elf32_External_Sym *)
       finfo->dynsym_sec->contents)
      + h->dynindx));

      bucketcount = ((struct n64_tag_elf_link_hash_table *) ((finfo->info)->hash))->bucketcount;
      bucket = (bfd_elf_hash ((const unsigned char *) h->root.root.string)
  % bucketcount);
      bucketpos = ((bfd_byte *) finfo->hash_sec->contents
     + (bucket + 2) * (32 / 8));
      chain = ((*((finfo->output_bfd)->xvec->bfd_h_getx32)) (bucketpos));
      ((*((finfo->output_bfd)->xvec->bfd_h_putx32)) (h->dynindx,bucketpos));
      ((*((finfo->output_bfd)->xvec->bfd_h_putx32)) (chain,((bfd_byte *) finfo->hash_sec->contents + (bucketcount + 2 + h->dynindx) * (32 / 8))))

                                                       ;
    }



  if (strip)
    return cxx_true;

  h->indx = finfo->output_bfd->symcount;

  if (! elf_link_output_sym (finfo, h->root.root.string, &sym, input_sec))
    {
      eif->failed = cxx_true;
      return cxx_false;
    }

  return cxx_true;
}






static boolean
elf_link_input_bfd(struct n64_tag_elf_final_link_info *finfo, bfd *input_bfd) asm("_elf_link_input_bfd");
static boolean
elf_link_input_bfd(struct n64_tag_elf_final_link_info *finfo, bfd *input_bfd)
{
  boolean (*relocate_section) (bfd *, struct n64_tag_bfd_link_info *, bfd *, asection *, bfd_byte *, Elf_Internal_Rela *, Elf_Internal_Sym *, asection **)


                                            ;
  bfd *output_bfd;
  Elf_Internal_Shdr *symtab_hdr;
  size_t locsymcount;
  size_t extsymoff;
  Elf32_External_Sym *esym;
  Elf32_External_Sym *esymend;
  Elf_Internal_Sym *isym;
  long *pindex;
  asection **ppsection;
  asection *o;

  output_bfd = finfo->output_bfd;
  relocate_section =
    ((struct n64_tag_elf_backend_data *) (output_bfd)->xvec->backend_data)->elf_backend_relocate_section;




  if ((((input_bfd) -> tdata.elf_obj_data) -> elf_header)->e_type == 3)
    return cxx_true;

  symtab_hdr = &((input_bfd) -> tdata.elf_obj_data)->symtab_hdr;
  if ((((input_bfd) -> tdata.elf_obj_data) -> bad_symtab))
    {
      locsymcount = symtab_hdr->sh_size / sizeof (Elf32_External_Sym);
      extsymoff = 0;
    }
  else
    {
      locsymcount = symtab_hdr->sh_info;
      extsymoff = symtab_hdr->sh_info;
    }


  if (locsymcount > 0
      && (bfd_seek (input_bfd, symtab_hdr->sh_offset, 
                                                     0
                                                             ) != 0
         || (bfd_read (finfo->external_syms, sizeof (Elf32_External_Sym),
   locsymcount, input_bfd)
       != locsymcount * sizeof (Elf32_External_Sym))))
    return cxx_false;



  esym = finfo->external_syms;
  esymend = esym + locsymcount;
  isym = finfo->internal_syms;
  pindex = finfo->indices;
  ppsection = finfo->sections;
  for (; esym < esymend; esym++, isym++, pindex++, ppsection++)
    {
      asection *isec;
      const char *name;
      Elf_Internal_Sym osym;

      bfd_elf32_swap_symbol_in (input_bfd, esym, isym);
      *pindex = -1;

      if ((((input_bfd) -> tdata.elf_obj_data) -> bad_symtab))
 {
   if ((((unsigned int)(isym->st_info)) >> 4) != 0)
     {
       *ppsection = 
                   ((void *)0)
                       ;
       continue;
     }
 }

      if (isym->st_shndx == 0)
 isec = ((asection *) &bfd_und_section);
      else if (isym->st_shndx > 0 && isym->st_shndx < 0xFF00)
 isec = bfd_section_from_elf_index (input_bfd, isym->st_shndx);
      else if (isym->st_shndx == 0xFFF1)
 isec = ((asection *) &bfd_abs_section);
      else if (isym->st_shndx == 0xFFF2)
 isec = ((asection *) &bfd_com_section);
      else
 {

   isec = 
         ((void *)0)
             ;
 }

      *ppsection = isec;


      if (esym == finfo->external_syms)
 continue;



      if (finfo->info->strip == strip_all)
 continue;



      if (((isym->st_info) & 0xF) == 3)
 continue;






      if (finfo->info->discard == discard_all)
 continue;


      name = bfd_elf_string_from_elf_section (input_bfd, symtab_hdr->sh_link,
       isym->st_name);
      if (name == 
                 ((void *)0)
                     )
 return cxx_false;


      if ((finfo->info->strip == strip_some
    && (bfd_hash_lookup (finfo->info->keep_hash, name, cxx_false, cxx_false)
        == 
          ((void *)0)
              ))
   || (finfo->info->discard == discard_l
       && strncmp (name, finfo->info->lprefix,
     finfo->info->lprefix_len) == 0))
 continue;



      osym = *isym;


      osym.st_shndx = _bfd_elf_section_from_bfd_section (output_bfd,
        isec->output_section);
      if (osym.st_shndx == (unsigned short) -1)
 return cxx_false;

      *pindex = output_bfd->symcount;
      osym.st_value += isec->output_offset;
      if (! finfo->info->relocateable)
 osym.st_value += isec->output_section->vma;

      if (! elf_link_output_sym (finfo, name, &osym, isec))
 return cxx_false;
    }


  for (o = input_bfd->sections; o != 
                                    ((void *)0)
                                        ; o = o->next)
    {
      if ((o->flags & 0x200) == 0)
 continue;

      if ((o->flags & 0x20000) != 0
   && input_bfd == ((struct n64_tag_elf_link_hash_table *) ((finfo->info)->hash))->dynobj)
 {


   continue;
 }


      if (! bfd_get_section_contents (input_bfd, o, finfo->contents,
          (file_ptr) 0, o->_raw_size))
 return cxx_false;

      if ((o->flags & 0x004) != 0)
 {
   Elf_Internal_Rela *internal_relocs;


   internal_relocs = elf_link_read_relocs (input_bfd, o,
        finfo->external_relocs,
        finfo->internal_relocs,
        cxx_false);
   if (internal_relocs == 
                         ((void *)0)
       
      && o->reloc_count > 0)
     return cxx_false;
   if (! (*relocate_section) (output_bfd, finfo->info,
         input_bfd, o,
         finfo->contents,
         internal_relocs,
         finfo->internal_syms,
         finfo->sections))
     return cxx_false;

   if (finfo->info->relocateable)
     {
       Elf_Internal_Rela *irela;
       Elf_Internal_Rela *irelaend;
       struct n64_tag_elf_link_hash_entry **rel_hash;
       Elf_Internal_Shdr *input_rel_hdr;
       Elf_Internal_Shdr *output_rel_hdr;



       irela = internal_relocs;
       irelaend = irela + o->reloc_count;
       rel_hash = (((struct n64_tag_bfd_elf_section_data*)o->output_section->used_by_bfd)->rel_hashes
     + o->output_section->reloc_count);
       for (; irela < irelaend; irela++, rel_hash++)
  {
    unsigned long r_symndx;
    Elf_Internal_Sym *isym;
    asection *sec;

    irela->r_offset += o->output_offset;

    r_symndx = ((irela->r_info) >> 8);

    if (r_symndx == 0)
      continue;

    if (r_symndx >= locsymcount
        || ((((input_bfd) -> tdata.elf_obj_data) -> bad_symtab)
     && finfo->sections[r_symndx] == 
                                    ((void *)0)
                                        ))
      {
        long indx;
        indx = r_symndx - extsymoff;
        *rel_hash = (((input_bfd) -> tdata.elf_obj_data) -> sym_hashes)[indx];




        { if (!((*rel_hash)->indx < 0)) bfd_assert("elflink.h",2873); };
        (*rel_hash)->indx = -2;

        continue;
      }



    *rel_hash = 
               ((void *)0)
                   ;
    isym = finfo->internal_syms + r_symndx;
    sec = finfo->sections[r_symndx];
    if (((isym->st_info) & 0xF) == 3)
      {



        if (sec != 
                  ((void *)0) 
                       && ((sec) == ((asection *) &bfd_abs_section)))
   r_symndx = 0;
        else if (sec == 
                       ((void *)0) 
                            || sec->owner == 
                                             ((void *)0)
                                                 )
   {
     bfd_set_error (bfd_error_bad_value);
     return cxx_false;
   }
        else
   {
     r_symndx = sec->output_section->target_index;
     { if (!(r_symndx != 0)) bfd_assert("elflink.h",2899); };
   }
      }
    else
      {
        if (finfo->indices[r_symndx] == -1)
   {
     unsigned long link;
     const char *name;
     asection *osec;

     if (finfo->info->strip == strip_all)
       {

         bfd_set_error (bfd_error_invalid_operation);
         return cxx_false;
       }




     link = symtab_hdr->sh_link;
     name = bfd_elf_string_from_elf_section (input_bfd,
          link,
          isym->st_name);
     if (name == 
                ((void *)0)
                    )
       return cxx_false;

     osec = sec->output_section;
     isym->st_shndx =
       _bfd_elf_section_from_bfd_section (output_bfd,
              osec);
     if (isym->st_shndx == (unsigned short) -1)
       return cxx_false;

     isym->st_value += sec->output_offset;
     if (! finfo->info->relocateable)
       isym->st_value += osec->vma;

     finfo->indices[r_symndx] = output_bfd->symcount;

     if (! elf_link_output_sym (finfo, name, isym, sec))
       return cxx_false;
   }

        r_symndx = finfo->indices[r_symndx];
      }

    irela->r_info = (((r_symndx) << 8) + ((((irela->r_info) & 0xff)) & 0xff))
                                      ;
  }


       input_rel_hdr = &((struct n64_tag_bfd_elf_section_data*)o->used_by_bfd)->rel_hdr;
       output_rel_hdr = &((struct n64_tag_bfd_elf_section_data*)o->output_section->used_by_bfd)->rel_hdr;
       { if (!(output_rel_hdr->sh_entsize == input_rel_hdr->sh_entsize)) bfd_assert("elflink.h",2954); }
                                  ;
       irela = internal_relocs;
       irelaend = irela + o->reloc_count;
       if (input_rel_hdr->sh_entsize == sizeof (Elf32_External_Rel))
  {
    Elf32_External_Rel *erel;

    erel = ((Elf32_External_Rel *) output_rel_hdr->contents
     + o->output_section->reloc_count);
    for (; irela < irelaend; irela++, erel++)
      {
        Elf_Internal_Rel irel;

        irel.r_offset = irela->r_offset;
        irel.r_info = irela->r_info;
        { if (!(irela->r_addend == 0)) bfd_assert("elflink.h",2970); };
        bfd_elf32_swap_reloc_out (output_bfd, &irel, erel);
      }
  }
       else
  {
    Elf32_External_Rela *erela;

    { if (!(input_rel_hdr->sh_entsize == sizeof (Elf32_External_Rela))) bfd_assert("elflink.h",2978); }
                                       ;
    erela = ((Elf32_External_Rela *) output_rel_hdr->contents
      + o->output_section->reloc_count);
    for (; irela < irelaend; irela++, erela++)
      bfd_elf32_swap_reloca_out (output_bfd, irela, erela);
  }

       o->output_section->reloc_count += o->reloc_count;
     }
 }


      if (! bfd_set_section_contents (output_bfd, o->output_section,
          finfo->contents, o->output_offset,
          (o->_cooked_size != 0
           ? o->_cooked_size
           : o->_raw_size)))
 return cxx_false;
    }

  return cxx_true;
}






static boolean
elf_reloc_link_order(bfd *output_bfd, struct n64_tag_bfd_link_info *info, asection *output_section, struct n64_tag_bfd_link_order *link_order) asm("_elf_reloc_link_order");
static boolean
elf_reloc_link_order(bfd *output_bfd, struct n64_tag_bfd_link_info *info, asection *output_section, struct n64_tag_bfd_link_order *link_order)
{
  reloc_howto_type *howto;
  long indx;
  bfd_vma offset;
  struct n64_tag_elf_link_hash_entry **rel_hash_ptr;
  Elf_Internal_Shdr *rel_hdr;

  howto = bfd_reloc_type_lookup (output_bfd, link_order->u.reloc.p->reloc);
  if (howto == 
              ((void *)0)
                  )
    {
      bfd_set_error (bfd_error_bad_value);
      return cxx_false;
    }



  if (howto->partial_inplace
      && link_order->u.reloc.p->addend != 0)
    {
      bfd_size_type size;
      bfd_reloc_status_type rstat;
      bfd_byte *buf;
      boolean ok;

      size = bfd_get_reloc_size (howto);
      buf = (bfd_byte *) bfd_zmalloc (size);
      if (buf == (bfd_byte *) 
                             ((void *)0)
                                 )
 {
   bfd_set_error (bfd_error_no_memory);
   return cxx_false;
 }
      rstat = _bfd_relocate_contents (howto, output_bfd,
          link_order->u.reloc.p->addend, buf);
      switch (rstat)
 {
 case bfd_reloc_ok:
   break;
 default:
 case bfd_reloc_outofrange:
   abort ();
 case bfd_reloc_overflow:
   if (! ((*info->callbacks->reloc_overflow)
   (info,
    (link_order->type == bfd_section_reloc_link_order
     ? ((link_order->u.reloc.p->u.section)->name)

     : link_order->u.reloc.p->u.name),
    howto->name, link_order->u.reloc.p->addend,
    (bfd *) 
           ((void *)0)
               , (asection *) 
                              ((void *)0)
                                  , (bfd_vma) 0)))
     {
       free (buf);
       return cxx_false;
     }
   break;
 }
      ok = bfd_set_section_contents (output_bfd, output_section, (void *) buf,
         (file_ptr) link_order->offset, size);
      free (buf);
      if (! ok)
 return cxx_false;
    }


  rel_hash_ptr = (((struct n64_tag_bfd_elf_section_data*)output_section->used_by_bfd)->rel_hashes
    + output_section->reloc_count);
  if (link_order->type == bfd_section_reloc_link_order)
    {
      indx = link_order->u.reloc.p->u.section->target_index;
      { if (!(indx != 0)) bfd_assert("elflink.h",3081); };
      *rel_hash_ptr = 
                     ((void *)0)
                         ;
    }
  else
    {
      struct n64_tag_elf_link_hash_entry *h;

      h = ((struct n64_tag_elf_link_hash_entry *) bfd_link_hash_lookup (&(((struct n64_tag_elf_link_hash_table *) ((info)->hash)))->root, (link_order->u.reloc.p->u.name), (cxx_false), (cxx_false), (cxx_true)))

                       ;
      if (h != 
              ((void *)0)
                  )
 {


   h->indx = -2;
   *rel_hash_ptr = h;
   indx = 0;
 }
      else
 {
   if (! ((*info->callbacks->unattached_reloc)
   (info, link_order->u.reloc.p->u.name, (bfd *) 
                                                ((void *)0)
                                                    ,
    (asection *) 
                ((void *)0)
                    , (bfd_vma) 0)))
     return cxx_false;
   indx = 0;
 }
    }




  offset = link_order->offset;
  if (! info->relocateable)
    offset += output_section->vma;

  rel_hdr = &((struct n64_tag_bfd_elf_section_data*)output_section->used_by_bfd)->rel_hdr;

  if (rel_hdr->sh_type == 9)
    {
      Elf_Internal_Rel irel;
      Elf32_External_Rel *erel;

      irel.r_offset = offset;
      irel.r_info = (((indx) << 8) + ((howto->type) & 0xff));
      erel = ((Elf32_External_Rel *) rel_hdr->contents
       + output_section->reloc_count);
      bfd_elf32_swap_reloc_out (output_bfd, &irel, erel);
    }
  else
    {
      Elf_Internal_Rela irela;
      Elf32_External_Rela *erela;

      irela.r_offset = offset;
      irela.r_info = (((indx) << 8) + ((howto->type) & 0xff));
      irela.r_addend = link_order->u.reloc.p->addend;
      erela = ((Elf32_External_Rela *) rel_hdr->contents
        + output_section->reloc_count);
      bfd_elf32_swap_reloca_out (output_bfd, &irela, erela);
    }

  ++output_section->reloc_count;

  return cxx_true;
}


extern const struct n64_tag_elf_size_info _bfd_elf32_size_info = {
  sizeof (Elf32_External_Ehdr),
  sizeof (Elf32_External_Phdr),
  sizeof (Elf32_External_Shdr),
  sizeof (Elf32_External_Rel),
  sizeof (Elf32_External_Rela),
  sizeof (Elf32_External_Sym),
  sizeof (Elf32_External_Dyn),
  sizeof (Elf_External_Note),

  32, 4,
  1, 1,
  write_out_phdrs,
  write_shdrs_and_ehdr,
  write_relocs,
  bfd_elf32_swap_symbol_out,
  elf_slurp_reloc_table,
  elf_slurp_symbol_table,
};

