// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/config/tc-mips.c
/* tc-mips.c -- assemble code for a MIPS chip.
   Copyright (C) 1993, 1995 Free Software Foundation, Inc.
   Contributed by the OSF and Ralph Campbell.
   Written by Keith Knowles and Ralph Campbell, working independently.
   Modified for ECOFF and R4000 support by Ian Lance Taylor of Cygnus
   Support.

   This file is part of GAS.

   GAS is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GAS is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GAS; see the file COPYING.  If not, write to
   the Free Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <stdarg.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_FLONUM_STRUCT;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__pseudo_type;
struct n64_tag__symbol_info;
union n64_tag_aux_ext;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_bit_fix;
struct n64_tag_carsym;
struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_ecoff_fdrtab_entry;
struct n64_tag_ecoff_find_line;
struct n64_tag_ecoff_value_adjust;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_emulation;
struct n64_tag_expressionS;
struct n64_tag_fdr;
struct n64_tag_file;
struct n64_tag_fix;
struct n64_tag_format_ops;
struct n64_tag_frag;
struct n64_tag_frchain;
struct n64_tag_hash_control;
struct n64_tag_hash_entry;
struct n64_tag_lineno_cache_entry;
struct n64_tag_loc;
struct n64_tag_mips_cl_insn;
struct n64_tag_mips_opcode;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_pdr;
struct n64_tag_proc;
struct n64_tag_regname;
struct n64_tag_relax_type;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_rndx_ext;
struct n64_tag_sec;
struct n64_tag_symbol;
struct n64_tag_symbol_cache_entry;
struct n64_tag_tir_ext;








extern char *strdup(...) asm("_strdup");


struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_ecoff_debug_info *input_debug, const struct n64_tag_ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct n64_tag_ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, const char *name, struct n64_tag_ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct coff_tdata *coff_obj_data;
      struct pe_tdata *pe_obj_data;
      struct xcoff_tdata *xcoff_obj_data;
      struct ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");



extern void * bfd_alloc_by_size_t (bfd *abfd, size_t sz) asm("_bfd_alloc_by_size_t");
extern char *strstr(...) asm("_strstr");

typedef unsigned short LITTLENUM_TYPE;







int bignum_copy (LITTLENUM_TYPE * in, int in_length, LITTLENUM_TYPE * out, int out_length) asm("_bignum_copy")
                                          ;
struct n64_tag_FLONUM_STRUCT
{
  LITTLENUM_TYPE *low;
  LITTLENUM_TYPE *high;
  LITTLENUM_TYPE *leader;

  long exponent;
  char sign;
};

typedef struct n64_tag_FLONUM_STRUCT FLONUM_TYPE;
extern const FLONUM_TYPE flonum_positive_powers_of_ten[];
extern const FLONUM_TYPE flonum_negative_powers_of_ten[];
extern const int table_size_of_flonum_powers_of_ten;
int atof_generic (char **address_of_string_pointer, const char *string_of_decimal_marks, const char *string_of_decimal_exponent_marks, FLONUM_TYPE * address_of_generic_floating_point_number) asm("_atof_generic")


                                                             ;

void flonum_copy (FLONUM_TYPE * in, FLONUM_TYPE * out) asm("_flonum_copy");
void flonum_multip (const FLONUM_TYPE * a, const FLONUM_TYPE * b, FLONUM_TYPE * product) asm("_flonum_multip")
                              ;




extern bfd *stdoutput;
typedef bfd_vma addressT;
typedef bfd_signed_vma offsetT;






typedef addressT valueT;
typedef asection *segT;





typedef int subsegT;


extern subsegT now_subseg;


extern segT now_seg;
extern segT reg_section, expr_section;

extern segT text_section, data_section, bss_section;
enum n64_cpp_enum__relax_state{



    rs_fill = 1,


    rs_align,



    rs_align_code,



    rs_org,



    rs_broken_word,



    rs_machine_dependent,





    rs_space
  };
typedef __underlying_type(enum n64_cpp_enum__relax_state) n64_enum__relax_state;


typedef n64_enum__relax_state relax_stateT;



typedef unsigned int relax_substateT;



typedef addressT relax_addressT;
struct n64_tag_frag
{

  addressT fr_address;

  struct n64_tag_frag *fr_next;


  offsetT fr_fix;

  offsetT fr_var;

  struct n64_tag_symbol *fr_symbol;

  offsetT fr_offset;

  char *fr_opcode;


  struct list_info_struct *line;



  relax_stateT fr_type;
  relax_substateT fr_subtype;



  unsigned short align_mask;
  unsigned short align_offset;
  char fr_pcrel_adjust, fr_bsr;


  char fr_literal[1];
};





typedef struct n64_tag_frag fragS;




extern fragS *frag_now;
extern int frag_now_fix(void) asm("_frag_now_fix");


extern fragS zero_address_frag;

extern fragS bss_address_frag;



extern unsigned char flag_no_comments;
extern unsigned char flag_debug;
extern unsigned char flag_signed_overflow_ok;

extern unsigned char flag_warn_displacement;



extern int flag_keep_locals;


extern int flag_mri;



extern unsigned char flag_readonly_data_in_text;


extern int flag_no_warnings;



extern unsigned char flag_always_generate_output;



extern unsigned char flag_print_statistics;


extern char *out_file_name;


extern int need_pass_2;



extern int linkrelax;


extern int listing;


extern int max_macro_nest;



extern int chunksize;

struct n64_tag__pseudo_type
  {

    const char *poc_name;

    void (*poc_handler) (int);

    int poc_val;
  };

typedef struct n64_tag__pseudo_type pseudo_typeS;
void as_bad (const char *format, ...) asm("_as_bad") __attribute__ ((format (printf, 1, 2)));
void as_fatal (const char *format, ...) asm("_as_fatal") __attribute__ ((format (printf, 1, 2)));
void as_tsktsk (const char *format, ...) asm("_as_tsktsk") __attribute__ ((format (printf, 1, 2)));
void as_warn (const char *format, ...) asm("_as_warn") __attribute__ ((format (printf, 1, 2)));
void as_bad_where (char *file, unsigned int line, const char *format, ...) asm("_as_bad_where") __attribute__ ((format (printf, 3, 4)));
void as_warn_where (char *file, unsigned int line, const char *format, ...) asm("_as_warn_where") __attribute__ ((format (printf, 3, 4)));
void as_assert (const char *, int, const char *) asm("_as_assert");
void as_abort (const char *, int, const char *) asm("_as_abort");

void fprint_value (FILE *file, addressT value) asm("_fprint_value");
void sprint_value (char *buf, addressT value) asm("_sprint_value");

int had_errors (void) asm("_had_errors");
int had_warnings (void) asm("_had_warnings");

void print_version_id (void) asm("_print_version_id");
char *app_push (void) asm("_app_push");
char *atof_ieee (char *str, int what_kind, LITTLENUM_TYPE * words) asm("_atof_ieee");
char *input_scrub_include_file (char *filename, char *position) asm("_input_scrub_include_file");
char *input_scrub_new_file (char *filename) asm("_input_scrub_new_file");
char *input_scrub_next_buffer (char **bufp) asm("_input_scrub_next_buffer");
void * xmalloc (unsigned long size) asm("_xmalloc");
void * xrealloc (void * ptr, unsigned long n) asm("_xrealloc");
int do_scrub_chars (int (*get) (char **), char *to, int tolen) asm("_do_scrub_chars");
int gen_to_words (LITTLENUM_TYPE * words, int precision, long exponent_bits) asm("_gen_to_words")
                         ;
int had_err (void) asm("_had_err");
int ignore_input (void) asm("_ignore_input");
int seen_at_least_1_file (void) asm("_seen_at_least_1_file");
void app_pop (char *arg) asm("_app_pop");
void as_howmuch (FILE * stream) asm("_as_howmuch");
void as_perror (const char *gripe, const char *filename) asm("_as_perror");
void as_where (char **namep, unsigned int *linep) asm("_as_where");
void bump_line_counters (void) asm("_bump_line_counters");
void do_scrub_begin (void) asm("_do_scrub_begin");
void input_scrub_begin (void) asm("_input_scrub_begin");
void input_scrub_close (void) asm("_input_scrub_close");
void input_scrub_end (void) asm("_input_scrub_end");
void new_logical_line (char *fname, int line_number) asm("_new_logical_line");
void subsegs_begin (void) asm("_subsegs_begin");
void subseg_change (segT seg, int subseg) asm("_subseg_change");
segT subseg_new (const char *name, subsegT subseg) asm("_subseg_new");
segT subseg_force_new (const char *name, subsegT subseg) asm("_subseg_force_new");
void subseg_set (segT seg, subsegT subseg) asm("_subseg_set");

segT subseg_get (const char *, int) asm("_subseg_get");


struct n64_tag_expressionS;
struct n64_tag_fix;
struct n64_tag_symbol;
struct n64_tag_relax_type;



valueT add_to_literal_pool (struct n64_tag_symbol *, valueT, segT, int) asm("_add_to_literal_pool");


enum n64_cpp_enum_anonymous_11{

  O_illegal,

  O_absent,

  O_constant,

  O_symbol,

  O_symbol_rva,

  O_register,




  O_big,

  O_uminus,

  O_bit_not,

  O_logical_not,

  O_multiply,

  O_divide,

  O_modulus,

  O_left_shift,

  O_right_shift,

  O_bit_inclusive_or,

  O_bit_or_not,

  O_bit_exclusive_or,

  O_bit_and,

  O_add,

  O_subtract,

  O_eq,

  O_ne,

  O_lt,

  O_le,

  O_ge,

  O_gt,

  O_logical_and,

  O_logical_or
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_11) n64_enum_anonymous_11;
typedef n64_enum_anonymous_11 operatorT;

typedef struct n64_tag_expressionS
{

  operatorT X_op;

  struct n64_tag_symbol *X_add_symbol;

  struct n64_tag_symbol *X_op_symbol;

  offsetT X_add_number;






  int X_unsigned;
} expressionS;







extern FLONUM_TYPE generic_floating_point_number;

extern LITTLENUM_TYPE generic_bignum[];



typedef char operator_rankT;

char get_symbol_end (void) asm("_get_symbol_end");
void expr_begin (void) asm("_expr_begin");
segT expr (int rank, expressionS * resultP) asm("_expr");
unsigned int get_single_number (void) asm("_get_single_number");
struct n64_tag_symbol *make_expr_symbol (expressionS * expressionP) asm("_make_expr_symbol");


typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct n64_tag_ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");
extern int mips_local_label (const char *) asm("_mips_local_label");
extern const char *mips_target_format(void) asm("_mips_target_format");

struct n64_tag_mips_cl_insn {
    unsigned long insn_opcode;
    const struct n64_tag_mips_opcode *insn_mo;
};

extern int tc_get_register (int frame) asm("_tc_get_register");


extern int mips_parse_long_option (const char *) asm("_mips_parse_long_option");


extern void mips_define_label (struct n64_tag_symbol *) asm("_mips_define_label");


extern void cons_fix_new_mips(...) asm("_cons_fix_new_mips");




extern int mips_force_relocation(...) asm("_mips_force_relocation");






extern unsigned long mips_gprmask;
extern unsigned long mips_cprmask[4];




extern void mips_elf_final_processing (void) asm("_mips_elf_final_processing");
extern void md_mips_end (void) asm("_md_mips_end");





extern void mips_pop_insert (void) asm("_mips_pop_insert");


extern void mips_flush_pending_output (void) asm("_mips_flush_pending_output");


extern void mips_enable_auto_align (void) asm("_mips_enable_auto_align");


extern void mips_init_after_args (void) asm("_mips_init_after_args");
extern asection *gdb_section;



extern void elf_frob_file (void) asm("_elf_frob_file");
extern void elf_file_symbol (char *) asm("_elf_file_symbol");


extern void obj_elf_section (int) asm("_obj_elf_section");
extern void obj_elf_previous (int) asm("_obj_elf_previous");
extern void obj_elf_version (int) asm("_obj_elf_version");
extern void obj_elf_init_stab_section (segT) asm("_obj_elf_init_stab_section");
extern void elf_frob_symbol (struct n64_tag_symbol *, int *) asm("_elf_frob_symbol");


extern void elf_pop_insert (void) asm("_elf_pop_insert");

struct n64_tag_symbol
{
  asymbol *bsym;



  expressionS sy_value;


  struct n64_tag_symbol *sy_next;

  struct n64_tag_symbol *sy_previous;




  struct n64_tag_frag *sy_frag;

  unsigned int written : 1;


  unsigned int sy_resolved : 1;


  unsigned int sy_resolving : 1;



  unsigned int sy_used_in_reloc : 1;





  unsigned int sy_used : 1;





  unsigned int sy_mri_common : 1;


  expressionS * sy_obj;







  int local:1; unsigned long sy_name_offset;

};

typedef struct n64_tag_symbol symbolS;
extern const segT N_TYPE_seg[];


extern const short seg_N_TYPE[];



void symbol_clear_list_pointers (symbolS * symbolP) asm("_symbol_clear_list_pointers");



void symbol_insert (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_insert")
                                           ;
void symbol_remove (symbolS * symbolP, symbolS ** rootP, symbolS ** lastP) asm("_symbol_remove")
                         ;





void verify_symbol_chain (symbolS * rootP, symbolS * lastP) asm("_verify_symbol_chain");
void verify_symbol_chain_2 (symbolS * symP) asm("_verify_symbol_chain_2");

void symbol_append (symbolS * addme, symbolS * target, symbolS ** rootP, symbolS ** lastP) asm("_symbol_append")
                                           ;
struct n64_tag_bit_fix
  {
    int fx_bit_size;
    int fx_bit_offset;
    long fx_bit_base;

    long fx_bit_base_adj;
    long fx_bit_max;
    long fx_bit_min;
    long fx_bit_add;
  };
typedef struct n64_tag_bit_fix bit_fixS;





struct n64_tag_fix
{




  char fx_pcrel_adjust;


  unsigned char fx_size;


  unsigned fx_pcrel : 1;






  unsigned fx_plt : 1;



  unsigned fx_im_disp : 2;



  unsigned fx_tcbit : 1;


  unsigned fx_done : 1;






  unsigned fx_no_overflow : 1;


  fragS *fx_frag;


  long fx_where;


  symbolS *fx_addsy;


  symbolS *fx_subsy;


  valueT fx_offset;


  struct n64_tag_fix *fx_next;




  bit_fixS *fx_bit_fixP;


  bfd_reloc_code_real_type fx_r_type;
  valueT fx_addnumber;



  char *fx_file;
  unsigned fx_line;






};

typedef struct n64_tag_fix fixS;
extern long string_byte_count;
extern int section_alignment[];

bit_fixS *bit_fix_new (int size, int offset, long base_type, long base_adj, long min, long max, long add) asm("_bit_fix_new")
                                                       ;
void append (char **charPP, char *fromP, unsigned long length) asm("_append");
void record_alignment (segT seg, int align) asm("_record_alignment");
void write_object_file (void) asm("_write_object_file");
void relax_segment (struct n64_tag_frag * seg_frag_root, segT seg_type) asm("_relax_segment");

void number_to_chars_littleendian (char *, valueT, int) asm("_number_to_chars_littleendian");
void number_to_chars_bigendian (char *, valueT, int) asm("_number_to_chars_bigendian");


fixS *fix_new (fragS * frag, int where, int size, symbolS * add_symbol, offsetT offset, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new")

                                          ;
fixS *fix_new_exp (fragS * frag, int where, int size, expressionS *exp, int pcrel, bfd_reloc_code_real_type r_type) asm("_fix_new_exp")

                                       ;
extern void frag_append_1_char (int) asm("_frag_append_1_char");




void frag_init (void) asm("_frag_init");
void frag_grow (unsigned int nchars) asm("_frag_grow");
char *frag_more (int nchars) asm("_frag_more");
void frag_align (int alignment, int fill_character) asm("_frag_align");
void frag_align_pattern (int alignment, const char *fill_pattern, int n_fill) asm("_frag_align_pattern")

                 ;
void frag_new (int old_frags_var_max_size) asm("_frag_new");
void frag_wane (fragS * fragP) asm("_frag_wane");

char *frag_variant (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_variant")





                     ;

char *frag_var (relax_stateT type, int max_chars, int var, relax_substateT subtype, symbolS * symbol, long offset, char *opcode) asm("_frag_var")





                 ;
struct n64_tag_hash_entry
{
  const char *hash_string;


  void * hash_value;
};



struct n64_tag_hash_control
{
  struct n64_tag_hash_entry *hash_where;
  int hash_sizelog;
  int hash_mask;
  int hash_full;

  struct n64_tag_hash_entry *hash_wall;

  int hash_stat[(6)];

};



struct n64_tag_hash_control *hash_new (void) asm("_hash_new");
void hash_die (struct n64_tag_hash_control *) asm("_hash_die");
void hash_say (struct n64_tag_hash_control *, int *buffer, int bufsiz) asm("_hash_say");

void * hash_delete (struct n64_tag_hash_control *, const char *str) asm("_hash_delete");

void * hash_replace (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_replace");

const char *hash_insert (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_insert")
              ;

char *hash_apply (struct n64_tag_hash_control *, char *(*fn) (const char *str, void * val)) asm("_hash_apply")
                                             ;

void * hash_find (struct n64_tag_hash_control *, const char *str) asm("_hash_find");

const char *hash_jam (struct n64_tag_hash_control *, const char *str, void * val) asm("_hash_jam")
                  ;
extern char *input_line_pointer;
extern char lex_type[];
extern char is_end_of_line[];

extern int target_big_endian;


extern const char comment_chars[];
extern const char line_comment_chars[];
extern const char line_separator_chars[];


extern int generate_asm_lineno;


extern addressT abs_section_offset;


extern symbolS *line_label;


extern symbolS *mri_common_symbol;

unsigned int get_stab_string_offset (const char *string, const char *stabstr_secname) asm("_get_stab_string_offset")
                                       ;

char *demand_copy_C_string (int *len_pointer) asm("_demand_copy_C_string");
char get_absolute_expression_and_terminator (long *val_pointer) asm("_get_absolute_expression_and_terminator");
offsetT get_absolute_expression (void) asm("_get_absolute_expression");
unsigned int next_char_of_string (void) asm("_next_char_of_string");
void s_mri_sect (char *) asm("_s_mri_sect");
char *mri_comment_field (char *) asm("_mri_comment_field");
void mri_comment_end (char *, int) asm("_mri_comment_end");
void add_include_dir (char *path) asm("_add_include_dir");
void cons (int nbytes) asm("_cons");
void demand_empty_rest_of_line (void) asm("_demand_empty_rest_of_line");
void emit_expr (expressionS *exp, unsigned int nbytes) asm("_emit_expr");
void equals (char *sym_name) asm("_equals");
void float_cons (int float_type) asm("_float_cons");
void ignore_rest_of_line (void) asm("_ignore_rest_of_line");
void pseudo_set (symbolS * symbolP) asm("_pseudo_set");
void read_a_source_file (char *name) asm("_read_a_source_file");
void read_begin (void) asm("_read_begin");
void s_abort (int) asm("_s_abort");
void s_align_bytes (int arg) asm("_s_align_bytes");
void s_align_ptwo (int) asm("_s_align_ptwo");
void s_app_file (int) asm("_s_app_file");
void s_app_line (int) asm("_s_app_line");
void s_comm (int) asm("_s_comm");
void s_data (int) asm("_s_data");
void s_desc (int) asm("_s_desc");
void s_else (int arg) asm("_s_else");
void s_end (int arg) asm("_s_end");
void s_endif (int arg) asm("_s_endif");
void s_err (int) asm("_s_err");
void s_fail (int) asm("_s_fail");
void s_fill (int) asm("_s_fill");
void s_float_space (int mult) asm("_s_float_space");
void s_globl (int arg) asm("_s_globl");
void s_if (int arg) asm("_s_if");
void s_ifc (int arg) asm("_s_ifc");
void s_ifdef (int arg) asm("_s_ifdef");
void s_ifeqs (int arg) asm("_s_ifeqs");
void s_ignore (int arg) asm("_s_ignore");
void s_include (int arg) asm("_s_include");
void s_irp (int arg) asm("_s_irp");
void s_lcomm (int needs_align) asm("_s_lcomm");
void s_lsym (int) asm("_s_lsym");
void s_macro (int) asm("_s_macro");
void s_mexit (int) asm("_s_mexit");
void s_mri_common (int) asm("_s_mri_common");
void s_org (int) asm("_s_org");
void s_print (int) asm("_s_print");
void s_purgem (int) asm("_s_purgem");
void s_rept (int) asm("_s_rept");
void s_set (int) asm("_s_set");
void s_space (int mult) asm("_s_space");
void s_stab (int what) asm("_s_stab");
void s_struct (int) asm("_s_struct");
void s_text (int) asm("_s_text");
void stringer (int append_zero) asm("_stringer");
void s_xstab (int what) asm("_s_xstab");
void s_rva (int) asm("_s_rva");
extern struct n64_tag_obstack notes;

extern struct n64_tag_obstack cond_obstack;


extern symbolS *symbol_rootP;
extern symbolS *symbol_lastP;

extern symbolS abs_symbol;

extern int symbol_table_frozen;



extern int symbols_case_sensitive;

char *decode_local_label_name (char *s) asm("_decode_local_label_name");
symbolS *symbol_find (const char *name) asm("_symbol_find");
symbolS *symbol_find_base (const char *name, int strip_underscore) asm("_symbol_find_base");
symbolS *symbol_find_or_make (const char *name) asm("_symbol_find_or_make");
symbolS *symbol_make (const char *name) asm("_symbol_make");
symbolS *symbol_new (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_new")
                      ;
symbolS *symbol_create (const char *name, segT segment, valueT value, fragS * frag) asm("_symbol_create")
                  ;
symbolS *colon (const char *sym_name) asm("_colon");
void local_colon (int n) asm("_local_colon");
void symbol_begin (void) asm("_symbol_begin");
void symbol_table_insert (symbolS * symbolP) asm("_symbol_table_insert");
void resolve_symbol_value (symbolS *) asm("_resolve_symbol_value");

int dollar_label_defined (long l) asm("_dollar_label_defined");
void dollar_label_clear (void) asm("_dollar_label_clear");
void define_dollar_label (long l) asm("_define_dollar_label");
char *dollar_label_name (long l, int augend) asm("_dollar_label_name");

void fb_label_instance_inc (long label) asm("_fb_label_instance_inc");
char *fb_label_name (long n, long augend) asm("_fb_label_name");

extern void copy_symbol_attributes (symbolS *, symbolS *) asm("_copy_symbol_attributes");


extern valueT S_GET_VALUE (symbolS *) asm("_S_GET_VALUE");
extern void S_SET_VALUE (symbolS *, valueT) asm("_S_SET_VALUE");


extern int S_IS_EXTERNAL (symbolS *) asm("_S_IS_EXTERNAL");
extern int S_IS_WEAK (symbolS *) asm("_S_IS_WEAK");
extern int S_IS_COMMON (symbolS *) asm("_S_IS_COMMON");
extern int S_IS_DEFINED (symbolS *) asm("_S_IS_DEFINED");
extern int S_IS_DEBUG (symbolS *) asm("_S_IS_DEBUG");
extern int S_IS_LOCAL (symbolS *) asm("_S_IS_LOCAL");
extern int S_IS_EXTERN (symbolS *) asm("_S_IS_EXTERN");
extern int S_IS_STABD (symbolS *) asm("_S_IS_STABD");
extern const char *S_GET_NAME (symbolS *) asm("_S_GET_NAME");
extern segT S_GET_SEGMENT (symbolS *) asm("_S_GET_SEGMENT");
extern void S_SET_SEGMENT (symbolS *, segT) asm("_S_SET_SEGMENT");
extern void S_SET_EXTERNAL (symbolS *) asm("_S_SET_EXTERNAL");
extern void S_SET_NAME (symbolS *, char *) asm("_S_SET_NAME");
extern void S_CLEAR_EXTERNAL (symbolS *) asm("_S_CLEAR_EXTERNAL");
extern void S_SET_WEAK (symbolS *) asm("_S_SET_WEAK");

extern const pseudo_typeS md_pseudo_table[];




struct n64_tag_relax_type
{

  long rlx_forward;

  long rlx_backward;


  unsigned char rlx_length;


  relax_substateT rlx_more;
};

typedef struct n64_tag_relax_type relax_typeS;

extern const int md_reloc_size;

char *md_atof (int what_statement_type, char *literalP, int *sizeP) asm("_md_atof");

int md_estimate_size_before_relax (fragS * fragP, segT segment) asm("_md_estimate_size_before_relax");

int md_parse_option (int c, char *arg) asm("_md_parse_option");
void md_show_usage (FILE *) asm("_md_show_usage");
long md_pcrel_from (fixS * fixP) asm("_md_pcrel_from");
short tc_coff_fix2rtype (fixS * fixP) asm("_tc_coff_fix2rtype");
void md_assemble (char *str) asm("_md_assemble");
void md_begin (void) asm("_md_begin");

void md_create_long_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_long_jump")

                           ;


void md_create_short_jump (char *ptr, addressT from_addr, addressT to_addr, fragS * frag, symbolS * to_symbol) asm("_md_create_short_jump")

                            ;

void md_number_to_chars (char *buf, valueT val, int n) asm("_md_number_to_chars");
int md_apply_fix (fixS * fixP, valueT *val) asm("_md_apply_fix");

void md_convert_frag (bfd * headers, segT sec, fragS * fragP) asm("_md_convert_frag");


void tc_headers_hook (segT *, fixS *) asm("_tc_headers_hook");




extern arelent **tc_gen_reloc (asection *, fixS *) asm("_tc_gen_reloc");
valueT md_section_align (segT seg, valueT size) asm("_md_section_align");
char *obj_default_output_file_name (void) asm("_obj_default_output_file_name");
void obj_emit_relocations (char **where, fixS * fixP, relax_addressT segment_address_in_file) asm("_obj_emit_relocations")
                                               ;
void obj_emit_strings (char **where) asm("_obj_emit_strings");
void obj_emit_symbols (char **where, symbolS * symbols) asm("_obj_emit_symbols");

void obj_read_begin_hook (void) asm("_obj_read_begin_hook");
void obj_symbol_new_hook (symbolS * symbolP) asm("_obj_symbol_new_hook");


void obj_symbol_to_chars (char **where, symbolS * symbolP) asm("_obj_symbol_to_chars");

extern const pseudo_typeS obj_pseudo_table[];


struct n64_tag_format_ops {
  int flavor;
  unsigned dfl_leading_underscore : 1;
  unsigned emit_section_symbols : 1;
  void (*frob_symbol) (symbolS *, int *);
  void (*frob_file) (void);
  bfd_vma (*s_get_size) (symbolS *);
  void (*s_set_size) (symbolS *, bfd_vma);
  bfd_vma (*s_get_align) (symbolS *);
  void (*s_set_align) (symbolS *, bfd_vma);
  void (*copy_symbol_attributes) (symbolS *, symbolS *);
  void (*generate_asm_lineno) (const char *, int);
  void (*process_stab) (segT, int, const char *, int, int, int);
  int (*sec_sym_ok_for_reloc) (asection *);
  void (*pop_insert) (void);

  void (*ecoff_set_ext) (symbolS *, struct n64_tag_ecoff_extr *);

  void (*read_begin_hook) (void);
  void (*symbol_new_hook) (symbolS *);
};

extern const struct n64_tag_format_ops elf_format_ops;
extern const struct n64_tag_format_ops ecoff_format_ops;


extern const struct n64_tag_format_ops *this_format;





struct n64_tag_emulation {
  void (*match) (const char *);
  const char *name;
  void (*init)(...);
  const char *(*bfd_name)(...);
  unsigned local_labels_fb : 1;
  unsigned local_labels_dollar : 1;
  unsigned leading_underscore : 2;
  unsigned strip_underscore : 1;
  unsigned default_endian : 2;
  const char *fake_label_name;
  const struct n64_tag_format_ops *format;
};

extern struct n64_tag_emulation *this_emulation;

extern const char *default_emul_bfd_name(void) asm("_default_emul_bfd_name");
extern void common_emul_init(void) asm("_common_emul_init");

void listing_eject (int) asm("_listing_eject");
void listing_error (const char *message) asm("_listing_error");
void listing_file (const char *name) asm("_listing_file");
void listing_flags (int) asm("_listing_flags");
void listing_list (int on) asm("_listing_list");
void listing_newline (char *ps) asm("_listing_newline");
void listing_prev_line (void) asm("_listing_prev_line");
void listing_print (char *name) asm("_listing_print");
void listing_psize (int) asm("_listing_psize");
void listing_nopage (int) asm("_listing_nopage");
void listing_source_file (const char *) asm("_listing_source_file");
void listing_source_line (unsigned int) asm("_listing_source_line");
void listing_title (int depth) asm("_listing_title");
void listing_warning (const char *message) asm("_listing_warning");
void listing_width (unsigned int x) asm("_listing_width");

struct n64_tag_frchain
{
  struct n64_tag_frag *frch_root;
  struct n64_tag_frag *frch_last;
  struct n64_tag_frchain *frch_next;
  segT frch_seg;
  subsegT frch_subseg;

  fixS *fix_root;
  fixS *fix_tail;

  struct n64_tag_obstack frch_obstack;
  fragS *frch_frag_now;
};

typedef struct n64_tag_frchain frchainS;


extern frchainS *frchain_root;



extern frchainS *frchain_now;


typedef struct
{
  frchainS *frchainP;
  int hadone : 1;






  int bss : 1;

  int user_stuff;



  fixS *fix_root;
  fixS *fix_tail;




  symbolS *dot;

  struct lineno_list *lineno_list_head;
  struct lineno_list *lineno_list_tail;



  asection *bfd_section;



  symbolS *sym;


  union
    {

      unsigned long stab_string_size;

      char *p;
    }
  stabu;




} segment_info_type;



extern segment_info_type *seg_info (segT) asm("_seg_info");
extern symbolS *section_symbol (segT) asm("_section_symbol");




extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");









struct n64_tag_mips_opcode
{

  const char *name;

  const char *args;





  unsigned long match;





  unsigned long mask;



  unsigned long pinfo;
};
enum n64_cpp_enum_anonymous_16{
    M_ABS,
    M_ADD_I,
    M_ADDU_I,
    M_AND_I,
    M_BEQ_I,
    M_BEQL_I,
    M_BGE,
    M_BGEL,
    M_BGE_I,
    M_BGEL_I,
    M_BGEU,
    M_BGEUL,
    M_BGEU_I,
    M_BGEUL_I,
    M_BGT,
    M_BGTL,
    M_BGT_I,
    M_BGTL_I,
    M_BGTU,
    M_BGTUL,
    M_BGTU_I,
    M_BGTUL_I,
    M_BLE,
    M_BLEL,
    M_BLE_I,
    M_BLEL_I,
    M_BLEU,
    M_BLEUL,
    M_BLEU_I,
    M_BLEUL_I,
    M_BLT,
    M_BLTL,
    M_BLT_I,
    M_BLTL_I,
    M_BLTU,
    M_BLTUL,
    M_BLTU_I,
    M_BLTUL_I,
    M_BNE_I,
    M_BNEL_I,
    M_DABS,
    M_DADD_I,
    M_DADDU_I,
    M_DDIV_3,
    M_DDIV_3I,
    M_DDIVU_3,
    M_DDIVU_3I,
    M_DIV_3,
    M_DIV_3I,
    M_DIVU_3,
    M_DIVU_3I,
    M_DLA_AB,
    M_DLI,
    M_DMUL,
    M_DMUL_I,
    M_DMULO,
    M_DMULO_I,
    M_DMULOU,
    M_DMULOU_I,
    M_DREM_3,
    M_DREM_3I,
    M_DREMU_3,
    M_DREMU_3I,
    M_DSUB_I,
    M_DSUBU_I,
    M_J_A,
    M_JAL_1,
    M_JAL_2,
    M_JAL_A,
    M_L_DOB,
    M_L_DAB,
    M_LA_AB,
    M_LB_A,
    M_LB_AB,
    M_LBU_A,
    M_LBU_AB,
    M_LD_A,
    M_LD_OB,
    M_LD_AB,
    M_LDC1_AB,
    M_LDC2_AB,
    M_LDC3_AB,
    M_LDL_AB,
    M_LDR_AB,
    M_LH_A,
    M_LH_AB,
    M_LHU_A,
    M_LHU_AB,
    M_LI,
    M_LI_D,
    M_LI_DD,
    M_LI_S,
    M_LI_SS,
    M_LL_AB,
    M_LLD_AB,
    M_LS_A,
    M_LW_A,
    M_LW_AB,
    M_LWC0_A,
    M_LWC0_AB,
    M_LWC1_A,
    M_LWC1_AB,
    M_LWC2_A,
    M_LWC2_AB,
    M_LWC3_A,
    M_LWC3_AB,
    M_LWL_A,
    M_LWL_AB,
    M_LWR_A,
    M_LWR_AB,
    M_LWU_AB,
    M_MUL,
    M_MUL_I,
    M_MULO,
    M_MULO_I,
    M_MULOU,
    M_MULOU_I,
    M_NOR_I,
    M_OR_I,
    M_REM_3,
    M_REM_3I,
    M_REMU_3,
    M_REMU_3I,
    M_ROL,
    M_ROL_I,
    M_ROR,
    M_ROR_I,
    M_S_DA,
    M_S_DOB,
    M_S_DAB,
    M_S_S,
    M_SC_AB,
    M_SCD_AB,
    M_SD_A,
    M_SD_OB,
    M_SD_AB,
    M_SDC1_AB,
    M_SDC2_AB,
    M_SDC3_AB,
    M_SDL_AB,
    M_SDR_AB,
    M_SEQ,
    M_SEQ_I,
    M_SGE,
    M_SGE_I,
    M_SGEU,
    M_SGEU_I,
    M_SGT,
    M_SGT_I,
    M_SGTU,
    M_SGTU_I,
    M_SLE,
    M_SLE_I,
    M_SLEU,
    M_SLEU_I,
    M_SLT_I,
    M_SLTU_I,
    M_SNE,
    M_SNE_I,
    M_SB_A,
    M_SB_AB,
    M_SH_A,
    M_SH_AB,
    M_SW_A,
    M_SW_AB,
    M_SWC0_A,
    M_SWC0_AB,
    M_SWC1_A,
    M_SWC1_AB,
    M_SWC2_A,
    M_SWC2_AB,
    M_SWC3_A,
    M_SWC3_AB,
    M_SWL_A,
    M_SWL_AB,
    M_SWR_A,
    M_SWR_AB,
    M_SUB_I,
    M_SUBU_I,
    M_TEQ_I,
    M_TGE_I,
    M_TGEU_I,
    M_TLT_I,
    M_TLTU_I,
    M_TNE_I,
    M_TRUNCWD,
    M_TRUNCWS,
    M_ULD,
    M_ULD_A,
    M_ULH,
    M_ULH_A,
    M_ULHU,
    M_ULHU_A,
    M_ULW,
    M_ULW_A,
    M_USH,
    M_USH_A,
    M_USW,
    M_USW_A,
    M_USD,
    M_USD_A,
    M_XOR_I
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_16) n64_enum_anonymous_16;

extern const struct n64_tag_mips_opcode mips_opcodes[];
extern const int bfd_mips_num_opcodes;
typedef struct
{

  unsigned long l_name;

  unsigned long l_time_stamp;

  unsigned long l_checksum;

  unsigned long l_version;

  unsigned long l_flags;
} Elf32_Lib;
typedef unsigned long Elf32_Conflict;
typedef union
{
  struct
    {

      unsigned long gt_current_g_value;

      unsigned long gt_unused;
    } gt_header;
  struct
    {

      unsigned long gt_g_value;

      unsigned long gt_bytes;
    } gt_entry;
} Elf32_gptab;



typedef union
{
  struct
    {
      unsigned char gt_current_g_value[4];
      unsigned char gt_unused[4];
    } gt_header;
  struct
    {
      unsigned char gt_g_value[4];
      unsigned char gt_bytes[4];
    } gt_entry;
} Elf32_External_gptab;



typedef struct
{

  unsigned long ri_gprmask;

  unsigned long ri_cprmask[4];

  long ri_gp_value;
} Elf32_RegInfo;


typedef struct
{
  unsigned char ri_gprmask[4];
  unsigned char ri_cprmask[4][4];
  unsigned char ri_gp_value[4];
} Elf32_External_RegInfo;


extern void bfd_mips_elf32_swap_reginfo_in
  (bfd *, const Elf32_External_RegInfo *, Elf32_RegInfo *) asm("_bfd_mips_elf32_swap_reginfo_in");
extern void bfd_mips_elf32_swap_reginfo_out
  (bfd *, const Elf32_RegInfo *, Elf32_External_RegInfo *) asm("_bfd_mips_elf32_swap_reginfo_out");







typedef struct {
 short magic;
 short vstamp;
 long ilineMax;
 bfd_vma cbLine;
 bfd_vma cbLineOffset;
 long idnMax;
 bfd_vma cbDnOffset;
 long ipdMax;
 bfd_vma cbPdOffset;
 long isymMax;
 bfd_vma cbSymOffset;
 long ioptMax;
 bfd_vma cbOptOffset;
 long iauxMax;
 bfd_vma cbAuxOffset;
 long issMax;
 bfd_vma cbSsOffset;
 long issExtMax;
 bfd_vma cbSsExtOffset;
 long ifdMax;
 bfd_vma cbFdOffset;
 long crfd;
 bfd_vma cbRfdOffset;
 long iextMax;
 bfd_vma cbExtOffset;

 } HDRR, *pHDRR;
typedef struct n64_tag_fdr {
 bfd_vma adr;
 long rss;
 long issBase;
 bfd_vma cbSs;
 long isymBase;
 long csym;
 long ilineBase;
 long cline;
 long ioptBase;
 long copt;
 unsigned short ipdFirst;
 short cpd;
 long iauxBase;
 long caux;
 long rfdBase;
 long crfd;
 unsigned lang: 5;
 unsigned fMerge : 1;
 unsigned fReadin : 1;
 unsigned fBigendian : 1;

 unsigned glevel : 2;
 unsigned reserved : 22;
 bfd_vma cbLineOffset;
 bfd_vma cbLine;
 } FDR, *pFDR;
typedef struct n64_tag_pdr {
 bfd_vma adr;
 long isym;
 long iline;
 long regmask;
 long regoffset;
 long iopt;
 long fregmask;
 long fregoffset;
 long frameoffset;
 short framereg;
 short pcreg;
 long lnLow;
 long lnHigh;
 bfd_vma cbLineOffset;

 unsigned gp_prologue : 8;
 unsigned gp_used : 1;
 unsigned reg_frame : 1;
 unsigned prof : 1;
 unsigned reserved : 13;
 unsigned localoff : 8;
 } PDR, *pPDR;
typedef long LINER, *pLINER;
typedef struct {
 long iss;
 bfd_vma value;
 unsigned st : 6;
 unsigned sc : 5;
 unsigned reserved : 1;
 unsigned index : 20;
 } SYMR, *pSYMR;
typedef struct n64_tag_ecoff_extr {
 unsigned jmptbl:1;
 unsigned cobol_main:1;
 unsigned weakext:1;
 unsigned reserved:13;
 int ifd;
 SYMR asym;
 } EXTR, *pEXTR;
typedef struct {
 unsigned fBitfield : 1;
 unsigned continued : 1;
 unsigned bt : 6;
 unsigned tq4 : 4;
 unsigned tq5 : 4;

 unsigned tq0 : 4;
 unsigned tq1 : 4;
 unsigned tq2 : 4;
 unsigned tq3 : 4;
 } TIR, *pTIR;
typedef struct {
 unsigned rfd : 12;
 unsigned index : 20;
 } RNDXR, *pRNDXR;






typedef struct {
 unsigned long rfd;
 unsigned long index;
 } DNR, *pDNR;
typedef union {
 TIR ti;
 RNDXR rndx;
 long dnLow;
 long dnHigh;
 long isym;
 long iss;
 long width;
 long count;
 } AUXU, *pAUXU;
typedef struct {
 unsigned ot: 8;
 unsigned value: 24;
 RNDXR rndx;
 unsigned long offset;
 } OPTR, *pOPTR;
typedef long RFDT, *pRFDT;
typedef long FIT, *pFIT;
struct n64_tag_tir_ext {
 unsigned char t_bits1[1];
 unsigned char t_tq45[1];
 unsigned char t_tq01[1];
 unsigned char t_tq23[1];
};
struct n64_tag_rndx_ext {
 unsigned char r_bits[4];
};
union n64_tag_aux_ext {
 struct n64_tag_tir_ext a_ti;
 struct n64_tag_rndx_ext a_rndx;
 unsigned char a_dnLow[4];
 unsigned char a_dnHigh[4];
 unsigned char a_isym[4];
 unsigned char a_iss[4];
 unsigned char a_width[4];
 unsigned char a_count[4];
};
struct n64_tag_ecoff_debug_info
{

  HDRR symbolic_header;
  unsigned char *line;
  void * external_dnr;
  void * external_pdr;
  void * external_sym;
  void * external_opt;
  union n64_tag_aux_ext *external_aux;
  char *ss;
  char *ssext;
  void * external_fdr;
  void * external_rfd;
  void * external_ext;



  char *ssext_end;
  void * external_ext_end;




  RFDT *ifdmap;





  FDR *fdr;







  struct n64_tag_ecoff_value_adjust *adjust;
};






struct n64_tag_ecoff_value_adjust
{

  struct n64_tag_ecoff_value_adjust *next;



  bfd_vma start;

  bfd_vma end;


  long adjust;
};



struct n64_tag_ecoff_fdrtab_entry
{

  bfd_vma base_addr;
  FDR *fdr;
};

struct n64_tag_ecoff_find_line
{

  char *find_buffer;


  long fdrtab_len;
  struct n64_tag_ecoff_fdrtab_entry *fdrtab;
};
struct n64_tag_ecoff_debug_swap
{

  int sym_magic;

  bfd_size_type debug_align;

  bfd_size_type external_hdr_size;
  bfd_size_type external_dnr_size;
  bfd_size_type external_pdr_size;
  bfd_size_type external_sym_size;
  bfd_size_type external_opt_size;
  bfd_size_type external_fdr_size;
  bfd_size_type external_rfd_size;
  bfd_size_type external_ext_size;

  void (*swap_hdr_in) (bfd *, void *, HDRR *);
  void (*swap_dnr_in) (bfd *, void *, DNR *);
  void (*swap_pdr_in) (bfd *, void *, PDR *);
  void (*swap_sym_in) (bfd *, void *, SYMR *);
  void (*swap_opt_in) (bfd *, void *, OPTR *);
  void (*swap_fdr_in) (bfd *, void *, FDR *);
  void (*swap_rfd_in) (bfd *, void *, RFDT *);
  void (*swap_ext_in) (bfd *, void *, EXTR *);
  void (*swap_tir_in) (int, const struct n64_tag_tir_ext *, TIR *);
  void (*swap_rndx_in) (int, const struct n64_tag_rndx_ext *, RNDXR *);

  void (*swap_hdr_out) (bfd *, const HDRR *, void *);
  void (*swap_dnr_out) (bfd *, const DNR *, void *);
  void (*swap_pdr_out) (bfd *, const PDR *, void *);
  void (*swap_sym_out) (bfd *, const SYMR *, void *);
  void (*swap_opt_out) (bfd *, const OPTR *, void *);
  void (*swap_fdr_out) (bfd *, const FDR *, void *);
  void (*swap_rfd_out) (bfd *, const RFDT *, void *);
  void (*swap_ext_out) (bfd *, const EXTR *, void *);
  void (*swap_tir_out) (int, const TIR *, struct n64_tag_tir_ext *);
  void (*swap_rndx_out) (int, const RNDXR *, struct n64_tag_rndx_ext *);



  boolean (*read_debug_info) (bfd *, asection *, struct n64_tag_ecoff_debug_info *)
                                     ;
};


extern int ecoff_debugging_seen;



extern void ecoff_read_begin_hook (void) asm("_ecoff_read_begin_hook");



extern void ecoff_symbol_new_hook (struct n64_tag_symbol *) asm("_ecoff_symbol_new_hook");


extern void ecoff_frob_symbol (struct n64_tag_symbol *) asm("_ecoff_frob_symbol");






extern unsigned long ecoff_build_debug
  (HDRR *hdr, char **bufp, const struct n64_tag_ecoff_debug_swap *) asm("_ecoff_build_debug");


extern void ecoff_directive_begin (int) asm("_ecoff_directive_begin");
extern void ecoff_directive_bend (int) asm("_ecoff_directive_bend");
extern void ecoff_directive_end (int) asm("_ecoff_directive_end");
extern void ecoff_directive_ent (int) asm("_ecoff_directive_ent");
extern void ecoff_directive_fmask (int) asm("_ecoff_directive_fmask");
extern void ecoff_directive_frame (int) asm("_ecoff_directive_frame");
extern void ecoff_directive_loc (int) asm("_ecoff_directive_loc");
extern void ecoff_directive_mask (int) asm("_ecoff_directive_mask");


extern void ecoff_directive_extern (int) asm("_ecoff_directive_extern");
extern void ecoff_directive_weakext (int) asm("_ecoff_directive_weakext");


extern void ecoff_directive_def (int) asm("_ecoff_directive_def");
extern void ecoff_directive_dim (int) asm("_ecoff_directive_dim");
extern void ecoff_directive_endef (int) asm("_ecoff_directive_endef");
extern void ecoff_directive_file (int) asm("_ecoff_directive_file");
extern void ecoff_directive_scl (int) asm("_ecoff_directive_scl");
extern void ecoff_directive_size (int) asm("_ecoff_directive_size");
extern void ecoff_directive_tag (int) asm("_ecoff_directive_tag");
extern void ecoff_directive_type (int) asm("_ecoff_directive_type");
extern void ecoff_directive_val (int) asm("_ecoff_directive_val");


extern void ecoff_stab (segT sec, int what, const char *string, int type, int other, int desc) asm("_ecoff_stab")
                                   ;


extern void ecoff_set_gp_prolog_size (int sz) asm("_ecoff_set_gp_prolog_size");
extern int ecoff_no_current_file (void) asm("_ecoff_no_current_file");



extern void ecoff_generate_asm_lineno (const char *, int) asm("_ecoff_generate_asm_lineno");



extern void ecoff_generate_asm_line_stab (char *, int) asm("_ecoff_generate_asm_line_stab");

static char *mips_regmask_frag;
enum n64_cpp_enum_mips_abi_level{
  NO_ABI = 0,
  O32_ABI,
  O64_ABI,
  N32_ABI,
  N64_ABI,
  EABI_ABI
};
typedef __underlying_type(enum n64_cpp_enum_mips_abi_level) n64_enum_mips_abi_level;



static n64_enum_mips_abi_level mips_abi = NO_ABI;

struct n64_tag_regname {
  const char *name;
  unsigned int num;
};
static const struct n64_tag_regname reg_names[] = {
  {"$0", 0x0000100 | 0}, {"$1", 0x0000100 | 1}, {"$2", 0x0000100 | 2}, {"$3", 0x0000100 | 3}, {"$4", 0x0000100 | 4}, {"$5", 0x0000100 | 5}, {"$6", 0x0000100 | 6}, {"$7", 0x0000100 | 7}, {"$8", 0x0000100 | 8}, {"$9", 0x0000100 | 9}, {"$10", 0x0000100 | 10}, {"$11", 0x0000100 | 11}, {"$12", 0x0000100 | 12}, {"$13", 0x0000100 | 13}, {"$14", 0x0000100 | 14}, {"$15", 0x0000100 | 15}, {"$16", 0x0000100 | 16}, {"$17", 0x0000100 | 17}, {"$18", 0x0000100 | 18}, {"$19", 0x0000100 | 19}, {"$20", 0x0000100 | 20}, {"$21", 0x0000100 | 21}, {"$22", 0x0000100 | 22}, {"$23", 0x0000100 | 23}, {"$24", 0x0000100 | 24}, {"$25", 0x0000100 | 25}, {"$26", 0x0000100 | 26}, {"$27", 0x0000100 | 27}, {"$28", 0x0000100 | 28}, {"$29", 0x0000100 | 29}, {"$30", 0x0000100 | 30}, {"$31", 0x0000100 | 31},
  {"$f0", 0x0000200 | 0}, {"$f1", 0x0000200 | 1}, {"$f2", 0x0000200 | 2}, {"$f3", 0x0000200 | 3}, {"$f4", 0x0000200 | 4}, {"$f5", 0x0000200 | 5}, {"$f6", 0x0000200 | 6}, {"$f7", 0x0000200 | 7}, {"$f8", 0x0000200 | 8}, {"$f9", 0x0000200 | 9}, {"$f10", 0x0000200 | 10}, {"$f11", 0x0000200 | 11}, {"$f12", 0x0000200 | 12}, {"$f13", 0x0000200 | 13}, {"$f14", 0x0000200 | 14}, {"$f15", 0x0000200 | 15}, {"$f16", 0x0000200 | 16}, {"$f17", 0x0000200 | 17}, {"$f18", 0x0000200 | 18}, {"$f19", 0x0000200 | 19}, {"$f20", 0x0000200 | 20}, {"$f21", 0x0000200 | 21}, {"$f22", 0x0000200 | 22}, {"$f23", 0x0000200 | 23}, {"$f24", 0x0000200 | 24}, {"$f25", 0x0000200 | 25}, {"$f26", 0x0000200 | 26}, {"$f27", 0x0000200 | 27}, {"$f28", 0x0000200 | 28}, {"$f29", 0x0000200 | 29}, {"$f30", 0x0000200 | 30}, {"$f31", 0x0000200 | 31},
  {"$fcc0", 0x0000400 | 0}, {"$fcc1", 0x0000400 | 1}, {"$fcc2", 0x0000400 | 2}, {"$fcc3", 0x0000400 | 3}, {"$fcc4", 0x0000400 | 4}, {"$fcc5", 0x0000400 | 5}, {"$fcc6", 0x0000400 | 6}, {"$fcc7", 0x0000400 | 7},
  {"$cc0", 0x0000400 | 0x0010000 | 0}, {"$cc1", 0x0000400 | 0x0010000 | 1}, {"$cc2", 0x0000400 | 0x0010000 | 2}, {"$cc3", 0x0000400 | 0x0010000 | 3}, {"$cc4", 0x0000400 | 0x0010000 | 4}, {"$cc5", 0x0000400 | 0x0010000 | 5}, {"$cc6", 0x0000400 | 0x0010000 | 6}, {"$cc7", 0x0000400 | 0x0010000 | 7},





  {"$zero", 0x0001000 | 0}, {"$at", 0x0001000 | 1}, {"$AT", 0x0001000 | 1}, {"$v0", 0x0001000 | 2}, {"$v1", 0x0001000 | 3}, {"$a0", 0x0001000 | 4}, {"$a1", 0x0001000 | 5}, {"$a2", 0x0001000 | 6}, {"$a3", 0x0001000 | 7}, {"$s0", 0x0001000 | 16}, {"$s1", 0x0001000 | 17}, {"$s2", 0x0001000 | 18}, {"$s3", 0x0001000 | 19}, {"$s4", 0x0001000 | 20}, {"$s5", 0x0001000 | 21}, {"$s6", 0x0001000 | 22}, {"$s7", 0x0001000 | 23}, {"$t8", 0x0001000 | 24}, {"$t9", 0x0001000 | 25}, {"$k0", 0x0001000 | 26}, {"$kt0", 0x0001000 | 26}, {"$k1", 0x0001000 | 27}, {"$kt1", 0x0001000 | 27}, {"$gp", 0x0001000 | 28}, {"$sp", 0x0001000 | 29}, {"$s8", 0x0001000 | 30}, {"$fp", 0x0001000 | 30}, {"$ra", 0x0001000 | 31},

  {"$pc", 0x0004000 | 0},
  {"$v2", 0x0000800 | 2}, {"$v3", 0x0000800 | 3}, {"$v4", 0x0000800 | 4}, {"$v5", 0x0000800 | 5}, {"$v6", 0x0000800 | 6}, {"$v7", 0x0000800 | 7}, {"$v8", 0x0000800 | 8}, {"$v9", 0x0000800 | 9}, {"$v10", 0x0000800 | 10}, {"$v11", 0x0000800 | 11}, {"$v12", 0x0000800 | 12}, {"$v13", 0x0000800 | 13}, {"$v14", 0x0000800 | 14}, {"$v15", 0x0000800 | 15}, {"$v16", 0x0000800 | 16}, {"$v17", 0x0000800 | 17}, {"$v18", 0x0000800 | 18}, {"$v19", 0x0000800 | 19}, {"$v20", 0x0000800 | 20}, {"$v21", 0x0000800 | 21}, {"$v22", 0x0000800 | 22}, {"$v23", 0x0000800 | 23}, {"$v24", 0x0000800 | 24}, {"$v25", 0x0000800 | 25}, {"$v26", 0x0000800 | 26}, {"$v27", 0x0000800 | 27}, {"$v28", 0x0000800 | 28}, {"$v29", 0x0000800 | 29}, {"$v30", 0x0000800 | 30}, {"$v31", 0x0000800 | 31},
  {"$I", 0x0080000 | 0},
  {"$Q", 0x0100000 | 0},
  {"$R", 0x0200000 | 0},
  {"$ACC", 0x0400000 | 0 },
  {"$ac0", 0x0008000 | 0}, {"$ac1", 0x0008000 | 1}, {"$ac2", 0x0008000 | 2}, {"$ac3", 0x0008000 | 3},
  {0, 0}
};

static const struct n64_tag_regname reg_names_o32[] = {
  {"$t0", 0x0001000 | 8}, {"$t1", 0x0001000 | 9}, {"$t2", 0x0001000 | 10}, {"$t3", 0x0001000 | 11}, {"$t4", 0x0001000 | 12}, {"$t5", 0x0001000 | 13}, {"$t6", 0x0001000 | 14}, {"$t7", 0x0001000 | 15}, {"$ta0", 0x0001000 | 12}, {"$ta1", 0x0001000 | 13}, {"$ta2", 0x0001000 | 14}, {"$ta3", 0x0001000 | 15},
  {"$fv0", 0x0000200 | 0}, {"$fv0f", 0x0000200 | 1}, {"$fv1", 0x0000200 | 2}, {"$fv1f", 0x0000200 | 3}, {"$ft0", 0x0000200 | 4}, {"$ft0f", 0x0000200 | 5}, {"$ft1", 0x0000200 | 6}, {"$ft1f", 0x0000200 | 7}, {"$ft2", 0x0000200 | 8}, {"$ft2f", 0x0000200 | 9}, {"$ft3", 0x0000200 | 10}, {"$ft3f", 0x0000200 | 11}, {"$fa0", 0x0000200 | 12}, {"$fa0f", 0x0000200 | 13}, {"$fa1", 0x0000200 | 14}, {"$fa1f", 0x0000200 | 15}, {"$ft4", 0x0000200 | 16}, {"$ft4f", 0x0000200 | 17}, {"$ft5", 0x0000200 | 18}, {"$ft5f", 0x0000200 | 19}, {"$fs0", 0x0000200 | 20}, {"$fs0f", 0x0000200 | 21}, {"$fs1", 0x0000200 | 22}, {"$fs1f", 0x0000200 | 23}, {"$fs2", 0x0000200 | 24}, {"$fs2f", 0x0000200 | 25}, {"$fs3", 0x0000200 | 26}, {"$fs3f", 0x0000200 | 27}, {"$fs4", 0x0000200 | 28}, {"$fs4f", 0x0000200 | 29}, {"$fs5", 0x0000200 | 30}, {"$fs5f", 0x0000200 | 31},
  {0, 0}
};

static const struct n64_tag_regname reg_names_n32n64[] = {
  {"$a4", 0x0001000 | 8}, {"$a5", 0x0001000 | 9}, {"$a6", 0x0001000 | 10}, {"$a7", 0x0001000 | 11}, {"$ta0", 0x0001000 | 8}, {"$ta1", 0x0001000 | 9}, {"$ta2", 0x0001000 | 10}, {"$ta3", 0x0001000 | 11}, {"$t0", 0x0001000 | 12}, {"$t1", 0x0001000 | 13}, {"$t2", 0x0001000 | 14}, {"$t3", 0x0001000 | 15},
  {0, 0}
};

extern int target_big_endian;


const char *
mips_target_format(void) asm("_mips_target_format");
const char *
mips_target_format(void)
{
  switch (bfd_target_elf_flavour)
    {
    case bfd_target_aout_flavour:
      return target_big_endian ? "a.out-mips-big" : "a.out-mips-little";
    case bfd_target_ecoff_flavour:
      return target_big_endian ? "ecoff-bigmips" : "ecoff-littlemips";
    case bfd_target_elf_flavour:
      return target_big_endian ? "elf32-bigmips" : "elf32-littlemips";
    default:
      as_abort ("targ-cpu.c", 476, ((char*)0));
    }
}
unsigned long mips_gprmask;
unsigned long mips_cprmask[4];



static int mips_isa = -1;


static int file_mips_isa;


static int mips_cpu = -1;


static int mips_4650 = -1;


static int mips_4010 = -1;


static int mips_4100 = -1;



static int interlocks = -1;



enum n64_cpp_enum_mips_pic_level{

  NO_PIC,



  IRIX4_PIC,


  SVR4_PIC,





  EMBEDDED_PIC
};
typedef __underlying_type(enum n64_cpp_enum_mips_pic_level) n64_enum_mips_pic_level;


static n64_enum_mips_pic_level mips_pic;



static int mips_trap;

static int mips_warn_about_macros;
static int mips_noreorder;
static int mips_any_noreorder;
static int mips_nomove;
static int mips_noat;
static int mips_nobopt;


static int g_switch_value = 8;

static int g_switch_seen = 0;
static int nopic_need_relax (symbolS *) asm("_nopic_need_relax");


static struct n64_tag_hash_control *op_hash = 
                                     ((void *)0)
                                         ;



extern const char comment_chars[] = "#";
extern const char line_comment_chars[] = "#";


extern const char line_separator_chars[] = "";


extern const char EXP_CHARS[] = "eE";




extern const char FLT_CHARS[] = "rRsSfFdDxXpP";






static char *insn_error;

static int byte_order;

static int auto_align = 1;


static symbolS *insn_label;





static offsetT mips_cprestore_offset = -1;



static int mips_frame_reg = 29;
static int mips_optimize = 2;



static int mips_debug = 0;


static struct n64_tag_mips_cl_insn prev_insn;


static struct n64_tag_mips_cl_insn prev_prev_insn;



static const struct n64_tag_mips_opcode dummy_opcode = { 0 };


static int prev_insn_valid;


static struct n64_tag_frag *prev_insn_frag;


static long prev_insn_where;


static fixS *prev_insn_fixp;


static int prev_insn_is_delay_slot;


static int prev_insn_unreordered;



static int prev_prev_insn_unreordered;
static int insn_uses_reg (struct n64_tag_mips_cl_insn *ip, unsigned int reg, int fpr) asm("_insn_uses_reg")
                                 ;
static void append_insn (char *place, struct n64_tag_mips_cl_insn * ip, expressionS * p, bfd_reloc_code_real_type r) asm("_append_insn")


                                 ;
static void mips_no_prev_insn (void) asm("_mips_no_prev_insn");
static void mips_emit_delays (void) asm("_mips_emit_delays");

static void macro_build (char *place, int *counter, expressionS * ep, const char *name, const char *fmt, ...) asm("_macro_build")

          ;



static void macro_build_lui (char *place, int *counter, expressionS * ep, int regnum) asm("_macro_build_lui")
                                       ;
static void set_at (int *counter, int reg, int unsignedp) asm("_set_at");
static void check_absolute_expr (struct n64_tag_mips_cl_insn * ip, expressionS *) asm("_check_absolute_expr")
                     ;
static void load_register (int *, int, expressionS *, int) asm("_load_register");
static void load_address (int *counter, int reg, expressionS *ep) asm("_load_address");
static void macro (struct n64_tag_mips_cl_insn * ip) asm("_macro");



static void mips_ip (char *str, struct n64_tag_mips_cl_insn * ip) asm("_mips_ip");
static int my_getSmallExpression (expressionS * ep, char *str) asm("_my_getSmallExpression");
static void my_getExpression (expressionS * ep, char *str) asm("_my_getExpression");
static symbolS *get_symbol (void) asm("_get_symbol");
static void mips_align (int to, int fill, symbolS *label) asm("_mips_align");
static void s_align (int) asm("_s_align");
static void s_change_sec (int) asm("_s_change_sec");
static void s_cons (int) asm("_s_cons");
static void s_mipserr (int) asm("_s_mipserr");
static void s_extern (int) asm("_s_extern");
static void s_float_cons (int) asm("_s_float_cons");
static void s_mips_globl (int) asm("_s_mips_globl");
static void s_option (int) asm("_s_option");
static void s_mipsset (int) asm("_s_mipsset");
static void s_abicalls (int) asm("_s_abicalls");
static void s_cpload (int) asm("_s_cpload");
static void s_cprestore (int) asm("_s_cprestore");
static void s_gpword (int) asm("_s_gpword");
static void s_cpadd (int) asm("_s_cpadd");
static void md_obj_begin (void) asm("_md_obj_begin");
static void md_obj_end (void) asm("_md_obj_end");
static long get_number (void) asm("_get_number");
static void s_ent (int) asm("_s_ent");
static void s_mipsend (int) asm("_s_mipsend");
static void s_file (int) asm("_s_file");
static const pseudo_typeS mips_pseudo_table[] =
{

  {"option", s_option, 0},
  {"set", s_mipsset, 0},
  {"rdata", s_change_sec, 'r'},
  {"sdata", s_change_sec, 's'},
  {"livereg", s_ignore, 0},
  {"abicalls", s_abicalls, 0},
  {"cpload", s_cpload, 0},
  {"cprestore", s_cprestore, 0},
  {"gpword", s_gpword, 0},
  {"cpadd", s_cpadd, 0},



  {"asciiz", stringer, 1},
  {"bss", s_change_sec, 'b'},
  {"err", s_mipserr, 0},
  {"half", s_cons, 1},
  {"dword", s_cons, 3},



  {"align", s_align, 0},
  {"byte", s_cons, 0},
  {"data", s_change_sec, 'd'},
  {"double", s_float_cons, 'd'},
  {"float", s_float_cons, 'f'},
  {"globl", s_mips_globl, 0},
  {"global", s_mips_globl, 0},
  {"hword", s_cons, 1},
  {"int", s_cons, 2},
  {"long", s_cons, 2},
  {"octa", s_cons, 4},
  {"quad", s_cons, 3},
  {"short", s_cons, 1},
  {"single", s_float_cons, 'f'},
  {"text", s_change_sec, 't'},
  {"word", s_cons, 2},
  { 0 },
};

static const pseudo_typeS mips_nonecoff_pseudo_table[] = {


  {"aent", s_ent, 1},
  {"bgnb", s_ignore, 0},
  {"end", s_mipsend, 0},
  {"endb", s_ignore, 0},
  {"ent", s_ent, 0},
  {"file", s_file, 0},
  {"fmask", s_ignore, 'F'},
  {"frame", s_ignore, 0},
  {"loc", s_ignore, 0},
  {"mask", s_ignore, 'R'},
  {"verstamp", s_ignore, 0},
  { 0 },
};

extern void pop_insert (const pseudo_typeS *) asm("_pop_insert");

void
mips_pop_insert(void) asm("_mips_pop_insert");
void
mips_pop_insert(void)
{
  pop_insert (mips_pseudo_table);
  if (! 0)
    pop_insert (mips_nonecoff_pseudo_table);
}

static char *expr_end;

static expressionS imm_expr;
static expressionS offset_expr;
static bfd_reloc_code_real_type imm_reloc;
static bfd_reloc_code_real_type offset_reloc;





void
md_begin(void) asm("_md_begin");
void
md_begin(void)
{
  boolean ok = cxx_false;
  register const char *retval = 
                               ((void *)0)
                                   ;
  register unsigned int i = 0;

  if (mips_isa == -1)
    {
      const char *cpu;
      char *a = 
               ((void *)0)
                   ;

      cpu = "mips";
      if (strcmp (cpu + (sizeof "mips") - 3, "el") == 0)
 {
   a = xmalloc (sizeof "mips");
   strcpy (a, "mips");
   a[(sizeof "mips") - 3] = '\0';
   cpu = a;
 }

      if (strcmp (cpu, "mips") == 0)
 {
   mips_isa = 1;
   if (mips_cpu == -1)
     mips_cpu = 3000;
 }
      else if (strcmp (cpu, "r6000") == 0
        || strcmp (cpu, "mips2") == 0)
 {
   mips_isa = 2;
   if (mips_cpu == -1)
     mips_cpu = 6000;
 }
      else if (strcmp (cpu, "mips64") == 0
        || strcmp (cpu, "r4000") == 0
        || strcmp (cpu, "mips3") == 0)
 {
   mips_isa = 3;
   if (mips_cpu == -1)
     mips_cpu = 4000;
 }
      else if (strcmp (cpu, "r4400") == 0)
 {
   mips_isa = 3;
   if (mips_cpu == -1)
     mips_cpu = 4400;
 }
      else if (strcmp (cpu, "mips64orion") == 0
        || strcmp (cpu, "r4600") == 0)
 {
   mips_isa = 3;
   if (mips_cpu == -1)
     mips_cpu = 4600;
 }
      else if (strcmp (cpu, "r4650") == 0)
 {
   mips_isa = 3;
   if (mips_cpu == -1)
     mips_cpu = 4650;
   if (mips_4650 == -1)
     mips_4650 = 1;
 }
      else if (strcmp (cpu, "mips64vr4300") == 0)
 {
   mips_isa = 3;
   if (mips_cpu == -1)
     mips_cpu = 4300;
 }
      else if (strcmp (cpu, "mips64vr4100") == 0)
        {
          mips_isa = 3;
          if (mips_cpu == -1)
            mips_cpu = 4100;
          if (mips_4100 == -1)
            mips_4100 = 1;
        }
      else if (strcmp (cpu, "r4010") == 0)
 {
   mips_isa = 2;
   if (mips_cpu == -1)
     mips_cpu = 4010;
   if (mips_4010 == -1)
     mips_4010 = 1;
 }
      else if (strcmp (cpu, "r8000") == 0
        || strcmp (cpu, "mips4") == 0)
 {
   mips_isa = 4;
   if (mips_cpu == -1)
     mips_cpu = 8000;
 }
      else if (strcmp (cpu, "r10000") == 0)
 {
   mips_isa = 4;
   if (mips_cpu == -1)
     mips_cpu = 10000;
 }
      else
 {
   mips_isa = 1;
   if (mips_cpu == -1)
     mips_cpu = 3000;
 }

      if (a != 
              ((void *)0)
                  )
 free (a);
    }

  if (mips_4650 < 0)
    mips_4650 = 0;

  if (mips_4010 < 0)
    mips_4010 = 0;

  if (mips_4100 < 0)
    mips_4100 = 0;

  if (mips_4650 || mips_4010 || mips_4100)
    interlocks = 1;
  else
    interlocks = 0;

  if (mips_isa < 2 && mips_trap)
    as_bad ("trap exception not supported at ISA 1");

  switch (mips_isa)
    {
    case 1:
      ok = ((*((stdoutput)->xvec->_bfd_set_arch_mach)) (stdoutput, bfd_arch_mips, 3000));
      break;
    case 2:
      ok = ((*((stdoutput)->xvec->_bfd_set_arch_mach)) (stdoutput, bfd_arch_mips, 6000));
      break;
    case 3:
      ok = ((*((stdoutput)->xvec->_bfd_set_arch_mach)) (stdoutput, bfd_arch_mips, 4000));
      break;
    case 4:
      ok = ((*((stdoutput)->xvec->_bfd_set_arch_mach)) (stdoutput, bfd_arch_mips, 8000));
      break;
    }
  if (! ok)
    as_warn ("Could not set architecture and machine");

  file_mips_isa = mips_isa;

  op_hash = hash_new ();

  for (i = 0; i < bfd_mips_num_opcodes;)
    {
      const char *name = mips_opcodes[i].name;

      retval = hash_insert (op_hash, name, (void *) &mips_opcodes[i]);
      if (retval != 
                   ((void *)0)
                       )
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "internal error: can't hash `%s': %s\n",
     mips_opcodes[i].name, retval);
   as_fatal ("Broken assembler.  No assembly attempted.");
 }
      do
 {
   if (mips_opcodes[i].pinfo != 0xffffffff
       && ((mips_opcodes[i].match & mips_opcodes[i].mask)
    != mips_opcodes[i].match))
     {
       fprintf (
               (__acrt_iob_func(2))
                     , "internal error: bad opcode: `%s' \"%s\"\n",
         mips_opcodes[i].name, mips_opcodes[i].args);
       as_fatal ("Broken assembler.  No assembly attempted.");
     }
   ++i;
 }
      while ((i < bfd_mips_num_opcodes) && !strcmp (mips_opcodes[i].name, name));
    }

  for (i = 0; reg_names[i].name; i++)
    symbol_table_insert (symbol_new (reg_names[i].name, reg_section,
      reg_names[i].num,
      &zero_address_frag));
  for (i = 0; reg_names_o32[i].name; i++)
    symbol_table_insert (symbol_new (reg_names_o32[i].name, reg_section,
      reg_names_o32[i].num,
      &zero_address_frag));

  for (i = 0; i < 32; i++)
    {
      char regname[6];


      sprintf (regname, "$vf%d", i);
      symbol_table_insert (symbol_new (regname, reg_section,
 0x0040000 | i, &zero_address_frag));


      sprintf (regname, "$vi%d", i);
      symbol_table_insert (symbol_new (regname, reg_section,
   0x0020000 | i, &zero_address_frag));


      sprintf (regname, "$w%d", i);
      symbol_table_insert (symbol_new (regname, reg_section,
        0x0800000 | i, &zero_address_frag));
    }

  mips_no_prev_insn ();

  mips_gprmask = 0;
  mips_cprmask[0] = 0;
  mips_cprmask[1] = 0;
  mips_cprmask[2] = 0;
  mips_cprmask[3] = 0;


  record_alignment (text_section, 2);

  if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
    bfd_set_gp_size (stdoutput, g_switch_value);

  if (bfd_target_elf_flavour == bfd_target_elf_flavour)
    {

      (void) (((text_section)->alignment_power = (4)),cxx_true);
      (void) (((data_section)->alignment_power = (4)),cxx_true);
      (void) (((bss_section)->alignment_power = (4)),cxx_true);



      {
 segT seg;
 subsegT subseg;
 segT sec;

 seg = now_seg;
 subseg = now_subseg;
 sec = subseg_new (".reginfo", (subsegT) 0);



 (void) bfd_set_section_flags (stdoutput, sec,
          (0x001 | 0x002
           | 0x010 | 0x040));
 (void) (((sec)->alignment_power = (2)),cxx_true);


 mips_regmask_frag = frag_more (sizeof (Elf32_External_RegInfo));


 if (0)
   {
     sec = subseg_new (".mdebug", (subsegT) 0);
     (void) bfd_set_section_flags (stdoutput, sec,
       0x200 | 0x010);
     (void) (((sec)->alignment_power = (2)),cxx_true);
   }

 subseg_set (seg, subseg);
      }
    }

  if (! 0)
    md_obj_begin ();
}

void
md_mips_end(void) asm("_md_mips_end");
void
md_mips_end(void)
{
  if (! 0)
    md_obj_end ();
}

void
md_assemble(char *str) asm("_md_assemble");
void
md_assemble(char *str)
{
  struct n64_tag_mips_cl_insn insn;

  imm_expr.X_op = O_absent;
  offset_expr.X_op = O_absent;

  mips_ip (str, &insn);
  if (insn_error)
    {
      as_bad ("%s `%s'", insn_error, str);
      return;
    }
  if (insn.insn_mo->pinfo == 0xffffffff)
    {
      macro (&insn);
    }
  else
    {
      if (imm_expr.X_op != O_absent)
 append_insn ((char *) 
                      ((void *)0)
                          , &insn, &imm_expr, imm_reloc);
      else if (offset_expr.X_op != O_absent)
 append_insn ((char *) 
                      ((void *)0)
                          , &insn, &offset_expr, offset_reloc);
      else
 append_insn ((char *) 
                      ((void *)0)
                          , &insn, 
                                   ((void *)0)
                                       , BFD_RELOC_UNUSED);
    }
}




static int
insn_uses_reg(struct n64_tag_mips_cl_insn *ip, unsigned int reg, int fpr) asm("_insn_uses_reg");
static int
insn_uses_reg(struct n64_tag_mips_cl_insn *ip, unsigned int reg, int fpr)
{

  if (! fpr && reg == 0)
    return 0;

  if (fpr)
    {







      if ((ip->insn_mo->pinfo & 0x00000100)
   && (((ip->insn_opcode >> 11) & 0x1f)
       == (reg &~ (unsigned) 1)))
 return 1;
      if ((ip->insn_mo->pinfo & 0x00000200)
   && (((ip->insn_opcode >> 16) & 0x1f)
       == (reg &~ (unsigned) 1)))
 return 1;
    }
  else
    {
      if ((ip->insn_mo->pinfo & 0x00000040)
   && ((ip->insn_opcode >> 21) & 0x1f) == reg)
 return 1;
      if ((ip->insn_mo->pinfo & 0x00000080)
   && ((ip->insn_opcode >> 16) & 0x1f) == reg)
 return 1;
    }

  return 0;
}






static void
append_insn(char *place, struct n64_tag_mips_cl_insn *ip, expressionS *address_expr, bfd_reloc_code_real_type reloc_type) asm("_append_insn");
static void
append_insn(char *place, struct n64_tag_mips_cl_insn *ip, expressionS *address_expr, bfd_reloc_code_real_type reloc_type)
{
  register unsigned long prev_pinfo, pinfo;
  char *f;
  fixS *fixp;
  int nops = 0;

  prev_pinfo = prev_insn.insn_mo->pinfo;
  pinfo = ip->insn_mo->pinfo;

  if (place == 
              ((void *)0) 
                   && ! mips_noreorder)
    {
      if (mips_isa < 4
   && ((prev_pinfo & 0x00010000)
       || (mips_isa < 2
    && (prev_pinfo & 0x00008000))))
 {




   ;
   if (mips_optimize == 0
       || insn_uses_reg (ip,
    ((prev_insn.insn_opcode >> 16)
     & 0x1f),
    0))
     ++nops;
 }
      else if (mips_isa < 4
        && ((prev_pinfo & 0x00100000)
     || (mips_isa < 2
         && (prev_pinfo & 0x00200000))))
 {
   if (prev_pinfo & 0x00000020)
     {
       if (mips_optimize == 0
    || insn_uses_reg (ip,
        ((prev_insn.insn_opcode >> 16)
         & 0x1f),
        1))
  ++nops;
     }
   else if (prev_pinfo & 0x00000010)
     {
       if (mips_optimize == 0
    || insn_uses_reg (ip,
        ((prev_insn.insn_opcode >> 11)
         & 0x1f),
        1))
  ++nops;
     }
   else
     {






       if (mips_optimize == 0
    || ((prev_pinfo & 0x00000800)
        && (pinfo & 0x00001000)))
  nops += 2;
       else if (pinfo & 0x00004000)
  ++nops;
     }
 }
      else if (mips_isa < 4
        && (prev_pinfo & 0x00000800))
 {





   if (mips_optimize == 0
       || (pinfo & 0x00001000))
     ++nops;
 }
      else if (prev_pinfo & 0x00800000)
 {



   if (! interlocks
       && (mips_optimize == 0
    || (pinfo & 0x02000000)))
     nops += 2;
 }
      else if (prev_insn.insn_mo->pinfo & 0x00400000)
 {



   if (! interlocks
       && (mips_optimize == 0
    || (pinfo & 0x01000000)))
     nops += 2;
 }
      if (nops == 0
   && ((mips_isa < 4
        && (prev_prev_insn.insn_mo->pinfo & 0x00100000)
        && (prev_prev_insn.insn_mo->pinfo & 0x00000800)
        && (pinfo & 0x00001000))
       || ((prev_prev_insn.insn_mo->pinfo & 0x00800000)
    && (pinfo & 0x02000000)
    && ! interlocks)
       || ((prev_prev_insn.insn_mo->pinfo & 0x00400000)
    && (pinfo & 0x01000000)
    && ! interlocks)))
 ++nops;





      if (nops > 0 && ip->insn_opcode == 0)
 --nops;


      if (nops > 0)
 {
   int i;

   for (i = 0; i < nops; i++)
     md_number_to_chars (frag_more (4), 0, 4);
   if (listing)
     {
       listing_prev_line ();
       frag_grow (40);
     }
   if (insn_label != 
                    ((void *)0)
                        )
     {
       ((S_GET_SEGMENT (insn_label) == now_seg) ? 0 : (as_assert ("targ-cpu.c", 1449, ((char*)0)), 0));
       insn_label->sy_frag = frag_now;
       S_SET_VALUE (insn_label, (valueT) frag_now_fix ());
     }
 }
    }

  if (place == 
              ((void *)0)
                  )
    f = frag_more (4);
  else
    f = place;
  fixp = 
        ((void *)0)
            ;
  if (address_expr != 
                     ((void *)0)
                         )
    {
      if (address_expr->X_op == O_constant)
 {
   switch (reloc_type)
     {
     case BFD_RELOC_32:
       ip->insn_opcode |= address_expr->X_add_number;
       break;

     case BFD_RELOC_LO16:
       ip->insn_opcode |= address_expr->X_add_number & 0xffff;
       break;

     case BFD_RELOC_MIPS_JMP:
     case BFD_RELOC_16_PCREL_S2:
       goto need_reloc;

     default:
       as_fatal ("internal Error, line %d, %s", 1480, "targ-cpu.c");
     }
 }
      else
 {
   ((reloc_type != BFD_RELOC_UNUSED) ? 0 : (as_assert ("targ-cpu.c", 1485, ((char*)0)), 0));
 need_reloc:


   if (place == 
               ((void *)0)
                   )
     fixp = fix_new_exp (frag_now, f - frag_now->fr_literal, 4,
    address_expr,
    reloc_type == BFD_RELOC_16_PCREL_S2,
    reloc_type);
 }
    }

  md_number_to_chars (f, ip->insn_opcode, 4);


  if (pinfo & 0x00000001)
    mips_gprmask |= 1 << ((ip->insn_opcode >> 11) & 0x1f);
  if ((pinfo & (0x00000002 | 0x00000080)) != 0)
    mips_gprmask |= 1 << ((ip->insn_opcode >> 16) & 0x1f);
  if (pinfo & 0x00000040)
    mips_gprmask |= 1 << ((ip->insn_opcode >> 21) & 0x1f);
  if (pinfo & 0x00000004)
    mips_gprmask |= 1 << 31;
  if (pinfo & 0x00000008)
    mips_cprmask[1] |= 1 << ((ip->insn_opcode >> 6) & 0x1f);
  if ((pinfo & (0x00000010 | 0x00000100)) != 0)
    mips_cprmask[1] |= 1 << ((ip->insn_opcode >> 11) & 0x1f);
  if ((pinfo & (0x00000020 | 0x00000200)) != 0)
    mips_cprmask[1] |= 1 << ((ip->insn_opcode >> 16) & 0x1f);
  if ((pinfo & 0x00000400) != 0)
    mips_cprmask[1] |= 1 << ((ip->insn_opcode >> 21) & 0x1f);
  if (pinfo & 0x00004000)
    {

    }

  mips_gprmask &=~ 1 << 0;

  if (place == 
              ((void *)0) 
                   && ! mips_noreorder)
    {





      if ((pinfo & 0x00020000)
   || (pinfo & 0x00040000))
 {
   if (mips_optimize < 2


       || mips_nomove != 0


       || nops != 0


       || ! prev_insn_valid


       || prev_insn_is_delay_slot
       || prev_prev_insn_unreordered





       || insn_label != 
                       ((void *)0)


       
      || prev_insn_frag->fr_type == rs_machine_dependent
       || (mips_isa < 4
    && (pinfo & 0x00001000))



       || (mips_isa < 4
    && (prev_pinfo
        & (0x00010000
    | 0x00100000
    | 0x00000800)))
       || (! interlocks
    && (prev_pinfo
        & (0x00800000
    | 0x00400000)))
       || (mips_isa < 2
    && (prev_pinfo
        & (0x00008000
    | 0x00200000)))

       || (prev_pinfo
    & (0x00020000
       | 0x00040000
       | 0x00080000))



       || (prev_pinfo & 0x04000000)


       || ((prev_pinfo & 0x00000002)
    && insn_uses_reg (ip,
        ((prev_insn.insn_opcode >> 16)
         & 0x1f),
        0))
       || ((prev_pinfo & 0x00000001)
    && insn_uses_reg (ip,
        ((prev_insn.insn_opcode >> 11)
         & 0x1f),
        0))



       || ((prev_pinfo & 0x00000002)
    && (((pinfo & 0x00000001)
         && (((prev_insn.insn_opcode >> 16) & 0x1f)
      == ((ip->insn_opcode >> 11) & 0x1f)))
        || ((pinfo & 0x00000004)
     && (((prev_insn.insn_opcode >> 16)
          & 0x1f)
         == 31))))
       || ((prev_pinfo & 0x00000001)
    && (((pinfo & 0x00000001)
         && (((prev_insn.insn_opcode >> 11) & 0x1f)
      == ((ip->insn_opcode >> 11) & 0x1f)))
        || ((pinfo & 0x00000004)
     && (((prev_insn.insn_opcode >> 11)
          & 0x1f)
         == 31))))



       || ((pinfo & 0x00000001)
    && insn_uses_reg (&prev_insn,
        ((ip->insn_opcode >> 11)
         & 0x1f),
        0))
       || ((pinfo & 0x00000004)
    && insn_uses_reg (&prev_insn, 31, 0))



       || (mips_pic == EMBEDDED_PIC
    && insn_uses_reg (&prev_insn, 1, 0))



       || (mips_isa < 4
    && ((prev_prev_insn.insn_mo->pinfo & 0x00010000)
        || (mips_isa < 2
     && (prev_prev_insn.insn_mo->pinfo
         & 0x00008000)))
    && insn_uses_reg (ip,
        ((prev_prev_insn.insn_opcode >> 16)
         & 0x1f),
        0)))
     {




       md_number_to_chars (frag_more (4), 0, 4);

       prev_prev_insn = *ip;
       prev_insn.insn_mo = &dummy_opcode;
     }
   else
     {
       char *prev_f;
       char temp[4];


       prev_f = prev_insn_frag->fr_literal + prev_insn_where;
       memcpy (temp, prev_f, 4);
       memcpy (prev_f, f, 4);
       memcpy (f, temp, 4);
       if (prev_insn_fixp)
  {
    prev_insn_fixp->fx_frag = frag_now;
    prev_insn_fixp->fx_where = f - frag_now->fr_literal;
  }
       if (fixp)
  {
    fixp->fx_frag = prev_insn_frag;
    fixp->fx_where = prev_insn_where;
  }


       prev_prev_insn = *ip;
     }
   prev_insn_is_delay_slot = 1;



   if (pinfo & 0x00020000)
     {
       prev_prev_insn.insn_mo = &dummy_opcode;
       prev_insn.insn_mo = &dummy_opcode;
     }
 }
      else if (pinfo & 0x00080000)
 {




   md_number_to_chars (frag_more (4), 0, 4);

   prev_prev_insn = *ip;
   prev_insn.insn_mo = &dummy_opcode;
 }
      else
 {

   if (nops > 0)
     prev_prev_insn.insn_mo = &dummy_opcode;
   else
     prev_prev_insn = prev_insn;
   prev_insn = *ip;




   prev_insn_is_delay_slot = 0;
 }

      prev_prev_insn_unreordered = prev_insn_unreordered;
      prev_insn_unreordered = 0;
      prev_insn_frag = frag_now;
      prev_insn_where = f - frag_now->fr_literal;
      prev_insn_fixp = fixp;
      prev_insn_valid = 1;
    }


  insn_label = 
              ((void *)0)
                  ;
}




static void
mips_no_prev_insn(void) asm("_mips_no_prev_insn");
static void
mips_no_prev_insn(void)
{
  prev_insn.insn_mo = &dummy_opcode;
  prev_prev_insn.insn_mo = &dummy_opcode;
  prev_insn_valid = 0;
  prev_insn_is_delay_slot = 0;
  prev_insn_unreordered = 0;
  prev_prev_insn_unreordered = 0;
  insn_label = 
              ((void *)0)
                  ;
}






static void
mips_emit_delays(void) asm("_mips_emit_delays");
static void
mips_emit_delays(void)
{
  if (! mips_noreorder)
    {
      int nop;

      nop = 0;
      if ((mips_isa < 4
    && (prev_insn.insn_mo->pinfo
        & (0x00010000
    | 0x00100000
    | 0x00000800)))
   || (! interlocks
       && (prev_insn.insn_mo->pinfo
    & (0x00800000
       | 0x00400000)))
   || (mips_isa < 2
       && (prev_insn.insn_mo->pinfo
    & (0x00008000
       | 0x00200000))))
 {
   nop = 1;
   if ((mips_isa < 4
        && (prev_insn.insn_mo->pinfo & 0x00000800))
       || (! interlocks
    && ((prev_insn.insn_mo->pinfo & 0x00400000)
        || (prev_insn.insn_mo->pinfo & 0x00800000))))
     md_number_to_chars (frag_more (4), 0, 4);
 }
      else if ((mips_isa < 4
  && (prev_prev_insn.insn_mo->pinfo & 0x00000800))
        || (! interlocks
     && ((prev_prev_insn.insn_mo->pinfo & 0x00400000)
         || (prev_prev_insn.insn_mo->pinfo & 0x00800000))))
 nop = 1;
      if (nop)
 {
   md_number_to_chars (frag_more (4), 0, 4);
   if (insn_label != 
                    ((void *)0)
                        )
     {
       ((S_GET_SEGMENT (insn_label) == now_seg) ? 0 : (as_assert ("targ-cpu.c", 1808, ((char*)0)), 0));
       insn_label->sy_frag = frag_now;
       S_SET_VALUE (insn_label, (valueT) frag_now_fix ());
     }
 }
    }

  mips_no_prev_insn ();
}







static void
macro_build (char *place,
      int *counter,
      expressionS * ep,
      const char *name,
      const char *fmt,
      ...) asm("_macro_build");
static void
macro_build (char *place,
      int *counter,
      expressionS * ep,
      const char *name,
      const char *fmt,
      ...)
{
  struct n64_tag_mips_cl_insn insn;
  bfd_reloc_code_real_type r;
  va_list args;


  
 __builtin_va_start(
 args
 ,
 fmt
 )
                     ;
  if (mips_warn_about_macros && place == 
                                        ((void *)0) 
                                             && *counter == 1)
    as_warn ("Macro instruction expanded into multiple instructions");

  if (place == 
              ((void *)0)
                  )
    *counter += 1;

  r = BFD_RELOC_UNUSED;
  insn.insn_mo = (struct n64_tag_mips_opcode *) hash_find (op_hash, name);
  ((insn.insn_mo) ? 0 : (as_assert ("targ-cpu.c", 1865, ((char*)0)), 0));
  ((strcmp (name, insn.insn_mo->name) == 0) ? 0 : (as_assert ("targ-cpu.c", 1866, ((char*)0)), 0));
  while (strcmp (fmt, insn.insn_mo->args) != 0
  || insn.insn_mo->pinfo == 0xffffffff
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x10000000
      && mips_isa < 2)
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x20000000
      && mips_isa < 2)
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x40000000
      && mips_isa < 4)
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x30000000
      && mips_isa < 2)
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x50000000
      && mips_isa < 2)
  || ((insn.insn_mo->pinfo & 0x70000000) == 0x60000000
      && ! mips_4100))
    {
      ++insn.insn_mo;
      ((insn.insn_mo->name) ? 0 : (as_assert ("targ-cpu.c", 1896, ((char*)0)), 0));
      ((strcmp (name, insn.insn_mo->name) == 0) ? 0 : (as_assert ("targ-cpu.c", 1897, ((char*)0)), 0));
    }
  insn.insn_opcode = insn.insn_mo->match;
  for (;;)
    {
      switch (*fmt++)
 {
 case '\0':
   break;

 case ',':
 case '(':
 case ')':
   continue;

 case 't':
 case 'w':
 case 'E':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 16;
   continue;

 case 'c':
 case 'T':
 case 'W':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 16;
   continue;

 case 'd':
 case 'G':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 11;
   continue;

 case 'V':
 case 'S':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 11;
   continue;

 case 'z':
   continue;

 case '<':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 6;
   continue;

 case 'D':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 6;
   continue;

 case 'B':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 6;
   continue;

 case 'b':
 case 's':
 case 'r':
 case 'v':
   insn.insn_opcode |= 
                      __builtin_va_arg(
                      args
                      ,
                      int
                      ) 
                                         << 21;
   continue;

 case 'i':
 case 'j':
 case 'o':
   r = (bfd_reloc_code_real_type) 
                                 __builtin_va_arg(
                                 args
                                 ,
                                 int
                                 )
                                                   ;
   ((r == BFD_RELOC_GPREL16 || r == BFD_RELOC_MIPS_LITERAL || r == BFD_RELOC_LO16 || r == BFD_RELOC_MIPS_GOT16 || r == BFD_RELOC_MIPS_CALL16 || (ep->X_op == O_subtract && now_seg == text_section && r == BFD_RELOC_PCREL_LO16)) ? 0 : (as_assert ("targ-cpu.c", 1960, ((char*)0)), 0))






                                      ;
   continue;

 case 'u':
   r = (bfd_reloc_code_real_type) 
                                 __builtin_va_arg(
                                 args
                                 ,
                                 int
                                 )
                                                   ;
   ((ep != 
  ((void *)0) 
  && (ep->X_op == O_constant || (ep->X_op == O_symbol && (r == BFD_RELOC_HI16_S || r == BFD_RELOC_HI16)) || (ep->X_op == O_subtract && now_seg == text_section && r == BFD_RELOC_PCREL_HI16_S))) ? 0 : (as_assert ("targ-cpu.c", 1972, ((char*)0)), 0))






                                      ;
   if (ep->X_op == O_constant)
     {
       insn.insn_opcode |= (ep->X_add_number >> 16) & 0xffff;
       ep = 
           ((void *)0)
               ;
       r = BFD_RELOC_UNUSED;
     }
   continue;

 case 'p':
   ((ep != 
  ((void *)0)
  ) ? 0 : (as_assert ("targ-cpu.c", 1989, ((char*)0)), 0));







   if (ep->X_op == O_constant)
     {
       insn.insn_opcode |= (ep->X_add_number >> 2) & 0xffff;
       ep = 
           ((void *)0)
               ;
     }
   else
     r = BFD_RELOC_16_PCREL_S2;
   continue;

 case 'a':
   ((ep != 
  ((void *)0)
  ) ? 0 : (as_assert ("targ-cpu.c", 2007, ((char*)0)), 0));
   r = BFD_RELOC_MIPS_JMP;
   continue;

 default:
   as_fatal ("internal Error, line %d, %s", 2012, "targ-cpu.c");
 }
      break;
    }
  
 __builtin_va_end(
 args
 )
              ;
  ((r == BFD_RELOC_UNUSED ? ep == 
 ((void *)0) 
 : ep != 
 ((void *)0)
 ) ? 0 : (as_assert ("targ-cpu.c", 2017, ((char*)0)), 0));

  append_insn (place, &insn, ep, r);
}




static void
macro_build_lui(char *place, int *counter, expressionS *ep, int regnum) asm("_macro_build_lui");
static void
macro_build_lui(char *place, int *counter, expressionS *ep, int regnum)
{
  expressionS high_expr;
  struct n64_tag_mips_cl_insn insn;
  bfd_reloc_code_real_type r;
  const char *name = "lui";
  const char *fmt = "t,u";

  if (place == 
              ((void *)0)
                  )
    high_expr = *ep;
  else
    {
      high_expr.X_op = O_constant;
      high_expr.X_add_number = 0;
    }

  if (high_expr.X_op == O_constant)
    {

      if (high_expr.X_add_number & 0x8000)
 high_expr.X_add_number += 0x10000;
      high_expr.X_add_number =
 ((unsigned long) high_expr.X_add_number >> 16) & 0xffff;
      r = BFD_RELOC_UNUSED;
    }
  else
    {
      ((ep->X_op == O_symbol) ? 0 : (as_assert ("targ-cpu.c", 2057, ((char*)0)), 0));

      ((mips_pic == NO_PIC || strcmp (S_GET_NAME (ep->X_add_symbol), "_gp_disp") == 0) ? 0 : (as_assert ("targ-cpu.c", 2059, ((char*)0)), 0))
                                                                  ;
      r = BFD_RELOC_HI16_S;
    }






  if (mips_warn_about_macros && place == 
                                        ((void *)0) 
                                             && *counter == 1)
    as_warn ("Macro instruction expanded into multiple instructions");

  if (place == 
              ((void *)0)
                  )
    *counter += 1;

  insn.insn_mo = (struct n64_tag_mips_opcode *) hash_find (op_hash, name);
  ((insn.insn_mo) ? 0 : (as_assert ("targ-cpu.c", 2076, ((char*)0)), 0));
  ((strcmp (name, insn.insn_mo->name) == 0) ? 0 : (as_assert ("targ-cpu.c", 2077, ((char*)0)), 0));
  ((strcmp (fmt, insn.insn_mo->args) == 0) ? 0 : (as_assert ("targ-cpu.c", 2078, ((char*)0)), 0));

  insn.insn_opcode = insn.insn_mo->match | (regnum << 16);
  if (r == BFD_RELOC_UNUSED)
    {
      insn.insn_opcode |= high_expr.X_add_number;
      append_insn (place, &insn, 
                                ((void *)0)
                                    , r);
    }
  else
    append_insn (place, &insn, &high_expr, r);
}





static void
set_at(int *counter, int reg, int unsignedp) asm("_set_at");
static void
set_at(int *counter, int reg, int unsignedp)
{
  if (imm_expr.X_add_number >= -0x8000 && imm_expr.X_add_number < 0x8000)
    macro_build ((char *) 
                         ((void *)0)
                             , counter, &imm_expr,
   unsignedp ? "sltiu" : "slti",
   "t,r,j", 1, reg, (int) BFD_RELOC_LO16);
  else
    {
      load_register (counter, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , counter, 
                                          ((void *)0)
                                              ,
     unsignedp ? "sltu" : "slt",
     "d,v,t", 1, reg, 1);
    }
}



static void
check_absolute_expr(struct n64_tag_mips_cl_insn *ip, expressionS *ex) asm("_check_absolute_expr");
static void
check_absolute_expr(struct n64_tag_mips_cl_insn *ip, expressionS *ex)
{
  if (ex->X_op != O_constant)
    as_warn ("Instruction %s requires absolute expression", ip->insn_mo->name);
}





static void
load_register(int *counter, int reg, expressionS *ep, int dbl) asm("_load_register");
static void
load_register(int *counter, int reg, expressionS *ep, int dbl)
{
  int shift, freg;
  expressionS hi32, lo32, tmp;

  if (ep->X_op != O_big)
    {
      ((ep->X_op == O_constant) ? 0 : (as_assert ("targ-cpu.c", 2140, ((char*)0)), 0));
      if (ep->X_add_number < 0x8000
   && (ep->X_add_number >= 0
       || (ep->X_add_number >= -0x8000
    && (! dbl
        || ! ep->X_unsigned
        || sizeof (ep->X_add_number) > 4))))
 {



   macro_build ((char *) 
                        ((void *)0)
                            , counter, ep, "addiu", "t,r,j", reg, 0,
         (int) BFD_RELOC_LO16);
   return;
 }
      else if (ep->X_add_number >= 0 && ep->X_add_number < 0x10000)
 {


   macro_build ((char *) 
                        ((void *)0)
                            , counter, ep, "ori", "t,r,i", reg, 0,
         (int) BFD_RELOC_LO16);
   return;
 }
      else if (((ep->X_add_number & 0x80000000) == 0
  || ((ep->X_add_number & 0x80000000)
      == 0x80000000))
        && (! dbl
     || ! ep->X_unsigned
     || sizeof (ep->X_add_number) > 4
     || (ep->X_add_number & 0x80000000) == 0))
 {

   macro_build ((char *) 
                        ((void *)0)
                            , counter, ep, "lui", "t,u", reg,
         (int) BFD_RELOC_HI16);
   if ((ep->X_add_number & 0xffff) != 0)
     macro_build ((char *) 
                          ((void *)0)
                              , counter, ep, "ori", "t,r,i", reg, reg,
    (int) BFD_RELOC_LO16);
   return;
 }
      else
 {



   generic_bignum[3] = 0;
   generic_bignum[2] = 0;
   generic_bignum[1] = (ep->X_add_number >> 16) & 0xffff;
   generic_bignum[0] = ep->X_add_number & 0xffff;
   tmp.X_op = O_big;
   tmp.X_add_number = 4;
   ep = &tmp;
 }
    }







  if (mips_isa < 2)
    {
      as_bad ("Number larger than 32 bits");
      macro_build ((char *) 
                           ((void *)0)
                               , counter, ep, "addiu", "t,r,j", reg, 0,
     (int) BFD_RELOC_LO16);
      return;
    }

  if (ep->X_op != O_big)
    {
      hi32 = *ep;
      shift = 32;
      hi32.X_add_number >>= shift;
      hi32.X_add_number &= 0xffffffff;
      if ((hi32.X_add_number & 0x80000000) != 0)
 hi32.X_add_number |= ~ (offsetT) 0xffffffff;
      lo32 = *ep;
      lo32.X_add_number &= 0xffffffff;
    }
  else
    {
      ((ep->X_add_number > 2) ? 0 : (as_assert ("targ-cpu.c", 2221, ((char*)0)), 0));
      if (ep->X_add_number == 3)
 generic_bignum[3] = 0;
      else if (ep->X_add_number > 4)
 as_bad ("Number larger than 64 bits");
      lo32.X_op = O_constant;
      lo32.X_add_number = generic_bignum[0] + (generic_bignum[1] << 16);
      hi32.X_op = O_constant;
      hi32.X_add_number = generic_bignum[2] + (generic_bignum[3] << 16);
    }

  if (hi32.X_add_number == 0)
    freg = 0;
  else
    {
      load_register (counter, reg, &hi32, 0);
      freg = reg;
    }
  if ((lo32.X_add_number & 0xffff0000) == 0)
    {
      if (freg != 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , counter, 
                                       ((void *)0)
                                           , "dsll32", "d,w,<", reg,
         freg, 0);
   freg = reg;
 }
    }
  else
    {
      expressionS mid16;

      if (freg != 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , counter, 
                                       ((void *)0)
                                           , "dsll", "d,w,<", reg,
         freg, 16);
   freg = reg;
 }
      mid16 = lo32;
      mid16.X_add_number >>= 16;
      macro_build ((char *) 
                           ((void *)0)
                               , counter, &mid16, "ori", "t,r,i", reg,
     freg, (int) BFD_RELOC_LO16);
      macro_build ((char *) 
                           ((void *)0)
                               , counter, 
                                          ((void *)0)
                                              , "dsll", "d,w,<", reg,
     reg, 16);
      freg = reg;
    }
  if ((lo32.X_add_number & 0xffff) != 0)
    macro_build ((char *) 
                         ((void *)0)
                             , counter, &lo32, "ori", "t,r,i", reg, freg,
   (int) BFD_RELOC_LO16);
}



static void
load_address(int *counter, int reg, expressionS *ep) asm("_load_address");
static void
load_address(int *counter, int reg, expressionS *ep)
{
  char *p;

  if (ep->X_op != O_constant
      && ep->X_op != O_symbol)
    {
      as_bad ("expression too complex");
      ep->X_op = O_constant;
    }

  if (ep->X_op == O_constant)
    {
      load_register (counter, reg, ep, 0);
      return;
    }

  if (mips_pic == NO_PIC)
    {






      if (ep->X_add_number != 0 || nopic_need_relax (ep->X_add_symbol))
 p = 
    ((void *)0)
        ;
      else
 {
   frag_grow (20);
   macro_build ((char *) 
                        ((void *)0)
                            , counter, ep,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", reg, 28, (int) BFD_RELOC_GPREL16);
   p = frag_var (rs_machine_dependent, 8, 0,
   ((relax_substateT) (((4) << 24) | ((8) << 16) | (((0) + 64) << 9) | (((4) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((mips_warn_about_macros) ? 1 : 0))),
   ep->X_add_symbol, (long) 0, (char *) 
                                       ((void *)0)
                                           );
 }
      macro_build_lui (p, counter, ep, reg);
      if (p != 
              ((void *)0)
                  )
 p += 4;
      macro_build (p, counter, ep,
     mips_isa < 3 ? "addiu" : "daddiu",
     "t,r,j", reg, reg, (int) BFD_RELOC_LO16);
    }
  else if (mips_pic == SVR4_PIC)
    {
      expressionS ex;
      ex.X_add_number = ep->X_add_number;
      ep->X_add_number = 0;
      frag_grow (20);
      macro_build ((char *) 
                           ((void *)0)
                               , counter, ep,
     mips_isa < 3 ? "lw" : "ld",
     "t,o(b)", reg, (int) BFD_RELOC_MIPS_GOT16, 28);
      macro_build ((char *) 
                           ((void *)0)
                               , counter, (expressionS *) 
                                                          ((void *)0)
                                                              , "nop", "");
      p = frag_var (rs_machine_dependent, 4, 0,
      ((relax_substateT) (((0) << 24) | ((4) << 16) | (((-8) + 64) << 9) | (((0) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((mips_warn_about_macros) ? 1 : 0))),
      ep->X_add_symbol, (long) 0, (char *) 
                                          ((void *)0)
                                              );
      macro_build (p, counter, ep,
     mips_isa < 3 ? "addiu" : "daddiu",
     "t,r,j", reg, reg, (int) BFD_RELOC_LO16);
      if (ex.X_add_number != 0)
 {
   if (ex.X_add_number < -0x8000 || ex.X_add_number >= 0x8000)
     as_bad ("PIC code offset overflow (max 16 signed bits)");
   ex.X_op = O_constant;
   macro_build (p, counter, &ex,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", reg, reg, (int) BFD_RELOC_LO16);
 }
    }
  else if (mips_pic == EMBEDDED_PIC)
    {



      macro_build ((char *) 
                           ((void *)0)
                               , counter, ep,
     mips_isa < 3 ? "addiu" : "daddiu",
     "t,r,j", reg, 28, (int) BFD_RELOC_GPREL16);
    }
  else
    as_abort ("targ-cpu.c", 2365, ((char*)0));
}
static void
macro(struct n64_tag_mips_cl_insn *ip) asm("_macro");
static void
macro(struct n64_tag_mips_cl_insn *ip)
{
  register int treg, sreg, dreg, breg;
  int tempreg;
  int mask;
  int icnt = 0;
  int used_at;
  expressionS expr1;
  const char *s;
  const char *s2;
  const char *fmt;
  int likely = 0;
  int dbl = 0;
  int coproc = 0;
  int lr = 0;
  offsetT maxnum;
  int off;
  bfd_reloc_code_real_type r;
  char *p;
  int hold_mips_optimize;

  treg = (ip->insn_opcode >> 16) & 0x1f;
  dreg = (ip->insn_opcode >> 11) & 0x1f;
  sreg = breg = (ip->insn_opcode >> 21) & 0x1f;
  mask = ip->insn_mo->mask;

  expr1.X_op = O_constant;
  expr1.X_op_symbol = 
                     ((void *)0)
                         ;
  expr1.X_add_symbol = 
                      ((void *)0)
                          ;
  expr1.X_add_number = 1;

  switch (mask)
    {
    case M_DABS:
      dbl = 1;
    case M_ABS:





      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;

      expr1.X_add_number = 8;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "bgez", "s,p", sreg);
      if (dreg == sreg)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "nop", "", 0);
      else
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "move", "d,s", dreg, sreg, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dsub" : "sub",
     "d,v,t", dreg, 0, sreg);

      --mips_noreorder;
      return;

    case M_ADD_I:
      s = "addi";
      s2 = "add";
      goto do_addi;
    case M_ADDU_I:
      s = "addiu";
      s2 = "addu";
      goto do_addi;
    case M_DADD_I:
      dbl = 1;
      s = "daddi";
      s2 = "dadd";
      goto do_addi;
    case M_DADDU_I:
      dbl = 1;
      s = "daddiu";
      s2 = "daddu";
    do_addi:
      if (imm_expr.X_add_number >= -0x8000 && imm_expr.X_add_number < 0x8000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr, s, "t,r,j", treg, sreg,
         (int) BFD_RELOC_LO16);
   return;
 }
      load_register (&icnt, 1, &imm_expr, dbl);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s2, "d,v,t", treg, sreg, 1);
      break;

    case M_AND_I:
      s = "andi";
      s2 = "and";
      goto do_bit;
    case M_OR_I:
      s = "ori";
      s2 = "or";
      goto do_bit;
    case M_NOR_I:
      s = "";
      s2 = "nor";
      goto do_bit;
    case M_XOR_I:
      s = "xori";
      s2 = "xor";
    do_bit:
      if (imm_expr.X_add_number >= 0 && imm_expr.X_add_number < 0x10000)
 {
   if (mask != M_NOR_I)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, &imm_expr, s, "t,r,i", treg,
    sreg, (int) BFD_RELOC_LO16);
   else
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &imm_expr, "ori", "t,r,i",
      treg, sreg, (int) BFD_RELOC_LO16);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, 
                                         ((void *)0)
                                             , "nor", "d,v,t",
      treg, treg, 0);
     }
   return;
 }

      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s2, "d,v,t", treg, sreg, 1);
      break;

    case M_BEQ_I:
      s = "beq";
      goto beq_i;
    case M_BEQL_I:
      s = "beql";
      likely = 1;
      goto beq_i;
    case M_BNE_I:
      s = "bne";
      goto beq_i;
    case M_BNEL_I:
      s = "bnel";
      likely = 1;
    beq_i:
      if (imm_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, s, "s,t,p", sreg,
         0);
   return;
 }
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "s,t,p", sreg, 1);
      break;

    case M_BGEL:
      likely = 1;
    case M_BGE:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgezl" : "bgez",
         "s,p", sreg);
   return;
 }
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "blezl" : "blez",
         "s,p", treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "slt", "d,v,t", 1, sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BGTL_I:
      likely = 1;
    case M_BGT_I:

      maxnum = 0x7fffffff;
      if (mips_isa >= 3)
 {
   maxnum <<= 16;
   maxnum |= 0xffff;
   maxnum <<= 16;
   maxnum |= 0xffff;
 }
      if (imm_expr.X_add_number >= maxnum
   && (mips_isa < 3 || sizeof (maxnum) > 4))
 {
 do_false:

   if (! likely)
     {
       as_warn ("Branch %s is always false (nop)", ip->insn_mo->name);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, 
                                         ((void *)0)
                                             , "nop", "", 0);
     }
   else
     {
       as_warn ("Branch likely %s is always false", ip->insn_mo->name);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, "bnel",
      "s,t,p", 0, 0);
     }
   return;
 }
      imm_expr.X_add_number++;

    case M_BGE_I:
    case M_BGEL_I:
      if (mask == M_BGEL_I)
 likely = 1;
      if (imm_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgezl" : "bgez",
         "s,p", sreg);
   return;
 }
      if (imm_expr.X_add_number == 1)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgtzl" : "bgtz",
         "s,p", sreg);
   return;
 }
      maxnum = 0x7fffffff;
      if (mips_isa >= 3)
 {
   maxnum <<= 16;
   maxnum |= 0xffff;
   maxnum <<= 16;
   maxnum |= 0xffff;
 }
      maxnum = - maxnum - 1;
      if (imm_expr.X_add_number <= maxnum
   && (mips_isa < 3 || sizeof (maxnum) > 4))
 {
 do_true:

   as_warn ("Branch %s is always true", ip->insn_mo->name);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, "b", "p");
   return;
 }
      set_at (&icnt, sreg, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BGEUL:
      likely = 1;
    case M_BGEU:
      if (treg == 0)
 goto do_true;
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "beql" : "beq",
         "s,t,p", 0, treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", 1, sreg,
     treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BGTUL_I:
      likely = 1;
    case M_BGTU_I:
      if (sreg == 0 || imm_expr.X_add_number == -1)
 goto do_false;
      imm_expr.X_add_number++;

    case M_BGEU_I:
    case M_BGEUL_I:
      if (mask == M_BGEUL_I)
 likely = 1;
      if (imm_expr.X_add_number == 0)
 goto do_true;
      if (imm_expr.X_add_number == 1)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bnel" : "bne",
         "s,t,p", sreg, 0);
   return;
 }
      set_at (&icnt, sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BGTL:
      likely = 1;
    case M_BGT:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgtzl" : "bgtz",
         "s,p", sreg);
   return;
 }
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bltzl" : "bltz",
         "s,p", treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "slt", "d,v,t", 1, treg, sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_BGTUL:
      likely = 1;
    case M_BGTU:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bnel" : "bne",
         "s,t,p", sreg, 0);
   return;
 }
      if (sreg == 0)
 goto do_false;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", 1, treg,
     sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_BLEL:
      likely = 1;
    case M_BLE:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "blezl" : "blez",
         "s,p", sreg);
   return;
 }
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgezl" : "bgez",
         "s,p", treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "slt", "d,v,t", 1, treg, sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BLEL_I:
      likely = 1;
    case M_BLE_I:
      maxnum = 0x7fffffff;
      if (mips_isa >= 3)
 {
   maxnum <<= 16;
   maxnum |= 0xffff;
   maxnum <<= 16;
   maxnum |= 0xffff;
 }
      if (imm_expr.X_add_number >= maxnum
   && (mips_isa < 3 || sizeof (maxnum) > 4))
 goto do_true;
      imm_expr.X_add_number++;

    case M_BLT_I:
    case M_BLTL_I:
      if (mask == M_BLTL_I)
 likely = 1;
      if (imm_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bltzl" : "bltz",
         "s,p", sreg);
   return;
 }
      if (imm_expr.X_add_number == 1)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "blezl" : "blez",
         "s,p", sreg);
   return;
 }
      set_at (&icnt, sreg, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_BLEUL:
      likely = 1;
    case M_BLEU:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "beql" : "beq",
         "s,t,p", sreg, 0);
   return;
 }
      if (sreg == 0)
 goto do_true;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", 1, treg,
     sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "beql" : "beq",
     "s,t,p", 1, 0);
      break;

    case M_BLEUL_I:
      likely = 1;
    case M_BLEU_I:
      if (sreg == 0 || imm_expr.X_add_number == -1)
 goto do_true;
      imm_expr.X_add_number++;

    case M_BLTU_I:
    case M_BLTUL_I:
      if (mask == M_BLTUL_I)
 likely = 1;
      if (imm_expr.X_add_number == 0)
 goto do_false;
      if (imm_expr.X_add_number == 1)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "beql" : "beq",
         "s,t,p", sreg, 0);
   return;
 }
      set_at (&icnt, sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_BLTL:
      likely = 1;
    case M_BLT:
      if (treg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bltzl" : "bltz",
         "s,p", sreg);
   return;
 }
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bgtzl" : "bgtz",
         "s,p", treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "slt", "d,v,t", 1, sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_BLTUL:
      likely = 1;
    case M_BLTU:
      if (treg == 0)
 goto do_false;
      if (sreg == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         likely ? "bnel" : "bne",
         "s,t,p", 0, treg);
   return;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", 1, sreg,
     treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr,
     likely ? "bnel" : "bne",
     "s,t,p", 1, 0);
      break;

    case M_DDIV_3:
      dbl = 1;
    case M_DIV_3:
      s = "mflo";
      goto do_div3;
    case M_DREM_3:
      dbl = 1;
    case M_REM_3:
      s = "mfhi";
    do_div3:
      if (treg == 0)
 {
   as_warn ("Divide by zero.");
   if (mips_trap)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "teq", "s,t", 0, 0);
   else
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "break", "c", 7);
   return;
 }

      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "ddiv" : "div",
     "z,s,t", sreg, treg);
      if (mips_trap)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "teq", "s,t", treg, 0);
      else
 {
   expr1.X_add_number = 8;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "bne", "s,t,p", treg, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "nop", "", 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "break", "c", 7);
 }
      expr1.X_add_number = -1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1,
     dbl ? "daddiu" : "addiu",
     "t,r,j", 1, 0, (int) BFD_RELOC_LO16);
      expr1.X_add_number = mips_trap ? (dbl ? 12 : 8) : (dbl ? 20 : 16);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "bne", "s,t,p", treg, 1);
      if (dbl)
 {
   expr1.X_add_number = 1;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "daddiu", "t,r,j", 1, 0,
         (int) BFD_RELOC_LO16);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "dsll32", "d,w,<", 1, 1,
         31);
 }
      else
 {
   expr1.X_add_number = 0x80000000;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "lui", "t,u", 1,
         (int) BFD_RELOC_HI16);
 }
      if (mips_trap)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "teq", "s,t", sreg, 1);
      else
 {
   expr1.X_add_number = 8;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "bne", "s,t,p", sreg, 1);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "nop", "", 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "break", "c", 6);
 }
      --mips_noreorder;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d", dreg);
      break;

    case M_DIV_3I:
      s = "div";
      s2 = "mflo";
      goto do_divi;
    case M_DIVU_3I:
      s = "divu";
      s2 = "mflo";
      goto do_divi;
    case M_REM_3I:
      s = "div";
      s2 = "mfhi";
      goto do_divi;
    case M_REMU_3I:
      s = "divu";
      s2 = "mfhi";
      goto do_divi;
    case M_DDIV_3I:
      dbl = 1;
      s = "ddiv";
      s2 = "mflo";
      goto do_divi;
    case M_DDIVU_3I:
      dbl = 1;
      s = "ddivu";
      s2 = "mflo";
      goto do_divi;
    case M_DREM_3I:
      dbl = 1;
      s = "ddiv";
      s2 = "mfhi";
      goto do_divi;
    case M_DREMU_3I:
      dbl = 1;
      s = "ddivu";
      s2 = "mfhi";
    do_divi:
      if (imm_expr.X_add_number == 0)
 {
   as_warn ("Divide by zero.");
   if (mips_trap)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "teq", "s,t", 0, 0);
   else
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "break", "c", 7);
   return;
 }
      if (imm_expr.X_add_number == 1)
 {
   if (strcmp (s2, "mflo") == 0)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "move", "d,s", dreg,
    sreg);
   else
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "move", "d,s", dreg, 0);
   return;
 }
      if (imm_expr.X_add_number == -1
   && s[strlen (s) - 1] != 'u')
 {
   if (strcmp (s2, "mflo") == 0)
     {
       if (dbl)
  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, 
                                    ((void *)0)
                                        , "dneg", "d,w", dreg,
        sreg);
       else
  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, 
                                    ((void *)0)
                                        , "neg", "d,w", dreg,
        sreg);
     }
   else
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, 
                                       ((void *)0)
                                           , "move", "d,s", dreg, 0);
   return;
 }

      load_register (&icnt, 1, &imm_expr, dbl);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "z,s,t", sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s2, "d", dreg);
      break;

    case M_DIVU_3:
      s = "divu";
      s2 = "mflo";
      goto do_divu3;
    case M_REMU_3:
      s = "divu";
      s2 = "mfhi";
      goto do_divu3;
    case M_DDIVU_3:
      s = "ddivu";
      s2 = "mflo";
      goto do_divu3;
    case M_DREMU_3:
      s = "ddivu";
      s2 = "mfhi";
    do_divu3:
      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "z,s,t", sreg, treg);
      if (mips_trap)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "teq", "s,t", treg, 0);
      else
 {
   expr1.X_add_number = 8;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "bne", "s,t,p", treg, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "nop", "", 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "break", "c", 7);
 }
      --mips_noreorder;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s2, "d", dreg);
      return;

    case M_DLA_AB:
      dbl = 1;
    case M_LA_AB:
      if (mips_pic == EMBEDDED_PIC
   && offset_expr.X_op == O_subtract
   && now_seg == text_section
   && (offset_expr.X_op_symbol->sy_value.X_op == O_constant
       ? S_GET_SEGMENT (offset_expr.X_op_symbol) == text_section
       : (offset_expr.X_op_symbol->sy_value.X_op == O_symbol
   && (S_GET_SEGMENT (offset_expr.X_op_symbol
        ->sy_value.X_add_symbol)
       == text_section)))
   && breg == 0
   && offset_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, "lui", "t,u",
         treg, (int) BFD_RELOC_PCREL_HI16_S);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", treg, treg, (int) BFD_RELOC_PCREL_LO16);
   return;
 }

      if (offset_expr.X_op != O_symbol
   && offset_expr.X_op != O_constant)
 {
   as_bad ("expression too complex");
   offset_expr.X_op = O_constant;
 }

      if (treg == breg)
 {
   tempreg = 1;
   used_at = 1;
 }
      else
 {
   tempreg = treg;
   used_at = 0;
 }

      if (offset_expr.X_op == O_constant)
 load_register (&icnt, tempreg, &offset_expr, dbl);
      else if (mips_pic == NO_PIC)
 {







   if (offset_expr.X_add_number != 0
       || nopic_need_relax (offset_expr.X_add_symbol))
     p = 
        ((void *)0)
            ;
   else
     {
       frag_grow (20);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr,
      mips_isa < 3 ? "addiu" : "daddiu",
      "t,r,j", tempreg, 28, (int) BFD_RELOC_GPREL16);
       p = frag_var (rs_machine_dependent, 8, 0,
       ((relax_substateT) (((4) << 24) | ((8) << 16) | (((0) + 64) << 9) | (((4) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((mips_warn_about_macros) ? 1 : 0)))
                              ,
       offset_expr.X_add_symbol, (long) 0,
       (char *) 
               ((void *)0)
                   );
     }
   macro_build_lui (p, &icnt, &offset_expr, tempreg);
   if (p != 
           ((void *)0)
               )
     p += 4;
   macro_build (p, &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", tempreg, tempreg, (int) BFD_RELOC_LO16);
 }
      else if (mips_pic == SVR4_PIC)
 {
   expr1.X_add_number = offset_expr.X_add_number;
   offset_expr.X_add_number = 0;
   frag_grow (32);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         dbl ? "ld" : "lw",
         "t,o(b)", tempreg, (int) BFD_RELOC_MIPS_GOT16, 28);
   if (expr1.X_add_number == 0)
     {
       int off;

       if (breg == 0)
  off = 0;
       else
  {



    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, (expressionS *) 
                                                      ((void *)0)
                                                          ,
          "nop", "");
    off = 4;
  }
       p = frag_var (rs_machine_dependent, 8 - off, 0,
       ((relax_substateT) (((0) << 24) | ((8 - off) << 16) | (((-4 - off) + 64) << 9) | (((4 - off) + 64) << 2) | ((0) ? (1 << 1) : 0) | (((breg == 0 ? mips_warn_about_macros : 0)) ? 1 : 0)))


             ,
       offset_expr.X_add_symbol, (long) 0,
       (char *) 
               ((void *)0)
                   );
       if (breg == 0)
  {
    macro_build (p, &icnt, (expressionS *) 
                                          ((void *)0)
                                              , "nop", "");
    p += 4;
  }
       macro_build (p, &icnt, &expr1,
      mips_isa < 3 ? "addiu" : "daddiu",
      "t,r,j", tempreg, tempreg, (int) BFD_RELOC_LO16);



     }
   else if (expr1.X_add_number >= -0x8000
     && expr1.X_add_number < 0x8000)
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, (expressionS *) 
                                                         ((void *)0)
                                                             ,
      "nop", "");
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &expr1,
      mips_isa < 3 ? "addiu" : "daddiu",
      "t,r,j", tempreg, tempreg, (int) BFD_RELOC_LO16);
       (void) frag_var (rs_machine_dependent, 0, 0,
          ((relax_substateT) (((0) << 24) | ((0) << 16) | (((-12) + 64) << 9) | (((-4) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
          offset_expr.X_add_symbol, (long) 0,
          (char *) 
                  ((void *)0)
                      );
     }
   else
     {
       int off1;
       if (breg != treg)
  off1 = 0;
       else
  {
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, (expressionS *) 
                                                      ((void *)0)
                                                          ,
          "nop", "");
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, (expressionS *) 
                                                      ((void *)0)
                                                          ,
          mips_isa < 3 ? "addu" : "daddu",
          "d,v,t", treg, 1, breg);
    breg = 0;
    tempreg = treg;
    off1 = -8;
  }



       hold_mips_optimize = mips_optimize;
       mips_optimize = 2;
       macro_build_lui ((char *) 
                                ((void *)0)
                                    , &icnt, &expr1, 1);
       mips_optimize = hold_mips_optimize;

       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &expr1,
      mips_isa < 3 ? "addiu" : "daddiu",
      "t,r,j", 1, 1, (int) BFD_RELOC_LO16);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, (expressionS *) 
                                                         ((void *)0)
                                                             ,
      mips_isa < 3 ? "addu" : "daddu",
      "d,v,t", tempreg, tempreg, 1);
       (void) frag_var (rs_machine_dependent, 0, 0,
          ((relax_substateT) (((0) << 24) | ((0) << 16) | (((-16 + off1) + 64) << 9) | (((-8) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
          offset_expr.X_add_symbol, (long) 0,
          (char *) 
                  ((void *)0)
                      );
       used_at = 1;
     }
 }
      else if (mips_pic == EMBEDDED_PIC)
 {



   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", tempreg, 28, (int) BFD_RELOC_GPREL16);
 }
      else
 as_abort ("targ-cpu.c", 3265, ((char*)0));

      if (breg != 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       ,
       mips_isa < 3 ? "addu" : "daddu",
       "d,v,t", treg, tempreg, breg);

      if (! used_at)
 return;

      break;

    case M_J_A:



      if (mips_pic == NO_PIC)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &offset_expr, "j", "a");
      else
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &offset_expr, "b", "p");
      return;




    case M_JAL_1:
      dreg = 31;

    case M_JAL_2:
      if (mips_pic == NO_PIC
   || mips_pic == EMBEDDED_PIC)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       , "jalr",
       "d,s", dreg, sreg);
      else if (mips_pic == SVR4_PIC)
 {
   if (sreg != 25)
     as_warn ("MIPS PIC call to register other than $25");

   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         , "jalr",
         "d,s", dreg, sreg);
   if (mips_cprestore_offset < 0)
     as_warn ("No .cprestore pseudo-op used in PIC code");
   else
     {
       expr1.X_add_number = mips_cprestore_offset;
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &expr1,
      mips_isa < 3 ? "lw" : "ld",
      "t,o(b)", 28, (int) BFD_RELOC_LO16, mips_frame_reg);
     }
 }
      else
 as_abort ("targ-cpu.c", 3316, ((char*)0));

      return;

    case M_JAL_A:
      if (mips_pic == NO_PIC)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &offset_expr, "jal", "a");
      else if (mips_pic == SVR4_PIC)
 {
   frag_grow (20);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "lw" : "ld",
         "t,o(b)", 25,
         (int) BFD_RELOC_MIPS_CALL16, 28);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         , "nop", "");
   p = frag_var (rs_machine_dependent, 4, 0,
   ((relax_substateT) (((0) << 24) | ((4) << 16) | (((-8) + 64) << 9) | (((0) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
   offset_expr.X_add_symbol, (long) 0, (char *) 
                                               ((void *)0)
                                                   );
   macro_build (p, &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", 25, 25,
         (int) BFD_RELOC_LO16);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         ,
         "jalr", "s", 25);
   if (mips_cprestore_offset < 0)
     as_warn ("No .cprestore pseudo-op used in PIC code");
   else
     {
       if (mips_noreorder)
  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, (expressionS *) 
                                                    ((void *)0)
                                                        ,
        "nop", "");
       expr1.X_add_number = mips_cprestore_offset;
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &expr1,
      mips_isa < 3 ? "lw" : "ld",
      "t,o(b)", 28, (int) BFD_RELOC_LO16,
      mips_frame_reg);
     }
 }
      else if (mips_pic == EMBEDDED_PIC)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, "bal", "p");


   break;
 }
      else
 as_abort ("targ-cpu.c", 3377, ((char*)0));

      return;

    case M_LB_AB:
      s = "lb";
      goto ld;
    case M_LBU_AB:
      s = "lbu";
      goto ld;
    case M_LH_AB:
      s = "lh";
      goto ld;
    case M_LHU_AB:
      s = "lhu";
      goto ld;
    case M_LW_AB:
      s = "lw";
      goto ld;
    case M_LWC0_AB:
      s = "lwc0";
      coproc = 1;
      goto ld;
    case M_LWC1_AB:
      s = "lwc1";
      coproc = 1;
      goto ld;
    case M_LWC2_AB:
      s = "lwc2";
      coproc = 1;
      goto ld;
    case M_LWC3_AB:
      s = "lwc3";
      coproc = 1;
      goto ld;
    case M_LWL_AB:
      s = "lwl";
      lr = 1;
      goto ld;
    case M_LWR_AB:
      s = "lwr";
      lr = 1;
      goto ld;
    case M_LDC1_AB:
      s = "ldc1";
      coproc = 1;
      goto ld;
    case M_LDC2_AB:
      s = "ldc2";
      coproc = 1;
      goto ld;
    case M_LDC3_AB:
      s = "ldc3";
      coproc = 1;
      goto ld;
    case M_LDL_AB:
      s = "ldl";
      lr = 1;
      goto ld;
    case M_LDR_AB:
      s = "ldr";
      lr = 1;
      goto ld;
    case M_LL_AB:
      s = "ll";
      goto ld;
    case M_LLD_AB:
      s = "lld";
      goto ld;
    case M_LWU_AB:
      s = "lwu";
    ld:
      if (breg == treg || coproc || lr)
 {
   tempreg = 1;
   used_at = 1;
 }
      else
 {
   tempreg = treg;
   used_at = 0;
 }
      goto ld_st;
    case M_SB_AB:
      s = "sb";
      goto st;
    case M_SH_AB:
      s = "sh";
      goto st;
    case M_SW_AB:
      s = "sw";
      goto st;
    case M_SWC0_AB:
      s = "swc0";
      coproc = 1;
      goto st;
    case M_SWC1_AB:
      s = "swc1";
      coproc = 1;
      goto st;
    case M_SWC2_AB:
      s = "swc2";
      coproc = 1;
      goto st;
    case M_SWC3_AB:
      s = "swc3";
      coproc = 1;
      goto st;
    case M_SWL_AB:
      s = "swl";
      goto st;
    case M_SWR_AB:
      s = "swr";
      goto st;
    case M_SC_AB:
      s = "sc";
      goto st;
    case M_SCD_AB:
      s = "scd";
      goto st;
    case M_SDC1_AB:
      s = "sdc1";
      coproc = 1;
      goto st;
    case M_SDC2_AB:
      s = "sdc2";
      coproc = 1;
      goto st;
    case M_SDC3_AB:
      s = "sdc3";
      coproc = 1;
      goto st;
    case M_SDL_AB:
      s = "sdl";
      goto st;
    case M_SDR_AB:
      s = "sdr";
    st:
      tempreg = 1;
      used_at = 1;
    ld_st:
      if (mask == M_LWC1_AB
   || mask == M_SWC1_AB
   || mask == M_LDC1_AB
   || mask == M_SDC1_AB
   || mask == M_L_DAB
   || mask == M_S_DAB)
 fmt = "T,o(b)";
      else if (coproc)
 fmt = "E,o(b)";
      else
 fmt = "t,o(b)";

      if (offset_expr.X_op != O_constant
   && offset_expr.X_op != O_symbol)
 {
   as_bad ("expression too complex");
   offset_expr.X_op = O_constant;
 }



      if (mips_pic == NO_PIC
   || offset_expr.X_op == O_constant)
 {
   if (breg == 0)
     {
       if (offset_expr.X_add_number != 0
    || nopic_need_relax (offset_expr.X_add_symbol))
  p = 
     ((void *)0)
         ;
       else
  {
    frag_grow (20);
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, &offset_expr, s, fmt,
          treg, (int) BFD_RELOC_GPREL16, 28);
    p = frag_var (rs_machine_dependent, 8, 0,
    ((relax_substateT) (((4) << 24) | ((8) << 16) | (((0) + 64) << 9) | (((4) + 64) << 2) | ((0) ? (1 << 1) : 0) | (((mips_warn_about_macros || (used_at && mips_noat))) ? 1 : 0)))

                                       ,
    offset_expr.X_add_symbol, (long) 0,
    (char *) 
            ((void *)0)
                );
    used_at = 0;
  }
       macro_build_lui (p, &icnt, &offset_expr, tempreg);
       if (p != 
               ((void *)0)
                   )
  p += 4;
       macro_build (p, &icnt, &offset_expr, s, fmt, treg,
      (int) BFD_RELOC_LO16, tempreg);
     }
   else
     {
       if (offset_expr.X_add_number != 0
    || nopic_need_relax (offset_expr.X_add_symbol))
  p = 
     ((void *)0)
         ;
       else
  {
    frag_grow (28);
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, (expressionS *) 
                                                      ((void *)0)
                                                          ,
          mips_isa < 3 ? "addu" : "daddu",
          "d,v,t", tempreg, breg, 28);
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, &offset_expr, s, fmt,
          treg, (int) BFD_RELOC_GPREL16, tempreg);
    p = frag_var (rs_machine_dependent, 12, 0,
    ((relax_substateT) (((8) << 24) | ((12) << 16) | (((0) + 64) << 9) | (((8) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
    offset_expr.X_add_symbol, (long) 0,
    (char *) 
            ((void *)0)
                );
  }
       macro_build_lui (p, &icnt, &offset_expr, tempreg);
       if (p != 
               ((void *)0)
                   )
  p += 4;
       macro_build (p, &icnt, (expressionS *) 
                                             ((void *)0)
                                                 ,
      mips_isa < 3 ? "addu" : "daddu",
      "d,v,t", tempreg, tempreg, breg);
       if (p != 
               ((void *)0)
                   )
  p += 4;
       macro_build (p, &icnt, &offset_expr, s, fmt, treg,
      (int) BFD_RELOC_LO16, tempreg);
     }
 }
      else if (mips_pic == SVR4_PIC)
 {
   ((offset_expr.X_op == O_symbol) ? 0 : (as_assert ("targ-cpu.c", 3631, ((char*)0)), 0));
   expr1.X_add_number = offset_expr.X_add_number;
   offset_expr.X_add_number = 0;
   if (expr1.X_add_number < -0x8000
       || expr1.X_add_number >= 0x8000)
     as_bad ("PIC code offset overflow (max 16 signed bits)");
   frag_grow (20);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "lw" : "ld",
         "t,o(b)", tempreg, (int) BFD_RELOC_MIPS_GOT16, 28);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         , "nop", "");
   p = frag_var (rs_machine_dependent, 4, 0,
   ((relax_substateT) (((0) << 24) | ((4) << 16) | (((-8) + 64) << 9) | (((0) + 64) << 2) | ((0) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
   offset_expr.X_add_symbol, (long) 0,
   (char *) 
           ((void *)0)
               );
   macro_build (p, &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", tempreg, tempreg, (int) BFD_RELOC_LO16);
   if (breg != 0)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, (expressionS *) 
                                                       ((void *)0)
                                                           ,
    mips_isa < 3 ? "addu" : "daddu",
    "d,v,t", tempreg, tempreg, breg);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, s, fmt, treg,
         (int) BFD_RELOC_LO16, tempreg);
 }
      else if (mips_pic == EMBEDDED_PIC)
 {






   ((offset_expr.X_op == O_symbol) ? 0 : (as_assert ("targ-cpu.c", 3664, ((char*)0)), 0));
   if (breg == 0)
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, s, fmt,
      treg, (int) BFD_RELOC_GPREL16, 28);
       used_at = 0;
     }
   else
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, (expressionS *) 
                                                         ((void *)0)
                                                             ,
      mips_isa < 3 ? "addu" : "daddu",
      "d,v,t", tempreg, breg, 28);
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, s, fmt,
      treg, (int) BFD_RELOC_GPREL16, tempreg);
     }
 }
      else
 as_abort ("targ-cpu.c", 3681, ((char*)0));

      if (! used_at)
 return;

      break;

    case M_LI:
    case M_LI_S:
      load_register (&icnt, treg, &imm_expr, 0);
      return;

    case M_DLI:
      load_register (&icnt, treg, &imm_expr, 1);
      return;

    case M_LI_SS:
      if (imm_expr.X_op == O_constant)
 {
   load_register (&icnt, 1, &imm_expr, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         ,
         "mtc1", "t,G", 1, treg);
   break;
 }
      else
 {
   ((offset_expr.X_op == O_symbol && strcmp (((S_GET_SEGMENT (offset_expr.X_add_symbol))->name + 0), ".lit4") == 0 && offset_expr.X_add_number == 0) ? 0 : (as_assert ("targ-cpu.c", 3707, ((char*)0)), 0))



                                     ;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, "lwc1", "T,o(b)",
         treg, (int) BFD_RELOC_MIPS_LITERAL, 28);
   return;
 }

    case M_LI_D:


      if (mips_pic == NO_PIC)
 {

   macro_build_lui ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, 1);
 }
      else if (mips_pic == SVR4_PIC)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "lw" : "ld",
         "t,o(b)", 1, (int) BFD_RELOC_MIPS_GOT16, 28);
 }
      else if (mips_pic == EMBEDDED_PIC)
 {


   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", 1, 28, (int) BFD_RELOC_GPREL16);
   offset_expr.X_op = O_constant;
   offset_expr.X_add_number = 0;
 }
      else
 as_abort ("targ-cpu.c", 3742, ((char*)0));


      if (mips_isa >= 3)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &offset_expr, "ld", "t,o(b)",
       treg, (int) BFD_RELOC_LO16, 1);
      else
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, "lw", "t,o(b)",
         treg, (int) BFD_RELOC_LO16, 1);
   if (treg != 31)
     {


       offset_expr.X_add_number += 4;
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, "lw", "t,o(b)",
      treg + 1, (int) BFD_RELOC_LO16, 1);
     }
 }



      frag_wane (frag_now);
      frag_new (0);

      break;

    case M_LI_DD:
      ((offset_expr.X_op == O_symbol && offset_expr.X_add_number == 0) ? 0 : (as_assert ("targ-cpu.c", 3770, ((char*)0)), 0))
                                        ;
      s = ((S_GET_SEGMENT (offset_expr.X_add_symbol))->name + 0);
      if (strcmp (s, ".lit8") == 0)
 {
   if (mips_isa >= 2)
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, "ldc1",
      "T,o(b)", treg, (int) BFD_RELOC_MIPS_LITERAL, 28);
       return;
     }
   breg = 28;
   r = BFD_RELOC_MIPS_LITERAL;
   goto dob;
 }
      else
 {
   ((strcmp (s, (bfd_target_elf_flavour == bfd_target_aout_flavour ? ".data" : bfd_target_elf_flavour == bfd_target_ecoff_flavour ? ".rdata" : bfd_target_elf_flavour == bfd_target_elf_flavour ? ".rodata" : (as_abort ("targ-cpu.c", 3787, ((char*)0)), ""))) == 0) ? 0 : (as_assert ("targ-cpu.c", 3787, ((char*)0)), 0));
   if (mips_pic == SVR4_PIC)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, &offset_expr,
    mips_isa < 3 ? "lw" : "ld",
    "t,o(b)", 1, (int) BFD_RELOC_MIPS_GOT16, 28);
   else
     {

       macro_build_lui ((char *) 
                                ((void *)0)
                                    , &icnt, &offset_expr, 1);
     }

   if (mips_isa >= 2)
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, "ldc1",
      "T,o(b)", treg, (int) BFD_RELOC_LO16, 1);



       frag_wane (frag_now);
       frag_new (0);

       break;
     }
   breg = 1;
   r = BFD_RELOC_LO16;
   goto dob;
 }

    case M_L_DOB:


      r = BFD_RELOC_LO16;
    dob:
      ((mips_isa < 2) ? 0 : (as_assert ("targ-cpu.c", 3820, ((char*)0)), 0));
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "lwc1", "T,o(b)",
     byte_order == 1234 ? treg : treg + 1,
     (int) r, breg);


      offset_expr.X_add_number += 4;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "lwc1", "T,o(b)",
     byte_order == 1234 ? treg + 1 : treg,
     (int) r, breg);



      frag_wane (frag_now);
      frag_new (0);

      if (breg != 1)
 return;
      break;

    case M_L_DAB:
      coproc = 1;
      if (mips_isa >= 2)
 {
   s = "ldc1";
   goto ld;
 }

      s = "lwc1";
      fmt = "T,o(b)";
      goto ldd_std;

    case M_S_DAB:
      if (mips_isa >= 2)
 {
   s = "sdc1";
   goto st;
 }

      s = "swc1";
      fmt = "T,o(b)";
      coproc = 1;
      goto ldd_std;

    case M_LD_AB:
      if (mips_isa >= 3)
 {
   s = "ld";
   goto ld;
 }

      s = "lw";
      fmt = "t,o(b)";
      goto ldd_std;

    case M_SD_AB:
      if (mips_isa >= 3)
 {
   s = "sd";
   goto st;
 }

      s = "sw";
      fmt = "t,o(b)";

    ldd_std:
      if (offset_expr.X_op != O_symbol
   && offset_expr.X_op != O_constant)
 {
   as_bad ("expression too complex");
   offset_expr.X_op = O_constant;
 }




      if (byte_order == 1234)
 coproc = 0;

      if (mips_pic == NO_PIC
   || offset_expr.X_op == O_constant)
 {
   if (offset_expr.X_add_number != 0
       || nopic_need_relax (offset_expr.X_add_symbol))
     {
       p = 
          ((void *)0)
              ;
       used_at = 1;
     }
   else
     {
       int off;

       if (breg == 0)
  {
    frag_grow (28);
    tempreg = 28;
    off = 0;
    used_at = 0;
  }
       else
  {
    frag_grow (36);
    macro_build ((char *) 
                         ((void *)0)
                             , &icnt, (expressionS *) 
                                                      ((void *)0)
                                                          ,
          mips_isa < 3 ? "addu" : "daddu",
          "d,v,t", 1, breg, 28);
    tempreg = 1;
    off = 4;
    used_at = 1;
  }

       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, s, fmt,
      coproc ? treg + 1 : treg,
      (int) BFD_RELOC_GPREL16, tempreg);
       offset_expr.X_add_number += 4;



       hold_mips_optimize = mips_optimize;
       mips_optimize = 2;
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, &offset_expr, s, fmt,
      coproc ? treg : treg + 1,
      (int) BFD_RELOC_GPREL16, tempreg);
       mips_optimize = hold_mips_optimize;

       p = frag_var (rs_machine_dependent, 12 + off, 0,
       ((relax_substateT) (((8 + off) << 24) | ((12 + off) << 16) | (((0) + 64) << 9) | (((4 + off) + 64) << 2) | ((1) ? (1 << 1) : 0) | ((used_at && mips_noat) ? 1 : 0)))
                            ,
       offset_expr.X_add_symbol, (long) 0,
       (char *) 
               ((void *)0)
                   );
       offset_expr.X_add_number -= 8;
       offset_expr.X_op = O_constant;
     }
   macro_build_lui (p, &icnt, &offset_expr, 1);
   if (p != 
           ((void *)0)
               )
     p += 4;
   if (breg != 0)
     {
       macro_build (p, &icnt, (expressionS *) 
                                             ((void *)0)
                                                 ,
      mips_isa < 3 ? "addu" : "daddu",
      "d,v,t", 1, breg, 1);
       if (p != 
               ((void *)0)
                   )
  p += 4;
     }
   macro_build (p, &icnt, &offset_expr, s, fmt,
         coproc ? treg + 1 : treg,
         (int) BFD_RELOC_LO16, 1);
   if (p != 
           ((void *)0)
               )
     p += 4;

   offset_expr.X_add_number += 4;
   macro_build (p, &icnt, &offset_expr, s, fmt,
         coproc ? treg : treg + 1,
         (int) BFD_RELOC_LO16, 1);
 }
      else if (mips_pic == SVR4_PIC)
 {
   int off;
   used_at = 1;
   expr1.X_add_number = offset_expr.X_add_number;
   offset_expr.X_add_number = 0;
   if (expr1.X_add_number < -0x8000
       || expr1.X_add_number >= 0x8000 - 4)
     as_bad ("PIC code offset overflow (max 16 signed bits)");
   if (breg == 0)
     off = 0;
   else
     off = 4;
   frag_grow (24 + off);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr,
         mips_isa < 3 ? "lw" : "ld",
         "t,o(b)", 1, (int) BFD_RELOC_MIPS_GOT16, 28);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, (expressionS *) 
                                                     ((void *)0)
                                                         , "nop", "");
   if (breg != 0)
     macro_build ((char *) 
                          ((void *)0)
                              , &icnt, (expressionS *) 
                                                       ((void *)0)
                                                           ,
    mips_isa < 3 ? "addu" : "daddu",
    "d,v,t", 1, breg, 1);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, s, fmt,
         coproc ? treg + 1 : treg,
         (int) BFD_RELOC_LO16, 1);
   expr1.X_add_number += 4;



   hold_mips_optimize = mips_optimize;
   mips_optimize = 2;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, s, fmt,
         coproc ? treg : treg + 1,
         (int) BFD_RELOC_LO16, 1);
   mips_optimize = hold_mips_optimize;

   (void) frag_var (rs_machine_dependent, 0, 0,
      ((relax_substateT) (((0) << 24) | ((0) << 16) | (((-16 - off) + 64) << 9) | (((-8) + 64) << 2) | ((1) ? (1 << 1) : 0) | ((0) ? 1 : 0))),
      offset_expr.X_add_symbol, (long) 0,
      (char *) 
              ((void *)0)
                  );
 }
      else if (mips_pic == EMBEDDED_PIC)
 {
   if (breg == 0)
     {
       tempreg = 28;
       used_at = 0;
     }
   else
     {
       macro_build ((char *) 
                            ((void *)0)
                                , &icnt, (expressionS *) 
                                                         ((void *)0)
                                                             ,
      mips_isa < 3 ? "addu" : "daddu",
      "d,v,t", 1, breg, 28);
       tempreg = 1;
       used_at = 1;
     }

   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, s, fmt,
         coproc ? treg + 1 : treg,
         (int) BFD_RELOC_GPREL16, tempreg);
   offset_expr.X_add_number += 4;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &offset_expr, s, fmt,
         coproc ? treg : treg + 1,
         (int) BFD_RELOC_GPREL16, tempreg);
 }
      else
 as_abort ("targ-cpu.c", 4096, ((char*)0));

      if (! used_at)
 return;

      break;

    case M_LD_OB:
      s = "lw";
      goto sd_ob;
    case M_SD_OB:
      s = "sw";
    sd_ob:
      ((mips_isa < 3) ? 0 : (as_assert ("targ-cpu.c", 4109, ((char*)0)), 0));
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      offset_expr.X_add_number += 4;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "t,o(b)", treg + 1,
     (int) BFD_RELOC_LO16, breg);
      return;
    case M_DMUL:
      dbl = 1;
    case M_MUL:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dmultu" : "multu",
     "s,t", sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mflo", "d", dreg);
      return;

    case M_DMUL_I:
      dbl = 1;
    case M_MUL_I:



      load_register (&icnt, 1, &imm_expr, dbl);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dmult" : "mult",
     "s,t", sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mflo", "d", dreg);
      break;

    case M_DMULO:
      dbl = 1;
    case M_MULO:
      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dmult" : "mult",
     "s,t", sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mflo", "d", dreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dsra32" : "sra",
     "d,w,<", dreg, dreg, 31);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mfhi", "d", 1);
      if (mips_trap)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "tne", "s,t", dreg, 1);
      else
 {
   expr1.X_add_number = 8;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "beq", "s,t,p", dreg, 1);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "nop", "", 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "break", "c", 6);
 }
      --mips_noreorder;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mflo", "d", dreg);
      break;

    case M_DMULOU:
      dbl = 1;
    case M_MULOU:
      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dmultu" : "multu",
     "s,t", sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mfhi", "d", 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "mflo", "d", dreg);
      if (mips_trap)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "tne", "s,t", 1, 0);
      else
 {
   expr1.X_add_number = 8;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "beq", "s,t,p", 1, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "nop", "", 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "break", "c", 6);
 }
      --mips_noreorder;
      break;

    case M_ROL:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "subu", "d,v,t", 1, 0, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srlv", "d,t,s", 1, sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sllv", "d,t,s", dreg, sreg,
     treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", dreg, dreg, 1);
      break;

    case M_ROL_I:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sll", "d,w,<", 1, sreg,
     imm_expr.X_add_number & 0x1f);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srl", "d,w,<", dreg, sreg,
     (0 - imm_expr.X_add_number) & 0x1f);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", dreg, dreg, 1);
      break;

    case M_ROR:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "subu", "d,v,t", 1, 0, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sllv", "d,t,s", 1, sreg, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srlv", "d,t,s", dreg, sreg,
     treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", dreg, dreg, 1);
      break;

    case M_ROR_I:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srl", "d,w,<", 1, sreg,
     imm_expr.X_add_number & 0x1f);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sll", "d,w,<", dreg, sreg,
     (0 - imm_expr.X_add_number) & 0x1f);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", dreg, dreg, 1);
      break;

    case M_S_DOB:
      ((mips_isa < 2) ? 0 : (as_assert ("targ-cpu.c", 4266, ((char*)0)), 0));


      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "swc1", "T,o(b)",
     byte_order == 1234 ? treg : treg + 1,
     (int) BFD_RELOC_LO16, breg);
      offset_expr.X_add_number += 4;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "swc1", "T,o(b)",
     byte_order == 1234 ? treg + 1 : treg,
     (int) BFD_RELOC_LO16, breg);
      return;

    case M_SEQ:
      if (sreg == 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &expr1, "sltiu", "t,r,j", dreg,
       treg, (int) BFD_RELOC_LO16);
      else if (treg == 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, &expr1, "sltiu", "t,r,j", dreg,
       sreg, (int) BFD_RELOC_LO16);
      else
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "xor", "d,v,t", dreg,
         sreg, treg);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "sltiu", "t,r,j", dreg,
         dreg, (int) BFD_RELOC_LO16);
 }
      return;

    case M_SEQ_I:
      if (imm_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1, "sltiu", "t,r,j", dreg,
         sreg, (int) BFD_RELOC_LO16);
   return;
 }
      if (sreg == 0)
 {
   as_warn ("Instruction %s: result is always false",
     ip->insn_mo->name);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "move", "d,s", dreg, 0);
   return;
 }
      if (imm_expr.X_add_number >= 0 && imm_expr.X_add_number < 0x10000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr, "xori", "t,r,i", dreg,
         sreg, (int) BFD_RELOC_LO16);
   used_at = 0;
 }
      else if (imm_expr.X_add_number > -0x8000 && imm_expr.X_add_number < 0)
 {
   imm_expr.X_add_number = -imm_expr.X_add_number;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", dreg, sreg,
         (int) BFD_RELOC_LO16);
   used_at = 0;
 }
      else
 {
   load_register (&icnt, 1, &imm_expr, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "xor", "d,v,t", dreg,
         sreg, 1);
   used_at = 1;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "sltiu", "t,r,j", dreg, dreg,
     (int) BFD_RELOC_LO16);
      if (used_at)
 break;
      return;

    case M_SGE:
      s = "slt";
      goto sge;
    case M_SGEU:
      s = "sltu";
    sge:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d,v,t", dreg, sreg, treg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "xori", "t,r,i", dreg, dreg,
     (int) BFD_RELOC_LO16);
      return;

    case M_SGE_I:
    case M_SGEU_I:
      if (imm_expr.X_add_number >= -0x8000 && imm_expr.X_add_number < 0x8000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1,
         mask == M_SGE_I ? "slti" : "sltiu",
         "t,r,j", dreg, sreg, (int) BFD_RELOC_LO16);
   used_at = 0;
 }
      else
 {
   load_register (&icnt, 1, &imm_expr, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         ,
         mask == M_SGE_I ? "slt" : "sltu",
         "d,v,t", dreg, sreg, 1);
   used_at = 1;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "xori", "t,r,i", dreg, dreg,
     (int) BFD_RELOC_LO16);
      if (used_at)
 break;
      return;

    case M_SGT:
      s = "slt";
      goto sgt;
    case M_SGTU:
      s = "sltu";
    sgt:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d,v,t", dreg, treg, sreg);
      return;

    case M_SGT_I:
      s = "slt";
      goto sgti;
    case M_SGTU_I:
      s = "sltu";
    sgti:
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d,v,t", dreg, 1, sreg);
      break;

    case M_SLE:
      s = "slt";
      goto sle;
    case M_SLEU:
      s = "sltu";
    sle:
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d,v,t", dreg, treg, sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "xori", "t,r,i", dreg, dreg,
     (int) BFD_RELOC_LO16);
      return;

    case M_SLE_I:
      s = "slt";
      goto slei;
    case M_SLEU_I:
      s = "sltu";
    slei:
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "d,v,t", dreg, 1, sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "xori", "t,r,i", dreg, dreg,
     (int) BFD_RELOC_LO16);
      break;

    case M_SLT_I:
      if (imm_expr.X_add_number >= -0x8000 && imm_expr.X_add_number < 0x8000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr, "slti", "t,r,j",
         dreg, sreg, (int) BFD_RELOC_LO16);
   return;
 }
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "slt", "d,v,t", dreg, sreg, 1);
      break;

    case M_SLTU_I:
      if (imm_expr.X_add_number >= -0x8000 && imm_expr.X_add_number < 0x8000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr, "sltiu", "t,r,j",
         dreg, sreg, (int) BFD_RELOC_LO16);
   return;
 }
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", dreg, sreg,
     1);
      break;

    case M_SNE:
      if (sreg == 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "sltu", "d,v,t", dreg, 0,
       treg);
      else if (treg == 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, 
                                   ((void *)0)
                                       , "sltu", "d,v,t", dreg, 0,
       sreg);
      else
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "xor", "d,v,t", dreg,
         sreg, treg);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "sltu", "d,v,t", dreg, 0,
         dreg);
 }
      return;

    case M_SNE_I:
      if (imm_expr.X_add_number == 0)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "sltu", "d,v,t", dreg, 0,
         sreg);
   return;
 }
      if (sreg == 0)
 {
   as_warn ("Instruction %s: result is always true",
     ip->insn_mo->name);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &expr1,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", dreg, 0, (int) BFD_RELOC_LO16);
   return;
 }
      if (imm_expr.X_add_number >= 0 && imm_expr.X_add_number < 0x10000)
 {
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr, "xori", "t,r,i",
         dreg, sreg, (int) BFD_RELOC_LO16);
   used_at = 0;
 }
      else if (imm_expr.X_add_number > -0x8000 && imm_expr.X_add_number < 0)
 {
   imm_expr.X_add_number = -imm_expr.X_add_number;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr,
         mips_isa < 3 ? "addiu" : "daddiu",
         "t,r,j", dreg, sreg, (int) BFD_RELOC_LO16);
   used_at = 0;
 }
      else
 {
   load_register (&icnt, 1, &imm_expr, 0);
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, 
                                     ((void *)0)
                                         , "xor", "d,v,t", dreg,
         sreg, 1);
   used_at = 1;
 }
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sltu", "d,v,t", dreg, 0, dreg);
      if (used_at)
 break;
      return;

    case M_DSUB_I:
      dbl = 1;
    case M_SUB_I:
      if (imm_expr.X_add_number > -0x8000 && imm_expr.X_add_number <= 0x8000)
 {
   imm_expr.X_add_number = -imm_expr.X_add_number;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr,
         dbl ? "daddi" : "addi",
         "t,r,j", dreg, sreg, (int) BFD_RELOC_LO16);
   return;
 }
      load_register (&icnt, 1, &imm_expr, dbl);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dsub" : "sub",
     "d,v,t", dreg, sreg, 1);
      break;

    case M_DSUBU_I:
      dbl = 1;
    case M_SUBU_I:
      if (imm_expr.X_add_number > -0x8000 && imm_expr.X_add_number <= 0x8000)
 {
   imm_expr.X_add_number = -imm_expr.X_add_number;
   macro_build ((char *) 
                        ((void *)0)
                            , &icnt, &imm_expr,
         dbl ? "daddiu" : "addiu",
         "t,r,j", dreg, sreg, (int) BFD_RELOC_LO16);
   return;
 }
      load_register (&icnt, 1, &imm_expr, dbl);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
     dbl ? "dsubu" : "subu",
     "d,v,t", dreg, sreg, 1);
      break;

    case M_TEQ_I:
      s = "teq";
      goto trap;
    case M_TGE_I:
      s = "tge";
      goto trap;
    case M_TGEU_I:
      s = "tgeu";
      goto trap;
    case M_TLT_I:
      s = "tlt";
      goto trap;
    case M_TLTU_I:
      s = "tltu";
      goto trap;
    case M_TNE_I:
      s = "tne";
    trap:
      load_register (&icnt, 1, &imm_expr, 0);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , s, "s,t", sreg, 1);
      break;

    case M_TRUNCWD:
    case M_TRUNCWS:
      ((mips_isa < 2) ? 0 : (as_assert ("targ-cpu.c", 4551, ((char*)0)), 0));
      sreg = (ip->insn_opcode >> 11) & 0x1f;
      dreg = (ip->insn_opcode >> 06) & 0x1f;





      mips_emit_delays ();
      ++mips_noreorder;
      mips_any_noreorder = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "cfc1", "t,G", treg, 31);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "cfc1", "t,G", treg, 31);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "nop", "");
      expr1.X_add_number = 3;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "ori", "t,r,i", 1, treg,
     (int) BFD_RELOC_LO16);
      expr1.X_add_number = 2;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "xori", "t,r,i", 1, 1,
       (int) BFD_RELOC_LO16);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "ctc1", "t,G", 1, 31);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "nop", "");
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            ,
       mask == M_TRUNCWD ? "cvt.w.d" : "cvt.w.s", "D,S", dreg, sreg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "ctc1", "t,G", treg, 31);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "nop", "");
      --mips_noreorder;
      break;

    case M_ULH:
      s = "lb";
      goto ulh;
    case M_ULHU:
      s = "lbu";
    ulh:
      if (offset_expr.X_add_number >= 0x7fff)
 as_bad ("operand overflow");

      if (byte_order == 1234)
 offset_expr.X_add_number += 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      if (byte_order == 1234)
 offset_expr.X_add_number -= 1;
      else
 offset_expr.X_add_number += 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "lbu", "t,o(b)", 1,
     (int) BFD_RELOC_LO16, breg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sll", "d,w,<", treg, treg, 8);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", treg, treg, 1);
      break;

    case M_ULD:
      s = "ldl";
      s2 = "ldr";
      off = 7;
      goto ulw;
    case M_ULW:
      s = "lwl";
      s2 = "lwr";
      off = 3;
    ulw:
      if (offset_expr.X_add_number >= 0x8000 - off)
 as_bad ("operand overflow");
      if (byte_order == 1234)
 offset_expr.X_add_number += off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      if (byte_order == 1234)
 offset_expr.X_add_number -= off;
      else
 offset_expr.X_add_number += off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s2, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      return;

    case M_ULD_A:
      s = "ldl";
      s2 = "ldr";
      off = 7;
      goto ulwa;
    case M_ULW_A:
      s = "lwl";
      s2 = "lwr";
      off = 3;
    ulwa:
      load_address (&icnt, 1, &offset_expr);
      if (breg != 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       ,
       mips_isa < 3 ? "addu" : "daddu",
       "d,v,t", 1, 1, breg);
      if (byte_order == 1234)
 expr1.X_add_number = off;
      else
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      if (byte_order == 1234)
 expr1.X_add_number = 0;
      else
 expr1.X_add_number = off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, s2, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      break;

    case M_ULH_A:
    case M_ULHU_A:
      load_address (&icnt, 1, &offset_expr);
      if (breg != 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       ,
       mips_isa < 3 ? "addu" : "daddu",
       "d,v,t", 1, 1, breg);
      if (byte_order == 4321)
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1,
     mask == M_ULH_A ? "lb" : "lbu", "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      if (byte_order == 4321)
 expr1.X_add_number = 1;
      else
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "lbu", "t,o(b)", 1,
     (int) BFD_RELOC_LO16, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sll", "d,w,<", treg,
     treg, 8);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", treg,
     treg, 1);
      break;

    case M_USH:
      if (offset_expr.X_add_number >= 0x7fff)
 as_bad ("operand overflow");
      if (byte_order == 4321)
 offset_expr.X_add_number += 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "sb", "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srl", "d,w,<", 1, treg, 8);
      if (byte_order == 4321)
 offset_expr.X_add_number -= 1;
      else
 offset_expr.X_add_number += 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, "sb", "t,o(b)", 1,
     (int) BFD_RELOC_LO16, breg);
      break;

    case M_USD:
      s = "sdl";
      s2 = "sdr";
      off = 7;
      goto usw;
    case M_USW:
      s = "swl";
      s2 = "swr";
      off = 3;
    usw:
      if (offset_expr.X_add_number >= 0x8000 - off)
 as_bad ("operand overflow");
      if (byte_order == 1234)
 offset_expr.X_add_number += off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      if (byte_order == 1234)
 offset_expr.X_add_number -= off;
      else
 offset_expr.X_add_number += off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &offset_expr, s2, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, breg);
      return;

    case M_USD_A:
      s = "sdl";
      s2 = "sdr";
      off = 7;
      goto uswa;
    case M_USW_A:
      s = "swl";
      s2 = "swr";
      off = 3;
    uswa:
      load_address (&icnt, 1, &offset_expr);
      if (breg != 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       ,
       mips_isa < 3 ? "addu" : "daddu",
       "d,v,t", 1, 1, breg);
      if (byte_order == 1234)
 expr1.X_add_number = off;
      else
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, s, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      if (byte_order == 1234)
 expr1.X_add_number = 0;
      else
 expr1.X_add_number = off;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, s2, "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      break;

    case M_USH_A:
      load_address (&icnt, 1, &offset_expr);
      if (breg != 0)
 macro_build ((char *) 
                      ((void *)0)
                          , &icnt, (expressionS *) 
                                                   ((void *)0)
                                                       ,
       mips_isa < 3 ? "addu" : "daddu",
       "d,v,t", 1, 1, breg);
      if (byte_order == 1234)
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "sb", "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "srl", "d,w,<", treg,
     treg, 8);
      if (byte_order == 1234)
 expr1.X_add_number = 1;
      else
 expr1.X_add_number = 0;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "sb", "t,o(b)", treg,
     (int) BFD_RELOC_LO16, 1);
      if (byte_order == 1234)
 expr1.X_add_number = 0;
      else
 expr1.X_add_number = 1;
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, &expr1, "lbu", "t,o(b)", 1,
     (int) BFD_RELOC_LO16, 1);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "sll", "d,w,<", treg,
     treg, 8);
      macro_build ((char *) 
                           ((void *)0)
                               , &icnt, 
                                        ((void *)0)
                                            , "or", "d,v,t", treg,
     treg, 1);
      break;

    default:
      as_bad ("Macro %s not implemented yet", ip->insn_mo->name);
      break;
    }
  if (mips_noat)
    as_warn ("Macro used $at after \".set noat\"");
}

int mips_is_gp_reg(char *s) asm("_mips_is_gp_reg");
int mips_is_gp_reg(char *s)
{
  if (s[0] != '$')
    return cxx_false;

  char *e = s+1;
  while(isalnum(*e)) e++;
  char save_c = *e;

  *e = '\0';
  symbolS *symbol = symbol_find(s);
  *e = save_c;

  unsigned int symval = 0;
  if (symbol && (S_GET_SEGMENT (symbol) == reg_section))
    {
      symval = S_GET_VALUE(symbol);
      if ((symval & 0x0001000) || (symval & 0x0000100))
 {
   return 1;
 }
    }
  return 0;
}

int mips_is_fp_reg(char *s) asm("_mips_is_fp_reg");
int mips_is_fp_reg(char *s)
{
  if ((s[0] != '$') || (s[1] != 'f'))
    return cxx_false;

  char *e = s+2;
  while(isalnum(*e)) e++;
  char save_c = *e;

  *e = '\0';
  symbolS *symbol = symbol_find(s);
  *e = save_c;

  unsigned int symval = 0;
  if (symbol && (S_GET_SEGMENT (symbol) == reg_section))
  {
    symval = S_GET_VALUE(symbol);
    if (symval & 0x0000200)
    {
      return 1;
    }
  }
  return 0;
}






static void
mips_ip(char *str, struct n64_tag_mips_cl_insn *ip) asm("_mips_ip");
static void
mips_ip(char *str, struct n64_tag_mips_cl_insn *ip)
{
  char *s;
  const char *args;
  char c;
  struct n64_tag_mips_opcode *insn;
  char *argsStart;
  unsigned int regno;
  unsigned int lastregno = 0;
  char *s_reset;

  insn_error = 
              ((void *)0)
                  ;

  for (s = str; islower (*s) || (*s >= '0' && *s <= '3') || *s == '6' || *s == '.'; ++s)
    continue;
  switch (*s)
    {
    case '\0':
      break;

    case ' ':
      *s++ = '\0';
      break;

    default:
      as_fatal ("Unknown opcode: `%s'", str);
    }
  if ((insn = (struct n64_tag_mips_opcode *) hash_find (op_hash, str)) == 
                                                                 ((void *)0)
                                                                     )
    {
      as_warn ("`%s' not in hash table.", str);
      insn_error = "ERROR: Unrecognized opcode";
      return;
    }
  argsStart = s;
  for (;;)
    {
      int insn_isa;

      ((strcmp (insn->name, str) == 0) ? 0 : (as_assert ("targ-cpu.c", 4883, ((char*)0)), 0));

      if (insn->pinfo == 0xffffffff)
 insn_isa = insn->match;
      else if ((insn->pinfo & 0x70000000) == 0x10000000)
 insn_isa = 2;
      else if ((insn->pinfo & 0x70000000) == 0x20000000)
 insn_isa = 3;
      else if ((insn->pinfo & 0x70000000) == 0x40000000)
 insn_isa = 4;
      else
 insn_isa = 1;


      if (insn_isa > 1) {
 insn_isa = 2;
      }
      if (insn_isa > mips_isa
   || ((insn->pinfo & 0x70000000) == 0x30000000
       && ! mips_4650)
   || ((insn->pinfo & 0x70000000) == 0x50000000
       && ! mips_4010)
   || ((insn->pinfo & 0x70000000) == 0x60000000
       && ! mips_4100))
 {
   if (insn + 1 < &mips_opcodes[bfd_mips_num_opcodes]
       && strcmp (insn->name, insn[1].name) == 0)
     {
       ++insn;
       continue;
     }
   as_warn ("Instruction not supported on this processor");
 }

      ip->insn_mo = insn;
      ip->insn_opcode = insn->match;
      for (args = insn->args;; ++args)
 {
   if (*s == ' ')
     ++s;
   switch (*args)
     {
     case '\0':
       if (*s == '\0')
  return;
       break;

     case ',':
       if (*s++ == *args)
  continue;
       s--;
       switch (*++args)
  {
  case 'r':
  case 'v':
    ip->insn_opcode |= lastregno << 21;
    continue;

  case 'w':
  case 'W':
    ip->insn_opcode |= lastregno << 16;
    continue;

  case 'V':
    ip->insn_opcode |= lastregno << 11;
    continue;
  }
       break;

     case '(':





       ((args[1] == 'b') ? 0 : (as_assert ("targ-cpu.c", 4958, ((char*)0)), 0));
       if (*s == '\0')
  return;

     case ')':
       if (*s++ == *args)
  continue;
       break;

     case '<':






       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
       if ((unsigned long) imm_expr.X_add_number > 31)
  {
    as_warn ("Improper shift amount (%ld)",
      (long) imm_expr.X_add_number);
    imm_expr.X_add_number = imm_expr.X_add_number & 0x1f;
  }
       ip->insn_opcode |= imm_expr.X_add_number << 6;
       imm_expr.X_op = O_absent;
       s = expr_end;
       continue;

     case '>':
       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
       if ((unsigned long) imm_expr.X_add_number < 32
    || (unsigned long) imm_expr.X_add_number > 63)
  break;
       ip->insn_opcode |= (imm_expr.X_add_number - 32) << 6;
       imm_expr.X_op = O_absent;
       s = expr_end;
       continue;

     case 'k':
     case 'h':
       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
       if ((unsigned long) imm_expr.X_add_number > 31)
  {
    as_warn ("Invalid value for `%s' (%lu)",
      ip->insn_mo->name,
      (unsigned long) imm_expr.X_add_number);
    imm_expr.X_add_number &= 0x1f;
  }
       if (*args == 'k')
  ip->insn_opcode |= imm_expr.X_add_number << 16;
       else
  ip->insn_opcode |= imm_expr.X_add_number << 11;
       imm_expr.X_op = O_absent;
       s = expr_end;
       continue;

     case 'c':
       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
       if ((unsigned) imm_expr.X_add_number > 1023)
  as_warn ("Illegal break code (%ld)",
    (long) imm_expr.X_add_number);
       ip->insn_opcode |= imm_expr.X_add_number << 16;
       imm_expr.X_op = O_absent;
       s = expr_end;
       continue;

     case 'B':
       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
       if ((unsigned) imm_expr.X_add_number > 0xfffff)
  as_warn ("Illegal syscall code (%ld)",
    (long) imm_expr.X_add_number);
       ip->insn_opcode |= imm_expr.X_add_number << 6;
       imm_expr.X_op = O_absent;
       s = expr_end;
       continue;

            case 'C':
              my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
              if ((unsigned long) imm_expr.X_add_number >= (1<<25))
  {
                  as_warn ("Coproccesor code > 25 bits (%ld)",
      (long) imm_expr.X_add_number);
                  imm_expr.X_add_number &= ((1<<25) - 1);
  }
              ip->insn_opcode |= imm_expr.X_add_number;
              imm_expr.X_op = O_absent;
              s = expr_end;
              continue;

     case 'b':
     case 'd':
     case 's':
     case 't':
     case 'r':
     case 'v':
     case 'w':
     case 'E':
     case 'G':
     case 'x':
     case 'z':
       s_reset = s;
       if (s[0] == '$')
  {
    if (mips_is_gp_reg(s))
      {
        char *e = s+1;
        while(isalnum(*e)) e++;
        char save_c = *e;
        *e = '\0';
        symbolS *symbol = symbol_find(s);
        *e = save_c;

        unsigned int symval = 0;
        if(symbol && S_GET_SEGMENT (symbol) == reg_section)
        {
   symval = S_GET_VALUE(symbol);
   if((symval & 0x0001000) || (symval & 0x0000100))
     regno = symval & 0x1F;
        }

        s = e;
        if (regno > 31)
   as_bad ("Invalid register number (%d)", regno);
      }
    else if (*args == 'E' || *args == 'G')
      goto notreg;
    else
      goto notreg;
    if (regno == 1 && ! mips_noat)
      as_warn ("Used $at without \".set noat\"");
    c = *args;
    if (*s == ' ')
      s++;
    if (args[1] != *s)
      {
        if (c == 'r' || c == 'v' || c == 'w')
   {
     regno = lastregno;
     s = s_reset;
     args++;
   }
      }

    if (c == 'z' && regno != 0)
      break;
    switch (c)
      {
      case 'r':
      case 's':
      case 'v':
      case 'b':
        ip->insn_opcode |= regno << 21;
        break;
      case 'd':
      case 'G':
        ip->insn_opcode |= regno << 11;
        break;
      case 'w':
      case 't':
      case 'E':
        ip->insn_opcode |= regno << 16;
        break;
      case 'x':







        break;
      case 'z':




        break;
      }
    lastregno = regno;
    continue;
  }
     notreg:
       switch (*args++)
  {
  case 'r':
  case 'v':
    ip->insn_opcode |= lastregno << 21;
    continue;
  case 'w':
    ip->insn_opcode |= lastregno << 16;
    continue;
  }
       break;

     case 'D':
     case 'S':
     case 'T':
     case 'R':
     case 'V':
     case 'W':
       s_reset = s;
       if (mips_is_fp_reg(s))
  {
                  char *e = s+1;
                  while(isalnum(*e)) e++;
                  char save_c = *e;
                  *e = '\0';
                  symbolS *symbol = symbol_find(s);
                  *e = save_c;

                  unsigned int symval = 0;
                  if(symbol && S_GET_SEGMENT (symbol) == reg_section)
                  {
                    symval = S_GET_VALUE(symbol);
                    if(symval & 0x0000200)
                      regno = symval & 0x1F;
                  }

                  s = e;

    if (regno > 31)
      as_bad ("Invalid float register number (%d)", regno);

    if ((regno & 1) != 0




        && mips_isa < 2
        && ! (strcmp (str, "mtc1") == 0 ||
       strcmp (str, "mfc1") == 0 ||
       strcmp (str, "lwc1") == 0 ||
       strcmp (str, "swc1") == 0))
      as_warn ("Float register should be even, was %d",
        regno);

    c = *args;
    if (*s == ' ')
      s++;
    if (args[1] != *s)
      {
        if (c == 'V' || c == 'W')
   {
     regno = lastregno;
     s = s_reset;
     args++;
   }
      }
    switch (c)
      {
      case 'D':
        ip->insn_opcode |= regno << 6;
        break;
      case 'V':
      case 'S':
        ip->insn_opcode |= regno << 11;
        break;
      case 'W':
      case 'T':
        ip->insn_opcode |= regno << 16;
        break;
      case 'R':
        ip->insn_opcode |= regno << 21;
        break;
      }
    lastregno = regno;
    continue;
  }
       switch (*args++)
  {
  case 'V':
    ip->insn_opcode |= lastregno << 11;
    continue;
  case 'W':
    ip->insn_opcode |= lastregno << 16;
    continue;
  }
       break;

     case 'I':
       my_getExpression (&imm_expr, s);
       if (imm_expr.X_op != O_big)
  check_absolute_expr (ip, &imm_expr);
       s = expr_end;
       continue;

     case 'A':
       my_getExpression (&offset_expr, s);
       imm_reloc = BFD_RELOC_32;
       s = expr_end;
       continue;

     case 'F':
     case 'L':
     case 'f':
     case 'l':
       {
  int f64;
  char *save_in;
  char *err;
  unsigned char temp[8];
  int len;
  unsigned int length;
  segT seg;
  subsegT subseg;
  char *p;
  f64 = *args == 'F' || *args == 'L';

  save_in = input_line_pointer;
  input_line_pointer = s;
  err = md_atof (f64 ? 'd' : 'f', (char *) temp, &len);
  length = len;
  s = input_line_pointer;
  input_line_pointer = save_in;
  if (err != 
            ((void *)0) 
                 && *err != '\0')
    {
      as_bad ("Bad floating point constant: %s", err);
      memset (temp, '\0', sizeof temp);
      length = f64 ? 8 : 4;
    }

  ((length == (f64 ? 8 : 4)) ? 0 : (as_assert ("targ-cpu.c", 5312, ((char*)0)), 0));

  if (*args == 'f'
      || (*args == 'l'
   && (! (bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour)
       || mips_pic == EMBEDDED_PIC
       || g_switch_value < 4)
   ))
    {
      imm_expr.X_op = O_constant;
      if (byte_order == 1234)
        imm_expr.X_add_number =
   (((((((int) temp[3] << 8)
        | temp[2]) << 8)
      | temp[1]) << 8)
    | temp[0]);
      else
        imm_expr.X_add_number =
   (((((((int) temp[0] << 8)
        | temp[1]) << 8)
      | temp[2]) << 8)
    | temp[3]);
    }
  else
    {
      const char *newname;
      segT new_seg;


      seg = now_seg;
      subseg = now_subseg;
      switch (*args)
        {
        default:
        case 'L':
   newname = (bfd_target_elf_flavour == bfd_target_aout_flavour ? ".data" : bfd_target_elf_flavour == bfd_target_ecoff_flavour ? ".rdata" : bfd_target_elf_flavour == bfd_target_elf_flavour ? ".rodata" : (as_abort ("targ-cpu.c", 5347, ((char*)0)), ""));
   if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour) && g_switch_value >= 8)
     newname = ".lit8";
   break;
        case 'F':
   newname = (bfd_target_elf_flavour == bfd_target_aout_flavour ? ".data" : bfd_target_elf_flavour == bfd_target_ecoff_flavour ? ".rdata" : bfd_target_elf_flavour == bfd_target_elf_flavour ? ".rodata" : (as_abort ("targ-cpu.c", 5352, ((char*)0)), ""));
   break;
        case 'l':
   ((!(bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour) || g_switch_value >= 4) ? 0 : (as_assert ("targ-cpu.c", 5355, ((char*)0)), 0))
                           ;
   newname = ".lit4";
   break;
        }
      new_seg = subseg_new (newname, (subsegT) 0);
      frag_align (*args == 'l' ? 2 : 3, 0);
      if (bfd_target_elf_flavour == bfd_target_elf_flavour)
        record_alignment (new_seg, 4);
      else
        record_alignment (new_seg, *args == 'l' ? 2 : 3);
      if (seg == now_seg)
        as_bad ("Can't use floating point insn in this section");



      offset_expr.X_op = O_symbol;
      offset_expr.X_add_symbol =
        symbol_new ("L0\001", now_seg,
      (valueT) frag_now_fix (), frag_now);
      offset_expr.X_add_number = 0;


      p = frag_more ((int) length);
      memcpy (p, temp, length);


      subseg_set (seg, subseg);
    }
       }
       continue;

     case 'i':
     case 'j':
       imm_reloc = BFD_RELOC_LO16;
       c = my_getSmallExpression (&imm_expr, s);
       if (c)
  {
    if (c != 'l')
      {
        if (imm_expr.X_op == O_constant)
   imm_expr.X_add_number =
     (imm_expr.X_add_number >> 16) & 0xffff;
        else if (c == 'h')
   imm_reloc = BFD_RELOC_HI16_S;
        else
   imm_reloc = BFD_RELOC_HI16;
      }
  }
       else if (imm_expr.X_op != O_big)
  check_absolute_expr (ip, &imm_expr);
       if (*args == 'i')
  {
    if (imm_expr.X_op == O_big
        || imm_expr.X_add_number < 0
        || imm_expr.X_add_number >= 0x10000)
      {
        if (insn + 1 < &mips_opcodes[bfd_mips_num_opcodes] &&
     !strcmp (insn->name, insn[1].name))
   break;
        as_bad ("16 bit expression not in range 0..65535");
      }
  }
       else
  {
    int more;
    offsetT max;
    more = (insn + 1 < &mips_opcodes[bfd_mips_num_opcodes] &&
     strcmp (insn->name, insn[1].name) == 0);
    if (more)
      max = 0x8000;
    else
      max = 0x10000;
    if (imm_expr.X_op == O_big
        || imm_expr.X_add_number < -0x8000
        || imm_expr.X_add_number >= max
        || (more
     && imm_expr.X_add_number < 0
     && mips_isa >= 3
     && imm_expr.X_unsigned
     && sizeof (imm_expr.X_add_number) <= 4))
      {
        if (more)
   break;
        as_bad ("16 bit expression not in range -32768..32767");
      }
  }
       s = expr_end;
       continue;

     case 'o':
       c = my_getSmallExpression (&offset_expr, s);
       if (c == 0
    && (offset_expr.X_op != O_constant
        || offset_expr.X_add_number >= 0x8000
        || offset_expr.X_add_number < -0x8000)
    && (mips_pic != EMBEDDED_PIC
        || offset_expr.X_op != O_subtract
        || now_seg != text_section
        || (S_GET_SEGMENT (offset_expr.X_op_symbol)
     != text_section)))
  break;

       offset_reloc = BFD_RELOC_LO16;
       if (c == 'h' || c == 'H')
  {
    ((offset_expr.X_op == O_constant) ? 0 : (as_assert ("targ-cpu.c", 5483, ((char*)0)), 0));
    offset_expr.X_add_number =
      (offset_expr.X_add_number >> 16) & 0xffff;
  }
       s = expr_end;
       continue;

     case 'p':
       offset_reloc = BFD_RELOC_16_PCREL_S2;
       my_getExpression (&offset_expr, s);
       s = expr_end;
       continue;

     case 'u':
       c = my_getSmallExpression (&imm_expr, s);
       if (imm_expr.X_op == O_constant
    && (imm_expr.X_add_number < 0
        || imm_expr.X_add_number >= 0x10000))
  as_bad ("lui expression not in range 0..65535");
       imm_reloc = BFD_RELOC_LO16;
       if (c)
  {
    if (c != 'l')
      {
        if (imm_expr.X_op == O_constant)
   imm_expr.X_add_number =
     (imm_expr.X_add_number >> 16) & 0xffff;
        else if (c == 'h')
   imm_reloc = BFD_RELOC_HI16_S;
        else
   imm_reloc = BFD_RELOC_HI16;
      }
  }
       s = expr_end;
       continue;

     case 'a':
       my_getExpression (&offset_expr, s);
       s = expr_end;
       offset_reloc = BFD_RELOC_MIPS_JMP;
       continue;

     case 'N':
     case 'M':
       my_getExpression (&imm_expr, s);
       check_absolute_expr (ip, &imm_expr);
              if ((unsigned long) imm_expr.X_add_number > 7)
  {
                  as_warn ("Condition code > 7 (%ld)",
      (long) imm_expr.X_add_number);
                  imm_expr.X_add_number &= 7;
  }
       if (*args == 'N')
  ip->insn_opcode |= imm_expr.X_add_number << 18;
       else
  ip->insn_opcode |= imm_expr.X_add_number << 8;
              imm_expr.X_op = O_absent;
              s = expr_end;
              continue;

     default:
       fprintf (
               (__acrt_iob_func(2))
                     , "bad char = '%c'\n", *args);
       as_fatal ("internal Error, line %d, %s", 5545, "targ-cpu.c");
     }
   break;
 }

      if (insn + 1 < &mips_opcodes[bfd_mips_num_opcodes] &&
   !strcmp (insn->name, insn[1].name))
 {
   ++insn;
   s = argsStart;
   continue;
 }
      insn_error = "ERROR: Illegal operands";
      return;
    }
}




static int
my_getSmallExpression(expressionS *ep, char *str) asm("_my_getSmallExpression");
static int
my_getSmallExpression(expressionS *ep, char *str)
{
  char *sp;
  int c = 0;

  if (*str == ' ')
    str++;
  if (*str == '('
      || (*str == '%' &&
   ((str[1] == 'h' && str[2] == 'i')
    || (str[1] == 'H' && str[2] == 'I')
    || (str[1] == 'l' && str[2] == 'o'))
   && str[3] == '('))
    {
      if (*str == '(')
 c = 0;
      else
 {
   c = str[1];
   str += 3;
 }







      for (sp = str; *sp && *sp != ','; sp++)
 ;
      if (sp - 4 >= str && sp[-1] == ')')
 {
   if (isalnum (sp[-2]))
     {
       for (sp -= 3; sp >= str && isalnum (*sp); sp--)
  ;
       if (*sp == '$' && sp > str && sp[-1] == '(')
  {
    sp--;
    goto do_it;
  }
     }
   else if (sp - 5 >= str
     && sp[-5] == '('
     && sp[-4] == '$'
     && ((sp[-3] == 'f' && sp[-2] == 'p')
         || (sp[-3] == 's' && sp[-2] == 'p')
         || (sp[-3] == 'g' && sp[-2] == 'p')
         || (sp[-3] == 'a' && sp[-2] == 't')))
     {
       sp -= 5;
     do_it:
       if (sp == str)
  {

    if (c)
      {

        ep->X_op = O_absent;
        expr_end = str - 3;
      }
    else
      {
        ep->X_op = O_constant;
        expr_end = sp;
      }
    ep->X_add_symbol = 
                      ((void *)0)
                          ;
    ep->X_op_symbol = 
                     ((void *)0)
                         ;
    ep->X_add_number = 0;
  }
       else
  {
    *sp = '\0';
    my_getExpression (ep, str);
    *sp = '(';
  }
       return c;
     }
 }
    }
  my_getExpression (ep, str);
  return c;
}

static void
my_getExpression(expressionS *ep, char *str) asm("_my_getExpression");
static void
my_getExpression(expressionS *ep, char *str)
{
  char *save_in;

  save_in = input_line_pointer;
  input_line_pointer = str;
  expr (0, ep);
  expr_end = input_line_pointer;
  input_line_pointer = save_in;
}






char *
md_atof(int type, char *litP, int *sizeP) asm("_md_atof");
char *
md_atof(int type, char *litP, int *sizeP)
{
  int prec;
  LITTLENUM_TYPE words[4];
  char *t;
  int i;

  switch (type)
    {
    case 'f':
      prec = 2;
      break;

    case 'd':
      prec = 4;
      break;

    default:
      *sizeP = 0;
      return "bad call to md_atof";
    }

  t = atof_ieee (input_line_pointer, type, words);
  if (t)
    input_line_pointer = t;

  *sizeP = prec * 2;

  if (byte_order == 1234)
    {
      for (i = prec - 1; i >= 0; i--)
 {
   md_number_to_chars (litP, (valueT) words[i], 2);
   litP += 2;
 }
    }
  else
    {
      for (i = 0; i < prec; i++)
 {
   md_number_to_chars (litP, (valueT) words[i], 2);
   litP += 2;
 }
    }

  return 
        ((void *)0)
            ;
}

void
md_number_to_chars(char *buf, valueT val, int n) asm("_md_number_to_chars");
void
md_number_to_chars(char *buf, valueT val, int n)
{
  switch (byte_order)
    {
    case 1234:
      number_to_chars_littleendian (buf, val, n);
      break;

    case 4321:
      number_to_chars_bigendian (buf, val, n);
      break;

    default:
      as_fatal ("internal Error, line %d, %s", 5740, "targ-cpu.c");
    }
}

static int support_64bit_objects(void) asm("_support_64bit_objects");
static int support_64bit_objects(void)
{

  return 0;
}
extern const char *md_shortopts = "O::g::G:";

extern boolean gIrixSymtab;

struct option md_longopts[] = {

  {"mips0", 
           0
                      , 
                        ((void *)0)
                            , (170 + 1)},
  {"mips1", 
           0
                      , 
                        ((void *)0)
                            , (170 + 1)},

  {"mips2", 
           0
                      , 
                        ((void *)0)
                            , (170 + 2)},

  {"mips3", 
           0
                      , 
                        ((void *)0)
                            , (170 + 3)},

  {"mips4", 
           0
                      , 
                        ((void *)0)
                            , (170 + 4)},

  {"mcpu", 
          1
                           , 
                             ((void *)0)
                                 , (170 + 5)},

  {"membedded-pic", 
                   0
                              , 
                                ((void *)0)
                                    , (170 + 6)},

  {"trap", 
          0
                     , 
                       ((void *)0)
                           , (170 + 9)},
  {"no-break", 
              0
                         , 
                           ((void *)0)
                               , (170 + 9)},

  {"break", 
           0
                      , 
                        ((void *)0)
                            , (170 + 10)},
  {"no-trap", 
             0
                        , 
                          ((void *)0)
                              , (170 + 10)},

  {"EB", 
        0
                   , 
                     ((void *)0)
                         , (170 + 11)},

  {"EL", 
        0
                   , 
                     ((void *)0)
                         , (170 + 12)},

  {"m4650", 
           0
                      , 
                        ((void *)0)
                            , (170 + 13)},

  {"no-m4650", 
              0
                         , 
                           ((void *)0)
                               , (170 + 14)},

  {"m4010", 
           0
                      , 
                        ((void *)0)
                            , (170 + 15)},

  {"no-m4010", 
              0
                         , 
                           ((void *)0)
                               , (170 + 16)},

  {"m4100", 
           0
                      , 
                        ((void *)0)
                            , (170 + 17)},

  {"no-m4100", 
              0
                         , 
                           ((void *)0)
                               , (170 + 18)},
  {"KPIC", 
          0
                     , 
                       ((void *)0)
                           , (170 + 7)},
  {"call_shared", 
                 0
                            , 
                              ((void *)0)
                                  , (170 + 7)},
  {"non_shared", 
                0
                           , 
                             ((void *)0)
                                 , (170 + 8)},
  {"irix-symtab", 
                 0
                            , 
                              ((void *)0)
                                  , (170 + 19)},
  {"32", 
        0
                   , 
                     ((void *)0)
                         , (170 + 20)},
  {"mabi", 
          1
                           , 
                             ((void *)0)
                                 , (170 + 21)},
  {"n32", 
         0
                    , 
                      ((void *)0)
                          , (170 + 22)},
  {"64", 
        0
                   , 
                     ((void *)0)
                         , (170 + 23)},


  {
  ((void *)0)
      , 
        0
                   , 
                     ((void *)0)
                         , 0}
};
size_t md_longopts_size = sizeof(md_longopts);

int
md_parse_option(int c, char *arg) asm("_md_parse_option");
int
md_parse_option(int c, char *arg)
{
  switch (c)
    {
    case (170 + 9):
      mips_trap = 1;
      break;

    case (170 + 10):
      mips_trap = 0;
      break;

    case (170 + 11):
      target_big_endian = 1;
      break;

    case (170 + 12):
      target_big_endian = 0;
      break;

    case 'O':
      if (arg && arg[1] == '0')
 mips_optimize = 1;
      else
 mips_optimize = 2;
      break;

    case 'g':
      if (arg == 
                ((void *)0)
                    )
 mips_debug = 2;
      else
 mips_debug = atoi (arg);



      if (mips_debug == 2)
 mips_optimize = 0;
      break;

    case (170 + 1):
      mips_isa = 1;
      if (mips_cpu == -1)
 mips_cpu = 3000;
      break;

    case (170 + 2):
      mips_isa = 2;
      if (mips_cpu == -1)
 mips_cpu = 6000;
      break;

    case (170 + 3):
      mips_isa = 2;
      if (mips_cpu == -1)
 mips_cpu = 6000;
      break;

    case (170 + 4):
      mips_isa = 4;
      if (mips_cpu == -1)
 mips_cpu = 8000;
      break;

    case (170 + 5):
      {
 char *p;


 p = arg;
 if (strcmp (p, "default") == 0
     || strcmp (p, "DEFAULT") == 0)
   mips_cpu = -1;
 else
   {
     int sv = 0;



     if (*p == 'v' || *p == 'V')
       {
  sv = 1;
  p++;
       }

     if (*p == 'r' || *p == 'R')
       p++;

     mips_cpu = -1;
     switch (*p)
       {
       case '1':
  if (strcmp (p, "10000") == 0
      || strcmp (p, "10k") == 0
      || strcmp (p, "10K") == 0)
    mips_cpu = 10000;
  break;

       case '2':
  if (strcmp (p, "2000") == 0
      || strcmp (p, "2k") == 0
      || strcmp (p, "2K") == 0)
    mips_cpu = 2000;
  break;

       case '3':
  if (strcmp (p, "3000") == 0
      || strcmp (p, "3k") == 0
      || strcmp (p, "3K") == 0)
    mips_cpu = 3000;
  break;

       case '4':
  if (strcmp (p, "4000") == 0
      || strcmp (p, "4k") == 0
      || strcmp (p, "4K") == 0)
    mips_cpu = 4000;
  else if (strcmp (p, "4100") == 0)
                  {
                    mips_cpu = 4100;
                    if (mips_4100 < 0)
                      mips_4100 = 1;
                  }
  else if (strcmp (p, "4300") == 0)
    mips_cpu = 4300;
  else if (strcmp (p, "4400") == 0)
    mips_cpu = 4400;
  else if (strcmp (p, "4600") == 0)
    mips_cpu = 4600;
  else if (strcmp (p, "4650") == 0)
    {
      mips_cpu = 4650;
      if (mips_4650 < 0)
        mips_4650 = 1;
    }
  else if (strcmp (p, "4010") == 0)
    {
      mips_cpu = 4010;
      if (mips_4010 < 0)
        mips_4010 = 1;
    }
  break;

       case '6':
  if (strcmp (p, "6000") == 0
      || strcmp (p, "6k") == 0
      || strcmp (p, "6K") == 0)
    mips_cpu = 6000;
  break;

       case '8':
  if (strcmp (p, "8000") == 0
      || strcmp (p, "8k") == 0
      || strcmp (p, "8K") == 0)
    mips_cpu = 8000;
  break;

       case 'o':
  if (strcmp (p, "orion") == 0)
    mips_cpu = 4600;
  break;
       }

     if (sv && mips_cpu != 4300 && mips_cpu != 4100)
       {
  as_bad ("ignoring invalid leading 'v' in -mcpu=%s switch", arg);
  return 0;
       }

     if (mips_cpu == -1)
       {
  as_bad ("invalid architecture -mcpu=%s", arg);
  return 0;
       }
   }
      }
      break;

    case (170 + 13):
      mips_4650 = 1;
      break;

    case (170 + 14):
      mips_4650 = 0;
      break;

    case (170 + 15):
      mips_4010 = 1;
      break;

    case (170 + 16):
      mips_4010 = 0;
      break;

    case (170 + 17):
      mips_4100 = 1;
      break;

    case (170 + 18):
      mips_4100 = 0;
      break;

    case (170 + 6):
      mips_pic = EMBEDDED_PIC;
      if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour) && g_switch_seen)
 {
   as_bad ("-G may not be used with embedded PIC code");
   return 0;
 }
      g_switch_value = 0x7fffffff;
      break;




    case (170 + 7):
      if (bfd_target_elf_flavour != bfd_target_elf_flavour)
 {
   as_bad ("-call_shared is supported only for ELF format");
   return 0;
 }
      mips_pic = SVR4_PIC;
      if (g_switch_seen && g_switch_value != 0)
 {
   as_bad ("-G may not be used with SVR4 PIC code");
   return 0;
 }
      g_switch_value = 0;
      break;

    case (170 + 8):
      if (bfd_target_elf_flavour != bfd_target_elf_flavour)
 {
   as_bad ("-non_shared is supported only for ELF format");
   return 0;
 }
      mips_pic = NO_PIC;
      break;

    case 'G':
      if (! (bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
 {
   as_bad ("-G is not supported for this configuration");
   return 0;
 }
      else if (mips_pic == SVR4_PIC || mips_pic == EMBEDDED_PIC)
 {
   as_bad ("-G may not be used with SVR4 or embedded PIC code");
   return 0;
 }
      else
 g_switch_value = atoi (arg);
      g_switch_seen = 1;
      break;



    case (170 + 20):
      mips_abi = O32_ABI;
      break;

    case (170 + 22):
      mips_abi = N32_ABI;
      break;

    case (170 + 23):
      mips_abi = N64_ABI;
      if (!support_64bit_objects())
 as_fatal (("no compiled in support for 64 bit object file format"));
      break;

    case (170 + 21):
      if (strcmp (arg, "32") == 0)
 mips_abi = O32_ABI;
      else if (strcmp (arg, "o64") == 0)
 mips_abi = O64_ABI;
      else if (strcmp (arg, "n32") == 0)
 mips_abi = N32_ABI;
      else if (strcmp (arg, "64") == 0)
 {
   mips_abi = N64_ABI;
   if (! support_64bit_objects())
     as_fatal (("no compiled in support for 64 bit object file " "format")
            );
 }
      else if (strcmp (arg, "eabi") == 0)
 mips_abi = EABI_ABI;
      else
 {
   as_fatal (("invalid abi -mabi=%s"), arg);
   return 0;
 }
      break;

    case (170 + 19):
      gIrixSymtab = cxx_true;
      break;

    default:
      return 0;
    }

  return 1;
}

void
md_show_usage(FILE *stream) asm("_md_show_usage");
void
md_show_usage(FILE *stream)
{
  fprintf(stream, "MIPS options:\n-membedded-pic		generate embedded position independent code\n-EB			generate big endian output\n-EL			generate little endian output\n-g, -g2			do not remove uneeded NOPs or swap branches\n-G NUM			allow referencing objects up to NUM bytes\n			implicitly with the gp register [default 8]\n");







  fprintf(stream, "-mips1, -mcpu=r{2,3}000	generate code for r2000 and r3000\n-mips2, -mcpu=r6000	generate code for r6000\n-mips3, -mcpu=r4000	generate code for r4000\n-mips4, -mcpu=r8000	generate code for r8000\n-mcpu=vr4300		generate code for vr4300\n-m4650			permit R4650 instructions\n-no-m4650		do not permit R4650 instructions\n-m4010			permit R4010 instructions\n-no-m4010		do not permit R4010 instructions\n-m4100                  permit VR4100 instructions\n-no-m4100		do not permit VR4100 instructions\n");
  fprintf(stream, "-O0			remove unneeded NOPs, do not swap branches\n-O			remove unneeded NOPs and swap branches\n--trap, --no-break	trap exception on div by 0 and mult overflow\n--break, --no-trap	break exception on div by 0 and mult overflow\n");





  fprintf(stream, "-KPIC, -call_shared	generate SVR4 position independent code\n-non_shared		do not generate position independent code\n-irix-symtab		create elfs with broken irix symtab\n");




}

void
mips_init_after_args(void) asm("_mips_init_after_args");
void
mips_init_after_args(void)
{
  if (target_big_endian)
    byte_order = 4321;
  else
    byte_order = 1234;
}

long
md_pcrel_from(fixS *fixP) asm("_md_pcrel_from");
long
md_pcrel_from(fixS *fixP)
{
  if (bfd_target_elf_flavour != bfd_target_aout_flavour
      && fixP->fx_addsy != (symbolS *) 
                                      ((void *)0)
      
     && ! S_IS_DEFINED (fixP->fx_addsy))
    {


      return 4;
    }


  return fixP->fx_size + fixP->fx_where + fixP->fx_frag->fr_address;
}





void
cons_fix_new_mips(fragS *frag, int where, unsigned int nbytes, expressionS *exp) asm("_cons_fix_new_mips");
void
cons_fix_new_mips(fragS *frag, int where, unsigned int nbytes, expressionS *exp)
{




  if (nbytes == 8)
    {
      if (byte_order == 4321)
 where += 4;
      nbytes = 4;
    }

  if (nbytes != 2 && nbytes != 4)
    as_bad ("Unsupported reloc size %d", nbytes);

  fix_new_exp (frag_now, where, (int) nbytes, exp, 0,
        nbytes == 2 ? BFD_RELOC_16 : BFD_RELOC_32);
}
int
mips_force_relocation(fixS *fixp) asm("_mips_force_relocation");
int
mips_force_relocation(fixS *fixp)
{
  return (mips_pic == EMBEDDED_PIC
   && (fixp->fx_pcrel
       || ((fixp)->fx_r_type == BFD_RELOC_32 && (fixp)->fx_addsy != 
         ((void *)0) 
         && (fixp)->fx_subsy != 
         ((void *)0) 
         && S_GET_SEGMENT ((fixp)->fx_addsy) == text_section && S_GET_SEGMENT ((fixp)->fx_subsy) == text_section)
       || fixp->fx_r_type == BFD_RELOC_PCREL_HI16_S
       || fixp->fx_r_type == BFD_RELOC_PCREL_LO16));
}



int
md_apply_fix(fixS *fixP, valueT *valueP) asm("_md_apply_fix");
int
md_apply_fix(fixS *fixP, valueT *valueP)
{
  unsigned char *buf;
  long insn, value;

  ((fixP->fx_size == 4 || fixP->fx_r_type == BFD_RELOC_16) ? 0 : (as_assert ("targ-cpu.c", 6249, ((char*)0)), 0));

  value = *valueP;
  fixP->fx_addnumber = value;

  if (fixP->fx_addsy == 
                       ((void *)0) 
                            && ! fixP->fx_pcrel)
    fixP->fx_done = 1;

  switch (fixP->fx_r_type)
    {
    case BFD_RELOC_MIPS_JMP:
    case BFD_RELOC_HI16:
    case BFD_RELOC_HI16_S:
    case BFD_RELOC_GPREL16:
    case BFD_RELOC_MIPS_LITERAL:
    case BFD_RELOC_MIPS_CALL16:
    case BFD_RELOC_MIPS_GOT16:
    case BFD_RELOC_GPREL32:
      if (fixP->fx_pcrel)
 as_bad_where (fixP->fx_file, fixP->fx_line,
        "Invalid PC relative reloc");

      break;

    case BFD_RELOC_PCREL_HI16_S:


      if ((fixP->fx_addsy->bsym->flags & 0x100) == 0)
 {



   value += (fixP->fx_next->fx_frag->fr_address
      + fixP->fx_next->fx_where);
 }
      if (value & 0x8000)
 value += 0x10000;
      value >>= 16;
      buf = (unsigned char *) fixP->fx_frag->fr_literal + fixP->fx_where;
      if (byte_order == 4321)
 buf += 2;
      md_number_to_chars (buf, value, 2);
      break;

    case BFD_RELOC_PCREL_LO16:


      if ((fixP->fx_addsy->bsym->flags & 0x100) == 0)
 value += fixP->fx_frag->fr_address + fixP->fx_where;
      buf = (unsigned char *) fixP->fx_frag->fr_literal + fixP->fx_where;
      if (byte_order == 4321)
 buf += 2;
      md_number_to_chars (buf, value, 2);
      break;

    case BFD_RELOC_32:





      if (fixP->fx_done
   || (mips_pic == EMBEDDED_PIC && ((fixP)->fx_r_type == BFD_RELOC_32 && (fixP)->fx_addsy != 
                                  ((void *)0) 
                                  && (fixP)->fx_subsy != 
                                  ((void *)0) 
                                  && S_GET_SEGMENT ((fixP)->fx_addsy) == text_section && S_GET_SEGMENT ((fixP)->fx_subsy) == text_section)))
 md_number_to_chars (fixP->fx_frag->fr_literal + fixP->fx_where,
       value, 4);
      break;

    case BFD_RELOC_16:


      ((fixP->fx_size == 2) ? 0 : (as_assert ("targ-cpu.c", 6319, ((char*)0)), 0));
      if (fixP->fx_done)
 md_number_to_chars (fixP->fx_frag->fr_literal + fixP->fx_where,
       value, 2);
      break;

    case BFD_RELOC_LO16:


      if (fixP->fx_done)
 {
   if (value < -0x8000 || value > 0x7fff)
     as_bad_where (fixP->fx_file, fixP->fx_line,
     "relocation overflow");
   buf = (unsigned char *) fixP->fx_frag->fr_literal + fixP->fx_where;
   if (byte_order == 4321)
     buf += 2;
   md_number_to_chars (buf, value, 2);
 }
      break;

    case BFD_RELOC_16_PCREL_S2:





      if (value & 0x3)
 as_warn_where (fixP->fx_file, fixP->fx_line,
         "Branch to odd address (%lx)", value);
      value >>= 2;


      buf = (unsigned char *) (fixP->fx_where + fixP->fx_frag->fr_literal);
      switch (byte_order)
 {
 case 1234:
   insn = (buf[3] << 24) | (buf[2] << 16) | (buf[1] << 8) | buf[0];
   break;

 case 4321:
   insn = (buf[0] << 24) | (buf[1] << 16) | (buf[2] << 8) | buf[3];
   break;

 default:
   as_fatal ("internal Error, line %d, %s", 6364, "targ-cpu.c");
   return 0;
 }

      if (value >= -0x8000 && value < 0x8000)
 insn |= value & 0xffff;
      else
 {



   if (mips_pic == NO_PIC
       && fixP->fx_done
       && fixP->fx_frag->fr_address >= text_section->vma
       && (fixP->fx_frag->fr_address
    < text_section->vma + text_section->_raw_size)
       && ((insn & 0xffff0000) == 0x10000000
    || (insn & 0xffff0000) == 0x04010000
    || (insn & 0xffff0000) == 0x04110000))
     {
       if ((insn & 0xffff0000) == 0x04110000)
  insn = 0x0c000000;
       else
  insn = 0x08000000;
       fixP->fx_r_type = BFD_RELOC_MIPS_JMP;
       fixP->fx_done = 0;
       fixP->fx_addsy = section_symbol (text_section);
       fixP->fx_addnumber = (value << 2) + md_pcrel_from (fixP);
     }
   else
     {







       as_bad_where (fixP->fx_file, fixP->fx_line,
       "Relocation overflow");
     }
 }

      md_number_to_chars ((char *) buf, (valueT) insn, 4);
      break;

    default:
      as_fatal ("internal Error, line %d, %s", 6411, "targ-cpu.c");
    }

  return 1;
}
static symbolS *
get_symbol(void) asm("_get_symbol");
static symbolS *
get_symbol(void)
{
  int c;
  char *name;
  symbolS *p;

  name = input_line_pointer;
  c = get_symbol_end ();
  p = (symbolS *) symbol_find_or_make (name);
  *input_line_pointer = c;
  return p;
}




static void
mips_align(int to, int fill, symbolS *label) asm("_mips_align");
static void
mips_align(int to, int fill, symbolS *label)
{
  mips_emit_delays ();
  frag_align (to, fill);
  record_alignment (now_seg, to);
  if (label != 
              ((void *)0)
                  )
    {
      ((S_GET_SEGMENT (label) == now_seg) ? 0 : (as_assert ("targ-cpu.c", 6533, ((char*)0)), 0));
      label->sy_frag = frag_now;
      S_SET_VALUE (label, (valueT) frag_now_fix ());
    }
}




static void
s_align(int x) asm("_s_align");
static void
s_align(int x)
{
  register int temp;
  register long temp_fill;
  long max_alignment = 15;
  temp = get_absolute_expression ();
  if (temp > max_alignment)
    as_bad ("Alignment too large: %d. assumed.", temp = max_alignment);
  else if (temp < 0)
    {
      as_warn ("Alignment negative: 0 assumed.");
      temp = 0;
    }
  if (*input_line_pointer == ',')
    {
      input_line_pointer++;
      temp_fill = get_absolute_expression ();
    }
  else
    temp_fill = 0;
  if (temp)
    {
      auto_align = 1;
      mips_align (temp, (int) temp_fill, insn_label);
    }
  else
    {
      auto_align = 0;
    }

  demand_empty_rest_of_line ();
}

void
mips_flush_pending_output(void) asm("_mips_flush_pending_output");
void
mips_flush_pending_output(void)
{
  mips_emit_delays ();
  insn_label = 
              ((void *)0)
                  ;
}

static void
s_change_sec(int sec) asm("_s_change_sec");
static void
s_change_sec(int sec)
{
  segT seg;




  if (mips_pic == EMBEDDED_PIC
      && (sec == 'd' || sec == 'r'))
    sec = 's';

  mips_emit_delays ();
  switch (sec)
    {
    case 't':
      s_text (0);
      break;
    case 'd':
      s_data (0);
      break;
    case 'b':
      subseg_set (bss_section, (subsegT) get_absolute_expression ());
      demand_empty_rest_of_line ();
      break;

    case 'r':
      if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
 {
   seg = subseg_new ((bfd_target_elf_flavour == bfd_target_aout_flavour ? ".data" : bfd_target_elf_flavour == bfd_target_ecoff_flavour ? ".rdata" : bfd_target_elf_flavour == bfd_target_elf_flavour ? ".rodata" : (as_abort ("targ-cpu.c", 6627, ((char*)0)), "")),
       (subsegT) get_absolute_expression ());
   if (bfd_target_elf_flavour == bfd_target_elf_flavour)
     {
       bfd_set_section_flags (stdoutput, seg,
         (0x001
          | 0x002
          | 0x010
          | 0x004
          | 0x040));
       (((seg)->alignment_power = (4)),cxx_true);
     }
   demand_empty_rest_of_line ();
 }
      else
 {
   as_bad ("No read only data section in this object file format");
   demand_empty_rest_of_line ();
   return;
 }
      break;

    case 's':
      if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
 {
   seg = subseg_new (".sdata", (subsegT) get_absolute_expression ());
   if (bfd_target_elf_flavour == bfd_target_elf_flavour)
     {
       bfd_set_section_flags (stdoutput, seg,
         0x001 | 0x002 | 0x004
         | 0x040);
       (((seg)->alignment_power = (4)),cxx_true);
     }
   demand_empty_rest_of_line ();
   break;
 }
      else
 {
   as_bad ("Global pointers not supported; recompile -G 0");
   demand_empty_rest_of_line ();
   return;
 }
    }

  auto_align = 1;
}

void
mips_enable_auto_align(void) asm("_mips_enable_auto_align");
void
mips_enable_auto_align(void)
{
  auto_align = 1;
}

static void
s_cons(int log_size) asm("_s_cons");
static void
s_cons(int log_size)
{
  symbolS *label;

  label = insn_label;
  mips_emit_delays ();
  if (log_size > 0 && auto_align)
    mips_align (log_size, 0, label);
  insn_label = 
              ((void *)0)
                  ;
  cons (1 << log_size);
}

static void
s_mipserr(int x) asm("_s_mipserr");
static void
s_mipserr(int x)
{
  as_fatal ("Encountered `.err', aborting assembly");
}

static void
s_float_cons(int type) asm("_s_float_cons");
static void
s_float_cons(int type)
{
  symbolS *label;

  label = insn_label;

  mips_emit_delays ();

  if (auto_align)
    if (type == 'd')
      mips_align (3, 0, label);
    else
      mips_align (2, 0, label);

  insn_label = 
              ((void *)0)
                  ;

  float_cons (type);
}







static void
s_mips_globl(int x) asm("_s_mips_globl");
static void
s_mips_globl(int x)
{
  char *name;
  int c;
  symbolS *symbolP;

  name = input_line_pointer;
  c = get_symbol_end ();
  symbolP = symbol_find_or_make (name);
  *input_line_pointer = c;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (! is_end_of_line[(unsigned char) *input_line_pointer])
    {
      char *secname;
      asection *sec;

      secname = input_line_pointer;
      c = get_symbol_end ();
      sec = bfd_get_section_by_name (stdoutput, secname);
      if (sec == 
                ((void *)0)
                    )
 as_bad ("%s: no such section", secname);
      *input_line_pointer = c;

      if (sec != 
                ((void *)0) 
                     && (sec->flags & 0x020) != 0)
 symbolP->bsym->flags |= 0x10;
    }

  S_SET_EXTERNAL (symbolP);
  demand_empty_rest_of_line ();
}

static void
s_option(int x) asm("_s_option");
static void
s_option(int x)
{
  char *opt;
  char c;

  opt = input_line_pointer;
  c = get_symbol_end ();

  if (*opt == 'O')
    {

    }
  else if (strncmp (opt, "pic", 3) == 0)
    {
      int i;

      i = atoi (opt + 3);
      if (i == 0)
 mips_pic = NO_PIC;
      else if (i == 2)
 mips_pic = SVR4_PIC;
      else
 as_bad (".option pic%d not supported", i);

      if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour) && mips_pic == SVR4_PIC)
 {
   if (g_switch_seen && g_switch_value != 0)
     as_warn ("-G may not be used with SVR4 PIC code");
   g_switch_value = 0;
   bfd_set_gp_size (stdoutput, 0);
 }
    }
  else
    as_warn ("Unrecognized option \"%s\"", opt);

  *input_line_pointer = c;
  demand_empty_rest_of_line ();
}

static void
s_mipsset(int x) asm("_s_mipsset");
static void
s_mipsset(int x)
{
  char *name = input_line_pointer, ch;

  while (!is_end_of_line[(unsigned char) *input_line_pointer])
    input_line_pointer++;
  ch = *input_line_pointer;
  *input_line_pointer = '\0';

  if (strcmp (name, "reorder") == 0)
    {
      if (mips_noreorder)
 {
   prev_insn_unreordered = 1;
   prev_prev_insn_unreordered = 1;
 }
      mips_noreorder = 0;
    }
  else if (strcmp (name, "noreorder") == 0)
    {
      mips_emit_delays ();
      mips_noreorder = 1;
      mips_any_noreorder = 1;
    }
  else if (strcmp (name, "at") == 0)
    {
      mips_noat = 0;
    }
  else if (strcmp (name, "noat") == 0)
    {
      mips_noat = 1;
    }
  else if (strcmp (name, "macro") == 0)
    {
      mips_warn_about_macros = 0;
    }
  else if (strcmp (name, "nomacro") == 0)
    {
      if (mips_noreorder == 0)
 as_bad ("`noreorder' must be set before `nomacro'");
      mips_warn_about_macros = 1;
    }
  else if (strcmp (name, "move") == 0 || strcmp (name, "novolatile") == 0)
    {
      mips_nomove = 0;
    }
  else if (strcmp (name, "nomove") == 0 || strcmp (name, "volatile") == 0)
    {
      mips_nomove = 1;
    }
  else if (strcmp (name, "bopt") == 0)
    {
      mips_nobopt = 0;
    }
  else if (strcmp (name, "nobopt") == 0)
    {
      mips_nobopt = 1;
    }
  else if (strncmp (name, "mips", 4) == 0)
    {
      int isa;



      isa = atoi (name + 4);
      if (isa == 0)
 mips_isa = file_mips_isa;
      else if (isa < 1 || isa > 4)
 as_bad ("unknown ISA level");
      else
 mips_isa = isa;
    }
  else
    {
 *input_line_pointer = ch;
 input_line_pointer = name;
 s_set(x);
 return;
    }
  *input_line_pointer = ch;
  demand_empty_rest_of_line ();
}




static void
s_abicalls(int ignore) asm("_s_abicalls");
static void
s_abicalls(int ignore)
{
  mips_pic = SVR4_PIC;
  if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
    {
      if (g_switch_seen && g_switch_value != 0)
 as_warn ("-G may not be used with SVR4 PIC code");
      g_switch_value = 0;
    }
  bfd_set_gp_size (stdoutput, 0);
  demand_empty_rest_of_line ();
}
static void
s_cpload(int ignore) asm("_s_cpload");
static void
s_cpload(int ignore)
{
  expressionS ex;
  int icnt = 0;


  if (mips_pic != SVR4_PIC)
    {
      s_ignore (0);
      return;
    }


  if (mips_noreorder == 0)
    as_warn (".cpload not in noreorder section");

  ex.X_op = O_symbol;
  ex.X_add_symbol = symbol_find_or_make ("_gp_disp");
  ex.X_op_symbol = 
                  ((void *)0)
                      ;
  ex.X_add_number = 0;

  macro_build_lui ((char *) 
                           ((void *)0)
                               , &icnt, &ex, 28);
  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, &ex, "addiu", "t,r,j", 28, 28,
        (int) BFD_RELOC_LO16);

  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, (expressionS *) 
                                                    ((void *)0)
                                                        , "addu", "d,v,t",
        28, 28, tc_get_register (0));

  demand_empty_rest_of_line ();
}





static void
s_cprestore(int ignore) asm("_s_cprestore");
static void
s_cprestore(int ignore)
{
  expressionS ex;
  int icnt = 0;


  if (mips_pic != SVR4_PIC)
    {
      s_ignore (0);
      return;
    }

  mips_cprestore_offset = get_absolute_expression ();

  ex.X_op = O_constant;
  ex.X_add_symbol = 
                   ((void *)0)
                       ;
  ex.X_op_symbol = 
                  ((void *)0)
                      ;
  ex.X_add_number = mips_cprestore_offset;

  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, &ex,
        mips_isa < 3 ? "sw" : "sd",
        "t,o(b)", 28, (int) BFD_RELOC_LO16, 29);

  demand_empty_rest_of_line ();
}




static void
s_gpword(int ignore) asm("_s_gpword");
static void
s_gpword(int ignore)
{
  symbolS *label;
  expressionS ex;
  char *p;


  if (mips_pic != SVR4_PIC)
    {
      s_cons (2);
      return;
    }

  label = insn_label;
  mips_emit_delays ();
  if (auto_align)
    mips_align (2, 0, label);
  insn_label = 
              ((void *)0)
                  ;

  expr (0, &ex);

  if (ex.X_op != O_symbol || ex.X_add_number != 0)
    {
      as_bad ("Unsupported use of .gpword");
      ignore_rest_of_line ();
    }

  p = frag_more (4);
  md_number_to_chars (p, (valueT) 0, 4);
  fix_new_exp (frag_now, p - frag_now->fr_literal, 4, &ex, 0,
        BFD_RELOC_GPREL32);

  demand_empty_rest_of_line ();
}




static void
s_cpadd(int ignore) asm("_s_cpadd");
static void
s_cpadd(int ignore)
{
  int icnt = 0;
  int reg;


  if (mips_pic != SVR4_PIC)
    {
      s_ignore (0);
      return;
    }


  reg = tc_get_register (0);
  macro_build ((char *) 
                       ((void *)0)
                           , &icnt, (expressionS *) 
                                                    ((void *)0)
                                                        ,
        mips_isa < 3 ? "addu" : "daddu",
        "d,v,t", reg, reg, 28);

  demand_empty_rest_of_line ();
}





int
tc_get_register(int frame) asm("_tc_get_register");
int
tc_get_register(int frame)
{
  int reg;

  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (*input_line_pointer++ != '$')
    {
      as_warn ("expected `$'");
      reg = 0;
    }
  else if (isdigit ((unsigned char) *input_line_pointer))
    {
      reg = get_absolute_expression ();
      if (reg < 0 || reg >= 32)
 {
   as_warn ("Bad register number");
   reg = 0;
 }
    }
  else
    {
      if (strncmp (input_line_pointer, "fp", 2) == 0)
 reg = 30;
      else if (strncmp (input_line_pointer, "sp", 2) == 0)
 reg = 29;
      else if (strncmp (input_line_pointer, "gp", 2) == 0)
 reg = 28;
      else if (strncmp (input_line_pointer, "at", 2) == 0)
 reg = 1;
      else
 {
   as_warn ("Unrecognized register name");
   reg = 0;
 }
      input_line_pointer += 2;
    }
  if (frame)
    mips_frame_reg = reg != 0 ? reg : 29;
  return reg;
}

valueT
md_section_align(asection *seg, valueT addr) asm("_md_section_align");
valueT
md_section_align(asection *seg, valueT addr)
{
  int align = ((seg)->alignment_power + 0);

  return ((addr + (1 << align) - 1) & (-1 << align));
}






static int
nopic_need_relax(symbolS *sym) asm("_nopic_need_relax");
static int
nopic_need_relax(symbolS *sym)
{
  if (sym == 0)
    return 0;

  if ((bfd_target_elf_flavour == bfd_target_ecoff_flavour || bfd_target_elf_flavour == bfd_target_elf_flavour))
    {
      const char *symname;
      int change;






      symname = S_GET_NAME (sym);
      if (symname != (const char *) 
                                   ((void *)0)
   
  && (strcmp (symname, "eprol") == 0
       || strcmp (symname, "etext") == 0
       || strcmp (symname, "_gp") == 0
       || strcmp (symname, "edata") == 0
       || strcmp (symname, "_fbss") == 0
       || strcmp (symname, "_fdata") == 0
       || strcmp (symname, "_ftext") == 0
       || strcmp (symname, "end") == 0
       || strcmp (symname, "_gp_disp") == 0))
 change = 1;
      else if (! S_IS_DEFINED (sym)
        && (0




     || (S_GET_VALUE (sym) != 0
         && S_GET_VALUE (sym) <= g_switch_value)))
 change = 0;
      else
 {
   const char *segname;

   segname = ((S_GET_SEGMENT (sym))->name + 0);
   ((strcmp (segname, ".lit8") != 0 && strcmp (segname, ".lit4") != 0) ? 0 : (as_assert ("targ-cpu.c", 7151, ((char*)0)), 0))
                                      ;
   change = (strcmp (segname, ".sdata") != 0
      && strcmp (segname, ".sbss") != 0);
 }
      return change;
    }
  else

    return 1;
}






int
md_estimate_size_before_relax(fragS *fragp, asection *segtype) asm("_md_estimate_size_before_relax");
int
md_estimate_size_before_relax(fragS *fragp, asection *segtype)
{
  int change;

  if (mips_pic == NO_PIC)
    {
      change = nopic_need_relax (fragp->fr_symbol);
    }
  else if (mips_pic == SVR4_PIC)
    {
      asection *symsec = fragp->fr_symbol->bsym->section;


      change = (symsec != &bfd_und_section
  && symsec != &bfd_abs_section
  && ! (((symsec)->flags & 0x8000) != 0));
    }
  else
    as_abort ("targ-cpu.c", 7189, ((char*)0));

  if (change)
    {



      fragp->fr_opcode = (fragp->fr_literal
     + fragp->fr_fix
     - (((fragp->fr_subtype) >> 24) & 0xff)
     + ((bfd_vma)(((fragp->fr_subtype) >> 9) & 0x7f) - 64));

      if (((fragp->fr_subtype) & 1))
 as_warn ("AT used after \".set noat\" or macro used after \".set nomacro\"");
    }

  if (! change)
    return 0;
  else
    return (((fragp->fr_subtype) >> 16) & 0xff) - (((fragp->fr_subtype) >> 24) & 0xff);
}




arelent **
tc_gen_reloc(asection *section, fixS *fixp) asm("_tc_gen_reloc");
arelent **
tc_gen_reloc(asection *section, fixS *fixp)
{
  static arelent *retval[4];
  arelent *reloc;

  reloc = retval[0] = (arelent *) xmalloc (sizeof (arelent));
  retval[1] = 
             ((void *)0)
                 ;

  reloc->sym_ptr_ptr = &fixp->fx_addsy->bsym;
  reloc->address = fixp->fx_frag->fr_address + fixp->fx_where;

  if (mips_pic == EMBEDDED_PIC
      && ((fixp)->fx_r_type == BFD_RELOC_32 && (fixp)->fx_addsy != 
        ((void *)0) 
        && (fixp)->fx_subsy != 
        ((void *)0) 
        && S_GET_SEGMENT ((fixp)->fx_addsy) == text_section && S_GET_SEGMENT ((fixp)->fx_subsy) == text_section))
    {



      reloc->addend = reloc->address - S_GET_VALUE (fixp->fx_subsy);
      if (bfd_target_elf_flavour != bfd_target_ecoff_flavour)
 as_fatal ("Double check fx_r_type in tc-mips.c:tc_gen_reloc");
      fixp->fx_r_type = BFD_RELOC_GPREL32;
    }
  else if (fixp->fx_r_type == BFD_RELOC_PCREL_LO16)
    {

      if (fixp->fx_addsy->bsym->flags & 0x100)
 reloc->addend = reloc->address - S_GET_VALUE (fixp->fx_subsy);
      else
 reloc->addend = fixp->fx_addnumber + reloc->address;
    }
  else if (fixp->fx_r_type == BFD_RELOC_PCREL_HI16_S)
    {
      ((fixp->fx_next != 
     ((void *)0) 
     && fixp->fx_next->fx_r_type == BFD_RELOC_PCREL_LO16) ? 0 : (as_assert ("targ-cpu.c", 7249, ((char*)0)), 0))
                                                           ;



      if (fixp->fx_addsy->bsym->flags & 0x100)
 reloc->addend = (fixp->fx_next->fx_frag->fr_address
    + fixp->fx_next->fx_where
    - S_GET_VALUE (fixp->fx_subsy));
      else
 reloc->addend = (fixp->fx_addnumber
    + fixp->fx_next->fx_frag->fr_address
    + fixp->fx_next->fx_where);
    }
  else if (fixp->fx_pcrel == 0)
    reloc->addend = fixp->fx_addnumber;
  else
    {
      if (bfd_target_elf_flavour != bfd_target_aout_flavour)


 reloc->addend = reloc->address;
      else
 reloc->addend = -reloc->address;
    }



  if (fixp->fx_frag->fr_opcode != 
                                 ((void *)0)
      
     && (fixp->fx_r_type == BFD_RELOC_GPREL16
   || fixp->fx_r_type == BFD_RELOC_MIPS_GOT16
   || fixp->fx_r_type == BFD_RELOC_MIPS_CALL16))
    {
      arelent *reloc2;




      if (fixp->fx_next != 
                          ((void *)0)
   
  && fixp->fx_frag == fixp->fx_next->fx_frag)
 {
   ((fixp->fx_r_type == BFD_RELOC_GPREL16 && fixp->fx_next->fx_r_type == BFD_RELOC_GPREL16) ? 0 : (as_assert ("targ-cpu.c", 7290, ((char*)0)), 0))
                                                        ;
   retval[0] = 
              ((void *)0)
                  ;
   return retval;
 }

      fixp->fx_where = fixp->fx_frag->fr_opcode - fixp->fx_frag->fr_literal;
      reloc->address = fixp->fx_frag->fr_address + fixp->fx_where;
      reloc2 = retval[1] = (arelent *) xmalloc (sizeof (arelent));
      retval[2] = 
                 ((void *)0)
                     ;
      reloc2->sym_ptr_ptr = &fixp->fx_addsy->bsym;
      reloc2->address = (reloc->address
    + (((bfd_vma)(((fixp->fx_frag->fr_subtype) >> 2) & 0x7f) - 64)
       - ((bfd_vma)(((fixp->fx_frag->fr_subtype) >> 9) & 0x7f) - 64)));
      reloc2->addend = fixp->fx_addnumber;
      reloc2->howto = bfd_reloc_type_lookup (stdoutput, BFD_RELOC_LO16);
      ((reloc2->howto != 
     ((void *)0)
     ) ? 0 : (as_assert ("targ-cpu.c", 7306, ((char*)0)), 0));

      if ((((fixp->fx_frag->fr_subtype) >> 1) & 1))
 {
   arelent *reloc3;

   reloc3 = retval[2] = (arelent *) xmalloc (sizeof (arelent));
   retval[3] = 
              ((void *)0)
                  ;
   *reloc3 = *reloc2;
   reloc3->address += 4;
 }

      if (mips_pic == NO_PIC)
 {
   ((fixp->fx_r_type == BFD_RELOC_GPREL16) ? 0 : (as_assert ("targ-cpu.c", 7320, ((char*)0)), 0));
   fixp->fx_r_type = BFD_RELOC_HI16_S;
 }
      else if (mips_pic == SVR4_PIC)
 {
   if (fixp->fx_r_type != BFD_RELOC_MIPS_GOT16)
     {
       ((fixp->fx_r_type == BFD_RELOC_MIPS_CALL16) ? 0 : (as_assert ("targ-cpu.c", 7327, ((char*)0)), 0));
       fixp->fx_r_type = BFD_RELOC_MIPS_GOT16;
     }
 }
      else
 as_abort ("targ-cpu.c", 7332, ((char*)0));
    }




  if (bfd_target_elf_flavour == bfd_target_ecoff_flavour
      && fixp->fx_r_type == BFD_RELOC_16_PCREL_S2
      && mips_pic != EMBEDDED_PIC)
    reloc->howto = 
                  ((void *)0)
                      ;
  else
    reloc->howto = bfd_reloc_type_lookup (stdoutput, fixp->fx_r_type);

  if (reloc->howto == 
                     ((void *)0)
                         )
    {
      as_bad_where (fixp->fx_file, fixp->fx_line,
      "Can not represent relocation in this object file format");
      retval[0] = 
                 ((void *)0)
                     ;
    }

  return retval;
}



void
md_convert_frag(bfd *abfd, segT asec, fragS *fragp) asm("_md_convert_frag");
void
md_convert_frag(bfd *abfd, segT asec, fragS *fragp)
{
  int old, cxx_new;
  char *fixptr;

  if (fragp->fr_opcode == 
                         ((void *)0)
                             )
    return;

  old = (((fragp->fr_subtype) >> 24) & 0xff);
  cxx_new = (((fragp->fr_subtype) >> 16) & 0xff);
  fixptr = fragp->fr_literal + fragp->fr_fix;

  if (cxx_new > 0)
    memmove (fixptr - old, fixptr, cxx_new);

  fragp->fr_fix += cxx_new - old;
}





void
mips_define_label(symbolS *sym) asm("_mips_define_label");
void
mips_define_label(symbolS *sym)
{
  insn_label = sym;
}






int
mips_local_label(const char *name) asm("_mips_local_label");
int
mips_local_label(const char *name)
{
  return (name[0] == '$' || name[0] == '.');
}





void
mips_elf_final_processing(void) asm("_mips_elf_final_processing");
void
mips_elf_final_processing(void)
{
  Elf32_RegInfo s;


  s.ri_gprmask = mips_gprmask;
  s.ri_cprmask[0] = mips_cprmask[0];
  s.ri_cprmask[1] = mips_cprmask[1];
  s.ri_cprmask[2] = mips_cprmask[2];
  s.ri_cprmask[3] = mips_cprmask[3];


  bfd_mips_elf32_swap_reginfo_out (stdoutput, &s,
       ((Elf32_External_RegInfo *)
        mips_regmask_frag));



  if (mips_any_noreorder)
    (((stdoutput) -> tdata.elf_obj_data) -> elf_header)->e_flags |= 0x00000001;
  if (mips_pic != NO_PIC)
    (((stdoutput) -> tdata.elf_obj_data) -> elf_header)->e_flags |= 0x00000002;


  if (mips_abi == O32_ABI)
    (((stdoutput) -> tdata.elf_obj_data) -> elf_header)->e_flags |= 0x00001000;
  else if (mips_abi == O64_ABI)
    (((stdoutput) -> tdata.elf_obj_data) -> elf_header)->e_flags |= 0x00002000;
  else if (mips_abi == EABI_ABI)
    {

    }


}
typedef struct n64_tag_loc
{
  struct n64_tag_loc *loc_next;
  unsigned long loc_fileno;
  unsigned long loc_lineno;
  unsigned long loc_offset;
  unsigned short loc_delta;
  unsigned short loc_count;



}
locS;

typedef struct n64_tag_proc
  {
    struct n64_tag_proc *proc_next;
    struct n64_tag_symbol *proc_isym;
    struct n64_tag_symbol *proc_end;
    unsigned long proc_reg_mask;
    unsigned long proc_reg_offset;
    unsigned long proc_fpreg_mask;
    unsigned long proc_fpreg_offset;
    unsigned long proc_frameoffset;
    unsigned long proc_framereg;
    unsigned long proc_pcreg;
    locS *proc_iline;
    struct n64_tag_file *proc_file;
    int proc_index;
  }
procS;

typedef struct n64_tag_file
  {
    struct n64_tag_file *file_next;
    unsigned long file_fileno;
    struct n64_tag_symbol *file_symbol;
    struct n64_tag_symbol *file_end;
    struct n64_tag_proc *file_proc;
    int file_numprocs;
  }
fileS;

static struct n64_tag_obstack proc_frags;
static procS *proc_lastP;
static procS *proc_rootP;
static int numprocs;

static void
md_obj_begin(void) asm("_md_obj_begin");
static void
md_obj_begin(void)
{
  _obstack_begin ((&proc_frags), (0x2000), 0, (void *(*)(...)) xmalloc, (void (*)(...)) free);
}

static void
md_obj_end(void) asm("_md_obj_end");
static void
md_obj_end(void)
{

  if (proc_lastP && proc_lastP->proc_end == 
                                           ((void *)0)
                                               )
    as_warn ("missing `.end' at end of assembly");
}

static long
get_number(void) asm("_get_number");
static long
get_number(void)
{
  int negative = 0;
  long val = 0;

  if (*input_line_pointer == '-')
    {
      ++input_line_pointer;
      negative = 1;
    }
  if (!isdigit (*input_line_pointer))
    as_bad ("Expected simple number.");
  if (input_line_pointer[0] == '0')
    {
      if (input_line_pointer[1] == 'x')
 {
   input_line_pointer += 2;
   while (isxdigit (*input_line_pointer))
     {
       val <<= 4;
       val |= (_hex_value[(unsigned char) (*input_line_pointer++)]);
     }
   return negative ? -val : val;
 }
      else
 {
   ++input_line_pointer;
   while (isdigit (*input_line_pointer))
     {
       val <<= 3;
       val |= *input_line_pointer++ - '0';
     }
   return negative ? -val : val;
 }
    }
  if (!isdigit (*input_line_pointer))
    {
      printf (" *input_line_pointer == '%c' 0x%02x\n",
       *input_line_pointer, *input_line_pointer);
      as_warn ("Invalid number");
      return -1;
    }
  while (isdigit (*input_line_pointer))
    {
      val *= 10;
      val += *input_line_pointer++ - '0';
    }
  return negative ? -val : val;
}




static void
s_file(int x) asm("_s_file");
static void
s_file(int x)
{
  int line;

  line = get_number ();
  s_app_file (0);
}




static void
s_mipsend(int x) asm("_s_mipsend");
static void
s_mipsend(int x)
{
  symbolS *p;

  if (!is_end_of_line[(unsigned char) *input_line_pointer])
    {
      p = get_symbol ();
      demand_empty_rest_of_line ();
    }
  else
    p = 
       ((void *)0)
           ;
  if (now_seg != text_section)
    as_warn (".end not in text section");
  if (!proc_lastP)
    {
      as_warn (".end and no .ent seen yet.");
      return;
    }

  if (p != 
          ((void *)0)
              )
    {
      ((S_GET_NAME (p)) ? 0 : (as_assert ("targ-cpu.c", 7619, ((char*)0)), 0));
      if (strcmp (S_GET_NAME (p), S_GET_NAME (proc_lastP->proc_isym)))
 as_warn (".end symbol does not match .ent symbol.");
    }

  proc_lastP->proc_end = (symbolS *) 1;
}



static void
s_ent(int aent) asm("_s_ent");
static void
s_ent(int aent)
{
  int number = 0;
  procS *procP;
  symbolS *symbolP;

  symbolP = get_symbol ();
  if (*input_line_pointer == ',')
    input_line_pointer++;
  {if (* input_line_pointer == ' ') ++ input_line_pointer;};
  if (isdigit (*input_line_pointer) || *input_line_pointer == '-')
    number = get_number ();
  if (now_seg != text_section)
    as_warn (".ent or .aent not in text section.");

  if (!aent && proc_lastP && proc_lastP->proc_end == 
                                                    ((void *)0)
                                                        )
    as_warn ("missing `.end'");

  if (!aent)
    {
      procP = (procS *) __extension__ ({ struct n64_tag_obstack *__h = (&proc_frags); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (*procP))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
      procP->proc_isym = symbolP;
      procP->proc_reg_mask = 0;
      procP->proc_reg_offset = 0;
      procP->proc_fpreg_mask = 0;
      procP->proc_fpreg_offset = 0;
      procP->proc_frameoffset = 0;
      procP->proc_framereg = 0;
      procP->proc_pcreg = 0;
      procP->proc_end = 
                       ((void *)0)
                           ;
      procP->proc_next = 
                        ((void *)0)
                            ;
      if (proc_lastP)
 proc_lastP->proc_next = procP;
      else
 proc_rootP = procP;
      proc_lastP = procP;
      numprocs++;
    }
  demand_empty_rest_of_line ();
}

