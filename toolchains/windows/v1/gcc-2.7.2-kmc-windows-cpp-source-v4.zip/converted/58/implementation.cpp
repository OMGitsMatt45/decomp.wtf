// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/stmt.c
/* Expands front end tree to back end RTL for GNU C-Compiler
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int bc_emit_instruction(...) asm("_bc_emit_instruction");
extern int error(...) asm("_error");
extern int bc_adjust_stack(...) asm("_bc_adjust_stack");
extern int error_with_decl(...) asm("_error_with_decl");
extern int decode_reg_name(...) asm("_decode_reg_name");
extern int mark_addressable(...) asm("_mark_addressable");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int warning_with_file_and_line(...) asm("_warning_with_file_and_line");
extern int preserve_temp_slots(...) asm("_preserve_temp_slots");
extern int start_sequence_for_rtl_expr(...) asm("_start_sequence_for_rtl_expr");
extern int volatile_refs_p(...) asm("_volatile_refs_p");
extern int reorder_insns(...) asm("_reorder_insns");
extern int push_temp_slots(...) asm("_push_temp_slots");
extern int warning_with_decl(...) asm("_warning_with_decl");
extern int use_variable(...) asm("_use_variable");
extern int pop_temp_slots(...) asm("_pop_temp_slots");
extern int mark_reg_pointer(...) asm("_mark_reg_pointer");
extern int bc_load_localaddr(...) asm("_bc_load_localaddr");
extern int warning(...) asm("_warning");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int bc_align_bytecode(...) asm("_bc_align_bytecode");
extern int reorder_blocks(...) asm("_reorder_blocks");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_bc_label;
struct n64_tag_bc_labelref;
struct n64_tag_bc_seg;
struct n64_tag_bc_segreloc;
struct n64_tag_bc_segsym;
struct n64_tag_bc_sym;
struct n64_tag_binary_operator;
struct n64_tag_case_node;
struct n64_tag_elims;
struct n64_tag_function;
struct n64_tag_goto_fixup;
struct n64_tag_increment_operator;
struct n64_tag_induction;
struct n64_tag_iv_class;
struct n64_tag_label_chain;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_nesting;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_unary_operator;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");



enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct n64_tag_nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct n64_tag_nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct n64_tag_nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct n64_tag_nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct n64_tag_nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct n64_tag_nesting *block_stack;
  struct n64_tag_nesting *stack_block_stack;
  struct n64_tag_nesting *cond_stack;
  struct n64_tag_nesting *loop_stack;
  struct n64_tag_nesting *case_stack;
  struct n64_tag_nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct n64_tag_goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;

typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
enum n64_cpp_enum_g_types{ DEST_ADDR, DEST_REG };
typedef __underlying_type(enum n64_cpp_enum_g_types) n64_enum_g_types;





struct n64_tag_induction
{
  rtx insn;
  rtx new_reg;

  rtx src_reg;

  n64_enum_g_types giv_type;
  rtx dest_reg;



  rtx *location;

  n64_enum_machine_mode mode;
  n64_enum_machine_mode mem_mode;
  rtx mult_val;
  rtx add_val;
  int benefit;
  rtx final_value;



  unsigned replaceable : 1;




  unsigned not_replaceable : 1;





  unsigned ignore : 1;
  unsigned always_computable : 1;
  unsigned maybe_multiple : 1;


  unsigned cant_derive : 1;



  unsigned combined_with : 1;

  unsigned maybe_dead : 1;


  int lifetime;
  int times_used;
  rtx derive_adjustment;



  struct n64_tag_induction *next_iv;



  struct n64_tag_induction *same;


  int const_adjust;



  struct n64_tag_induction *same_insn;



};



struct n64_tag_iv_class {
  int regno;
  int biv_count;
  struct n64_tag_induction *biv;
  int giv_count;


  struct n64_tag_induction *giv;

  int total_benefit;
  rtx initial_value;
  rtx initial_test;
  struct n64_tag_iv_class *next;
  rtx init_insn;
  rtx init_set;
  unsigned incremented : 1;
  unsigned eliminable : 1;
  unsigned nonneg : 1;
  unsigned reversed : 1;

};


enum n64_cpp_enum_iv_mode{ UNKNOWN_INDUCT, BASIC_INDUCT, NOT_BASIC_INDUCT,
   GENERAL_INDUCT };
typedef __underlying_type(enum n64_cpp_enum_iv_mode) n64_enum_iv_mode;




extern int *uid_luid;
extern int max_uid_for_loop;
extern int *uid_loop_num;
extern int *loop_outer_loop;
extern rtx *loop_number_exit_labels;
extern int *loop_number_exit_count;
extern unsigned int loop_n_iterations;
extern int max_reg_before_loop;

extern FILE *loop_dump_stream;

extern n64_enum_iv_mode *reg_iv_type;
extern struct n64_tag_induction **reg_iv_info;
extern struct n64_tag_iv_class **reg_biv_class;
extern struct n64_tag_iv_class *loop_iv_list;



int invariant_p (rtx) asm("_invariant_p");
rtx get_condition_for_loop (rtx) asm("_get_condition_for_loop");
void emit_iv_add_mult (rtx, rtx, rtx, rtx, rtx) asm("_emit_iv_add_mult");


void find_loop_tree_blocks (void) asm("_find_loop_tree_blocks");
void unroll_block_trees (void) asm("_unroll_block_trees");

void unroll_loop (rtx, int, rtx, rtx, int) asm("_unroll_loop");
rtx biv_total_increment (struct n64_tag_iv_class *, rtx, rtx) asm("_biv_total_increment");
unsigned int loop_iterations (rtx, rtx) asm("_loop_iterations");
rtx final_biv_value (struct n64_tag_iv_class *, rtx, rtx) asm("_final_biv_value");
rtx final_giv_value (struct n64_tag_induction *, rtx, rtx) asm("_final_giv_value");
void emit_unrolled_add (rtx, rtx, rtx) asm("_emit_unrolled_add");
int back_branch_in_range_p (rtx, rtx, rtx) asm("_back_branch_in_range_p");
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];

extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");
enum n64_cpp_enum_typecode{

QIcode,
QUcode,
HIcode,
HUcode,
SIcode,
SUcode,
DIcode,
DUcode,
SFcode,
DFcode,
XFcode,
Pcode,
Tcode,


  LAST_AND_UNUSED_TYPECODE
};
typedef __underlying_type(enum n64_cpp_enum_typecode) n64_enum_typecode;




enum n64_cpp_enum_bytecode_opcode{ neverneverland,
  drop,
  duplicate,
  over,
  setstackSI,
  adjstackSI,
  constQI,
  constHI,
  constSI,
  constDI,
  constSF,
  constDF,
  constXF,
  constP,
  loadQI,
  loadHI,
  loadSI,
  loadDI,
  loadSF,
  loadDF,
  loadXF,
  loadP,
  storeQI,
  storeHI,
  storeSI,
  storeDI,
  storeSF,
  storeDF,
  storeXF,
  storeP,
  storeBLK,
  clearBLK,
  addconstPSI,
  newlocalSI,
  localP,
  argP,
  convertQIHI,
  convertHISI,
  convertSIDI,
  convertQISI,
  convertQUHU,
  convertHUSU,
  convertSUDU,
  convertQUSU,
  convertSFDF,
  convertDFXF,
  convertHIQI,
  convertSIHI,
  convertDISI,
  convertSIQI,
  convertSUQU,
  convertDFSF,
  convertXFDF,
  convertSISF,
  convertSIDF,
  convertSIXF,
  convertSUSF,
  convertSUDF,
  convertSUXF,
  convertDISF,
  convertDIDF,
  convertDIXF,
  convertDUSF,
  convertDUDF,
  convertDUXF,
  convertSFSI,
  convertDFSI,
  convertXFSI,
  convertSFSU,
  convertDFSU,
  convertXFSU,
  convertSFDI,
  convertDFDI,
  convertXFDI,
  convertSFDU,
  convertDFDU,
  convertXFDU,
  convertPSI,
  convertSIP,
  convertSIT,
  convertDIT,
  convertSFT,
  convertDFT,
  convertXFT,
  convertPT,
  zxloadBI,
  sxloadBI,
  sstoreBI,
  addSI,
  addDI,
  addSF,
  addDF,
  addXF,
  addPSI,
  subSI,
  subDI,
  subSF,
  subDF,
  subXF,
  subPP,
  mulSI,
  mulDI,
  mulSU,
  mulDU,
  mulSF,
  mulDF,
  mulXF,
  divSI,
  divDI,
  divSU,
  divDU,
  divSF,
  divDF,
  divXF,
  modSI,
  modDI,
  modSU,
  modDU,
  andSI,
  andDI,
  iorSI,
  iorDI,
  xorSI,
  xorDI,
  lshiftSI,
  lshiftSU,
  lshiftDI,
  lshiftDU,
  rshiftSI,
  rshiftSU,
  rshiftDI,
  rshiftDU,
  ltSI,
  ltSU,
  ltDI,
  ltDU,
  ltSF,
  ltDF,
  ltXF,
  ltP,
  leSI,
  leSU,
  leDI,
  leDU,
  leSF,
  leDF,
  leXF,
  leP,
  geSI,
  geSU,
  geDI,
  geDU,
  geSF,
  geDF,
  geXF,
  geP,
  gtSI,
  gtSU,
  gtDI,
  gtDU,
  gtSF,
  gtDF,
  gtXF,
  gtP,
  eqSI,
  eqDI,
  eqSF,
  eqDF,
  eqXF,
  eqP,
  neSI,
  neDI,
  neSF,
  neDF,
  neXF,
  neP,
  negSI,
  negDI,
  negSF,
  negDF,
  negXF,
  notSI,
  notDI,
  notT,
  predecQI,
  predecHI,
  predecSI,
  predecDI,
  predecP,
  predecSF,
  predecDF,
  predecXF,
  predecBI,
  preincQI,
  preincHI,
  preincSI,
  preincDI,
  preincP,
  preincSF,
  preincDF,
  preincXF,
  preincBI,
  postdecQI,
  postdecHI,
  postdecSI,
  postdecDI,
  postdecP,
  postdecSF,
  postdecDF,
  postdecXF,
  postdecBI,
  postincQI,
  postincHI,
  postincSI,
  postincDI,
  postincP,
  postincSF,
  postincDF,
  postincXF,
  postincBI,
  xjumpif,
  xjumpifnot,
  jump,
  jumpP,
  caseSI,
  caseSU,
  caseDI,
  caseDU,
  call,
  returnP,
  ret,
  linenote,
  LAST_AND_UNUSED_OPCODE
};
typedef __underlying_type(enum n64_cpp_enum_bytecode_opcode) n64_enum_bytecode_opcode;

extern void bc_expand_conversion(...) asm("_bc_expand_conversion");
extern void bc_expand_truth_conversion(...) asm("_bc_expand_truth_conversion");
extern void bc_expand_binary_operation(...) asm("_bc_expand_binary_operation");
extern void bc_expand_unary_operation(...) asm("_bc_expand_unary_operation");

struct n64_tag_binary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
  n64_enum_typecode arg1;
};

extern struct n64_tag_binary_operator optab_plus_expr[];
extern struct n64_tag_binary_operator optab_minus_expr[];
extern struct n64_tag_binary_operator optab_mult_expr[];
extern struct n64_tag_binary_operator optab_trunc_div_expr[];
extern struct n64_tag_binary_operator optab_trunc_mod_expr[];
extern struct n64_tag_binary_operator optab_rdiv_expr[];
extern struct n64_tag_binary_operator optab_bit_and_expr[];
extern struct n64_tag_binary_operator optab_bit_ior_expr[];
extern struct n64_tag_binary_operator optab_bit_xor_expr[];
extern struct n64_tag_binary_operator optab_lshift_expr[];
extern struct n64_tag_binary_operator optab_rshift_expr[];
extern struct n64_tag_binary_operator optab_truth_and_expr[];
extern struct n64_tag_binary_operator optab_truth_or_expr[];
extern struct n64_tag_binary_operator optab_lt_expr[];
extern struct n64_tag_binary_operator optab_le_expr[];
extern struct n64_tag_binary_operator optab_ge_expr[];
extern struct n64_tag_binary_operator optab_gt_expr[];
extern struct n64_tag_binary_operator optab_eq_expr[];
extern struct n64_tag_binary_operator optab_ne_expr[];

struct n64_tag_unary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
};

extern struct n64_tag_unary_operator optab_negate_expr[];
extern struct n64_tag_unary_operator optab_bit_not_expr[];
extern struct n64_tag_unary_operator optab_truth_not_expr[];

struct n64_tag_increment_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode arg;
};

extern struct n64_tag_increment_operator optab_predecrement_expr[];
extern struct n64_tag_increment_operator optab_preincrement_expr[];
extern struct n64_tag_increment_operator optab_postdecrement_expr[];
extern struct n64_tag_increment_operator optab_postincrement_expr[];



struct n64_tag_bc_sym
{

  char *name;


  unsigned int defined:1;


  unsigned int global:1;


  unsigned int common:1;


  unsigned long int val;


  struct n64_tag_bc_sym *next;
};



struct n64_tag_bc_segsym
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *next;
};



struct n64_tag_bc_segreloc
{

  unsigned int offset;


  struct n64_tag_bc_sym *sym;

  struct n64_tag_bc_segreloc *next;
};



struct n64_tag_bc_seg
{

  unsigned int alloc;


  char *data;


  unsigned int size;


  struct n64_tag_bc_segsym *syms;


  struct n64_tag_bc_segreloc *relocs;
};



struct n64_tag_bc_label
{

  unsigned int offset;


  unsigned int defined:1;



  int uid;


  struct n64_tag_bc_label *next;
};






struct n64_tag_bc_labelref
{

  struct n64_tag_bc_label *label;


  unsigned int offset;


  struct n64_tag_bc_labelref *next;
};



extern void bc_initialize(void) asm("_bc_initialize");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern void bc_emit_bytecode(...) asm("_bc_emit_bytecode");
extern void bc_emit_bytecode_const(...) asm("_bc_emit_bytecode_const");
extern struct n64_tag_bc_label *bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
extern int bc_emit_bytecode_labeldef(...) asm("_bc_emit_bytecode_labeldef");
extern void bc_emit_bytecode_labelref(...) asm("_bc_emit_bytecode_labelref");
extern void bc_emit_code_labelref(...) asm("_bc_emit_code_labelref");
extern char *bc_end_function(void) asm("_bc_end_function");
extern void bc_align_const(...) asm("_bc_align_const");
extern void bc_emit_const(...) asm("_bc_emit_const");
extern void bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern void bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern void bc_align_data(...) asm("_bc_align_data");
extern void bc_emit_data(...) asm("_bc_emit_data");
extern void bc_emit_data_skip(...) asm("_bc_emit_data_skip");
extern int bc_emit_data_labeldef(...) asm("_bc_emit_data_labeldef");
extern void bc_emit_data_labelref(...) asm("_bc_emit_data_labelref");
extern int bc_define_pointer(...) asm("_bc_define_pointer");
extern int bc_emit_common(...) asm("_bc_emit_common");
extern void bc_globalize_label(...) asm("_bc_globalize_label");
extern void bc_text(void) asm("_bc_text");
extern void bc_data(void) asm("_bc_data");
extern void bc_align(...) asm("_bc_align");
extern void bc_emit(...) asm("_bc_emit");
extern void bc_emit_skip(...) asm("_bc_emit_skip");
extern int bc_emit_labeldef(...) asm("_bc_emit_labeldef");
extern void bc_emit_labelref(...) asm("_bc_emit_labelref");
extern void bc_write_file(...) asm("_bc_write_file");



struct n64_tag_obstack stmt_obstack;



char *emit_filename;
int emit_lineno;




int expr_stmts_for_value;




static tree last_expr_type;
static rtx last_expr_value;






static rtx last_block_end_note;



int block_start_count;




extern int current_function_returns_pcc_struct;





extern rtx cleanup_label;





extern rtx return_label;



extern rtx save_expr_regs;




extern int frame_offset;



extern rtx tail_recursion_label;


extern rtx tail_recursion_reentry;






extern rtx arg_pointer_save_area;


extern tree rtl_expr_chain;
extern void (*interim_eh_hook) (tree);
struct n64_tag_case_node
{
  struct n64_tag_case_node *left;
  struct n64_tag_case_node *right;
  struct n64_tag_case_node *parent;
  tree low;
  tree high;
  tree code_label;
};

typedef struct n64_tag_case_node case_node;
typedef struct n64_tag_case_node *case_node_ptr;




static short *cost_table;
static int use_cost_table;
struct n64_tag_nesting
{
  struct n64_tag_nesting *all;
  struct n64_tag_nesting *next;
  int depth;
  rtx exit_label;
  union
    {

      struct
 {



   rtx endif_label;


   rtx next_label;
 } cond;

      struct
 {

   rtx start_label;

   rtx end_label;


   rtx alt_end_label;


   rtx continue_label;
 } loop;

      struct
 {


   int block_start_count;


   rtx stack_level;



   rtx first_insn;

   struct n64_tag_nesting *innermost_stack_block;




   tree cleanups;
   tree outer_cleanups;


   struct n64_tag_label_chain *label_chain;

   int function_call_count;

   int bc_stack_level;
 } block;


      struct
 {


   rtx start;



   rtx skip_label;




   struct n64_tag_case_node *case_list;

   tree default_label;

   tree index_expr;

   tree nominal_type;

   int num_ranges;

   char *printname;

   char seenlabel;
 } case_stmt;
    } data;
};


struct n64_tag_nesting *block_stack;





struct n64_tag_nesting *stack_block_stack;


struct n64_tag_nesting *cond_stack;


struct n64_tag_nesting *loop_stack;


struct n64_tag_nesting *case_stack;



struct n64_tag_nesting *nesting_stack;


int nesting_depth;
struct n64_tag_goto_fixup
{

  struct n64_tag_goto_fixup *next;


  rtx before_jump;


  tree target;

  tree context;

  rtx target_rtl;


  int block_start_count;



  rtx stack_level;







  tree cleanup_list_list;





  struct n64_tag_bc_label *bc_target;


  struct n64_tag_bc_label *label;


  int bc_handled:1;


  int bc_stack_level;
};

static struct n64_tag_goto_fixup *goto_fixup_chain;




struct n64_tag_label_chain
{

  struct n64_tag_label_chain *next;
  tree label;
};
static void expand_goto_internal (tree, rtx, rtx) asm("_expand_goto_internal");
static void bc_expand_goto_internal (n64_enum_bytecode_opcode, struct n64_tag_bc_label *, tree) asm("_bc_expand_goto_internal")
                                     ;
static int expand_fixup (tree, rtx, rtx) asm("_expand_fixup");
static void bc_expand_fixup (n64_enum_bytecode_opcode, struct n64_tag_bc_label *, int) asm("_bc_expand_fixup")
                                    ;
static void fixup_gotos (struct n64_tag_nesting *, rtx, tree, rtx, int) asm("_fixup_gotos")
                      ;
static void bc_fixup_gotos (struct n64_tag_nesting *, int, tree, rtx, int) asm("_bc_fixup_gotos")
                      ;
static void bc_expand_start_cond (tree, int) asm("_bc_expand_start_cond");
static void bc_expand_end_cond (void) asm("_bc_expand_end_cond");
static void bc_expand_start_else (void) asm("_bc_expand_start_else");
static void bc_expand_end_loop (void) asm("_bc_expand_end_loop");
static void bc_expand_end_bindings (tree, int, int) asm("_bc_expand_end_bindings");
static void bc_expand_decl (tree, tree) asm("_bc_expand_decl");
static void bc_expand_variable_local_init (tree) asm("_bc_expand_variable_local_init");
static void bc_expand_decl_init (tree) asm("_bc_expand_decl_init");
static void expand_null_return_1 (rtx, int) asm("_expand_null_return_1");
static void expand_value_return (rtx) asm("_expand_value_return");
static int tail_recursion_args (tree, tree) asm("_tail_recursion_args");
static void expand_cleanups (tree, tree, int, int) asm("_expand_cleanups");
static void bc_expand_start_case (struct n64_tag_nesting *, tree, tree, char *) asm("_bc_expand_start_case")
                          ;
static int bc_pushcase (tree, tree) asm("_bc_pushcase");
static void bc_check_for_full_enumeration_handling (tree) asm("_bc_check_for_full_enumeration_handling");
static void bc_expand_end_case (tree) asm("_bc_expand_end_case");
static void do_jump_if_equal (rtx, rtx, rtx, int) asm("_do_jump_if_equal");
static int estimate_case_costs (case_node_ptr) asm("_estimate_case_costs");
static void group_case_nodes (case_node_ptr) asm("_group_case_nodes");
static void balance_case_nodes (case_node_ptr *, case_node_ptr) asm("_balance_case_nodes")
                           ;
static int node_has_low_bound (case_node_ptr, tree) asm("_node_has_low_bound");
static int node_has_high_bound (case_node_ptr, tree) asm("_node_has_high_bound");
static int node_is_bounded (case_node_ptr, tree) asm("_node_is_bounded");
static void emit_jump_if_reachable (rtx) asm("_emit_jump_if_reachable");
static void emit_case_nodes (rtx, case_node_ptr, rtx, tree) asm("_emit_case_nodes");

extern rtx bc_allocate_local(...) asm("_bc_allocate_local");
extern rtx bc_allocate_variable_array(...) asm("_bc_allocate_variable_array");

void
init_stmt(void) asm("_init_stmt");
void
init_stmt(void)
{
  gcc_obstack_init (&stmt_obstack);



}

void
init_stmt_for_function(void) asm("_init_stmt_for_function");
void
init_stmt_for_function(void)
{

  block_stack = 0;
  stack_block_stack = 0;
  loop_stack = 0;
  case_stack = 0;
  cond_stack = 0;
  nesting_stack = 0;
  nesting_depth = 0;

  block_start_count = 0;


  goto_fixup_chain = 0;


  expr_stmts_for_value = 0;
  last_expr_type = 0;
}

void
save_stmt_status(struct n64_tag_function *p) asm("_save_stmt_status");
void
save_stmt_status(struct n64_tag_function *p)
{
  p->block_stack = block_stack;
  p->stack_block_stack = stack_block_stack;
  p->cond_stack = cond_stack;
  p->loop_stack = loop_stack;
  p->case_stack = case_stack;
  p->nesting_stack = nesting_stack;
  p->nesting_depth = nesting_depth;
  p->block_start_count = block_start_count;
  p->last_expr_type = last_expr_type;
  p->last_expr_value = last_expr_value;
  p->expr_stmts_for_value = expr_stmts_for_value;
  p->emit_filename = emit_filename;
  p->emit_lineno = emit_lineno;
  p->goto_fixup_chain = goto_fixup_chain;
}

void
restore_stmt_status(struct n64_tag_function *p) asm("_restore_stmt_status");
void
restore_stmt_status(struct n64_tag_function *p)
{
  block_stack = p->block_stack;
  stack_block_stack = p->stack_block_stack;
  cond_stack = p->cond_stack;
  loop_stack = p->loop_stack;
  case_stack = p->case_stack;
  nesting_stack = p->nesting_stack;
  nesting_depth = p->nesting_depth;
  block_start_count = p->block_start_count;
  last_expr_type = p->last_expr_type;
  last_expr_value = p->last_expr_value;
  expr_stmts_for_value = p->expr_stmts_for_value;
  emit_filename = p->emit_filename;
  emit_lineno = p->emit_lineno;
  goto_fixup_chain = p->goto_fixup_chain;
}



void
emit_nop(void) asm("_emit_nop");
void
emit_nop(void)
{
  rtx last_insn;

  if (!output_bytecode)
    {
      last_insn = get_last_insn ();
      if (!optimize
   && (((last_insn)->code) == CODE_LABEL
       || (((last_insn)->code) == NOTE
    && prev_real_insn (last_insn) == 0)))
 emit_insn (gen_nop ());
    }
}




rtx
label_rtx(tree label) asm("_label_rtx");
rtx
label_rtx(tree label)
{
  if (((n64_enum_tree_code) (label)->common.code) != LABEL_DECL)
    abort ();

  if (((label)->decl.rtl))
    return ((label)->decl.rtl);

  return ((label)->decl.rtl) = gen_label_rtx ();
}



void
emit_jump(rtx label) asm("_emit_jump");
void
emit_jump(rtx label)
{
  do_pending_stack_adjust ();
  emit_jump_insn (gen_jump (label));
  emit_barrier ();
}




void
expand_computed_goto(tree exp) asm("_expand_computed_goto");
void
expand_computed_goto(tree exp)
{
  if (output_bytecode)
    {
      bc_expand_expr (exp);
      bc_emit_instruction (jumpP);
    }
  else
    {
      rtx x = expand_expr (exp, (rtx) 0, VOIDmode, 0);





      emit_queue ();
      do_pending_stack_adjust ();
      emit_indirect_jump (x);
    }
}
void
expand_label(tree label) asm("_expand_label");
void
expand_label(tree label)
{
  struct n64_tag_label_chain *p;

  if (output_bytecode)
    {
      if (! ((label)->decl.rtl))
 ((label)->decl.rtl) = bc_gen_rtx ((char *) 0, 0, bc_get_bytecode_label ());
      if (! bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((((label)->decl.rtl)))->fld[1].rtx))))
 error ("multiply defined label");
      return;
    }

  do_pending_stack_adjust ();
  emit_label (label_rtx (label));
  if (((label)->decl.name))
    ((((label)->decl.rtl))->fld[4].rtstr) = ((((label)->decl.name))->identifier.pointer);

  if (stack_block_stack != 0)
    {
      p = (struct n64_tag_label_chain *) oballoc (sizeof (struct n64_tag_label_chain));
      p->next = stack_block_stack->data.block.label_chain;
      stack_block_stack->data.block.label_chain = p;
      p->label = label;
    }
}




void
declare_nonlocal_label(tree label) asm("_declare_nonlocal_label");
void
declare_nonlocal_label(tree label)
{
  nonlocal_labels = tree_cons ((tree) 
                              ((void *)0)
                                       , label, nonlocal_labels);
  ((label_rtx (label))->in_struct) = 1;
  if (nonlocal_goto_handler_slot == 0)
    {
      nonlocal_goto_handler_slot
 = assign_stack_local (((target_flags & 0x00000002) ? DImode : SImode), (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]), 0);
      emit_stack_save (SAVE_NONLOCAL,
         &nonlocal_goto_stack_level,
         ((tail_recursion_reentry)->fld[1].rtx));
    }
}





void
expand_goto(tree label) asm("_expand_goto");
void
expand_goto(tree label)
{
  tree context;

  if (output_bytecode)
    {
      expand_goto_internal (label, label_rtx (label), (rtx) 0);
      return;
    }


  context = decl_function_context (label);
  if (context != 0 && context != current_function_decl)
    {
      struct n64_tag_function *p = find_function_data (context);
      rtx label_ref = gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), label_rtx (label));
      rtx temp;

      p->has_nonlocal_label = 1;
      current_function_has_nonlocal_goto = 1;
      ((label_ref)->volatil) = 1;
 {
   rtx addr;






   emit_move_insn (hard_frame_pointer_rtx, lookup_static_chain (label));
   addr = copy_rtx (p->nonlocal_goto_handler_slot);
   temp = copy_to_reg (replace_rtx (addr, virtual_stack_vars_rtx,
        hard_frame_pointer_rtx));


   addr = p->nonlocal_goto_stack_level;
   if (addr)
     addr = replace_rtx (copy_rtx (addr),
    virtual_stack_vars_rtx,
    hard_frame_pointer_rtx);

   emit_stack_restore (SAVE_NONLOCAL, addr, (rtx) 0);


   emit_move_insn (static_chain_rtx, label_ref);


   emit_insn (gen_rtx (USE, VOIDmode, hard_frame_pointer_rtx));
   emit_insn (gen_rtx (USE, VOIDmode, stack_pointer_rtx));
   emit_insn (gen_rtx (USE, VOIDmode, static_chain_rtx));
   emit_indirect_jump (temp);
 }
     }
  else
    expand_goto_internal (label, label_rtx (label), (rtx) 0);
}






static void
expand_goto_internal(tree body, rtx label, rtx last_insn) asm("_expand_goto_internal");
static void
expand_goto_internal(tree body, rtx label, rtx last_insn)
{
  struct n64_tag_nesting *block;
  rtx stack_level = 0;





  if (output_bytecode)
    {
      expand_goto_internal (body, label, last_insn);
      return;
    }

  if (((label)->code) != CODE_LABEL)
    abort ();




  if (((label)->fld[1].rtx) != 0)
    {




      for (block = block_stack; block; block = block->next)
 {
   if (((block->data.block.first_insn)->fld[0].rtint) < ((label)->fld[0].rtint))
     break;
   if (block->data.block.stack_level != 0)
     stack_level = block->data.block.stack_level;

   if (block->data.block.cleanups != 0)
     {
       expand_cleanups (block->data.block.cleanups, (tree) 
                                                   ((void *)0)
                                                            , 1, 1);
       do_pending_stack_adjust ();
     }
 }

      if (stack_level)
 {


   clear_pending_stack_adjust ();
   do_pending_stack_adjust ();
   emit_stack_restore (SAVE_BLOCK, stack_level, (rtx) 0);
 }

      if (body != 0 && ((body)->decl.bit_field_flag))
 error ("jump to `%s' invalidly jumps into binding contour",
        ((((body)->decl.name))->identifier.pointer));
    }


  else if (! expand_fixup (body, label, last_insn))
    {


      if (body != 0)
 ((body)->common.addressable_flag) = 1;
    }

  emit_jump (label);
}




static void
bc_expand_goto_internal(n64_enum_bytecode_opcode opcode, struct n64_tag_bc_label *label, tree body) asm("_bc_expand_goto_internal");
static void
bc_expand_goto_internal(n64_enum_bytecode_opcode opcode, struct n64_tag_bc_label *label, tree body)
{
  struct n64_tag_nesting *block;
  int stack_level = -1;





  if (label->defined)
    {





      for (block = block_stack; block; block = block->next)
 {
   if ((*(struct n64_tag_bc_label **) &(((block->data.block.first_insn))->fld[1].rtx))->uid < label->uid)
     break;
   if (block->data.block.bc_stack_level)
     stack_level = block->data.block.bc_stack_level;


   if (block->data.block.cleanups != 0)
     {
       expand_cleanups (block->data.block.cleanups, (tree) 
                                                   ((void *)0)
                                                            , 1, 1);
       do_pending_stack_adjust ();
     }
 }







      if (stack_level >= 0
   && stack_depth != stack_level
   && opcode != jump)

 bc_expand_fixup (opcode, label, stack_level);
      else
 {
   if (stack_level >= 0)
     bc_adjust_stack (stack_depth - stack_level);

   if (body && ((body)->decl.bit_field_flag))
     error ("jump to `%s' invalidly jumps into binding contour",
     ((((body)->decl.name))->identifier.pointer));


   bc_emit_bytecode (opcode);
   bc_emit_bytecode_labelref (label);




 }
    }
  else

    bc_expand_fixup (opcode, label, stack_level);
}
static int
expand_fixup(tree tree_label, rtx rtl_label, rtx last_insn) asm("_expand_fixup");
static int
expand_fixup(tree tree_label, rtx rtl_label, rtx last_insn)
{
  struct n64_tag_nesting *block, *end_block;






  if (cond_stack
      && (rtl_label == cond_stack->data.cond.endif_label
   || rtl_label == cond_stack->data.cond.next_label))
    end_block = cond_stack;



  else if (loop_stack
      && (rtl_label == loop_stack->data.loop.start_label
   || rtl_label == loop_stack->data.loop.end_label
   || rtl_label == loop_stack->data.loop.continue_label))
    end_block = loop_stack;
  else
    end_block = 0;



  if (end_block)
    {
      struct n64_tag_nesting *next_block = end_block->all;
      block = block_stack;



      while (next_block && next_block != block)
 next_block = next_block->all;

      if (next_block)
 return 0;



      next_block = block_stack->next;
      for (block = block_stack; block != end_block; block = block->all)
 if (block == next_block)
   next_block = next_block->next;
      end_block = next_block;
    }




  for (block = block_stack; block != end_block; block = block->next)
    if (block->data.block.stack_level != 0
 || block->data.block.cleanups != 0)
      break;

  if (block != end_block)
    {

      struct n64_tag_goto_fixup *fixup
 = (struct n64_tag_goto_fixup *) oballoc (sizeof (struct n64_tag_goto_fixup));






      if (last_insn == 0)
 do_pending_stack_adjust ();
      fixup->target = tree_label;
      fixup->target_rtl = rtl_label;
      {
        register rtx original_before_jump
          = last_insn ? last_insn : get_last_insn ();

        start_sequence ();
        pushlevel (0);
        fixup->before_jump = emit_note (((void *)0), -2);
        last_block_end_note = emit_note (((void *)0), -3);
        fixup->context = poplevel (1, 0, 0);
        end_sequence ();
        emit_insns_after (fixup->before_jump, original_before_jump);
      }

      fixup->block_start_count = block_start_count;
      fixup->stack_level = 0;
      fixup->cleanup_list_list
 = (((block->data.block.outer_cleanups



      )
     || block->data.block.cleanups)
    ? tree_cons ((tree) 
                ((void *)0)
                         , block->data.block.cleanups,
   block->data.block.outer_cleanups)
    : 0);
      fixup->next = goto_fixup_chain;
      goto_fixup_chain = fixup;
    }

  return block != 0;
}





static void
bc_expand_fixup(n64_enum_bytecode_opcode opcode, struct n64_tag_bc_label *label, int stack_level) asm("_bc_expand_fixup");
static void
bc_expand_fixup(n64_enum_bytecode_opcode opcode, struct n64_tag_bc_label *label, int stack_level)
{
  struct n64_tag_goto_fixup *fixup
    = (struct n64_tag_goto_fixup *) oballoc (sizeof (struct n64_tag_goto_fixup));

  fixup->label = bc_get_bytecode_label ();
  fixup->bc_target = label;
  fixup->bc_stack_level = stack_level;
  fixup->bc_handled = 0;

  fixup->next = goto_fixup_chain;
  goto_fixup_chain = fixup;


  bc_emit_bytecode (opcode);
  bc_emit_bytecode_labelref (fixup->label);




}




void
expand_fixups(rtx first_insn) asm("_expand_fixups");
void
expand_fixups(rtx first_insn)
{
  fixup_gotos (((void *)0), (rtx) 0, (tree) 
                                  ((void *)0)
                                           , first_insn, 0);
}
static void
fixup_gotos(struct n64_tag_nesting *thisblock, rtx stack_level, tree cleanup_list, rtx first_insn, int dont_jump_in) asm("_fixup_gotos");
static void
fixup_gotos(struct n64_tag_nesting *thisblock, rtx stack_level, tree cleanup_list, rtx first_insn, int dont_jump_in)
{
  register struct n64_tag_goto_fixup *f, *prev;

  if (output_bytecode)
    {



      bc_fixup_gotos (thisblock, 0, cleanup_list, first_insn, dont_jump_in);
      return;
    }






  for (prev = 0, f = goto_fixup_chain; f; prev = f, f = f->next)
    {

      if (f->before_jump == 0)
 {

   if (prev != 0)
     prev->next = f->next;
 }


      else if (((f->target_rtl)->fld[1].rtx) != 0)
 {
   register rtx cleanup_insns;




   rtx after_label = f->target_rtl;
   while (after_label != 0 && ((after_label)->code) == CODE_LABEL)
     after_label = ((after_label)->fld[2].rtx);







   if (f->target != 0
       && (dont_jump_in || stack_level || cleanup_list)


       && (after_label == 0
    || ((first_insn)->fld[0].rtint) < ((after_label)->fld[0].rtint))
       && ((first_insn)->fld[0].rtint) > ((f->before_jump)->fld[0].rtint)
       && ! ((f->target)->decl.regdecl_flag))
     {
       error_with_decl (f->target,
          "label `%s' used before containing binding contour");

       ((f->target)->decl.regdecl_flag) = 1;
     }





   start_sequence ();





   pushlevel (0);
   set_block (f->context);


   if (f->cleanup_list_list)
     {
       tree lists;
       for (lists = f->cleanup_list_list; lists; lists = ((lists)->common.chain))


  if (((lists)->common.addressable_flag)
      && ((lists)->list.value) != 0)
    {
      expand_cleanups (((lists)->list.value), (tree) 
                                          ((void *)0)
                                                   , 1, 1);


      do_pending_stack_adjust ();
    }
     }



   if (f->stack_level)
     emit_stack_restore (SAVE_BLOCK, f->stack_level, f->before_jump);
   cleanup_insns = get_insns ();
   poplevel (1, 0, 0);

   end_sequence ();
   emit_insns_after (cleanup_insns, f->before_jump);


   f->before_jump = 0;
 }
    }




  for (prev = 0, f = goto_fixup_chain; f; prev = f, f = f->next)
    if (f->before_jump != 0
 && ((f->target_rtl)->fld[1].rtx) == 0




 && thisblock != 0


 && (thisblock->data.block.block_start_count
     <= f->block_start_count))
      {
 tree lists = f->cleanup_list_list;
 rtx cleanup_insns;

 for (; lists; lists = ((lists)->common.chain))


   if (((lists)->common.chain) == thisblock->data.block.outer_cleanups)
     {
       start_sequence ();
       pushlevel (0);
       set_block (f->context);
       expand_cleanups (((lists)->list.value), (tree) 
                                           ((void *)0)
                                                    , 1, 1);
       do_pending_stack_adjust ();
       cleanup_insns = get_insns ();
       poplevel (1, 0, 0);
       end_sequence ();
       f->before_jump
  = emit_insns_after (cleanup_insns, f->before_jump);

       f->cleanup_list_list = ((lists)->common.chain);
     }

 if (stack_level)
   f->stack_level = stack_level;
      }
}
static void
bc_fixup_gotos(struct n64_tag_nesting *thisblock, int stack_level, tree cleanup_list, rtx first_insn, int dont_jump_in) asm("_bc_fixup_gotos");
static void
bc_fixup_gotos(struct n64_tag_nesting *thisblock, int stack_level, tree cleanup_list, rtx first_insn, int dont_jump_in)
{
  register struct n64_tag_goto_fixup *f, *prev;
  int saved_stack_depth;



  for (prev = 0, f = goto_fixup_chain; f; prev = f, f = f->next)
    {

      if (f->before_jump == 0)
 {

   if (prev)
     prev->next = f->next;
 }


      bc_emit_bytecode_labeldef (f->label);




      if (f->bc_stack_level >= 0)
 {
   saved_stack_depth = stack_depth;
   bc_adjust_stack (stack_depth - f->bc_stack_level);
   stack_depth = saved_stack_depth;
 }

      bc_emit_bytecode (jump);
      bc_emit_bytecode_labelref (f->bc_target);




    }

  goto_fixup_chain = 
                    ((void *)0)
                        ;
}





void
expand_asm(tree body) asm("_expand_asm");
void
expand_asm(tree body)
{
  if (output_bytecode)
    {
      error ("`asm' is invalid when generating bytecode");
      return;
    }

  if (((n64_enum_tree_code) (body)->common.code) == ADDR_EXPR)
    body = ((body)->exp.operands[0]);

  emit_insn (gen_rtx (ASM_INPUT, VOIDmode,
        ((body)->string.pointer)));
  last_expr_type = 0;
}
void
expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line) asm("_expand_asm_operands");
void
expand_asm_operands(tree string, tree outputs, tree inputs, tree clobbers, int vol, char *filename, int line)
{
  rtvec argvec, constraints;
  rtx body;
  int ninputs = list_length (inputs);
  int noutputs = list_length (outputs);
  int nclobbers;
  tree tail;
  register int i;

  rtx *output_rtx = (rtx *) 
                           __builtin_alloca((
                           noutputs * sizeof (rtx)
                           ))
                                                           ;

  rtx insn;

  if (output_bytecode)
    {
      error ("`asm' is invalid when generating bytecode");
      return;
    }



  nclobbers = 0;
  for (tail = clobbers; tail; tail = ((tail)->common.chain))
    {
      char *regname = ((((tail)->list.value))->string.pointer);
      i = decode_reg_name (regname);
      if (i >= 0 || i == -4)
 ++nclobbers;
      else if (i == -2)
 error ("unknown register name `%s' in `asm'", regname);
    }

  last_expr_type = 0;

  for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
    {
      tree val = ((tail)->list.value);
      tree type = ((val)->common.type);
      tree val1;
      int j;
      int found_equal = 0;
      int allows_reg = 0;


      if (((val)->common.type) == error_mark_node)
 return;






      for (j = 0; j < ((((tail)->list.purpose))->string.length) - 1; j++)
 switch (((((tail)->list.purpose))->string.pointer)[j])
   {
   case '+':
     error ("output operand constraint contains `+'");
     return;

   case '=':
     found_equal = 1;
     break;

   case '?': case '!': case '*': case '%': case '&':
   case '0': case '1': case '2': case '3': case '4':
   case 'V': case 'm': case 'o': case '<': case '>':
   case 'E': case 'F': case 'G': case 'H': case 'X':
   case 's': case 'i': case 'n':
   case 'I': case 'J': case 'K': case 'L': case 'M':
   case 'N': case 'O': case 'P': case ',':

   case 'Q': case 'R': case 'S': case 'T': case 'U':

     break;

   case 'p': case 'g': case 'r':
   default:
     allows_reg = 1;
     break;
   }

      if (! found_equal)
 {
   error ("output operand constraint lacks `='");
   return;
 }






      if (((n64_enum_tree_code) (val)->common.code) == INDIRECT_REF
   || ((*tree_code_type[(int) (((n64_enum_tree_code) (val)->common.code))]) == 'd'
       && ! (((((val)->decl.rtl))->code) == REG
      && ((((val)->decl.rtl))->mode) != ((type)->type.mode)))
   || ! allows_reg)
 {
   if (! allows_reg)
     mark_addressable (((tail)->list.value));

   output_rtx[i]
     = expand_expr (((tail)->list.value), (rtx) 0, VOIDmode, 0);

   if (! allows_reg && ((output_rtx[i])->code) != MEM)
     error ("output number %d not directly addressable", i);
 }
      else
 {
   if (((type)->type.mode) == BLKmode)
     {
       output_rtx[i] = assign_stack_temp (BLKmode,
       int_size_in_bytes (type), 0);
       ((output_rtx[i])->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
     }
   else
     output_rtx[i] = gen_reg_rtx (((type)->type.mode));

   ((tail)->list.value) = make_tree (type, output_rtx[i]);
 }
    }

  if (ninputs + noutputs > 10)
    {
      error ("more than %d operands in `asm'", 10);
      return;
    }



  argvec = rtvec_alloc (ninputs);
  constraints = rtvec_alloc (ninputs);

  body = gen_rtx (ASM_OPERANDS, VOIDmode,
    ((string)->string.pointer), "", 0, argvec, constraints,
    filename, line);
  ((body)->volatil) = vol;




  i = 0;
  for (tail = inputs; tail; tail = ((tail)->common.chain))
    {
      int j;
      int allows_reg = 0;




      if (((((tail)->list.value))->common.type) == error_mark_node)
 return;
      if (((tail)->list.purpose) == (tree) 
                                ((void *)0)
                                         )
 {
   error ("hard register `%s' listed as input operand to `asm'",
   ((((tail)->list.value))->string.pointer) );
   return;
 }



      for (j = 0; j < ((((tail)->list.purpose))->string.length) - 1; j++)
 switch (((((tail)->list.purpose))->string.pointer)[j])
   {
   case '+': case '=':
     error ("input operand constraint contains `%c'",
     ((((tail)->list.purpose))->string.pointer)[j]);
     return;

   case '?': case '!': case '*': case '%': case '&':
   case 'V': case 'm': case 'o': case '<': case '>':
   case 'E': case 'F': case 'G': case 'H': case 'X':
   case 's': case 'i': case 'n':
   case 'I': case 'J': case 'K': case 'L': case 'M':
   case 'N': case 'O': case 'P': case ',':

   case 'Q': case 'R': case 'S': case 'T': case 'U':

     break;

   case '0': case '1': case '2': case '3': case '4':
   case 'p': case 'g': case 'r':
   default:
     allows_reg = 1;
     break;
   }

      if (! allows_reg)
 mark_addressable (((tail)->list.value));

      ((body)->fld[3].rtvec->elem[i].rtx)
 = expand_expr (((tail)->list.value), (rtx) 0, VOIDmode, 0);
      if ((((((body)->fld[3].rtvec->elem[i].rtx))->code) == LABEL_REF || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == SYMBOL_REF || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == CONST_INT || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == CONST_DOUBLE || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == CONST || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == HIGH)
   && ! general_operand (((body)->fld[3].rtvec->elem[i].rtx),
    ((((((tail)->list.value))->common.type))->type.mode)))
 {
   if (allows_reg)
     ((body)->fld[3].rtvec->elem[i].rtx)
       = force_reg (((((((tail)->list.value))->common.type))->type.mode),
      ((body)->fld[3].rtvec->elem[i].rtx));
   else
     ((body)->fld[3].rtvec->elem[i].rtx)
       = force_const_mem (((((((tail)->list.value))->common.type))->type.mode),
     ((body)->fld[3].rtvec->elem[i].rtx));
 }

      if (! allows_reg
   && (((((body)->fld[3].rtvec->elem[i].rtx))->code) == REG
       || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == SUBREG
       || ((((body)->fld[3].rtvec->elem[i].rtx))->code) == CONCAT))
 {
   tree type = ((((tail)->list.value))->common.type);
   rtx memloc = assign_stack_temp (((type)->type.mode),
       int_size_in_bytes (type), 1);

   ((memloc)->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
   emit_move_insn (memloc, ((body)->fld[3].rtvec->elem[i].rtx));
   ((body)->fld[3].rtvec->elem[i].rtx) = memloc;
 }

      ((body)->fld[4].rtvec->elem[i].rtx)
 = gen_rtx (ASM_INPUT, ((((((tail)->list.value))->common.type))->type.mode),
     ((((tail)->list.purpose))->string.pointer));
      i++;
    }




  for (i = 0; i < ninputs; i++)
    ((body)->fld[3].rtvec->elem[i].rtx) = protect_from_queue (((body)->fld[3].rtvec->elem[i].rtx), 0);

  for (i = 0; i < noutputs; i++)
    output_rtx[i] = protect_from_queue (output_rtx[i], 1);






  if (noutputs == 1 && nclobbers == 0)
    {
      ((body)->fld[1].rtstr) = ((((outputs)->list.purpose))->string.pointer);
      insn = emit_insn (gen_rtx (SET, VOIDmode, output_rtx[0], body));
    }
  else if (noutputs == 0 && nclobbers == 0)
    {

      insn = emit_insn (body);
    }
  else
    {
      rtx obody = body;
      int num = noutputs;
      if (num == 0) num = 1;
      body = gen_rtx (PARALLEL, VOIDmode, rtvec_alloc (num + nclobbers));



      for (i = 0, tail = outputs; tail; tail = ((tail)->common.chain), i++)
 {
   ((body)->fld[0].rtvec->elem[i].rtx)
     = gen_rtx (SET, VOIDmode,
         output_rtx[i],
         gen_rtx (ASM_OPERANDS, VOIDmode,
    ((string)->string.pointer),
    ((((tail)->list.purpose))->string.pointer),
    i, argvec, constraints,
    filename, line));
   ((((((body)->fld[0].rtvec->elem[i].rtx))->fld[1].rtx))->volatil) = vol;
 }




      if (i == 0)
 ((body)->fld[0].rtvec->elem[i++].rtx) = obody;



      for (tail = clobbers; tail; tail = ((tail)->common.chain))
 {
   char *regname = ((((tail)->list.value))->string.pointer);
   int j = decode_reg_name (regname);

   if (j < 0)
     {
       if (j == -3)
  continue;

       if (j == -4)
  {
    ((body)->fld[0].rtvec->elem[i++].rtx)
      = gen_rtx (CLOBBER, VOIDmode,
          gen_rtx (MEM, BLKmode,
     gen_rtx (SCRATCH, VOIDmode, 0)));
    continue;
  }


       continue;
     }


   ((body)->fld[0].rtvec->elem[i++].rtx)
     = gen_rtx (CLOBBER, VOIDmode, gen_rtx (REG, QImode, j));
 }

      insn = emit_insn (body);
    }

  free_temp_slots ();
}




void
expand_expr_stmt(tree exp) asm("_expand_expr_stmt");
void
expand_expr_stmt(tree exp)
{
  if (output_bytecode)
    {
      int org_stack_depth = stack_depth;

      bc_expand_expr (exp);


      if (stack_depth < org_stack_depth)
 abort ();

      bc_emit_instruction (drop);

      last_expr_type = ((exp)->common.type);
      return;
    }




  if (expr_stmts_for_value == 0 && exp != error_mark_node)
    {
      if (! ((exp)->common.side_effects_flag) && (extra_warnings || warn_unused)
   && !(((n64_enum_tree_code) (exp)->common.code) == CONVERT_EXPR
        && ((exp)->common.type) == void_type_node))
 warning_with_file_and_line (emit_filename, emit_lineno,
        "statement with no effect");
      else if (warn_unused)
 warn_if_unused_value (exp);
    }



  if (expr_stmts_for_value && ((n64_enum_tree_code) (((exp)->common.type))->common.code) == FUNCTION_TYPE)
    exp = build1 (ADDR_EXPR, build_pointer_type (((exp)->common.type)), exp);

  last_expr_type = ((exp)->common.type);
  if (! flag_syntax_only)
    last_expr_value = expand_expr (exp,
       (expr_stmts_for_value
        ? (rtx) 0 : const0_rtx),
       VOIDmode, 0);



  if (last_expr_value != 0 && ((last_expr_value)->code) == MEM
      && ((exp)->common.volatile_flag))
    {
      if (((((exp)->common.type))->type.mode) == VOIDmode)
 ;
      else if (((((exp)->common.type))->type.mode) != BLKmode)
 copy_to_reg (last_expr_value);
      else
 {
   rtx lab = gen_label_rtx ();


   emit_cmp_insn (last_expr_value, last_expr_value, EQ,
    expand_expr (((last_expr_type)->type.size),
          (rtx) 0, VOIDmode, 0),
    BLKmode, 0,
    ((last_expr_type)->type.align) / 8);
   emit_jump_insn ((*bcc_gen_fctn[(int) EQ]) (lab));
   emit_label (lab);
 }
    }



  preserve_temp_slots (last_expr_value);




  free_temp_slots ();

  emit_queue ();
}




int
warn_if_unused_value(tree exp) asm("_warn_if_unused_value");
int
warn_if_unused_value(tree exp)
{
  if (((exp)->common.used_flag))
    return 0;

  switch (((n64_enum_tree_code) (exp)->common.code))
    {
    case PREINCREMENT_EXPR:
    case POSTINCREMENT_EXPR:
    case PREDECREMENT_EXPR:
    case POSTDECREMENT_EXPR:
    case MODIFY_EXPR:
    case INIT_EXPR:
    case TARGET_EXPR:
    case CALL_EXPR:
    case METHOD_CALL_EXPR:
    case RTL_EXPR:
    case WITH_CLEANUP_EXPR:
    case EXIT_EXPR:


    case COND_EXPR:
      return 0;

    case BIND_EXPR:

      return warn_if_unused_value (((exp)->exp.operands[1]));

    case SAVE_EXPR:
      return warn_if_unused_value (((exp)->exp.operands[1]));

    case TRUTH_ORIF_EXPR:
    case TRUTH_ANDIF_EXPR:

      return warn_if_unused_value (((exp)->exp.operands[1]));

    case COMPOUND_EXPR:
      if (((exp)->common.static_flag))
 return 0;
      if (warn_if_unused_value (((exp)->exp.operands[0])))
 return 1;

      if (((((exp)->exp.operands[1]))->common.constant_flag))
 return 0;
      return warn_if_unused_value (((exp)->exp.operands[1]));

    case NOP_EXPR:
    case CONVERT_EXPR:
    case NON_LVALUE_EXPR:

      if (((exp)->common.type) == void_type_node)
 return 0;

      if (((exp)->common.static_flag))
 return 0;




      {
 tree tem = ((exp)->exp.operands[0]);

 while (((n64_enum_tree_code) (tem)->common.code) == CONVERT_EXPR || ((n64_enum_tree_code) (tem)->common.code) == NOP_EXPR)
   tem = ((tem)->exp.operands[0]);

 if (((n64_enum_tree_code) (tem)->common.code) == MODIFY_EXPR || ((n64_enum_tree_code) (tem)->common.code) == INIT_EXPR
     || ((n64_enum_tree_code) (tem)->common.code) == CALL_EXPR)
   return 0;
      }
      goto warn;

    case INDIRECT_REF:


      if (((n64_enum_tree_code) (((((exp)->exp.operands[0]))->common.type))->common.code) == REFERENCE_TYPE)
 return warn_if_unused_value (((exp)->exp.operands[0]));


    default:

      if (((*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'd'
    || (*tree_code_type[(int) (((n64_enum_tree_code) (exp)->common.code))]) == 'r')
   && ((exp)->common.volatile_flag))
 return 0;
    warn:
      warning_with_file_and_line (emit_filename, emit_lineno,
      "value computed is not used");
      return 1;
    }
}



void
clear_last_expr(void) asm("_clear_last_expr");
void
clear_last_expr(void)
{
  last_expr_type = 0;
}





tree
expand_start_stmt_expr(void) asm("_expand_start_stmt_expr");
tree
expand_start_stmt_expr(void)
{
  int momentary;
  tree t;


  if (output_bytecode)
    return (build_int_2_wide ((int) (stack_depth), (int) (0)));



  momentary = suspend_momentary ();
  t = make_node (RTL_EXPR);
  resume_momentary (momentary);
  do_pending_stack_adjust ();
  start_sequence_for_rtl_expr (t);
  (inhibit_defer_pop += 1);
  expr_stmts_for_value++;
  return t;
}
tree
expand_end_stmt_expr(tree t) asm("_expand_end_stmt_expr");
tree
expand_end_stmt_expr(tree t)
{
  if (output_bytecode)
    {
      int i;
      tree t;
      bc_adjust_stack (-1);

      if (!last_expr_type)
 last_expr_type = void_type_node;

      t = make_node (RTL_EXPR);
      ((t)->common.type) = last_expr_type;
      (*(struct n64_tag_rtx_def **) &(t)->exp.operands[1]) = 
                        ((void *)0)
                            ;
      (*(struct n64_tag_rtx_def **) &(t)->exp.operands[0]) = 
                             ((void *)0)
                                 ;


      ((t)->common.volatile_flag) = 1;

      last_expr_type = 0;
      return t;
    }

  (inhibit_defer_pop -= 1);

  if (last_expr_type == 0)
    {
      last_expr_type = void_type_node;
      last_expr_value = const0_rtx;
    }
  else if (last_expr_value == 0)


    last_expr_value = const0_rtx;
  else if (((last_expr_value)->code) != REG && ! (((last_expr_value)->code) == LABEL_REF || ((last_expr_value)->code) == SYMBOL_REF || ((last_expr_value)->code) == CONST_INT || ((last_expr_value)->code) == CONST_DOUBLE || ((last_expr_value)->code) == CONST || ((last_expr_value)->code) == HIGH))

    last_expr_value = protect_from_queue (last_expr_value, 0);

  emit_queue ();

  ((t)->common.type) = last_expr_type;
  (*(struct n64_tag_rtx_def **) &(t)->exp.operands[1]) = last_expr_value;
  (*(struct n64_tag_rtx_def **) &(t)->exp.operands[0]) = get_insns ();

  rtl_expr_chain = tree_cons ((tree) 
                             ((void *)0)
                                      , t, rtl_expr_chain);

  end_sequence ();


  ((t)->common.side_effects_flag) = 1;

  ((t)->common.volatile_flag) = volatile_refs_p (last_expr_value);

  last_expr_type = 0;
  expr_stmts_for_value--;

  return t;
}







void
expand_start_cond(tree cond, int exitflag) asm("_expand_start_cond");
void
expand_start_cond(tree cond, int exitflag)
{
  struct n64_tag_nesting *thiscond = (struct n64_tag_nesting *) __extension__ ({ struct n64_tag_obstack *__h = (&stmt_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_nesting))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  thiscond->next = cond_stack;
  thiscond->all = nesting_stack;
  thiscond->depth = ++nesting_depth;
  thiscond->data.cond.next_label = gen_label_rtx ();



  thiscond->exit_label = exitflag ? gen_label_rtx () : 0;
  thiscond->data.cond.endif_label = thiscond->exit_label;
  cond_stack = thiscond;
  nesting_stack = thiscond;

  if (output_bytecode)
    bc_expand_start_cond (cond, exitflag);
  else
    do_jump (cond, thiscond->data.cond.next_label, (rtx) 0);
}




void
expand_start_elseif(tree cond) asm("_expand_start_elseif");
void
expand_start_elseif(tree cond)
{
  if (cond_stack->data.cond.endif_label == 0)
    cond_stack->data.cond.endif_label = gen_label_rtx ();
  emit_jump (cond_stack->data.cond.endif_label);
  emit_label (cond_stack->data.cond.next_label);
  cond_stack->data.cond.next_label = gen_label_rtx ();
  do_jump (cond, cond_stack->data.cond.next_label, (rtx) 0);
}




void
expand_start_else(void) asm("_expand_start_else");
void
expand_start_else(void)
{
  if (cond_stack->data.cond.endif_label == 0)
    cond_stack->data.cond.endif_label = gen_label_rtx ();

  if (output_bytecode)
    {
      bc_expand_start_else ();
      return;
    }

  emit_jump (cond_stack->data.cond.endif_label);
  emit_label (cond_stack->data.cond.next_label);
  cond_stack->data.cond.next_label = 0;
}




void
expand_elseif(tree cond) asm("_expand_elseif");
void
expand_elseif(tree cond)
{
  cond_stack->data.cond.next_label = gen_label_rtx ();
  do_jump (cond, cond_stack->data.cond.next_label, (rtx) 0);
}




void
expand_end_cond(void) asm("_expand_end_cond");
void
expand_end_cond(void)
{
  struct n64_tag_nesting *thiscond = cond_stack;

  if (output_bytecode)
    bc_expand_end_cond ();
  else
    {
      do_pending_stack_adjust ();
      if (thiscond->data.cond.next_label)
 emit_label (thiscond->data.cond.next_label);
      if (thiscond->data.cond.endif_label)
 emit_label (thiscond->data.cond.endif_label);
    }

  do { struct n64_tag_nesting *target = cond_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);
  last_expr_type = 0;
}







static void
bc_expand_start_cond(tree cond, int exitflag) asm("_bc_expand_start_cond");
static void
bc_expand_start_cond(tree cond, int exitflag)
{
  struct n64_tag_nesting *thiscond = cond_stack;

  thiscond->data.case_stmt.nominal_type = cond;
  if (! exitflag)
    thiscond->exit_label = gen_label_rtx ();
  bc_expand_expr (cond);
  bc_emit_bytecode (xjumpifnot);
  bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thiscond->exit_label))->fld[1].rtx)));




}




static void
bc_expand_end_cond(void) asm("_bc_expand_end_cond");
static void
bc_expand_end_cond(void)
{
  struct n64_tag_nesting *thiscond = cond_stack;

  bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thiscond->exit_label))->fld[1].rtx)));
}




static void
bc_expand_start_else(void) asm("_bc_expand_start_else");
static void
bc_expand_start_else(void)
{
  struct n64_tag_nesting *thiscond = cond_stack;

  thiscond->data.cond.endif_label = thiscond->exit_label;
  thiscond->exit_label = gen_label_rtx ();
  bc_emit_bytecode (jump);
  bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thiscond->exit_label))->fld[1].rtx)));





  bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thiscond->data.cond.endif_label))->fld[1].rtx)));
}
struct n64_tag_nesting *
expand_start_loop(int exit_flag) asm("_expand_start_loop");
struct n64_tag_nesting *
expand_start_loop(int exit_flag)
{
  register struct n64_tag_nesting *thisloop = (struct n64_tag_nesting *) __extension__ ({ struct n64_tag_obstack *__h = (&stmt_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_nesting))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  thisloop->next = loop_stack;
  thisloop->all = nesting_stack;
  thisloop->depth = ++nesting_depth;
  thisloop->data.loop.start_label = gen_label_rtx ();
  thisloop->data.loop.end_label = gen_label_rtx ();
  thisloop->data.loop.alt_end_label = 0;
  thisloop->data.loop.continue_label = thisloop->data.loop.start_label;
  thisloop->exit_label = exit_flag ? thisloop->data.loop.end_label : 0;
  loop_stack = thisloop;
  nesting_stack = thisloop;

  if (output_bytecode)
    {
      bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thisloop->data.loop.start_label))->fld[1].rtx)));
      return thisloop;
    }

  do_pending_stack_adjust ();
  emit_queue ();
  emit_note (((void *)0), -4);
  emit_label (thisloop->data.loop.start_label);

  return thisloop;
}




struct n64_tag_nesting *
expand_start_loop_continue_elsewhere(int exit_flag) asm("_expand_start_loop_continue_elsewhere");
struct n64_tag_nesting *
expand_start_loop_continue_elsewhere(int exit_flag)
{
  struct n64_tag_nesting *thisloop = expand_start_loop (exit_flag);
  loop_stack->data.loop.continue_label = gen_label_rtx ();
  return thisloop;
}






void
expand_loop_continue_here(void) asm("_expand_loop_continue_here");
void
expand_loop_continue_here(void)
{
  if (output_bytecode)
    {
      bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((loop_stack->data.loop.continue_label))->fld[1].rtx)));
      return;
    }
  do_pending_stack_adjust ();
  emit_note (((void *)0), -8);
  emit_label (loop_stack->data.loop.continue_label);
}



static void
bc_expand_end_loop(void) asm("_bc_expand_end_loop");
static void
bc_expand_end_loop(void)
{
  struct n64_tag_nesting *thisloop = loop_stack;

  bc_emit_bytecode (jump);
  bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thisloop->data.loop.start_label))->fld[1].rtx)));





  bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thisloop->exit_label))->fld[1].rtx)));
  do { struct n64_tag_nesting *target = loop_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);
  last_expr_type = 0;
}





void
expand_end_loop(void) asm("_expand_end_loop");
void
expand_end_loop(void)
{
  register rtx insn;
  register rtx start_label;
  rtx last_test_insn = 0;
  int num_insns = 0;

  if (output_bytecode)
    {
      bc_expand_end_loop ();
      return;
    }

  insn = get_last_insn ();
  start_label = loop_stack->data.loop.start_label;


  if (start_label == loop_stack->data.loop.continue_label)
    emit_note_before (-8, start_label);

  do_pending_stack_adjust ();
  if (optimize
      &&
      ! (((insn)->code) == JUMP_INSN
  && ((((insn)->fld[3].rtx))->code) == SET
  && ((((insn)->fld[3].rtx))->fld[0].rtx) == pc_rtx
  && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == IF_THEN_ELSE))
    {


      for (insn = ((loop_stack->data.loop.start_label)->fld[2].rtx); insn;
    insn = ((insn)->fld[2].rtx))
 {
   if (((insn)->code) == CALL_INSN || ((insn)->code) == CODE_LABEL)
     break;

   if (((insn)->code) == NOTE
       && (((insn)->fld[4].rtint) == -2
    || ((insn)->fld[4].rtint) == -3))
     break;

   if (((insn)->code) == JUMP_INSN || ((insn)->code) == INSN)
     num_insns++;

   if (last_test_insn && num_insns > 30)
     break;

   if (((insn)->code) == JUMP_INSN && ((((insn)->fld[3].rtx))->code) == SET
       && ((((insn)->fld[3].rtx))->fld[0].rtx) == pc_rtx
       && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == IF_THEN_ELSE
       && ((((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->code) == LABEL_REF
     && ((((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->fld[0].rtx)
   == loop_stack->data.loop.end_label)
         || (((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[1].rtx))->fld[0].rtx)
      == loop_stack->data.loop.alt_end_label)))
    || (((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->code) == LABEL_REF
        && ((((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->fld[0].rtx)
      == loop_stack->data.loop.end_label)
     || (((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[2].rtx))->fld[0].rtx)
         == loop_stack->data.loop.alt_end_label)))))
     last_test_insn = insn;

   if (last_test_insn == 0 && ((insn)->code) == JUMP_INSN
       && ((((insn)->fld[3].rtx))->code) == SET
       && ((((insn)->fld[3].rtx))->fld[0].rtx) == pc_rtx
       && ((((((insn)->fld[3].rtx))->fld[1].rtx))->code) == LABEL_REF
       && ((((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx)
     == loop_stack->data.loop.end_label)
    || (((((((insn)->fld[3].rtx))->fld[1].rtx))->fld[0].rtx)
        == loop_stack->data.loop.alt_end_label)))

     last_test_insn = ((insn)->fld[2].rtx);
 }

      if (last_test_insn != 0 && last_test_insn != get_last_insn ())
 {



   register rtx newstart_label = gen_label_rtx ();
   register rtx start_move = start_label;



   if (((((start_move)->fld[1].rtx))->code) == NOTE
       && (((((start_move)->fld[1].rtx))->fld[4].rtint)
    == -8))
     start_move = ((start_move)->fld[1].rtx);

   emit_label_after (newstart_label, ((start_move)->fld[1].rtx));
   reorder_insns (start_move, last_test_insn, get_last_insn ());
   emit_jump_insn_after (gen_jump (start_label),
    ((newstart_label)->fld[1].rtx));
   emit_barrier_after (((newstart_label)->fld[1].rtx));
   start_label = newstart_label;
 }
    }

  emit_jump (start_label);
  emit_note (((void *)0), -5);
  emit_label (loop_stack->data.loop.end_label);

  do { struct n64_tag_nesting *target = loop_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);

  last_expr_type = 0;
}






int
expand_continue_loop(struct n64_tag_nesting *whichloop) asm("_expand_continue_loop");
int
expand_continue_loop(struct n64_tag_nesting *whichloop)
{
  last_expr_type = 0;
  if (whichloop == 0)
    whichloop = loop_stack;
  if (whichloop == 0)
    return 0;
  expand_goto_internal ((tree) 
                       ((void *)0)
                                , whichloop->data.loop.continue_label,
   (rtx) 0);
  return 1;
}




int
expand_exit_loop(struct n64_tag_nesting *whichloop) asm("_expand_exit_loop");
int
expand_exit_loop(struct n64_tag_nesting *whichloop)
{
  last_expr_type = 0;
  if (whichloop == 0)
    whichloop = loop_stack;
  if (whichloop == 0)
    return 0;
  expand_goto_internal ((tree) 
                       ((void *)0)
                                , whichloop->data.loop.end_label, (rtx) 0);
  return 1;
}





int
expand_exit_loop_if_false(struct n64_tag_nesting *whichloop, tree cond) asm("_expand_exit_loop_if_false");
int
expand_exit_loop_if_false(struct n64_tag_nesting *whichloop, tree cond)
{
  last_expr_type = 0;
  if (whichloop == 0)
    whichloop = loop_stack;
  if (whichloop == 0)
    return 0;
  if (output_bytecode)
    {
      bc_expand_expr (cond);
      bc_expand_goto_internal (xjumpifnot,
          (*(struct n64_tag_bc_label **) &(((whichloop->exit_label))->fld[1].rtx)),
          (tree) 
         ((void *)0)
                  );
    }
  else
    {




      rtx label = gen_label_rtx ();
      rtx last_insn;

      do_jump (cond, (rtx) 0, label);
      last_insn = get_last_insn ();
      if (((last_insn)->code) == CODE_LABEL)
 whichloop->data.loop.alt_end_label = last_insn;
      expand_goto_internal ((tree) 
                           ((void *)0)
                                    , whichloop->data.loop.end_label,
       (rtx) 0);
      emit_label (label);
    }

  return 1;
}
int
preserve_subexpressions_p(void) asm("_preserve_subexpressions_p");
int
preserve_subexpressions_p(void)
{
  rtx insn;

  if (flag_expensive_optimizations)
    return 1;

  if (optimize == 0 || loop_stack == 0)
    return 0;

  insn = get_last_insn_anywhere ();

  return (insn
   && (((insn)->fld[0].rtint) - ((loop_stack->data.loop.start_label)->fld[0].rtint)
       < n_non_fixed_regs * 3));

}
int
expand_exit_something(void) asm("_expand_exit_something");
int
expand_exit_something(void)
{
  struct n64_tag_nesting *n;
  last_expr_type = 0;
  for (n = nesting_stack; n; n = n->all)
    if (n->exit_label != 0)
      {
 expand_goto_internal ((tree) 
                      ((void *)0)
                               , n->exit_label, (rtx) 0);
 return 1;
      }

  return 0;
}




void
expand_null_return(void) asm("_expand_null_return");
void
expand_null_return(void)
{
  struct n64_tag_nesting *block = block_stack;
  rtx last_insn = 0;

  if (output_bytecode)
    {
      bc_emit_instruction (ret);
      return;
    }



  while (block && block->data.block.cleanups == 0)
    block = block->next;



  expand_null_return_1 (last_insn, block != 0);
}



static void
expand_value_return(rtx val) asm("_expand_value_return");
static void
expand_value_return(rtx val)
{
  struct n64_tag_nesting *block = block_stack;
  rtx last_insn = get_last_insn ();
  rtx return_reg = ((((current_function_decl)->decl.result))->decl.rtl);




  if (return_reg != val)
    {
 emit_move_insn (return_reg, val);
    }
  if (((return_reg)->code) == REG
      && ((return_reg)->fld[0].rtint) < 68)
    emit_insn (gen_rtx (USE, VOIDmode, return_reg));



  while (block && block->data.block.cleanups == 0)
    block = block->next;




  expand_null_return_1 (last_insn, block != 0);
}







static void
expand_null_return_1(rtx last_insn, int use_goto) asm("_expand_null_return_1");
static void
expand_null_return_1(rtx last_insn, int use_goto)
{
  rtx end_label = cleanup_label ? cleanup_label : return_label;

  clear_pending_stack_adjust ();
  do_pending_stack_adjust ();
  last_expr_type = 0;


  if (current_function_returns_pcc_struct || use_goto)
    {
      if (end_label == 0)
 end_label = return_label = gen_label_rtx ();
      expand_goto_internal ((tree) 
                           ((void *)0)
                                    , end_label, last_insn);
      return;
    }




  if ((simple_epilogue_p ()) && use_goto == 0 && cleanup_label == 0)
    {
      emit_jump_insn (gen_return ());
      emit_barrier ();
      return;
    }



  expand_goto_internal ((tree) 
                       ((void *)0)
                                , end_label, last_insn);
}




void
expand_return(tree retval) asm("_expand_return");
void
expand_return(tree retval)
{
  rtx last_insn = 0;
  register rtx val = 0;
  register rtx op0;
  tree retval_rhs;
  int cleanups;
  struct n64_tag_nesting *block;



  if (output_bytecode)
    {
      bc_expand_expr (retval);
      bc_emit_instruction (ret);
      return;
    }


  if (((n64_enum_tree_code) (((((current_function_decl)->common.type))->common.type))->common.code) == VOID_TYPE)
    {
      expand_expr (retval, (rtx) 0, VOIDmode, 0);
      emit_queue ();
      expand_null_return ();
      return;
    }
  cleanups = 1;


  if (((n64_enum_tree_code) (retval)->common.code) == RESULT_DECL)
    retval_rhs = retval;
  else if ((((n64_enum_tree_code) (retval)->common.code) == MODIFY_EXPR || ((n64_enum_tree_code) (retval)->common.code) == INIT_EXPR)
    && ((n64_enum_tree_code) (((retval)->exp.operands[0]))->common.code) == RESULT_DECL)
    retval_rhs = ((retval)->exp.operands[1]);
  else if (((retval)->common.type) == void_type_node)

    retval_rhs = retval;
  else
    retval_rhs = (tree) 
                ((void *)0)
                         ;


  if (cleanups || cleanup_label != 0)
    last_insn = get_last_insn ();







  if (optimize && retval_rhs != 0
      && frame_offset == 0
      && ((n64_enum_tree_code) (retval_rhs)->common.code) == COND_EXPR
      && (((n64_enum_tree_code) (((retval_rhs)->exp.operands[1]))->common.code) == CALL_EXPR
   || ((n64_enum_tree_code) (((retval_rhs)->exp.operands[2]))->common.code) == CALL_EXPR))
    {
      rtx label = gen_label_rtx ();
      tree expr;

      do_jump (((retval_rhs)->exp.operands[0]), label, (rtx) 0);
      expr = build (MODIFY_EXPR, ((current_function_decl)->common.type),
      ((current_function_decl)->decl.result),
      ((retval_rhs)->exp.operands[1]));
      ((expr)->common.side_effects_flag) = 1;
      expand_return (expr);
      emit_label (label);

      expr = build (MODIFY_EXPR, ((current_function_decl)->common.type),
      ((current_function_decl)->decl.result),
      ((retval_rhs)->exp.operands[2]));
      ((expr)->common.side_effects_flag) = 1;
      expand_return (expr);
      return;
    }






  if (optimize && retval_rhs != 0
      && frame_offset == 0
      && ((n64_enum_tree_code) (retval_rhs)->common.code) == CALL_EXPR
      && ((n64_enum_tree_code) (((retval_rhs)->exp.operands[0]))->common.code) == ADDR_EXPR
      && ((((retval_rhs)->exp.operands[0]))->exp.operands[0]) == current_function_decl


      && tail_recursion_args (((retval_rhs)->exp.operands[1]),
         ((current_function_decl)->decl.arguments)))
    {
      if (tail_recursion_label == 0)
 {
   tail_recursion_label = gen_label_rtx ();
   emit_label_after (tail_recursion_label,
       tail_recursion_reentry);
 }
      emit_queue ();
      expand_goto_internal ((tree) 
                           ((void *)0)
                                    , tail_recursion_label, last_insn);
      emit_barrier ();
      return;
    }






  if ((simple_epilogue_p ()) && cleanup_label == 0
      && ! current_function_returns_pcc_struct
      && ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 2 : 1) <= 1)
    {




      if (retval_rhs)
 switch (((n64_enum_tree_code) (retval_rhs)->common.code))
   {
   case EQ_EXPR:
   case NE_EXPR:
   case GT_EXPR:
   case GE_EXPR:
   case LT_EXPR:
   case LE_EXPR:
   case TRUTH_ANDIF_EXPR:
   case TRUTH_ORIF_EXPR:
   case TRUTH_AND_EXPR:
   case TRUTH_OR_EXPR:
   case TRUTH_NOT_EXPR:
   case TRUTH_XOR_EXPR:
     op0 = gen_label_rtx ();
     jumpifnot (retval_rhs, op0);
     expand_value_return (const1_rtx);
     emit_label (op0);
     expand_value_return (const0_rtx);
     return;
   }
    }
  if (retval_rhs != 0
      && ((((retval_rhs)->common.type))->type.mode) == BLKmode
      && ((((((current_function_decl)->decl.result))->decl.rtl))->code) == REG)
    {
      int i, bitpos, xbitpos;
      int big_endian_correction = 0;
      int bytes = int_size_in_bytes (((retval_rhs)->common.type));
      int n_regs = (bytes + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4);
      int bitsize = ((((((retval_rhs)->common.type))->type.align)) < (((target_flags & 0x00002000) ? 64 : 32)) ? (((((retval_rhs)->common.type))->type.align)) : (((target_flags & 0x00002000) ? 64 : 32)));
      rtx *result_pseudos = (rtx *) 
                                   __builtin_alloca((
                                   sizeof (rtx) * n_regs
                                   ))
                                                                 ;
      rtx result_reg, src, dst;
      rtx result_val = expand_expr (retval_rhs, (rtx) 0, VOIDmode, 0);
      n64_enum_machine_mode tmpmode, result_reg_mode;





      if (((target_flags & 0x00010000) != 0) && bytes % ((target_flags & 0x00002000) ? 8 : 4))
 big_endian_correction = (((target_flags & 0x00002000) ? 64 : 32) - ((bytes % ((target_flags & 0x00002000) ? 8 : 4))
        * 8));


      for (bitpos = 0, xbitpos = big_endian_correction;
    bitpos < bytes * 8;
    bitpos += bitsize, xbitpos += bitsize)
 {



   if (xbitpos % ((target_flags & 0x00002000) ? 64 : 32) == 0
       || xbitpos == big_endian_correction)
     {

       dst = gen_reg_rtx (word_mode);
       result_pseudos[xbitpos / ((target_flags & 0x00002000) ? 64 : 32)] = dst;


       emit_insn (gen_rtx (CLOBBER, VOIDmode, dst));
     }



   if (bitpos % ((target_flags & 0x00002000) ? 64 : 32) == 0)
     src = operand_subword_force (result_val,
      bitpos / ((target_flags & 0x00002000) ? 64 : 32),
      BLKmode);



   store_bit_field (dst, bitsize, xbitpos % ((target_flags & 0x00002000) ? 64 : 32), word_mode,
      extract_bit_field (src, bitsize,
           bitpos % ((target_flags & 0x00002000) ? 64 : 32), 1,
           (rtx) 0, word_mode,
           word_mode,
           bitsize / 8,
           ((target_flags & 0x00002000) ? 64 : 32)),
      bitsize / 8, ((target_flags & 0x00002000) ? 64 : 32));
 }




      bytes = int_size_in_bytes (((retval_rhs)->common.type));
      for (tmpmode = class_narrowest_mode[(int)(MODE_INT)];
    tmpmode != MAX_MACHINE_MODE;
    tmpmode = (mode_wider_mode[(int)(tmpmode)]))
 {

   if ((mode_size[(int)(tmpmode)]) >= bytes)
     break;
 }


      if (tmpmode == MAX_MACHINE_MODE)
 abort ();

      ((((((current_function_decl)->decl.result))->decl.rtl))->mode = (tmpmode));

      if ((mode_size[(int)(tmpmode)]) < (mode_size[(int)(word_mode)]))
 result_reg_mode = word_mode;
      else
 result_reg_mode = tmpmode;
      result_reg = gen_reg_rtx (result_reg_mode);


      emit_queue ();
      free_temp_slots ();
      for (i = 0; i < n_regs; i++)
 emit_move_insn (operand_subword (result_reg, i, 0, result_reg_mode),
   result_pseudos[i]);

      if (tmpmode != result_reg_mode)
 result_reg = gen_lowpart (tmpmode, result_reg);

      expand_value_return (result_reg);
    }
  else if (cleanups
      && retval_rhs != 0
      && ((retval_rhs)->common.type) != void_type_node
      && ((((((current_function_decl)->decl.result))->decl.rtl))->code) == REG)
    {

      val = expand_expr (retval_rhs, (rtx) 0, VOIDmode, 0);
      emit_queue ();

      free_temp_slots ();

      expand_value_return (val);
    }
  else
    {


      expand_expr (retval, const0_rtx, VOIDmode, 0);
      emit_queue ();
      free_temp_slots ();
      expand_value_return (((((current_function_decl)->decl.result))->decl.rtl));
    }
}




int
drop_through_at_end_p(void) asm("_drop_through_at_end_p");
int
drop_through_at_end_p(void)
{
  rtx insn = get_last_insn ();
  while (insn && ((insn)->code) == NOTE)
    insn = ((insn)->fld[1].rtx);
  return insn && ((insn)->code) != BARRIER;
}







static int
tail_recursion_args(tree actuals, tree formals) asm("_tail_recursion_args");
static int
tail_recursion_args(tree actuals, tree formals)
{
  register tree a = actuals, f = formals;
  register int i;
  register rtx *argvec;
  for (a = actuals, f = formals, i = 0; a && f; a = ((a)->common.chain), f = ((f)->common.chain), i++)
    {
      if (((((a)->list.value))->common.type) != ((f)->common.type))
 return 0;
      if (((((f)->decl.rtl))->code) != REG || ((f)->decl.mode) == BLKmode)
 return 0;
    }
  if (a != 0 || f != 0)
    return 0;



  argvec = (rtx *) 
                  __builtin_alloca((
                  i * sizeof (rtx)
                  ))
                                           ;

  for (a = actuals, i = 0; a; a = ((a)->common.chain), i++)
    argvec[i] = expand_expr (((a)->list.value), (rtx) 0, VOIDmode, 0);




  for (a = actuals, i = 0; a; a = ((a)->common.chain), i++)
    {
      int copy = 0;
      register int j;
      for (f = formals, j = 0; j < i; f = ((f)->common.chain), j++)
 if (reg_mentioned_p (((f)->decl.rtl), argvec[i]))
   { copy = 1; break; }
      if (copy)
 argvec[i] = copy_to_reg (argvec[i]);
    }



  for (f = formals, a = actuals, i = 0; f;
       f = ((f)->common.chain), a = ((a)->common.chain), i++)
    {
      if (((((f)->decl.rtl))->mode) == ((argvec[i])->mode))
 emit_move_insn (((f)->decl.rtl), argvec[i]);
      else
 convert_move (((f)->decl.rtl), argvec[i],
        ((((((a)->list.value))->common.type))->common.unsigned_flag));
    }

  free_temp_slots ();
  return 1;
}







void
expand_start_bindings(int exit_flag) asm("_expand_start_bindings");
void
expand_start_bindings(int exit_flag)
{
  struct n64_tag_nesting *thisblock = (struct n64_tag_nesting *) __extension__ ({ struct n64_tag_obstack *__h = (&stmt_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_nesting))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  rtx note = output_bytecode ? 0 : emit_note (((void *)0), -2);



  thisblock->next = block_stack;
  thisblock->all = nesting_stack;
  thisblock->depth = ++nesting_depth;
  thisblock->data.block.stack_level = 0;
  thisblock->data.block.cleanups = 0;
  thisblock->data.block.function_call_count = 0;
  if (block_stack
      && !(block_stack->data.block.cleanups == (tree) 
                                              ((void *)0)
    
   && block_stack->data.block.outer_cleanups == (tree) 
                                                ((void *)0)
                                                         ))
    thisblock->data.block.outer_cleanups
      = tree_cons ((tree) 
                  ((void *)0)
                           , block_stack->data.block.cleanups,
     block_stack->data.block.outer_cleanups);
  else
    thisblock->data.block.outer_cleanups = 0;

  thisblock->data.block.label_chain = 0;
  thisblock->data.block.innermost_stack_block = stack_block_stack;
  thisblock->data.block.first_insn = note;
  thisblock->data.block.block_start_count = ++block_start_count;
  thisblock->exit_label = exit_flag ? gen_label_rtx () : 0;
  block_stack = thisblock;
  nesting_stack = thisblock;

  if (!output_bytecode)
    {

      push_temp_slots ();
    }
}





void
remember_end_note(register tree block) asm("_remember_end_note");
void
remember_end_note(register tree block)
{
  ((block)->block.end_note) = last_block_end_note;
  last_block_end_note = (rtx) 0;
}
void
expand_end_bindings(tree vars, int mark_ends, int dont_jump_in) asm("_expand_end_bindings");
void
expand_end_bindings(tree vars, int mark_ends, int dont_jump_in)
{
  register struct n64_tag_nesting *thisblock = block_stack;
  register tree decl;

  if (output_bytecode)
    {
      bc_expand_end_bindings (vars, mark_ends, dont_jump_in);
      return;
    }

  if (warn_unused)
    for (decl = vars; decl; decl = ((decl)->common.chain))
      if (! ((decl)->common.used_flag) && ((n64_enum_tree_code) (decl)->common.code) == VAR_DECL
   && ! ((decl)->decl.in_system_header_flag))
 warning_with_decl (decl, "unused variable `%s'");

  if (thisblock->exit_label)
    {
      do_pending_stack_adjust ();
      emit_label (thisblock->exit_label);
    }



  if (function_call_count != thisblock->data.block.function_call_count
      && nonlocal_labels


      && (thisblock->next == 0 ? current_function_has_nonlocal_label


   : (thisblock->data.block.cleanups != 0
      || thisblock->data.block.stack_level != 0)))
    {
      tree link;
      rtx afterward = gen_label_rtx ();
      rtx handler_label = gen_label_rtx ();
      rtx save_receiver = gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode));
      rtx insns;


      ((handler_label)->in_struct) = 1;



      if (thisblock->next != 0)
 {
   emit_move_insn (nonlocal_goto_handler_slot, save_receiver);

   start_sequence ();
   emit_move_insn (save_receiver, nonlocal_goto_handler_slot);
   insns = get_insns ();
   end_sequence ();
   emit_insns_before (insns, thisblock->data.block.first_insn);
 }

      start_sequence ();
      emit_move_insn (nonlocal_goto_handler_slot,
        gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), handler_label));
      insns = get_insns ();
      end_sequence ();
      emit_insns_before (insns, thisblock->data.block.first_insn);


      emit_jump (afterward);
      emit_label (handler_label);
 emit_move_insn (virtual_stack_vars_rtx, hard_frame_pointer_rtx);


      if (fixed_regs[0])
 {






   static struct n64_tag_elims {int from, to;} elim_regs[] = {{ 0, (0 + 29)}, { 0, (0 + 30)}, { (0 + 30), (0 + 29)}};
   int i;

   for (i = 0; i < sizeof elim_regs / sizeof elim_regs[0]; i++)
     if (elim_regs[i].from == 0
  && elim_regs[i].to == (0 + 30))
       break;

   if (i == sizeof elim_regs / sizeof elim_regs [0])

     {




       if (arg_pointer_save_area == 0)
  arg_pointer_save_area
    = assign_stack_local (((target_flags & 0x00000002) ? DImode : SImode), (mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]), 0);
       emit_move_insn (virtual_incoming_args_rtx,


         copy_to_reg (arg_pointer_save_area));
     }
 }





      for (link = nonlocal_labels; link; link = ((link)->common.chain))

 if (! ((((link)->list.value))->decl.bit_field_flag))
   {
     rtx not_this = gen_label_rtx ();
     rtx cxx_this = gen_label_rtx ();
     do_jump_if_equal (static_chain_rtx,
         gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), ((((link)->list.value))->decl.rtl)),
         cxx_this, 0);
     emit_jump (not_this);
     emit_label (cxx_this);
     expand_goto (((link)->list.value));
     emit_label (not_this);
   }

      emit_library_call (gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "abort"), 0,
    VOIDmode, 0);
      emit_barrier ();
      emit_label (afterward);
    }


  if (dont_jump_in
      || thisblock->data.block.stack_level != 0
      || thisblock->data.block.cleanups != 0)
    {
      struct n64_tag_label_chain *chain;



      for (chain = thisblock->data.block.label_chain; chain; chain = chain->next)
 {
   ((chain->label)->decl.bit_field_flag) = 1;



   if (((chain->label)->common.addressable_flag))
     error_with_decl (chain->label,
        "label `%s' used before containing binding contour");
 }
    }





  if (thisblock->data.block.stack_level != 0
      || thisblock->data.block.cleanups != 0)
    {

      int reachable = ((get_last_insn ())->code) != BARRIER;


      int old_expr_stmts_for_value = expr_stmts_for_value;
      rtx old_last_expr_value = last_expr_value;
      tree old_last_expr_type = last_expr_type;
      expr_stmts_for_value = 0;


      expand_cleanups (thisblock->data.block.cleanups, (tree) 
                                                      ((void *)0)
                                                               , 0, reachable);
      if (reachable)
 do_pending_stack_adjust ();

      expr_stmts_for_value = old_expr_stmts_for_value;
      last_expr_value = old_last_expr_value;
      last_expr_type = old_last_expr_type;



      if (reachable && thisblock->data.block.stack_level != 0)
 {
   emit_stack_restore (thisblock->next ? SAVE_BLOCK : SAVE_FUNCTION,
         thisblock->data.block.stack_level, (rtx) 0);
   if (nonlocal_goto_handler_slot != 0)
     emit_stack_save (SAVE_NONLOCAL, &nonlocal_goto_stack_level,
        (rtx) 0);
 }




      fixup_gotos (thisblock,
     thisblock->data.block.stack_level,
     thisblock->data.block.cleanups,
     thisblock->data.block.first_insn,
     dont_jump_in);
    }





  if (mark_ends)
    last_block_end_note = emit_note (((void *)0), -3);
  else

    ((thisblock->data.block.first_insn)->fld[4].rtint) = -1;




  if (obey_regdecls)
    for (decl = vars; decl; decl = ((decl)->common.chain))
      {
 rtx rtl = ((decl)->decl.rtl);
 if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL && rtl != 0)
   use_variable (rtl);
      }



  stack_block_stack = thisblock->data.block.innermost_stack_block;
  do { struct n64_tag_nesting *target = block_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);


  pop_temp_slots ();
}
static void
bc_expand_end_bindings(tree vars, int mark_ends, int dont_jump_in) asm("_bc_expand_end_bindings");
static void
bc_expand_end_bindings(tree vars, int mark_ends, int dont_jump_in)
{
  struct n64_tag_nesting *thisbind = nesting_stack;
  tree decl;

  if (warn_unused)
    for (decl = vars; decl; decl = ((decl)->common.chain))
      if (! ((((decl)->list.value))->common.used_flag) && ((n64_enum_tree_code) (((decl)->list.value))->common.code) == VAR_DECL)
 warning_with_decl (decl, "unused variable `%s'");

  if (thisbind->exit_label)
    bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thisbind->exit_label))->fld[1].rtx)));


  do { struct n64_tag_nesting *target = block_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);
}




void
expand_decl(register tree decl) asm("_expand_decl");
void
expand_decl(register tree decl)
{
  struct n64_tag_nesting *thisblock = block_stack;
  tree type;

  if (output_bytecode)
    {
      bc_expand_decl (decl, 0);
      return;
    }

  type = ((decl)->common.type);







  if (((n64_enum_tree_code) (decl)->common.code) != VAR_DECL)
    return;
  if (((decl)->common.static_flag) || ((decl)->decl.external_flag))
    return;



  if (type == error_mark_node)
    ((decl)->decl.rtl) = gen_rtx (MEM, BLKmode, const0_rtx);
  else if (((decl)->decl.size) == 0)

    {
      if (((decl)->decl.initial) == 0)

 ((decl)->decl.rtl) = assign_stack_temp (((decl)->decl.mode), 0, 1);
      else


 ((decl)->decl.rtl) = gen_rtx (MEM, BLKmode, gen_reg_rtx (((target_flags & 0x00000002) ? DImode : SImode)));
      ((((decl)->decl.rtl))->in_struct) = (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (type)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (type)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (type)->common.code) == SET_TYPE);
    }
  else if (((decl)->decl.mode) != BLKmode


    && !(flag_float_store
  && ((n64_enum_tree_code) (type)->common.code) == REAL_TYPE)
    && ! ((decl)->common.volatile_flag)
    && ! ((decl)->common.addressable_flag)
    && (((decl)->decl.regdecl_flag) || ! obey_regdecls))
    {

      int unsignedp = ((type)->common.unsigned_flag);
      n64_enum_machine_mode reg_mode
 = promote_mode (type, ((decl)->decl.mode), &unsignedp, 0);

      if (((n64_enum_tree_code) (type)->common.code) == COMPLEX_TYPE)
 {
   rtx realpart, imagpart;
   n64_enum_machine_mode partmode = ((((type)->common.type))->type.mode);




   realpart = gen_reg_rtx (partmode);
   ((realpart)->volatil) = 1;
   imagpart = gen_reg_rtx (partmode);
   ((imagpart)->volatil) = 1;
   ((decl)->decl.rtl) = gen_rtx (CONCAT, reg_mode, realpart, imagpart);
 }
      else
 {
   ((decl)->decl.rtl) = gen_reg_rtx (reg_mode);
   if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE)
     mark_reg_pointer (((decl)->decl.rtl));
   ((((decl)->decl.rtl))->volatil) = 1;
 }
    }
  else if (((n64_enum_tree_code) (((decl)->decl.size))->common.code) == INTEGER_CST)
    {

      rtx oldaddr = 0;
      rtx addr;





      if (((decl)->decl.rtl) != 0)
 {
   if (((((decl)->decl.rtl))->code) != MEM
       || ((((((decl)->decl.rtl))->fld[0].rtx))->code) != REG)
     abort ();
   oldaddr = ((((decl)->decl.rtl))->fld[0].rtx);
 }

      ((decl)->decl.rtl)
 = assign_stack_temp (((decl)->decl.mode),
        ((((((decl)->decl.size))->int_cst.int_cst_low)
          + 8 - 1)
         / 8),
        1);
      ((((decl)->decl.rtl))->in_struct) = (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == SET_TYPE);


      ((decl)->decl.frame_size.u) = (((decl)->decl.mode) == BLKmode ? 64
      : (8 * mode_size[(int)(((decl)->decl.mode))]));

      if (oldaddr)
 {
   addr = force_operand (((((decl)->decl.rtl))->fld[0].rtx), oldaddr);
   if (addr != oldaddr)
     emit_move_insn (oldaddr, addr);
 }



      ((((decl)->decl.rtl))->in_struct) = (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == SET_TYPE);







    }
  else

    {
      rtx address, size;



      if (thisblock->data.block.stack_level == 0)
 {
   do_pending_stack_adjust ();
   emit_stack_save (thisblock->next ? SAVE_BLOCK : SAVE_FUNCTION,
      &thisblock->data.block.stack_level,
      thisblock->data.block.first_insn);
   stack_block_stack = thisblock;
 }


      size = expand_expr (size_binop (CEIL_DIV_EXPR,
          ((decl)->decl.size),
          size_int (8)),
     (rtx) 0, VOIDmode, 0);
      free_temp_slots ();


      address = allocate_dynamic_stack_space (size, (rtx) 0,
           ((decl)->decl.frame_size.u));


      ((decl)->decl.rtl) = gen_rtx (MEM, ((decl)->decl.mode), address);



      ((((decl)->decl.rtl))->in_struct) = (((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == QUAL_UNION_TYPE || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == SET_TYPE);



      ((decl)->decl.frame_size.u) = 64;



    }

  if (((decl)->common.volatile_flag))
    ((((decl)->decl.rtl))->volatil) = 1;
  if (obey_regdecls)
    use_variable (((decl)->decl.rtl));
}







static void
bc_expand_decl(tree decl, tree cleanup) asm("_bc_expand_decl");
static void
bc_expand_decl(tree decl, tree cleanup)
{
  tree type;

  if (!decl)
    {

      if (!cleanup)
 abort ();

      return;
    }


  if (((n64_enum_tree_code) (decl)->common.code) != VAR_DECL || ((decl)->common.static_flag) || ((decl)->decl.external_flag))
    return;

  type = ((decl)->common.type);

  if (type == error_mark_node)
    ((decl)->decl.rtl) = bc_gen_rtx ((char *) 0, 0, (struct n64_tag_bc_label *) 0);

  else if (((decl)->decl.size) == 0)



    ((decl)->decl.rtl) = bc_gen_rtx ((char *) 0, 0, (struct n64_tag_bc_label *) 0);

  else if (((((decl)->decl.size))->common.constant_flag))
    {
      ((decl)->decl.rtl) = bc_allocate_local (((((decl)->decl.size))->int_cst.int_cst_low) / 8,
        ((decl)->decl.frame_size.u));
    }
  else
    ((decl)->decl.rtl) = bc_allocate_variable_array (((decl)->decl.size));
}



void
expand_decl_init(tree decl) asm("_expand_decl_init");
void
expand_decl_init(tree decl)
{
  int was_used = ((decl)->common.used_flag);

  if (output_bytecode)
    {
      bc_expand_decl_init (decl);
      return;
    }







  if (((n64_enum_tree_code) (decl)->common.code) == CONST_DECL)
    {
      if (((decl)->decl.initial) && ((((decl)->decl.initial))->common.constant_flag))
 expand_expr (((decl)->decl.initial), (rtx) 0, VOIDmode,
       EXPAND_INITIALIZER);
      return;
    }

  if (((decl)->common.static_flag))
    return;



  if (((decl)->decl.initial) == error_mark_node)
    {
      n64_enum_tree_code code = ((n64_enum_tree_code) (((decl)->common.type))->common.code);
      if (code == INTEGER_TYPE || code == REAL_TYPE || code == ENUMERAL_TYPE
   || code == POINTER_TYPE)
 expand_assignment (decl, convert (((decl)->common.type), integer_zero_node),
      0, 0);
      emit_queue ();
    }
  else if (((decl)->decl.initial) && ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) != TREE_LIST)
    {
      emit_line_note (((decl)->decl.filename), ((decl)->decl.linenum));
      expand_assignment (decl, ((decl)->decl.initial), 0, 0);
      emit_queue ();
    }


  ((decl)->common.used_flag) = was_used;


  preserve_temp_slots ((rtx) 0);
  free_temp_slots ();
}





static void
bc_expand_variable_local_init(tree decl) asm("_bc_expand_variable_local_init");
static void
bc_expand_variable_local_init(tree decl)
{

  bc_expand_expr (((decl)->decl.size));
  bc_emit_instruction (newlocalSI);
  bc_load_localaddr (((decl)->decl.rtl));
  bc_emit_instruction (storeP);
}




static void
bc_expand_decl_init(tree decl) asm("_bc_expand_decl_init");
static void
bc_expand_decl_init(tree decl)
{
  int org_stack_depth;



  if (((decl)->common.static_flag))
    return;


  org_stack_depth = stack_depth;





  if (((n64_enum_tree_code) (((decl)->decl.size))->common.code) != INTEGER_CST)
    bc_expand_variable_local_init (decl);


  if (((decl)->decl.initial) == error_mark_node)
    {
      n64_enum_tree_code code = ((n64_enum_tree_code) (((decl)->common.type))->common.code);

      if (code == INTEGER_TYPE || code == REAL_TYPE || code == ENUMERAL_TYPE
   || code == POINTER_TYPE)

 expand_assignment (((decl)->common.type), decl, 0, 0);
    }
  else if (((decl)->decl.initial))
    expand_assignment (((decl)->common.type), decl, 0, 0);


  if (org_stack_depth > stack_depth)
    abort ();

  bc_adjust_stack (stack_depth - org_stack_depth);
}
int
expand_decl_cleanup(tree decl, tree cleanup) asm("_expand_decl_cleanup");
int
expand_decl_cleanup(tree decl, tree cleanup)
{
  struct n64_tag_nesting *thisblock = block_stack;


  if (thisblock == 0)
    return 0;



  if (cleanup != 0)
    {
      thisblock->data.block.cleanups
 = temp_tree_cons (decl, cleanup, thisblock->data.block.cleanups);

      stack_block_stack = thisblock;
      (*interim_eh_hook) ((tree) 
                         ((void *)0)
                                  );
    }
  return 1;
}





void
expand_anon_union_decl(tree decl, tree cleanup, tree decl_elts) asm("_expand_anon_union_decl");
void
expand_anon_union_decl(tree decl, tree cleanup, tree decl_elts)
{
  struct n64_tag_nesting *thisblock = block_stack;
  rtx x;

  expand_decl (decl);
  expand_decl_cleanup (decl, cleanup);
  x = ((decl)->decl.rtl);

  while (decl_elts)
    {
      tree decl_elt = ((decl_elts)->list.value);
      tree cleanup_elt = ((decl_elts)->list.purpose);
      n64_enum_machine_mode mode = ((((decl_elt)->common.type))->type.mode);


      ((decl_elt)->decl.frame_size.u) = ((decl)->decl.frame_size.u);




      if (mode == BLKmode && ((decl)->decl.mode) != BLKmode)
 ((decl_elt)->decl.mode) = mode
   = mode_for_size (((((decl_elt)->decl.size))->int_cst.int_cst_low),
      MODE_INT, 1);



      if (((x)->code) == MEM)
 {
   if (mode == ((x)->mode))
     ((decl_elt)->decl.rtl) = x;
   else
     {
       ((decl_elt)->decl.rtl) = gen_rtx (MEM, mode, copy_rtx (((x)->fld[0].rtx)));
       ((((decl_elt)->decl.rtl))->in_struct) = ((x)->in_struct);
       ((((decl_elt)->decl.rtl))->unchanging) = ((x)->unchanging);
     }
 }
      else if (((x)->code) == REG)
 {
   if (mode == ((x)->mode))
     ((decl_elt)->decl.rtl) = x;
   else
     ((decl_elt)->decl.rtl) = gen_rtx (SUBREG, mode, x, 0);
 }
      else
 abort ();



      if (cleanup != 0)
 thisblock->data.block.cleanups
   = temp_tree_cons (decl_elt, cleanup_elt,
       thisblock->data.block.cleanups);

      decl_elts = ((decl_elts)->common.chain);
    }
}
static void
expand_cleanups(tree list, tree dont_do, int in_fixup, int reachable) asm("_expand_cleanups");
static void
expand_cleanups(tree list, tree dont_do, int in_fixup, int reachable)
{
  tree tail;
  for (tail = list; tail; tail = ((tail)->common.chain))
    if (dont_do == 0 || ((tail)->list.purpose) != dont_do)
      {
 if (((n64_enum_tree_code) (((tail)->list.value))->common.code) == TREE_LIST)
   expand_cleanups (((tail)->list.value), dont_do, in_fixup, reachable);
 else
   {
     if (! in_fixup)
       (*interim_eh_hook) (((tail)->list.value));

     if (reachable)
       {
  expand_expr (((tail)->list.value), const0_rtx, VOIDmode, 0);
  free_temp_slots ();
       }
   }
      }
}







void
move_cleanups_up(void) asm("_move_cleanups_up");
void
move_cleanups_up(void)
{
  struct n64_tag_nesting *block = block_stack;
  struct n64_tag_nesting *outer = block->next;

  outer->data.block.cleanups
    = chainon (block->data.block.cleanups,
        outer->data.block.cleanups);
  block->data.block.cleanups = 0;
}

tree
last_cleanup_this_contour(void) asm("_last_cleanup_this_contour");
tree
last_cleanup_this_contour(void)
{
  if (block_stack == 0)
    return 0;

  return block_stack->data.block.cleanups;
}





int
any_pending_cleanups(int this_contour) asm("_any_pending_cleanups");
int
any_pending_cleanups(int this_contour)
{
  struct n64_tag_nesting *block;

  if (block_stack == 0)
    return 0;

  if (this_contour && block_stack->data.block.cleanups != 
                                                         ((void *)0)
                                                             )
    return 1;
  if (block_stack->data.block.cleanups == 0
      && (block_stack->data.block.outer_cleanups == 0



   ))
    return 0;

  for (block = block_stack->next; block; block = block->next)
    if (block->data.block.cleanups != 0)
      return 1;

  return 0;
}
void
expand_start_case(int exit_flag, tree expr, tree type, char *printname) asm("_expand_start_case");
void
expand_start_case(int exit_flag, tree expr, tree type, char *printname)
{
  register struct n64_tag_nesting *thiscase = (struct n64_tag_nesting *) __extension__ ({ struct n64_tag_obstack *__h = (&stmt_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_nesting))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  thiscase->next = case_stack;
  thiscase->all = nesting_stack;
  thiscase->depth = ++nesting_depth;
  thiscase->exit_label = exit_flag ? gen_label_rtx () : 0;
  thiscase->data.case_stmt.case_list = 0;
  thiscase->data.case_stmt.index_expr = expr;
  thiscase->data.case_stmt.nominal_type = type;
  thiscase->data.case_stmt.default_label = 0;
  thiscase->data.case_stmt.num_ranges = 0;
  thiscase->data.case_stmt.printname = printname;
  thiscase->data.case_stmt.seenlabel = 0;
  case_stack = thiscase;
  nesting_stack = thiscase;

  if (output_bytecode)
    {
      bc_expand_start_case (thiscase, expr, type, printname);
      return;
    }

  do_pending_stack_adjust ();



  if (((get_last_insn ())->code) != NOTE)
    emit_note (((void *)0), -1);

  thiscase->data.case_stmt.start = get_last_insn ();
}





static void
bc_expand_start_case(struct n64_tag_nesting *thiscase, tree expr, tree type, char *printname) asm("_bc_expand_start_case");
static void
bc_expand_start_case(struct n64_tag_nesting *thiscase, tree expr, tree type, char *printname)
{
  bc_expand_expr (expr);
  bc_expand_conversion (((expr)->common.type), type);




  thiscase->data.case_stmt.skip_label = gen_label_rtx ();
  bc_emit_bytecode (jump);
  bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thiscase->data.case_stmt.skip_label))->fld[1].rtx)));




}







void
expand_start_case_dummy(void) asm("_expand_start_case_dummy");
void
expand_start_case_dummy(void)
{
  register struct n64_tag_nesting *thiscase = (struct n64_tag_nesting *) __extension__ ({ struct n64_tag_obstack *__h = (&stmt_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_nesting))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  thiscase->next = case_stack;
  thiscase->all = nesting_stack;
  thiscase->depth = ++nesting_depth;
  thiscase->exit_label = 0;
  thiscase->data.case_stmt.case_list = 0;
  thiscase->data.case_stmt.start = 0;
  thiscase->data.case_stmt.nominal_type = 0;
  thiscase->data.case_stmt.default_label = 0;
  thiscase->data.case_stmt.num_ranges = 0;
  case_stack = thiscase;
  nesting_stack = thiscase;
}



void
expand_end_case_dummy(void) asm("_expand_end_case_dummy");
void
expand_end_case_dummy(void)
{
  do { struct n64_tag_nesting *target = case_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);
}




tree
case_index_expr_type(void) asm("_case_index_expr_type");
tree
case_index_expr_type(void)
{
  if (case_stack)
    return ((case_stack->data.case_stmt.index_expr)->common.type);
  return 0;
}
int
pushcase(register tree value, tree (*converter) (tree, tree), register tree label, tree *duplicate) asm("_pushcase");
int
pushcase(register tree value, tree (*converter) (tree, tree), register tree label, tree *duplicate)
{
  register struct n64_tag_case_node **l;
  register struct n64_tag_case_node *n;
  tree index_type;
  tree nominal_type;

  if (output_bytecode)
    return bc_pushcase (value, label);


  if (! (case_stack && case_stack->data.case_stmt.start))
    return 1;

  if (stack_block_stack
      && stack_block_stack->depth > case_stack->depth)
    return 5;

  index_type = ((case_stack->data.case_stmt.index_expr)->common.type);
  nominal_type = case_stack->data.case_stmt.nominal_type;


  if (index_type == error_mark_node)
    return 0;


  if (value != 0)
    value = (*converter) (nominal_type, value);


  if (case_stack->data.case_stmt.seenlabel == 0)
    {
      rtx insn;
      for (insn = case_stack->data.case_stmt.start;
    insn;
    insn = ((insn)->fld[2].rtx))
 {
   if (((insn)->code) == CODE_LABEL)
     break;
   if (((insn)->code) != NOTE
       && (((insn)->code) != INSN || ((((insn)->fld[3].rtx))->code) != USE))
     {
       warning ("unreachable code at beginning of %s",
         case_stack->data.case_stmt.printname);
       break;
     }
 }
    }
  case_stack->data.case_stmt.seenlabel = 1;



  if (value != 0 && ! int_fits_type_p (value, index_type))
    return 3;


  if (value == 0)
    {
      if (case_stack->data.case_stmt.default_label != 0)
 {
   *duplicate = case_stack->data.case_stmt.default_label;
   return 2;
 }
      case_stack->data.case_stmt.default_label = label;
    }
  else
    {



      for (l = &case_stack->data.case_stmt.case_list;

    *l != 0 && tree_int_cst_lt ((*l)->high, value);
    l = &(*l)->right)
 ;
      if (*l)
 {


   if (! tree_int_cst_lt (value, (*l)->low))
     {
       *duplicate = (*l)->code_label;
       return 2;
     }
 }




      n = (struct n64_tag_case_node *) oballoc (sizeof (struct n64_tag_case_node));
      n->left = 0;
      n->right = *l;
      n->high = n->low = copy_node (value);
      n->code_label = label;
      *l = n;
    }

  expand_label (label);
  return 0;
}







int
pushcase_range(register tree value1, register tree value2, tree (*converter) (tree, tree), register tree label, tree *duplicate) asm("_pushcase_range");
int
pushcase_range(register tree value1, register tree value2, tree (*converter) (tree, tree), register tree label, tree *duplicate)
{
  register struct n64_tag_case_node **l;
  register struct n64_tag_case_node *n;
  tree index_type;
  tree nominal_type;


  if (! (case_stack && case_stack->data.case_stmt.start))
    return 1;

  if (stack_block_stack
      && stack_block_stack->depth > case_stack->depth)
    return 5;

  index_type = ((case_stack->data.case_stmt.index_expr)->common.type);
  nominal_type = case_stack->data.case_stmt.nominal_type;


  if (index_type == error_mark_node)
    return 0;


  if (case_stack->data.case_stmt.seenlabel == 0)
    {
      rtx insn;
      for (insn = case_stack->data.case_stmt.start;
    insn;
    insn = ((insn)->fld[2].rtx))
 {
   if (((insn)->code) == CODE_LABEL)
     break;
   if (((insn)->code) != NOTE
       && (((insn)->code) != INSN || ((((insn)->fld[3].rtx))->code) != USE))
     {
       warning ("unreachable code at beginning of %s",
         case_stack->data.case_stmt.printname);
       break;
     }
 }
    }
  case_stack->data.case_stmt.seenlabel = 1;


  if (value1 == 0)
    value1 = ((index_type)->type.minval);
  value1 = (*converter) (nominal_type, value1);

  if (value2 == 0)
    value2 = ((index_type)->type.maxval);
  value2 = (*converter) (nominal_type, value2);


  if (! int_fits_type_p (value1, index_type))
    return 3;

  if (! int_fits_type_p (value2, index_type))
    return 3;


  if (tree_int_cst_lt (value2, value1))
    return 4;


  if (tree_int_cst_equal (value1, value2))
    return pushcase (value1, converter, label, duplicate);




  for (l = &case_stack->data.case_stmt.case_list;

       *l != 0 && tree_int_cst_lt ((*l)->high, value1);
       l = &(*l)->right)
    ;
  if (*l)
    {


      if (! tree_int_cst_lt (value2, (*l)->low))
 {
   *duplicate = (*l)->code_label;
   return 2;
 }
    }





  n = (struct n64_tag_case_node *) oballoc (sizeof (struct n64_tag_case_node));
  n->left = 0;
  n->right = *l;
  n->low = copy_node (value1);
  n->high = copy_node (value2);
  n->code_label = label;
  *l = n;

  expand_label (label);

  case_stack->data.case_stmt.num_ranges++;

  return 0;
}
static int
bc_pushcase(tree value, tree label) asm("_bc_pushcase");
static int
bc_pushcase(tree value, tree label)
{
  struct n64_tag_nesting *thiscase = case_stack;
  struct n64_tag_case_node *case_label, *new_label;

  if (! thiscase)
    return 1;


  if (value)
    {
      value = convert (thiscase->data.case_stmt.nominal_type, value);
      if (! int_fits_type_p (value, thiscase->data.case_stmt.nominal_type))
 return 3;

      for (case_label = thiscase->data.case_stmt.case_list;
    case_label->left; case_label = case_label->left)
 if (! tree_int_cst_lt (case_label->left->high, value))
   break;

      if (case_label != thiscase->data.case_stmt.case_list
   && ! tree_int_cst_lt (case_label->high, value)
   || case_label->left && ! tree_int_cst_lt (value, case_label->left->low))
 return 2;

      new_label = (struct n64_tag_case_node *) oballoc (sizeof (struct n64_tag_case_node));
      new_label->low = new_label->high = copy_node (value);
      new_label->code_label = label;
      new_label->left = case_label->left;

      case_label->left = new_label;
      thiscase->data.case_stmt.num_ranges++;
    }
  else
    {
      if (thiscase->data.case_stmt.default_label)
 return 2;
      thiscase->data.case_stmt.default_label = label;
    }

  expand_label (label);
  return 0;
}
int
all_cases_count(tree type, int *spareness) asm("_all_cases_count");
int
all_cases_count(tree type, int *spareness)
{
  int count, count_high = 0;
  *spareness = 0;

  switch (((n64_enum_tree_code) (type)->common.code))
    {
      tree t;
    case BOOLEAN_TYPE:
      count = 2;
      break;
    case CHAR_TYPE:
      count = 1 << 8;
      break;
    default:
    case INTEGER_TYPE:
      if (((n64_enum_tree_code) (((type)->type.minval))->common.code) != INTEGER_CST
   || ((n64_enum_tree_code) (((type)->type.maxval))->common.code) != INTEGER_CST)
 return -1;
      else
 {




   tree mint = ((type)->type.minval);
   tree maxt = ((type)->type.maxval);
   int lo, hi;
   neg_double(((mint)->int_cst.int_cst_low), ((mint)->int_cst.int_cst_high),
       &lo, &hi);
   add_double(((maxt)->int_cst.int_cst_low), ((maxt)->int_cst.int_cst_high),
       lo, hi, &lo, &hi);
   add_double (lo, hi, 1, 0, &lo, &hi);
   if (hi != 0 || lo < 0)
     return -2;
   count = lo;
 }
      break;
    case ENUMERAL_TYPE:
      count = 0;
      for (t = ((type)->type.values); t != (tree) 
                                       ((void *)0)
                                                ; t = ((t)->common.chain))
 {
   if (((n64_enum_tree_code) (((type)->type.minval))->common.code) != INTEGER_CST
       || ((n64_enum_tree_code) (((t)->list.value))->common.code) != INTEGER_CST
       || ((((type)->type.minval))->int_cst.int_cst_low) + count
       != ((((t)->list.value))->int_cst.int_cst_low))
     *spareness = 1;
   count++;
 }
      if (*spareness == 1)
 {
   tree prev = ((((type)->type.values))->list.value);
   for (t = ((type)->type.values); t = ((t)->common.chain), t != (tree) 
                                                        ((void *)0)
                                                                 ; )
     {
       if (! tree_int_cst_lt (prev, ((t)->list.value)))
  {
    *spareness = 2;
    break;
  }
       prev = ((t)->list.value);
     }

 }
    }
  return count;
}
void
mark_seen_cases(tree type, unsigned char *cases_seen, long int count, int sparseness) asm("_mark_seen_cases");
void
mark_seen_cases(tree type, unsigned char *cases_seen, long int count, int sparseness)
{
  long i;

  tree next_node_to_try = (tree) 
                         ((void *)0)
                                  ;
  long next_node_offset = 0;

  register struct n64_tag_case_node *n;
  tree val = make_node (INTEGER_CST);
  ((val)->common.type) = type;
  for (n = case_stack->data.case_stmt.case_list; n;
       n = n->right)
    {
      ((val)->int_cst.int_cst_low) = ((n->low)->int_cst.int_cst_low);
      ((val)->int_cst.int_cst_high) = ((n->low)->int_cst.int_cst_high);
      while ( ! tree_int_cst_lt (n->high, val))
 {




   int xlo, xhi;
   tree t;
   if (sparseness == 2)
     {



       for (t = ((type)->type.values), xlo = 0; t != (tree) 
                                                  ((void *)0)
                                                           ;
     t = ((t)->common.chain), xlo++)
  {
    if (tree_int_cst_equal (val, ((t)->list.value)))
      ((cases_seen)[(unsigned)(xlo) / 8] |= 1 << ((unsigned)(xlo) % 8));
  }
     }
   else
     {
       if (sparseness && ((type)->type.values) != (tree) 
                                              ((void *)0)
                                                       )
  {


    t = next_node_to_try;
    xlo = next_node_offset;
    xhi = 0;
    for (;;)
      {
        if (t == (tree) 
                ((void *)0)
                         )
   {
     t = ((type)->type.values);
     xlo = 0;
   }
        if (tree_int_cst_equal (val, ((t)->list.value)))
   {
     next_node_to_try = ((t)->common.chain);
     next_node_offset = xlo + 1;
     break;
   }
        xlo++;
        t = ((t)->common.chain);
        if (t == next_node_to_try)
   break;
      }
  }
       else
  {
    t = ((type)->type.minval);
    if (t)
      neg_double (((t)->int_cst.int_cst_low), ((t)->int_cst.int_cst_high),
    &xlo, &xhi);
    else
      xlo = xhi = 0;
    add_double (xlo, xhi,
         ((val)->int_cst.int_cst_low), ((val)->int_cst.int_cst_high),
         &xlo, &xhi);
  }

       if (xhi == 0 && xlo >= 0 && xlo < count)
  ((cases_seen)[(unsigned)(xlo) / 8] |= 1 << ((unsigned)(xlo) % 8));
     }
   add_double (((val)->int_cst.int_cst_low), ((val)->int_cst.int_cst_high),
        1, 0,
        &((val)->int_cst.int_cst_low), &((val)->int_cst.int_cst_high));
 }
    }
}
void
check_for_full_enumeration_handling(tree type) asm("_check_for_full_enumeration_handling");
void
check_for_full_enumeration_handling(tree type)
{
  register struct n64_tag_case_node *n;
  register struct n64_tag_case_node **l;
  register tree chain;
  int all_values = 1;


  int sparseness = 0;


  int size;



  unsigned char *cases_seen;


  long bytes_needed;
  tree t;

  if (output_bytecode)
    {
      bc_check_for_full_enumeration_handling (type);
      return;
    }

  if (! warn_switch)
    return;

  size = all_cases_count (type, &sparseness);
  bytes_needed = (size + 8) / 8;

  if (size > 0 && size < 600000

      && (cases_seen = (unsigned char *) malloc (bytes_needed)) != 
                                                                  ((void *)0)
                                                                      )
    {
      long i;
      tree v = ((type)->type.values);
      memset (cases_seen,0,bytes_needed);






      mark_seen_cases (type, cases_seen, size, sparseness);

      for (i = 0; v != (tree) 
                       ((void *)0) 
                                 && i < size; i++, v = ((v)->common.chain))
 {
   if (((cases_seen)[(unsigned)(i) / 8] & (1 << ((unsigned)(i) % 8))) == 0)
     warning ("enumeration value `%s' not handled in switch",
       ((((v)->list.purpose))->identifier.pointer));
 }

      free (cases_seen);
    }






  if (warn_switch)
    for (n = case_stack->data.case_stmt.case_list; n; n = n->right)
      {
 for (chain = ((type)->type.values);
      chain && !tree_int_cst_equal (n->low, ((chain)->list.value));
      chain = ((chain)->common.chain))
   ;

 if (!chain)
   {
     if (((type)->type.name) == 0)
       warning ("case value `%d' not in enumerated type",
         ((n->low)->int_cst.int_cst_low));
     else
       warning ("case value `%d' not in enumerated type `%s'",
         ((n->low)->int_cst.int_cst_low),
         (((((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE) ? ((type)->type.name) : ((((type)->type.name))->decl.name))->identifier.pointer)


                                       );
   }
 if (!tree_int_cst_equal (n->low, n->high))
   {
     for (chain = ((type)->type.values);
   chain && !tree_int_cst_equal (n->high, ((chain)->list.value));
   chain = ((chain)->common.chain))
       ;

     if (!chain)
       {
  if (((type)->type.name) == 0)
    warning ("case value `%d' not in enumerated type",
      ((n->high)->int_cst.int_cst_low));
  else
    warning ("case value `%d' not in enumerated type `%s'",
      ((n->high)->int_cst.int_cst_low),
      (((((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE) ? ((type)->type.name) : ((((type)->type.name))->decl.name))->identifier.pointer)


                                           );
       }
   }
      }
}






static void
bc_check_for_full_enumeration_handling(tree type) asm("_bc_check_for_full_enumeration_handling");
static void
bc_check_for_full_enumeration_handling(tree type)
{
  struct n64_tag_nesting *thiscase = case_stack;
  struct n64_tag_case_node *c;
  tree e;


  for (e = ((type)->type.values); e; e = ((e)->common.chain))
    {
      for (c = thiscase->data.case_stmt.case_list->left;
    c && tree_int_cst_lt (c->high, ((e)->list.value));
    c = c->left)
 ;
      if (! (c && tree_int_cst_equal (c->low, ((e)->list.value))))
 warning ("enumerated value `%s' not handled in switch",
   ((((e)->list.purpose))->identifier.pointer));
    }


  for (c = thiscase->data.case_stmt.case_list->left; c; c = c->left)
    {
      for (e = ((type)->type.values);
    e && !tree_int_cst_equal (c->low, ((e)->list.value));
    e = ((e)->common.chain))
 ;
      if (! e)
 warning ("case value `%d' not in enumerated type `%s'",
   ((c->low)->int_cst.int_cst_low),
   ((((n64_enum_tree_code) (((type)->type.name))->common.code) == IDENTIFIER_NODE ? ((type)->type.name) : ((((type)->type.name))->decl.name))->identifier.pointer)

                                        );
    }
}





void
expand_end_case(tree orig_index) asm("_expand_end_case");
void
expand_end_case(tree orig_index)
{
  tree minval, maxval, range, orig_minval;
  rtx default_label = 0;
  register struct n64_tag_case_node *n;
  int count;
  rtx strchr;
  rtx table_label;
  int ncases;
  rtx *labelvec;
  register int i;
  rtx before_case;
  register struct n64_tag_nesting *thiscase = case_stack;
  tree index_expr, index_type;
  int unsignedp;

  if (output_bytecode)
    {
      bc_expand_end_case (orig_index);
      return;
    }

  table_label = gen_label_rtx ();
  index_expr = thiscase->data.case_stmt.index_expr;
  index_type = ((index_expr)->common.type);
  unsignedp = ((index_type)->common.unsigned_flag);

  do_pending_stack_adjust ();


  if (index_type != error_mark_node)
    {




      if (!thiscase->data.case_stmt.default_label
   && ((n64_enum_tree_code) (((orig_index)->common.type))->common.code) == ENUMERAL_TYPE
   && ((n64_enum_tree_code) (index_expr)->common.code) != INTEGER_CST)
 check_for_full_enumeration_handling (((orig_index)->common.type));


      if (thiscase->data.case_stmt.seenlabel == 0)
 {
   rtx insn;
   for (insn = get_last_insn ();
        insn != case_stack->data.case_stmt.start;
        insn = ((insn)->fld[1].rtx))
     if (((insn)->code) != NOTE
         && (((insn)->code) != INSN || ((((insn)->fld[3].rtx))->code)!= USE))
       {
  warning ("unreachable code at beginning of %s",
    case_stack->data.case_stmt.printname);
  break;
       }
 }



      if (thiscase->data.case_stmt.default_label == 0)
 {
   thiscase->data.case_stmt.default_label
     = build_decl (LABEL_DECL, (tree) 
                              ((void *)0)
                                       , (tree) 
                                         ((void *)0)
                                                  );
   expand_label (thiscase->data.case_stmt.default_label);
 }
      default_label = label_rtx (thiscase->data.case_stmt.default_label);

      before_case = get_last_insn ();


      group_case_nodes (thiscase->data.case_stmt.case_list);




      count = 0;
      for (n = thiscase->data.case_stmt.case_list; n; n = n->right)
 {

   if (((n64_enum_tree_code) (n->low)->common.code) != INTEGER_CST)
     abort ();
   if (((n64_enum_tree_code) (n->high)->common.code) != INTEGER_CST)
     abort ();

   n->low = convert (index_type, n->low);
   n->high = convert (index_type, n->high);



   if (count++ == 0)
     {
       minval = n->low;
       maxval = n->high;
     }
   else
     {
       if ((((n->low)->int_cst.int_cst_high) < ((minval)->int_cst.int_cst_high) || (((n->low)->int_cst.int_cst_high) == ((minval)->int_cst.int_cst_high) && ((unsigned int) ((n->low)->int_cst.int_cst_low) < (unsigned int) ((minval)->int_cst.int_cst_low)))))
  minval = n->low;
       if ((((maxval)->int_cst.int_cst_high) < ((n->high)->int_cst.int_cst_high) || (((maxval)->int_cst.int_cst_high) == ((n->high)->int_cst.int_cst_high) && ((unsigned int) ((maxval)->int_cst.int_cst_low) < (unsigned int) ((n->high)->int_cst.int_cst_low)))))
  maxval = n->high;
     }

   if (! tree_int_cst_equal (n->low, n->high))
     count++;
 }

      orig_minval = minval;


      if (count != 0)
 range = fold (build (MINUS_EXPR, index_type, maxval, minval));

      if (count == 0)
 {
   expand_expr (index_expr, const0_rtx, VOIDmode, 0);
   emit_queue ();
   emit_jump (default_label);
 }
      else if (((range)->int_cst.int_cst_high) != 0
        || count < (((target_flags & 0x00004000)) ? 4 : 5)
        || ((unsigned int) (((range)->int_cst.int_cst_low))
     > 10 * count)
        || ((n64_enum_tree_code) (index_expr)->common.code) == INTEGER_CST

        || (((n64_enum_tree_code) (index_expr)->common.code) == CALL_EXPR
     && ((n64_enum_tree_code) (((index_expr)->exp.operands[0]))->common.code) == ADDR_EXPR
     && ((n64_enum_tree_code) (((((index_expr)->exp.operands[0]))->exp.operands[0]))->common.code) == FUNCTION_DECL
     && ((((((index_expr)->exp.operands[0]))->exp.operands[0]))->decl.frame_size.f) == BUILT_IN_CLASSIFY_TYPE)
        || (((n64_enum_tree_code) (index_expr)->common.code) == COMPOUND_EXPR
     && ((n64_enum_tree_code) (((index_expr)->exp.operands[1]))->common.code) == INTEGER_CST))
 {
   strchr = expand_expr (index_expr, (rtx) 0, VOIDmode, 0);






   if ((mode_class[(int)(((strchr)->mode))]) == MODE_INT
       && (cmp_optab->handlers[(int) ((strchr)->mode)].insn_code
    == CODE_FOR_nothing))
     {
       n64_enum_machine_mode wider_mode;
       for (wider_mode = ((strchr)->mode); wider_mode != VOIDmode;
     wider_mode = (mode_wider_mode[(int)(wider_mode)]))
  if (cmp_optab->handlers[(int) wider_mode].insn_code
      != CODE_FOR_nothing)
    {
      strchr = convert_to_mode (wider_mode, strchr, unsignedp);
      break;
    }
     }

   emit_queue ();
   do_pending_stack_adjust ();

   strchr = protect_from_queue (strchr, 0);
   if (((strchr)->code) == MEM)
     strchr = copy_to_reg (strchr);
   if (((strchr)->code) == CONST_INT
       || ((n64_enum_tree_code) (index_expr)->common.code) == INTEGER_CST)
     {


       if (((n64_enum_tree_code) (index_expr)->common.code) != INTEGER_CST)
  {
    index_expr
      = build_int_2_wide ((int) (((strchr)->fld[0].rtwint)), (int) (unsignedp || ((strchr)->fld[0].rtwint) >= 0 ? 0 : -1))
                                                 ;
    index_expr = convert (index_type, index_expr);
  }






       for (n = thiscase->data.case_stmt.case_list; n; n = n->right)
  if (! tree_int_cst_lt (index_expr, n->low)
      && ! tree_int_cst_lt (n->high, index_expr))
    break;

       if (n)
  emit_jump (label_rtx (n->code_label));
       else
  emit_jump (default_label);
     }
   else
     {
       use_cost_table
  = (((n64_enum_tree_code) (((orig_index)->common.type))->common.code) != ENUMERAL_TYPE
     && estimate_case_costs (thiscase->data.case_stmt.case_list));
       balance_case_nodes (&thiscase->data.case_stmt.case_list,
      ((void *)0));
       emit_case_nodes (strchr, thiscase->data.case_stmt.case_list,
          default_label, index_type);
       emit_jump_if_reachable (default_label);
     }
 }
      else
 {
   int win = 0;

   if (((target_flags & 0x00004000)))
     {
       n64_enum_machine_mode index_mode = SImode;
       int index_bits = (8 * mode_size[(int)(index_mode)]);
       rtx op1, op2;
       n64_enum_machine_mode op_mode;


       if ((8 * mode_size[(int)(((index_type)->type.mode))])
    > (8 * mode_size[(int)(index_mode)]))
  {
    n64_enum_machine_mode omode = ((index_type)->type.mode);
    rtx rangertx = expand_expr (range, (rtx) 0, VOIDmode, 0);


    index_expr = build (MINUS_EXPR, index_type,
          index_expr, minval);
    minval = integer_zero_node;
    strchr = expand_expr (index_expr, (rtx) 0, VOIDmode, 0);
    emit_cmp_insn (rangertx, strchr, LTU, (rtx) 0, omode, 1, 0);
    emit_jump_insn (gen_bltu (default_label));

    strchr = convert_to_mode (index_mode, strchr, 0);
  }
       else
  {
    if (((index_type)->type.mode) != index_mode)
      {
        index_expr = convert (type_for_size (index_bits, 0),
         index_expr);
        index_type = ((index_expr)->common.type);
      }

    strchr = expand_expr (index_expr, (rtx) 0, VOIDmode, 0);
  }
       emit_queue ();
       strchr = protect_from_queue (strchr, 0);
       do_pending_stack_adjust ();

       op_mode = insn_operand_mode[(int)CODE_FOR_casesi][0];
       if (! (*insn_operand_predicate[(int)CODE_FOR_casesi][0])
    (strchr, op_mode))
  strchr = copy_to_mode_reg (op_mode, strchr);

       op1 = expand_expr (minval, (rtx) 0, VOIDmode, 0);

       op_mode = insn_operand_mode[(int)CODE_FOR_casesi][1];
       if (! (*insn_operand_predicate[(int)CODE_FOR_casesi][1])
    (op1, op_mode))
  op1 = copy_to_mode_reg (op_mode, op1);

       op2 = expand_expr (range, (rtx) 0, VOIDmode, 0);

       op_mode = insn_operand_mode[(int)CODE_FOR_casesi][2];
       if (! (*insn_operand_predicate[(int)CODE_FOR_casesi][2])
    (op2, op_mode))
  op2 = copy_to_mode_reg (op_mode, op2);

       emit_jump_insn (gen_casesi (strchr, op1, op2,
       table_label, default_label));
       win = 1;
     }


   if (! win && 1)
     {
       index_expr = convert (thiscase->data.case_stmt.nominal_type,
        fold (build (MINUS_EXPR, index_type,
       index_expr, minval)));
       index_type = ((index_expr)->common.type);
       strchr = expand_expr (index_expr, (rtx) 0, VOIDmode, 0);
       emit_queue ();
       strchr = protect_from_queue (strchr, 0);
       do_pending_stack_adjust ();

       do_tablejump (strchr, ((index_type)->type.mode),
       expand_expr (range, (rtx) 0, VOIDmode, 0),
       table_label, default_label);
       win = 1;
     }

   if (! win)
     abort ();



   ncases = ((range)->int_cst.int_cst_low) + 1;
   labelvec = (rtx *) 
                     __builtin_alloca((
                     ncases * sizeof (rtx)
                     ))
                                                   ;
   memset ((char *) labelvec,0,ncases * sizeof (rtx));

   for (n = thiscase->data.case_stmt.case_list; n; n = n->right)
     {
       register int i
  = ((n->low)->int_cst.int_cst_low) - ((orig_minval)->int_cst.int_cst_low);

       while (1)
  {
    labelvec[i]
      = gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), label_rtx (n->code_label));
    if (i + ((orig_minval)->int_cst.int_cst_low)
        == ((n->high)->int_cst.int_cst_low))
      break;
    i++;
  }
     }


   for (i = 0; i < ncases; i++)
     if (labelvec[i] == 0)
       labelvec[i] = gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), default_label);


   emit_label (table_label);



   if (



       flag_pic)
     emit_jump_insn (gen_rtx (ADDR_DIFF_VEC, ((target_flags & 0x00000002) ? DImode : SImode),
         gen_rtx (LABEL_REF, ((target_flags & 0x00000002) ? DImode : SImode), table_label),
         gen_rtvec_v (ncases, labelvec)));
   else
     emit_jump_insn (gen_rtx (ADDR_VEC, ((target_flags & 0x00000002) ? DImode : SImode),
         gen_rtvec_v (ncases, labelvec)));







   emit_barrier ();

 }

      before_case = squeeze_notes (((before_case)->fld[2].rtx), get_last_insn ());
      reorder_insns (before_case, get_last_insn (),
       thiscase->data.case_stmt.start);
    }

  if (thiscase->exit_label)
    emit_label (thiscase->exit_label);

  do { struct n64_tag_nesting *target = case_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);

  free_temp_slots ();
}





static void
bc_expand_end_case(tree expr) asm("_bc_expand_end_case");
static void
bc_expand_end_case(tree expr)
{
  struct n64_tag_nesting *thiscase = case_stack;
  n64_enum_bytecode_opcode opcode;
  struct n64_tag_bc_label *jump_label;
  struct n64_tag_case_node *c;

  bc_emit_bytecode (jump);
  bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thiscase->exit_label))->fld[1].rtx)));







  bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thiscase->data.case_stmt.skip_label))->fld[1].rtx)));

  opcode = ((thiscase->data.case_stmt.nominal_type)->type.mode) == SImode
    ? ((thiscase->data.case_stmt.nominal_type)->common.unsigned_flag) ? caseSU : caseSI
      : ((thiscase->data.case_stmt.nominal_type)->common.unsigned_flag) ? caseDU : caseDI;

  bc_emit_bytecode (opcode);







  jump_label = bc_get_bytecode_label ();
  bc_emit_bytecode_labelref (jump_label);
  bc_emit_bytecode_const ((char *) &thiscase->data.case_stmt.num_ranges,
     sizeof thiscase->data.case_stmt.num_ranges);

  if (thiscase->data.case_stmt.default_label)
    bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((((thiscase->data.case_stmt.default_label)->decl.rtl)))->fld[1].rtx)));
  else
    bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((thiscase->exit_label))->fld[1].rtx)));



  bc_align_bytecode (3 );
  bc_emit_bytecode_labeldef (jump_label);

  if (((thiscase->data.case_stmt.nominal_type)->type.mode) == SImode)
    for (c = thiscase->data.case_stmt.case_list->left; c; c = c->left)
      {
 opcode = ((c->low)->int_cst.int_cst_low);
 bc_emit_bytecode_const ((char *) &opcode, sizeof opcode);

 opcode = ((c->high)->int_cst.int_cst_low);
 bc_emit_bytecode_const ((char *) &opcode, sizeof opcode);

 bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((((c->code_label)->decl.rtl)))->fld[1].rtx)));
      }
  else
    if (((thiscase->data.case_stmt.nominal_type)->type.mode) == DImode)
      for (c = thiscase->data.case_stmt.case_list->left; c; c = c->left)
 {
   { int opcode; opcode = (((target_flags & 0x00010000) != 0) ? ((c->low)->int_cst.int_cst_high) : ((c->low)->int_cst.int_cst_low)); bc_emit_bytecode_const ((char *) &opcode, sizeof opcode); opcode = (((target_flags & 0x00010000) != 0) ? ((c->low)->int_cst.int_cst_low) : ((c->low)->int_cst.int_cst_high)); bc_emit_bytecode_const ((char *) &opcode, sizeof opcode); };
   { int opcode; opcode = (((target_flags & 0x00010000) != 0) ? ((c->high)->int_cst.int_cst_high) : ((c->high)->int_cst.int_cst_low)); bc_emit_bytecode_const ((char *) &opcode, sizeof opcode); opcode = (((target_flags & 0x00010000) != 0) ? ((c->high)->int_cst.int_cst_low) : ((c->high)->int_cst.int_cst_high)); bc_emit_bytecode_const ((char *) &opcode, sizeof opcode); };

   bc_emit_bytecode_labelref ((*(struct n64_tag_bc_label **) &(((((c->code_label)->decl.rtl)))->fld[1].rtx)));
 }
    else

      abort ();


  bc_emit_bytecode_labeldef ((*(struct n64_tag_bc_label **) &(((thiscase->exit_label))->fld[1].rtx)));



  if (!thiscase->data.case_stmt.default_label
      && ((n64_enum_tree_code) (((expr)->common.type))->common.code) == ENUMERAL_TYPE
      && ((n64_enum_tree_code) (expr)->common.code) != INTEGER_CST
      && warn_switch)
    check_for_full_enumeration_handling (((expr)->common.type));






  do { struct n64_tag_nesting *target = case_stack; struct n64_tag_nesting *cxx_this; do { cxx_this = nesting_stack; if (loop_stack == cxx_this) loop_stack = loop_stack->next; if (cond_stack == cxx_this) cond_stack = cond_stack->next; if (block_stack == cxx_this) block_stack = block_stack->next; if (stack_block_stack == cxx_this) stack_block_stack = stack_block_stack->next; if (case_stack == cxx_this) case_stack = case_stack->next; nesting_depth = nesting_stack->depth - 1; nesting_stack = cxx_this->all; __extension__ ({ struct n64_tag_obstack *__o = (&stmt_obstack); void *__obj = (cxx_this); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); }); } while (cxx_this != target); } while (0);
}




int
bc_new_uid(void) asm("_bc_new_uid");
int
bc_new_uid(void)
{
  static int bc_uid = 0;

  return (++bc_uid);
}



static void
do_jump_if_equal(rtx op1, rtx op2, rtx label, int unsignedp) asm("_do_jump_if_equal");
static void
do_jump_if_equal(rtx op1, rtx op2, rtx label, int unsignedp)
{
  if (((op1)->code) == CONST_INT
      && ((op2)->code) == CONST_INT)
    {
      if (((op1)->fld[0].rtwint) == ((op2)->fld[0].rtwint))
 emit_jump (label);
    }
  else
    {
      n64_enum_machine_mode mode = ((op1)->mode);
      if (mode == VOIDmode)
 mode = ((op2)->mode);
      emit_cmp_insn (op1, op2, EQ, (rtx) 0, mode, unsignedp, 0);
      emit_jump_insn (gen_beq (label));
    }
}
static int
estimate_case_costs(case_node_ptr node) asm("_estimate_case_costs");
static int
estimate_case_costs(case_node_ptr node)
{
  tree min_ascii = build_int_2_wide ((int) (-1), (int) (-1));
  tree max_ascii = convert (((node->high)->common.type), build_int_2_wide ((int) (127), (int) (0)));
  case_node_ptr n;
  int i;




  if (cost_table == 
                   ((void *)0)
                       )
    {
      cost_table = ((short *) xmalloc (129 * sizeof (short))) + 1;
      memset ((char *) (cost_table - 1),0,129 * sizeof (short));

      for (i = 0; i < 128; i++)
 {
   if (isalnum (i))
     cost_table[i] = 16;
   else if (ispunct (i))
     cost_table[i] = 8;
   else if (iscntrl (i))
     cost_table[i] = -1;
 }

      cost_table[' '] = 8;
      cost_table['\t'] = 4;
      cost_table['\0'] = 4;
      cost_table['\n'] = 2;
      cost_table['\f'] = 1;
      cost_table['\v'] = 1;
      cost_table['\b'] = 1;
    }







  for (n = node; n; n = n->right)
    {
      if (((((n->low)->int_cst.int_cst_high) < ((min_ascii)->int_cst.int_cst_high) || (((n->low)->int_cst.int_cst_high) == ((min_ascii)->int_cst.int_cst_high) && ((unsigned int) ((n->low)->int_cst.int_cst_low) < (unsigned int) ((min_ascii)->int_cst.int_cst_low))))) || (((max_ascii)->int_cst.int_cst_high) < ((n->high)->int_cst.int_cst_high) || (((max_ascii)->int_cst.int_cst_high) == ((n->high)->int_cst.int_cst_high) && ((unsigned int) ((max_ascii)->int_cst.int_cst_low) < (unsigned int) ((n->high)->int_cst.int_cst_low)))))
 return 0;

      for (i = ((n->low)->int_cst.int_cst_low); i <= ((n->high)->int_cst.int_cst_low); i++)
 if (cost_table[i] < 0)
   return 0;
    }



  return 1;
}






static void
group_case_nodes(case_node_ptr head) asm("_group_case_nodes");
static void
group_case_nodes(case_node_ptr head)
{
  case_node_ptr node = head;

  while (node)
    {
      rtx lb = next_real_insn (label_rtx (node->code_label));
      case_node_ptr np = node;


      while (((np = np->right) != 0)

      && next_real_insn (label_rtx (np->code_label)) == lb

      && tree_int_cst_equal (np->low,
        fold (build (PLUS_EXPR,
       ((node->high)->common.type),
       node->high,
       integer_one_node)))

      && tree_int_cst_lt (node->high,
     fold (build (PLUS_EXPR,
           ((node->high)->common.type),
           node->high,
           integer_one_node))))
 {
   node->high = np->high;
 }


      node->right = np;
      node = np;
    }
}
static void
balance_case_nodes(case_node_ptr *head, case_node_ptr parent) asm("_balance_case_nodes");
static void
balance_case_nodes(case_node_ptr *head, case_node_ptr parent)
{
  register case_node_ptr np;

  np = *head;
  if (np)
    {
      int cost = 0;
      int i = 0;
      int ranges = 0;
      register case_node_ptr *npp;
      case_node_ptr left;



      while (np)
 {
   if (!tree_int_cst_equal (np->low, np->high))
     {
       ranges++;
       if (use_cost_table)
  cost += cost_table[((np->high)->int_cst.int_cst_low)];
     }

   if (use_cost_table)
     cost += cost_table[((np->low)->int_cst.int_cst_low)];

   i++;
   np = np->right;
 }

      if (i > 2)
 {

   npp = head;
   left = *npp;
   if (use_cost_table)
     {


       int n_moved = 0;
       i = (cost + 1) / 2;
       while (1)
  {

    if (!tree_int_cst_equal ((*npp)->low, (*npp)->high))
      i -= cost_table[(((*npp)->high)->int_cst.int_cst_low)];
    i -= cost_table[(((*npp)->low)->int_cst.int_cst_low)];
    if (i <= 0)
      break;
    npp = &(*npp)->right;
    n_moved += 1;
  }
       if (n_moved == 0)
  {


    np = *head;
    np->parent = parent;
    balance_case_nodes (&np->left, np);
    for (; np->right; np = np->right)
      np->right->parent = np;
    return;
  }
     }

   else if (i == 3)
     npp = &(*npp)->right;
   else
     {



       i = (i + ranges + 1) / 2;
       while (1)
  {

    if (!tree_int_cst_equal ((*npp)->low, (*npp)->high))
      i--;
    i--;
    if (i <= 0)
      break;
    npp = &(*npp)->right;
  }
     }
   *head = np = *npp;
   *npp = 0;
   np->parent = parent;
   np->left = left;


   balance_case_nodes (&np->left, np);
   balance_case_nodes (&np->right, np);
 }
      else
 {


   np = *head;
   np->parent = parent;
   for (; np->right; np = np->right)
     np->right->parent = np;
 }
    }
}
static int
node_has_low_bound(case_node_ptr node, tree index_type) asm("_node_has_low_bound");
static int
node_has_low_bound(case_node_ptr node, tree index_type)
{
  tree low_minus_one;
  case_node_ptr pnode;




  if (tree_int_cst_equal (node->low, ((index_type)->type.minval)))
    return 1;





  if (node->left)
    return 0;

  low_minus_one = fold (build (MINUS_EXPR, ((node->low)->common.type),
          node->low, integer_one_node));




  if (! tree_int_cst_lt (low_minus_one, node->low))
    return 0;

  for (pnode = node->parent; pnode; pnode = pnode->parent)
    if (tree_int_cst_equal (low_minus_one, pnode->high))
      return 1;

  return 0;
}
static int
node_has_high_bound(case_node_ptr node, tree index_type) asm("_node_has_high_bound");
static int
node_has_high_bound(case_node_ptr node, tree index_type)
{
  tree high_plus_one;
  case_node_ptr pnode;




  if (tree_int_cst_equal (node->high, ((index_type)->type.maxval)))
    return 1;





  if (node->right)
    return 0;

  high_plus_one = fold (build (PLUS_EXPR, ((node->high)->common.type),
          node->high, integer_one_node));




  if (! tree_int_cst_lt (node->high, high_plus_one))
    return 0;

  for (pnode = node->parent; pnode; pnode = pnode->parent)
    if (tree_int_cst_equal (high_plus_one, pnode->low))
      return 1;

  return 0;
}





static int
node_is_bounded(case_node_ptr node, tree index_type) asm("_node_is_bounded");
static int
node_is_bounded(case_node_ptr node, tree index_type)
{
  return (node_has_low_bound (node, index_type)
   && node_has_high_bound (node, index_type));
}



static void
emit_jump_if_reachable(rtx label) asm("_emit_jump_if_reachable");
static void
emit_jump_if_reachable(rtx label)
{
  if (((get_last_insn ())->code) != BARRIER)
    emit_jump (label);
}
static void
emit_case_nodes(rtx strchr, case_node_ptr node, rtx default_label, tree index_type) asm("_emit_case_nodes");
static void
emit_case_nodes(rtx strchr, case_node_ptr node, rtx default_label, tree index_type)
{

  int unsignedp = ((index_type)->common.unsigned_flag);
  typedef rtx rtx_function(...);
  rtx_function *gen_bgt_pat = unsignedp ? gen_bgtu : gen_bgt;
  rtx_function *gen_bge_pat = unsignedp ? gen_bgeu : gen_bge;
  rtx_function *gen_blt_pat = unsignedp ? gen_bltu : gen_blt;
  rtx_function *gen_ble_pat = unsignedp ? gen_bleu : gen_ble;
  n64_enum_machine_mode mode = ((strchr)->mode);



  if (node_is_bounded (node, index_type))
    emit_jump (label_rtx (node->code_label));

  else if (tree_int_cst_equal (node->low, node->high))
    {



      do_jump_if_equal (strchr, expand_expr (node->low, (rtx) 0, VOIDmode, 0),
   label_rtx (node->code_label), unsignedp);

      if (node->right != 0 && node->left != 0)
 {






   if (node_is_bounded (node->right, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
       VOIDmode, 0),
        GT, (rtx) 0, mode, unsignedp, 0);

       emit_jump_insn ((*gen_bgt_pat) (label_rtx (node->right->code_label)));
       emit_case_nodes (strchr, node->left, default_label, index_type);
     }

   else if (node_is_bounded (node->left, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
       VOIDmode, 0),
        LT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_blt_pat) (label_rtx (node->left->code_label)));
       emit_case_nodes (strchr, node->right, default_label, index_type);
     }

   else
     {



       tree test_label
  = build_decl (LABEL_DECL, (tree) 
                           ((void *)0)
                                    , (tree) 
                                      ((void *)0)
                                               );


       emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
       VOIDmode, 0),
        GT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_bgt_pat) (label_rtx (test_label)));



       emit_case_nodes (strchr, node->left, default_label, index_type);


       emit_jump_if_reachable (default_label);


       expand_label (test_label);
       emit_case_nodes (strchr, node->right, default_label, index_type);
     }
 }

      else if (node->right != 0 && node->left == 0)
 {






   if (node->right->right || node->right->left
       || !tree_int_cst_equal (node->right->low, node->right->high))
     {
       if (!node_has_low_bound (node, index_type))
  {
    emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
           VOIDmode, 0),
     LT, (rtx) 0, mode, unsignedp, 0);
    emit_jump_insn ((*gen_blt_pat) (default_label));
  }

       emit_case_nodes (strchr, node->right, default_label, index_type);
     }
   else



     do_jump_if_equal (strchr,
         expand_expr (node->right->low, (rtx) 0,
        VOIDmode, 0),
         label_rtx (node->right->code_label), unsignedp);
 }

      else if (node->right == 0 && node->left != 0)
 {
    if (node->left->left || node->left->right
       || !tree_int_cst_equal (node->left->low, node->left->high))
     {
       if (!node_has_high_bound (node, index_type))
  {
    emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
           VOIDmode, 0),
     GT, (rtx) 0, mode, unsignedp, 0);
    emit_jump_insn ((*gen_bgt_pat) (default_label));
  }

       emit_case_nodes (strchr, node->left, default_label, index_type);
     }
   else



     do_jump_if_equal (strchr,
         expand_expr (node->left->low, (rtx) 0,
        VOIDmode, 0),
         label_rtx (node->left->code_label), unsignedp);
 }
    }
  else
    {




      if (node->right != 0 && node->left != 0)
 {





   tree test_label = 0;

   emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
          VOIDmode, 0),
    GT, (rtx) 0, mode, unsignedp, 0);

   if (node_is_bounded (node->right, index_type))


     emit_jump_insn ((*gen_bgt_pat) (label_rtx (node->right->code_label)));
   else
     {



       test_label = build_decl (LABEL_DECL, (tree) 
                                           ((void *)0)
                                                    , (tree) 
                                                      ((void *)0)
                                                               );
       emit_jump_insn ((*gen_bgt_pat) (label_rtx (test_label)));
     }



   emit_cmp_insn (strchr, expand_expr (node->low, (rtx) 0, VOIDmode, 0),
    GE, (rtx) 0, mode, unsignedp, 0);
   emit_jump_insn ((*gen_bge_pat) (label_rtx (node->code_label)));


   emit_case_nodes (strchr, node->left, default_label, index_type);



   if (test_label)
     {


       emit_jump_if_reachable (default_label);

       expand_label (test_label);
       emit_case_nodes (strchr, node->right, default_label, index_type);
     }
 }

      else if (node->right != 0 && node->left == 0)
 {


   if (!node_has_low_bound (node, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->low, (rtx) 0,
       VOIDmode, 0),
        LT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_blt_pat) (default_label));
     }



   emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
          VOIDmode, 0),
    LE, (rtx) 0, mode, unsignedp, 0);
   emit_jump_insn ((*gen_ble_pat) (label_rtx (node->code_label)));

   emit_case_nodes (strchr, node->right, default_label, index_type);
 }

      else if (node->right == 0 && node->left != 0)
 {


   if (!node_has_high_bound (node, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
       VOIDmode, 0),
        GT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_bgt_pat) (default_label));
     }



   emit_cmp_insn (strchr, expand_expr (node->low, (rtx) 0, VOIDmode, 0),
    GE, (rtx) 0, mode, unsignedp, 0);
   emit_jump_insn ((*gen_bge_pat) (label_rtx (node->code_label)));

   emit_case_nodes (strchr, node->left, default_label, index_type);
 }

      else
 {




   if (!node_has_high_bound (node, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->high, (rtx) 0,
       VOIDmode, 0),
        GT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_bgt_pat) (default_label));
     }

   if (!node_has_low_bound (node, index_type))
     {
       emit_cmp_insn (strchr, expand_expr (node->low, (rtx) 0,
       VOIDmode, 0),
        LT, (rtx) 0, mode, unsignedp, 0);
       emit_jump_insn ((*gen_blt_pat) (default_label));
     }

   emit_jump (label_rtx (node->code_label));
 }
    }
}






static tree *block_vector;

void
find_loop_tree_blocks(void) asm("_find_loop_tree_blocks");
void
find_loop_tree_blocks(void)
{
  tree block = ((current_function_decl)->decl.initial);



  block = ((block)->block.subblocks);

  block_vector = identify_blocks (block, get_insns ());
}

void
unroll_block_trees(void) asm("_unroll_block_trees");
void
unroll_block_trees(void)
{
  tree block = ((current_function_decl)->decl.initial);

  reorder_blocks (block_vector, block, get_insns ());
}

