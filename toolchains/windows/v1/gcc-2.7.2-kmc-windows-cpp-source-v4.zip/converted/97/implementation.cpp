// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/bfd/bfd.c
/* Generic BFD library interface and support routines.
   Copyright (C) 1990, 91, 92, 93, 94 Free Software Foundation, Inc.
   Written by Cygnus Support.

This file is part of BFD, the Binary File Descriptor library.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__IMAGE_DATA_DIRECTORY;
struct n64_tag__bfd;
struct n64_tag__bfd_window;
struct n64_tag__obstack_chunk;
struct n64_tag__symbol_info;
struct n64_tag_areltdata;
struct n64_tag_artdata;
union n64_tag_aux_ext;
struct n64_tag_bfd_arch_info;
struct n64_tag_bfd_elf_section_data;
struct n64_tag_bfd_hash_entry;
struct n64_tag_bfd_hash_table;
struct n64_tag_bfd_link_callbacks;
struct n64_tag_bfd_link_hash_common_entry;
struct n64_tag_bfd_link_hash_entry;
struct n64_tag_bfd_link_hash_table;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_needed_list;
struct n64_tag_bfd_link_order;
struct n64_tag_bfd_link_order_reloc;
struct n64_tag_bfd_target;
struct n64_tag_carsym;
struct n64_tag_coff_link_hash_entry;
struct n64_tag_coff_link_hash_table;
struct n64_tag_coff_ptr_struct;
struct n64_tag_coff_section_tdata;
struct n64_tag_coff_symbol_struct;
struct n64_tag_coff_tdata;
struct n64_tag_ecoff_backend_data;
struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_ecoff_fdrtab_entry;
struct n64_tag_ecoff_find_line;
struct n64_tag_ecoff_link_hash_entry;
struct n64_tag_ecoff_link_hash_table;
struct n64_tag_ecoff_section_tdata;
struct n64_tag_ecoff_symbol_struct;
struct n64_tag_ecoff_tdata;
struct n64_tag_ecoff_value_adjust;
struct n64_tag_elf_backend_data;
struct n64_tag_elf_internal_dyn;
struct n64_tag_elf_internal_ehdr;
struct n64_tag_elf_internal_note;
struct n64_tag_elf_internal_phdr;
struct n64_tag_elf_internal_rel;
struct n64_tag_elf_internal_rela;
struct n64_tag_elf_internal_shdr;
struct n64_tag_elf_internal_sym;
struct n64_tag_elf_link_hash_entry;
struct n64_tag_elf_link_hash_table;
struct n64_tag_elf_obj_tdata;
struct n64_tag_elf_size_info;
struct n64_tag_fdr;
struct n64_tag_internal_aouthdr;
union n64_tag_internal_auxent;
struct n64_tag_internal_extra_pe_aouthdr;
struct n64_tag_internal_extra_pe_filehdr;
struct n64_tag_internal_filehdr;
struct n64_tag_internal_lineno;
struct n64_tag_internal_reloc;
struct n64_tag_internal_scnhdr;
struct n64_tag_internal_syment;
struct n64_tag_lineno_cache_entry;
struct n64_tag_obstack;
struct n64_tag_orl;
struct n64_tag_pdr;
struct n64_tag_pe_tdata;
struct n64_tag_relent_chain;
struct n64_tag_reloc_cache_entry;
struct n64_tag_reloc_howto_struct;
struct n64_tag_rndx_ext;
struct n64_tag_sec;
struct n64_tag_symbol_cache_entry;
struct n64_tag_tir_ext;
struct n64_tag_xcoff_section_tdata;
struct n64_tag_xcoff_tdata;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
typedef struct n64_tag__bfd bfd;
enum n64_cpp_enum_bfd_boolean{cxx_false, cxx_true};
typedef __underlying_type(enum n64_cpp_enum_bfd_boolean) n64_enum_bfd_boolean;
typedef n64_enum_bfd_boolean boolean;
typedef long int file_ptr;
typedef unsigned long bfd_vma;





typedef long bfd_signed_vma;

typedef unsigned long symvalue;
typedef unsigned long bfd_size_type;







typedef unsigned int flagword;
typedef unsigned char bfd_byte;



enum n64_cpp_enum_bfd_format{
       bfd_unknown = 0,
       bfd_object,
       bfd_archive,
       bfd_core,
       bfd_type_end};
typedef __underlying_type(enum n64_cpp_enum_bfd_format) n64_enum_bfd_format;
typedef n64_enum_bfd_format
         bfd_format;
typedef unsigned long symindex;


typedef const struct n64_tag_reloc_howto_struct reloc_howto_type;
typedef struct n64_tag_carsym {
  char *name;
  file_ptr file_offset;
} carsym;




struct n64_tag_orl {
  char **name;
  file_ptr pos;
  int namidx;
};



typedef struct n64_tag_lineno_cache_entry {
  unsigned int line_number;
  union {
    struct n64_tag_symbol_cache_entry *sym;
    unsigned long offset;
  } u;
} alent;






typedef struct n64_tag_sec *sec_ptr;
typedef struct stat stat_type;

enum n64_cpp_enum_bfd_print_symbol{
  bfd_print_symbol_name,
  bfd_print_symbol_more,
  bfd_print_symbol_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_print_symbol) n64_enum_bfd_print_symbol;
typedef n64_enum_bfd_print_symbol bfd_print_symbol_type;



typedef struct n64_tag__symbol_info
{
  symvalue value;
  char type;
  const char *name;
  char stab_other;
  short stab_desc;
  const char *stab_name;
} symbol_info;






struct n64_tag_bfd_hash_entry
{

  struct n64_tag_bfd_hash_entry *next;

  const char *string;


  unsigned long hash;
};



struct n64_tag_bfd_hash_table
{

  struct n64_tag_bfd_hash_entry **table;

  unsigned int size;







  struct n64_tag_bfd_hash_entry *(*newfunc) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)

                        ;

  struct n64_tag_obstack memory;
};


extern boolean bfd_hash_table_init
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("_bfd_hash_table_init")


                          ;


extern boolean bfd_hash_table_init_n
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *), unsigned int size) asm("_bfd_hash_table_init_n")



                       ;


extern void bfd_hash_table_free (struct n64_tag_bfd_hash_table *) asm("_bfd_hash_table_free");





extern struct n64_tag_bfd_hash_entry *bfd_hash_lookup
  (struct n64_tag_bfd_hash_table *, const char *, boolean create, boolean copy) asm("_bfd_hash_lookup")
                  ;


extern void bfd_hash_replace
  (struct n64_tag_bfd_hash_table *, struct n64_tag_bfd_hash_entry *old, struct n64_tag_bfd_hash_entry *nw) asm("_bfd_hash_replace")
                               ;


extern struct n64_tag_bfd_hash_entry *bfd_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("_bfd_hash_newfunc")
                  ;


extern void * bfd_hash_allocate (struct n64_tag_bfd_hash_table *, unsigned int) asm("_bfd_hash_allocate")
                        ;




extern void bfd_hash_traverse (struct n64_tag_bfd_hash_table *, boolean (*) (struct n64_tag_bfd_hash_entry *, void *), void * info) asm("_bfd_hash_traverse")


                     ;
extern bfd_size_type bfd_read
  (void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_read");
extern bfd_size_type bfd_write
  (const void *, bfd_size_type size, bfd_size_type nitems, bfd *abfd) asm("_bfd_write");
extern int bfd_seek (bfd *abfd, file_ptr fp, int direction) asm("_bfd_seek");
extern long bfd_tell (bfd *abfd) asm("_bfd_tell");
extern int bfd_flush (bfd *abfd) asm("_bfd_flush");
extern int bfd_stat (bfd *abfd, struct stat *) asm("_bfd_stat");
bfd_vma bfd_getb64 (const unsigned char *) asm("_bfd_getb64");
bfd_vma bfd_getl64 (const unsigned char *) asm("_bfd_getl64");
bfd_signed_vma bfd_getb_signed_64 (const unsigned char *) asm("_bfd_getb_signed_64");
bfd_signed_vma bfd_getl_signed_64 (const unsigned char *) asm("_bfd_getl_signed_64");
bfd_vma bfd_getb32 (const unsigned char *) asm("_bfd_getb32");
bfd_vma bfd_getl32 (const unsigned char *) asm("_bfd_getl32");
bfd_signed_vma bfd_getb_signed_32 (const unsigned char *) asm("_bfd_getb_signed_32");
bfd_signed_vma bfd_getl_signed_32 (const unsigned char *) asm("_bfd_getl_signed_32");
bfd_vma bfd_getb16 (const unsigned char *) asm("_bfd_getb16");
bfd_vma bfd_getl16 (const unsigned char *) asm("_bfd_getl16");
bfd_signed_vma bfd_getb_signed_16 (const unsigned char *) asm("_bfd_getb_signed_16");
bfd_signed_vma bfd_getl_signed_16 (const unsigned char *) asm("_bfd_getl_signed_16");
void bfd_putb64 (bfd_vma, unsigned char *) asm("_bfd_putb64");
void bfd_putl64 (bfd_vma, unsigned char *) asm("_bfd_putl64");
void bfd_putb32 (bfd_vma, unsigned char *) asm("_bfd_putb32");
void bfd_putl32 (bfd_vma, unsigned char *) asm("_bfd_putl32");
void bfd_putb16 (bfd_vma, unsigned char *) asm("_bfd_putb16");
void bfd_putl16 (bfd_vma, unsigned char *) asm("_bfd_putl16");




struct n64_tag_ecoff_debug_info;
struct n64_tag_ecoff_debug_swap;
struct n64_tag_ecoff_extr;
struct n64_tag_symbol_cache_entry;
struct n64_tag_bfd_link_info;
struct n64_tag_bfd_link_hash_entry;

extern bfd_vma bfd_ecoff_get_gp_value (bfd * abfd) asm("_bfd_ecoff_get_gp_value");
extern boolean bfd_ecoff_set_gp_value (bfd *abfd, bfd_vma gp_value) asm("_bfd_ecoff_set_gp_value");
extern boolean bfd_ecoff_set_regmasks
  (bfd *abfd, unsigned long gprmask, unsigned long fprmask, unsigned long *cprmask) asm("_bfd_ecoff_set_regmasks")
                            ;
extern void * bfd_ecoff_debug_init
  (bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_init")

                            ;
extern void bfd_ecoff_debug_free
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_free")

                            ;
extern boolean bfd_ecoff_debug_accumulate
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_ecoff_debug_info *input_debug, const struct n64_tag_ecoff_debug_swap *input_swap, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate")



                            ;
extern boolean bfd_ecoff_debug_accumulate_other
  (void * handle, bfd *output_bfd, struct n64_tag_ecoff_debug_info *output_debug, const struct n64_tag_ecoff_debug_swap *output_swap, bfd *input_bfd, struct n64_tag_bfd_link_info *) asm("_bfd_ecoff_debug_accumulate_other")

                            ;
extern boolean bfd_ecoff_debug_externals
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, boolean relocateable, boolean (*get_extr) (struct n64_tag_symbol_cache_entry *, struct n64_tag_ecoff_extr *), void (*set_index) (struct n64_tag_symbol_cache_entry *, bfd_size_type)) asm("_bfd_ecoff_debug_externals")





                         ;
extern boolean bfd_ecoff_debug_one_external
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, const char *name, struct n64_tag_ecoff_extr *esym) asm("_bfd_ecoff_debug_one_external")

                                               ;
extern bfd_size_type bfd_ecoff_debug_size
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap) asm("_bfd_ecoff_debug_size")
                                         ;
extern boolean bfd_ecoff_write_debug
  (bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, file_ptr where) asm("_bfd_ecoff_write_debug")
                                                         ;
extern boolean bfd_ecoff_write_accumulated_debug
  (void * handle, bfd *abfd, struct n64_tag_ecoff_debug_info *debug, const struct n64_tag_ecoff_debug_swap *swap, struct n64_tag_bfd_link_info *info, file_ptr where) asm("_bfd_ecoff_write_accumulated_debug")

                                                ;
extern boolean bfd_mips_ecoff_create_embedded_relocs
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec *, struct n64_tag_sec *, char **) asm("_bfd_mips_ecoff_create_embedded_relocs")
             ;



struct n64_tag_bfd_link_needed_list
{
  struct n64_tag_bfd_link_needed_list *next;
  bfd *by;
  const char *name;
};

extern boolean bfd_elf32_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf32_record_link_assignment");
extern boolean bfd_elf64_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *, boolean) asm("_bfd_elf64_record_link_assignment");
extern struct n64_tag_bfd_link_needed_list *bfd_elf_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf_get_needed_list");
extern boolean bfd_elf32_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf32_size_dynamic_sections")
                                           ;
extern boolean bfd_elf64_size_dynamic_sections
  (bfd *, const char *, const char *, boolean, struct n64_tag_bfd_link_info *, struct n64_tag_sec **) asm("_bfd_elf64_size_dynamic_sections")
                                           ;
extern void bfd_elf_set_dt_needed_name (bfd *, const char *) asm("_bfd_elf_set_dt_needed_name");



extern struct n64_tag_bfd_link_needed_list *bfd_sunos_get_needed_list
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_sunos_get_needed_list");
extern boolean bfd_sunos_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_sunos_record_link_assignment");
extern boolean bfd_sunos_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_sec **, struct n64_tag_sec **, struct n64_tag_sec **) asm("_bfd_sunos_size_dynamic_sections")
                   ;



extern boolean bfd_linux_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_linux_size_dynamic_sections");



struct _bfd_window_internal;
typedef struct _bfd_window_internal bfd_window_internal;

typedef struct n64_tag__bfd_window {

  void * data;
  bfd_size_type size;






  struct _bfd_window_internal *i;
} bfd_window;

extern void bfd_init_window (bfd_window *) asm("_bfd_init_window");
extern void bfd_free_window (bfd_window *) asm("_bfd_free_window");
extern boolean bfd_get_file_window
  (bfd *, file_ptr, bfd_size_type, bfd_window *, boolean) asm("_bfd_get_file_window");



extern boolean bfd_xcoff_link_record_set
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_size_type) asm("_bfd_xcoff_link_record_set")
                   ;
extern boolean bfd_xcoff_import_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, bfd_vma, const char *, const char *, const char *) asm("_bfd_xcoff_import_symbol")
                                                       ;
extern boolean bfd_xcoff_export_symbol
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *, boolean) asm("_bfd_xcoff_export_symbol")
             ;
extern boolean bfd_xcoff_link_count_reloc
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_link_count_reloc");
extern boolean bfd_xcoff_record_link_assignment
  (bfd *, struct n64_tag_bfd_link_info *, const char *) asm("_bfd_xcoff_record_link_assignment");
extern boolean bfd_xcoff_size_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *, const char *, const char *, unsigned long, unsigned long, unsigned long, boolean, int, boolean, struct n64_tag_sec **) asm("_bfd_xcoff_size_dynamic_sections")

                                 ;


void
bfd_init (void) asm("_bfd_init");

bfd *
bfd_openr (const char *filename, const char *target) asm("_bfd_openr");

bfd *
bfd_fdopenr (const char *filename, const char *target, int fd) asm("_bfd_fdopenr");

bfd *
bfd_openstreamr (...) asm("_bfd_openstreamr");

bfd *
bfd_openw (const char *filename, const char *target) asm("_bfd_openw");

boolean
bfd_close (bfd *abfd) asm("_bfd_close");

boolean
bfd_close_all_done (bfd *) asm("_bfd_close_all_done");

bfd_size_type
bfd_alloc_size (bfd *abfd) asm("_bfd_alloc_size");

bfd *
bfd_create (const char *filename, bfd *templ) asm("_bfd_create");
typedef struct n64_tag_sec
{



    const char *name;



   int index;



    struct n64_tag_sec *next;





    flagword flags;
   bfd_vma vma;
   boolean user_set_vma;





   bfd_vma lma;





   bfd_size_type _cooked_size;





   bfd_size_type _raw_size;






   bfd_vma output_offset;



   struct n64_tag_sec *output_section;




   unsigned int alignment_power;




   struct n64_tag_reloc_cache_entry *relocation;




   struct n64_tag_reloc_cache_entry **orelocation;



   unsigned reloc_count;






   file_ptr filepos;



   file_ptr rel_filepos;



   file_ptr line_filepos;



   void * userdata;



   unsigned char *contents;



   alent *lineno;



   unsigned int lineno_count;




   file_ptr moving_line_filepos;



   int target_index;

   void * used_by_bfd;




   struct n64_tag_relent_chain *constructor_chain;



   bfd *owner;

   boolean reloc_done;

   struct n64_tag_symbol_cache_entry *symbol;
   struct n64_tag_symbol_cache_entry **symbol_ptr_ptr;

   struct n64_tag_bfd_link_order *link_order_head;
   struct n64_tag_bfd_link_order *link_order_tail;
} asection ;
extern const asection bfd_abs_section;



extern const asection bfd_und_section;



extern const asection bfd_com_section;


extern const asection bfd_ind_section;



extern const struct n64_tag_symbol_cache_entry * const bfd_abs_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_com_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_und_symbol;
extern const struct n64_tag_symbol_cache_entry * const bfd_ind_symbol;




asection *
bfd_get_section_by_name (bfd *abfd, const char *name) asm("_bfd_get_section_by_name");

asection *
bfd_make_section_old_way (bfd *abfd, const char *name) asm("_bfd_make_section_old_way");

asection *
bfd_make_section_anyway (bfd *abfd, const char *name) asm("_bfd_make_section_anyway");

asection *
bfd_make_section (bfd *, const char *name) asm("_bfd_make_section");

boolean
bfd_set_section_flags (bfd *abfd, asection *sec, flagword flags) asm("_bfd_set_section_flags");

void
bfd_map_over_sections (bfd *abfd, void (*func)(bfd *abfd, asection *sect, void * obj), void * obj) asm("_bfd_map_over_sections")



             ;

boolean
bfd_set_section_size (bfd *abfd, asection *sec, bfd_size_type val) asm("_bfd_set_section_size");

boolean
bfd_set_section_contents
 (bfd *abfd, asection *section, void * data, file_ptr offset, bfd_size_type count) asm("_bfd_set_section_contents")



                         ;

boolean
bfd_get_section_contents
 (bfd *abfd, asection *section, void * location, file_ptr offset, bfd_size_type count) asm("_bfd_get_section_contents")
                                          ;

boolean
bfd_copy_private_section_data (bfd *ibfd, asection *isec, bfd *obfd, asection *osec) asm("_bfd_copy_private_section_data");




enum n64_cpp_enum_bfd_architecture{
  bfd_arch_unknown,
  bfd_arch_obscure,
  bfd_arch_m68k,
  bfd_arch_vax,
  bfd_arch_i960,
  bfd_arch_a29k,
  bfd_arch_sparc,


  bfd_arch_mips,
  bfd_arch_i386,
  bfd_arch_we32k,
  bfd_arch_tahoe,
  bfd_arch_i860,
  bfd_arch_romp,
  bfd_arch_alliant,
  bfd_arch_convex,
  bfd_arch_m88k,
  bfd_arch_pyramid,
  bfd_arch_h8300,


  bfd_arch_powerpc,
  bfd_arch_rs6000,
  bfd_arch_hppa,
  bfd_arch_z8k,


  bfd_arch_h8500,
  bfd_arch_sh,
  bfd_arch_alpha,
  bfd_arch_arm,
  bfd_arch_ns32k,
  bfd_arch_w65,
  bfd_arch_last
  };
typedef __underlying_type(enum n64_cpp_enum_bfd_architecture) n64_enum_bfd_architecture;


typedef struct n64_tag_bfd_arch_info
{
  int bits_per_word;
  int bits_per_address;
  int bits_per_byte;
  n64_enum_bfd_architecture arch;
  unsigned long mach;
  const char *arch_name;
  const char *printable_name;
  unsigned int section_align_power;

  boolean the_default;
  const struct n64_tag_bfd_arch_info * (*compatible)
 (const struct n64_tag_bfd_arch_info *a, const struct n64_tag_bfd_arch_info *b)
                                         ;

  boolean (*scan) (const struct n64_tag_bfd_arch_info *, const char *);

  const struct n64_tag_bfd_arch_info *next;
} bfd_arch_info_type;
const char *
bfd_printable_name (bfd *abfd) asm("_bfd_printable_name");

const bfd_arch_info_type *
bfd_scan_arch (const char *string) asm("_bfd_scan_arch");

const bfd_arch_info_type *
bfd_arch_get_compatible ( const bfd *abfd, const bfd *bbfd) asm("_bfd_arch_get_compatible")

                     ;

void
bfd_set_arch_info (bfd *abfd, const bfd_arch_info_type *arg) asm("_bfd_set_arch_info");

n64_enum_bfd_architecture
bfd_get_arch (bfd *abfd) asm("_bfd_get_arch");

unsigned long
bfd_get_mach (bfd *abfd) asm("_bfd_get_mach");

unsigned int
bfd_arch_bits_per_byte (bfd *abfd) asm("_bfd_arch_bits_per_byte");

unsigned int
bfd_arch_bits_per_address (bfd *abfd) asm("_bfd_arch_bits_per_address");

const bfd_arch_info_type *
bfd_get_arch_info (bfd *abfd) asm("_bfd_get_arch_info");

const bfd_arch_info_type *
bfd_lookup_arch
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_lookup_arch")

                           ;

const char *
bfd_printable_arch_mach
 (n64_enum_bfd_architecture arch, unsigned long machine) asm("_bfd_printable_arch_mach");

enum n64_cpp_enum_bfd_reloc_status{

  bfd_reloc_ok,


  bfd_reloc_overflow,


  bfd_reloc_outofrange,


  bfd_reloc_continue,


  bfd_reloc_notsupported,


  bfd_reloc_other,


  bfd_reloc_undefined,





  bfd_reloc_dangerous
 };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_status) n64_enum_bfd_reloc_status;
typedef n64_enum_bfd_reloc_status
 bfd_reloc_status_type;


typedef struct n64_tag_reloc_cache_entry
{

  struct n64_tag_symbol_cache_entry **sym_ptr_ptr;


  bfd_size_type address;


  bfd_vma addend;


  reloc_howto_type *howto;

} arelent;
enum n64_cpp_enum_complain_overflow{

  complain_overflow_dont,



  complain_overflow_bitfield,



  complain_overflow_signed,



  complain_overflow_unsigned
};
typedef __underlying_type(enum n64_cpp_enum_complain_overflow) n64_enum_complain_overflow;


struct n64_tag_reloc_howto_struct
{






  unsigned int type;



  unsigned int rightshift;




  int size;



  unsigned int bitsize;





  boolean pc_relative;



  unsigned int bitpos;



  n64_enum_complain_overflow complain_on_overflow;





  bfd_reloc_status_type (*special_function)
        (bfd *abfd, arelent *reloc_entry, struct n64_tag_symbol_cache_entry *symbol, void * data, asection *input_section, bfd *output_bfd, char **error_message)





                                                                  ;


  char *name;



  boolean partial_inplace;
  bfd_vma src_mask;





  bfd_vma dst_mask;







  boolean pcrel_offset;

};
int
bfd_get_reloc_size (reloc_howto_type *) asm("_bfd_get_reloc_size");

typedef struct n64_tag_relent_chain {
  arelent relent;
  struct n64_tag_relent_chain *next;
} arelent_chain;
bfd_reloc_status_type

bfd_perform_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, asection *input_section, bfd *output_bfd, char **error_message) asm("_bfd_perform_relocation")




                          ;

bfd_reloc_status_type

bfd_install_relocation
 (bfd *abfd, arelent *reloc_entry, void * data, bfd_vma data_start, asection *input_section, char **error_message) asm("_bfd_install_relocation")



                          ;

enum n64_cpp_enum_bfd_reloc_code_real{
  _dummy_first_bfd_reloc_code_real,



  BFD_RELOC_64,
  BFD_RELOC_32,
  BFD_RELOC_26,
  BFD_RELOC_16,
  BFD_RELOC_14,
  BFD_RELOC_8,






  BFD_RELOC_64_PCREL,
  BFD_RELOC_32_PCREL,
  BFD_RELOC_24_PCREL,
  BFD_RELOC_16_PCREL,
  BFD_RELOC_12_PCREL,
  BFD_RELOC_8_PCREL,


  BFD_RELOC_32_GOT_PCREL,
  BFD_RELOC_16_GOT_PCREL,
  BFD_RELOC_8_GOT_PCREL,
  BFD_RELOC_32_GOTOFF,
  BFD_RELOC_16_GOTOFF,
  BFD_RELOC_LO16_GOTOFF,
  BFD_RELOC_HI16_GOTOFF,
  BFD_RELOC_HI16_S_GOTOFF,
  BFD_RELOC_8_GOTOFF,
  BFD_RELOC_32_PLT_PCREL,
  BFD_RELOC_24_PLT_PCREL,
  BFD_RELOC_16_PLT_PCREL,
  BFD_RELOC_8_PLT_PCREL,
  BFD_RELOC_32_PLTOFF,
  BFD_RELOC_16_PLTOFF,
  BFD_RELOC_LO16_PLTOFF,
  BFD_RELOC_HI16_PLTOFF,
  BFD_RELOC_HI16_S_PLTOFF,
  BFD_RELOC_8_PLTOFF,


  BFD_RELOC_68K_GLOB_DAT,
  BFD_RELOC_68K_JMP_SLOT,
  BFD_RELOC_68K_RELATIVE,


  BFD_RELOC_32_BASEREL,
  BFD_RELOC_16_BASEREL,
  BFD_RELOC_LO16_BASEREL,
  BFD_RELOC_HI16_BASEREL,
  BFD_RELOC_HI16_S_BASEREL,
  BFD_RELOC_8_BASEREL,
  BFD_RELOC_RVA,


  BFD_RELOC_8_FFnn,







  BFD_RELOC_32_PCREL_S2,
  BFD_RELOC_16_PCREL_S2,
  BFD_RELOC_23_PCREL_S2,



  BFD_RELOC_HI22,
  BFD_RELOC_LO10,





  BFD_RELOC_GPREL16,
  BFD_RELOC_GPREL32,


  BFD_RELOC_I960_CALLJ,



  BFD_RELOC_NONE,
  BFD_RELOC_SPARC_WDISP22,
  BFD_RELOC_SPARC22,
  BFD_RELOC_SPARC13,
  BFD_RELOC_SPARC_GOT10,
  BFD_RELOC_SPARC_GOT13,
  BFD_RELOC_SPARC_GOT22,
  BFD_RELOC_SPARC_PC10,
  BFD_RELOC_SPARC_PC22,
  BFD_RELOC_SPARC_WPLT30,
  BFD_RELOC_SPARC_COPY,
  BFD_RELOC_SPARC_GLOB_DAT,
  BFD_RELOC_SPARC_JMP_SLOT,
  BFD_RELOC_SPARC_RELATIVE,
  BFD_RELOC_SPARC_UA32,


  BFD_RELOC_SPARC_BASE13,
  BFD_RELOC_SPARC_BASE22,



  BFD_RELOC_SPARC_10,
  BFD_RELOC_SPARC_11,
  BFD_RELOC_SPARC_OLO10,
  BFD_RELOC_SPARC_HH22,
  BFD_RELOC_SPARC_HM10,
  BFD_RELOC_SPARC_LM22,
  BFD_RELOC_SPARC_PC_HH22,
  BFD_RELOC_SPARC_PC_HM10,
  BFD_RELOC_SPARC_PC_LM22,
  BFD_RELOC_SPARC_WDISP16,
  BFD_RELOC_SPARC_WDISP19,
  BFD_RELOC_SPARC_GLOB_JMP,
  BFD_RELOC_SPARC_LO7,







  BFD_RELOC_ALPHA_GPDISP_HI16,





  BFD_RELOC_ALPHA_GPDISP_LO16,
  BFD_RELOC_ALPHA_LITERAL,
  BFD_RELOC_ALPHA_LITUSE,




  BFD_RELOC_ALPHA_HINT,



  BFD_RELOC_MIPS_JMP,


  BFD_RELOC_HI16,





  BFD_RELOC_HI16_S,


  BFD_RELOC_LO16,


  BFD_RELOC_PCREL_HI16_S,


  BFD_RELOC_PCREL_LO16,





  BFD_RELOC_MIPS_LITERAL,


  BFD_RELOC_MIPS_GOT16,
  BFD_RELOC_MIPS_CALL16,



  BFD_RELOC_386_GOT32,
  BFD_RELOC_386_PLT32,
  BFD_RELOC_386_COPY,
  BFD_RELOC_386_GLOB_DAT,
  BFD_RELOC_386_JUMP_SLOT,
  BFD_RELOC_386_RELATIVE,
  BFD_RELOC_386_GOTOFF,
  BFD_RELOC_386_GOTPC,


  BFD_RELOC_NS32K_IMM_8,
  BFD_RELOC_NS32K_IMM_16,
  BFD_RELOC_NS32K_IMM_32,
  BFD_RELOC_NS32K_IMM_8_PCREL,
  BFD_RELOC_NS32K_IMM_16_PCREL,
  BFD_RELOC_NS32K_IMM_32_PCREL,
  BFD_RELOC_NS32K_DISP_8,
  BFD_RELOC_NS32K_DISP_16,
  BFD_RELOC_NS32K_DISP_32,
  BFD_RELOC_NS32K_DISP_8_PCREL,
  BFD_RELOC_NS32K_DISP_16_PCREL,
  BFD_RELOC_NS32K_DISP_32_PCREL,


  BFD_RELOC_PPC_B26,
  BFD_RELOC_PPC_BA26,
  BFD_RELOC_PPC_TOC16,
  BFD_RELOC_PPC_B16,
  BFD_RELOC_PPC_B16_BRTAKEN,
  BFD_RELOC_PPC_B16_BRNTAKEN,
  BFD_RELOC_PPC_BA16,
  BFD_RELOC_PPC_BA16_BRTAKEN,
  BFD_RELOC_PPC_BA16_BRNTAKEN,
  BFD_RELOC_PPC_COPY,
  BFD_RELOC_PPC_GLOB_DAT,
  BFD_RELOC_PPC_JMP_SLOT,
  BFD_RELOC_PPC_RELATIVE,
  BFD_RELOC_PPC_LOCAL24PC,




  BFD_RELOC_CTOR,



  BFD_RELOC_ARM_PCREL_BRANCH,



  BFD_RELOC_ARM_IMMEDIATE,
  BFD_RELOC_ARM_OFFSET_IMM,
  BFD_RELOC_ARM_SHIFT_IMM,
  BFD_RELOC_ARM_SWI,
  BFD_RELOC_ARM_MULTI,
  BFD_RELOC_ARM_CP_OFF_IMM,
  BFD_RELOC_ARM_ADR_IMM,
  BFD_RELOC_ARM_LDR_IMM,
  BFD_RELOC_ARM_LITERAL,
  BFD_RELOC_ARM_IN_POOL,
  BFD_RELOC_UNUSED };
typedef __underlying_type(enum n64_cpp_enum_bfd_reloc_code_real) n64_enum_bfd_reloc_code_real;

typedef n64_enum_bfd_reloc_code_real bfd_reloc_code_real_type;
reloc_howto_type *

bfd_reloc_type_lookup (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_reloc_type_lookup");

const char *
bfd_get_reloc_code_name (bfd_reloc_code_real_type code) asm("_bfd_get_reloc_code_name");


typedef struct n64_tag_symbol_cache_entry
{
  struct n64_tag__bfd *the_bfd;



  const char *name;




  symvalue value;
  flagword flags;




  struct n64_tag_sec *section;


  union
    {
      void * p;
      bfd_vma i;
    } udata;

} asymbol;


boolean
bfd_is_local_label (bfd *abfd, asymbol *sym) asm("_bfd_is_local_label");






boolean
bfd_set_symtab (bfd *abfd, asymbol **location, unsigned int count) asm("_bfd_set_symtab");

void
bfd_print_symbol_vandf (void * file, asymbol *symbol) asm("_bfd_print_symbol_vandf");





int
bfd_decode_symclass (asymbol *symbol) asm("_bfd_decode_symclass");

void
bfd_symbol_info (asymbol *symbol, symbol_info *ret) asm("_bfd_symbol_info");

boolean
bfd_copy_private_symbol_data (bfd *ibfd, asymbol *isym, bfd *obfd, asymbol *osym) asm("_bfd_copy_private_symbol_data");




enum n64_cpp_enum_bfd_direction{no_direction = 0,
                        read_direction = 1,
                        write_direction = 2,
                        both_direction = 3};
typedef __underlying_type(enum n64_cpp_enum_bfd_direction) n64_enum_bfd_direction;
struct n64_tag__bfd
{

    const char *filename;


    const struct n64_tag_bfd_target *xvec;






    char *iostream;




    boolean cacheable;





    boolean target_defaulted;




    struct n64_tag__bfd *lru_prev, *lru_next;




    file_ptr where;



    boolean opened_once;




    boolean mtime_set;



    long mtime;



    int ifd;



    bfd_format format;



    n64_enum_bfd_direction direction;



    flagword flags;





    file_ptr origin;



    boolean output_has_begun;


    struct n64_tag_sec *sections;


    unsigned int section_count;



    bfd_vma start_address;


    unsigned int symcount;


    struct n64_tag_symbol_cache_entry **outsymbols;


    const struct n64_tag_bfd_arch_info *arch_info;


    void * arelt_data;
    struct n64_tag__bfd *my_archive;
    struct n64_tag__bfd *next;
    struct n64_tag__bfd *archive_head;
    boolean has_armap;


    struct n64_tag__bfd *link_next;



    int archive_pass;



    union
      {
      struct aout_data_struct *aout_data;
      struct n64_tag_artdata *aout_ar_data;
      struct _oasys_data *oasys_obj_data;
      struct _oasys_ar_data *oasys_ar_data;
      struct n64_tag_coff_tdata *coff_obj_data;
      struct n64_tag_pe_tdata *pe_obj_data;
      struct n64_tag_xcoff_tdata *xcoff_obj_data;
      struct n64_tag_ecoff_tdata *ecoff_obj_data;
      struct ieee_data_struct *ieee_data;
      struct ieee_ar_data_struct *ieee_ar_data;
      struct srec_data_struct *srec_data;
      struct tekhex_data_struct *tekhex_data;
      struct n64_tag_elf_obj_tdata *elf_obj_data;
      struct nlm_obj_tdata *nlm_obj_data;
      struct bout_data_struct *bout_data;
      struct sun_core_struct *sun_core_data;
      struct trad_core_struct *trad_core_data;
      struct som_data_struct *som_data;
      struct hpux_core_struct *hpux_core_data;
      struct hppabsd_core_struct *hppabsd_core_data;
      struct sgi_core_struct *sgi_core_data;
      struct lynx_core_struct *lynx_core_data;
      struct osf_core_struct *osf_core_data;
      struct cisco_core_struct *cisco_core_data;
      struct versados_data_struct *versados_data;
      void * any;
      } tdata;


    void * usrdata;


    struct n64_tag_obstack memory;
};

enum n64_cpp_enum_bfd_error{
  bfd_error_no_error = 0,
  bfd_error_system_call,
  bfd_error_invalid_target,
  bfd_error_wrong_format,
  bfd_error_invalid_operation,
  bfd_error_no_memory,
  bfd_error_no_symbols,
  bfd_error_no_armap,
  bfd_error_no_more_archived_files,
  bfd_error_malformed_archive,
  bfd_error_file_not_recognized,
  bfd_error_file_ambiguously_recognized,
  bfd_error_no_contents,
  bfd_error_nonrepresentable_section,
  bfd_error_no_debug_section,
  bfd_error_bad_value,
  bfd_error_file_truncated,
  bfd_error_file_too_big,
  bfd_error_invalid_error_code
};
typedef __underlying_type(enum n64_cpp_enum_bfd_error) n64_enum_bfd_error;
typedef n64_enum_bfd_error bfd_error_type;

bfd_error_type
bfd_get_error (void) asm("_bfd_get_error");

void
bfd_set_error (bfd_error_type error_tag) asm("_bfd_set_error");

const char *
bfd_errmsg (bfd_error_type error_tag) asm("_bfd_errmsg");

void
bfd_perror (const char *message) asm("_bfd_perror");

typedef void (*bfd_error_handler_type) (const char *, ...);

bfd_error_handler_type
bfd_set_error_handler (bfd_error_handler_type) asm("_bfd_set_error_handler");

void
bfd_set_error_program_name (const char *) asm("_bfd_set_error_program_name");

long
bfd_get_reloc_upper_bound (bfd *abfd, asection *sect) asm("_bfd_get_reloc_upper_bound");

long
bfd_canonicalize_reloc
 (bfd *abfd, asection *sec, arelent **loc, asymbol **syms) asm("_bfd_canonicalize_reloc")


                    ;

void
bfd_set_reloc
 (bfd *abfd, asection *sec, arelent **rel, unsigned int count) asm("_bfd_set_reloc")

     ;

boolean
bfd_set_file_flags (bfd *abfd, flagword flags) asm("_bfd_set_file_flags");

boolean
bfd_set_start_address (bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");

long
bfd_get_mtime (bfd *abfd) asm("_bfd_get_mtime");

long
bfd_get_size (bfd *abfd) asm("_bfd_get_size");

int
bfd_get_gp_size (bfd *abfd) asm("_bfd_get_gp_size");

void
bfd_set_gp_size (bfd *abfd, int i) asm("_bfd_set_gp_size");

bfd_vma
bfd_scan_vma (const char *string, const char **end, int base) asm("_bfd_scan_vma");

boolean
bfd_copy_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_copy_private_bfd_data");




boolean
bfd_merge_private_bfd_data (bfd *ibfd, bfd *obfd) asm("_bfd_merge_private_bfd_data");




boolean
bfd_set_private_flags (bfd *abfd, flagword flags) asm("_bfd_set_private_flags");
extern bfd_byte *bfd_get_relocated_section_contents
 (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **) asm("_bfd_get_relocated_section_contents")

                         ;

symindex
bfd_get_next_mapent (bfd *abfd, symindex previous, carsym **sym) asm("_bfd_get_next_mapent");

boolean
bfd_set_archive_head (bfd *output, bfd *new_head) asm("_bfd_set_archive_head");

bfd *
bfd_get_elt_at_index (bfd *archive, int index) asm("_bfd_get_elt_at_index");

bfd *
bfd_openr_next_archived_file (bfd *archive, bfd *previous) asm("_bfd_openr_next_archived_file");

const char *
bfd_core_file_failing_command (bfd *abfd) asm("_bfd_core_file_failing_command");

int
bfd_core_file_failing_signal (bfd *abfd) asm("_bfd_core_file_failing_signal");

boolean
core_file_matches_executable_p
 (bfd *core_bfd, bfd *exec_bfd) asm("_core_file_matches_executable_p");
enum n64_cpp_enum_bfd_flavour{
  bfd_target_unknown_flavour,
  bfd_target_aout_flavour,
  bfd_target_coff_flavour,
  bfd_target_ecoff_flavour,
  bfd_target_elf_flavour,
  bfd_target_ieee_flavour,
  bfd_target_nlm_flavour,
  bfd_target_oasys_flavour,
  bfd_target_tekhex_flavour,
  bfd_target_srec_flavour,
  bfd_target_som_flavour,
  bfd_target_os9k_flavour,
  bfd_target_versados_flavour,
  bfd_target_msdos_flavour
};
typedef __underlying_type(enum n64_cpp_enum_bfd_flavour) n64_enum_bfd_flavour;



typedef struct n64_tag_bfd_link_info _bfd_link_info;

typedef struct n64_tag_bfd_target
{
  char *name;
  n64_enum_bfd_flavour flavour;
  boolean byteorder_big_p;
  boolean header_byteorder_big_p;
  flagword object_flags;
  flagword section_flags;
  char symbol_leading_char;
  char ar_pad_char;
  unsigned short ar_max_namelen;
  bfd_vma (*bfd_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_64) (const bfd_byte *);
  void (*bfd_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_32) (const bfd_byte *);
  void (*bfd_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_getx_signed_16) (const bfd_byte *);
  void (*bfd_putx16) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx64) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_64) (const bfd_byte *);
  void (*bfd_h_putx64) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx32) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_32) (const bfd_byte *);
  void (*bfd_h_putx32) (bfd_vma, bfd_byte *);
  bfd_vma (*bfd_h_getx16) (const bfd_byte *);
  bfd_signed_vma (*bfd_h_getx_signed_16) (const bfd_byte *);
  void (*bfd_h_putx16) (bfd_vma, bfd_byte *);
  const struct n64_tag_bfd_target *(*_bfd_check_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_set_format[bfd_type_end]) (bfd *);
  boolean (*_bfd_write_contents[bfd_type_end]) (bfd *);
  boolean (*_close_and_cleanup) (bfd *);

  boolean (*_bfd_free_cached_info) (bfd *);

  boolean (*_new_section_hook) (bfd *, sec_ptr);

  boolean (*_bfd_get_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  boolean (*_bfd_get_section_contents_in_window)
                          (bfd *, sec_ptr, bfd_window *, file_ptr, bfd_size_type)
                                                            ;
  boolean (*_bfd_copy_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_merge_private_bfd_data) (bfd *, bfd *);


  boolean (*_bfd_copy_private_section_data) (bfd *, sec_ptr, bfd *, sec_ptr)
                                                                       ;


  boolean (*_bfd_copy_private_symbol_data) (bfd *, asymbol *, bfd *, asymbol *)
                            ;

  boolean (*_bfd_set_private_flags) (bfd *, flagword);


  boolean (*_bfd_print_private_bfd_data) (bfd *, void *);






  char * (*_core_file_failing_command) (bfd *);
  int (*_core_file_failing_signal) (bfd *);
  boolean (*_core_file_matches_executable_p) (bfd *, bfd *);
  boolean (*_bfd_slurp_armap) (bfd *);
  boolean (*_bfd_slurp_extended_name_table) (bfd *);
  boolean (*_bfd_construct_extended_name_table)
             (bfd *, char **, bfd_size_type *, const char **);
  void (*_bfd_truncate_arname) (bfd *, const char *, char *);
  boolean (*write_armap) (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx)



                                          ;
  void * (*_bfd_read_ar_hdr_fn) (bfd *);
  bfd * (*openr_next_archived_file) (bfd *arch, bfd *prev);
  int (*_bfd_stat_arch_elt) (bfd *, struct stat *);
  boolean (*_bfd_update_armap_timestamp) (bfd *);
  long (*_bfd_get_symtab_upper_bound) (bfd *);
  long (*_bfd_canonicalize_symtab) (bfd *, struct n64_tag_symbol_cache_entry **)
                                                                           ;
  struct n64_tag_symbol_cache_entry *
                (*_bfd_make_empty_symbol) (bfd *);
  void (*_bfd_print_symbol) (bfd *, void *, struct n64_tag_symbol_cache_entry *, bfd_print_symbol_type)

                                                             ;

  void (*_bfd_get_symbol_info) (bfd *, struct n64_tag_symbol_cache_entry *, symbol_info *)

                                                     ;

  boolean (*_bfd_is_local_label) (bfd *, asymbol *);

  alent * (*_get_lineno) (bfd *, struct n64_tag_symbol_cache_entry *);
  boolean (*_bfd_find_nearest_line) (bfd *abfd, struct n64_tag_sec *section, struct n64_tag_symbol_cache_entry **symbols, bfd_vma offset, const char **file, const char **func, unsigned int *line)


                                        ;



  asymbol * (*_bfd_make_debug_symbol) ( bfd *abfd, void *ptr, unsigned long size)


                           ;


  long (*_read_minisymbols) (bfd *, boolean, void * *, unsigned int *)
                                                      ;


  asymbol *(*_minisymbol_to_symbol) (bfd *, boolean, const void *, asymbol *)
                                                        ;






  long (*_get_reloc_upper_bound) (bfd *, sec_ptr);
  long (*_bfd_canonicalize_reloc) (bfd *, sec_ptr, arelent **, struct n64_tag_symbol_cache_entry **)
                                                                          ;

  reloc_howto_type *
       (*reloc_type_lookup) (bfd *abfd, bfd_reloc_code_real_type code)
                                                                    ;





  boolean (*_bfd_set_arch_mach) (bfd *, n64_enum_bfd_architecture, unsigned long)
                                   ;
  boolean (*_bfd_set_section_contents) (bfd *, sec_ptr, void *, file_ptr, bfd_size_type)
                                                                     ;
  int (*_bfd_sizeof_headers) (bfd *, boolean);
  bfd_byte * (*_bfd_get_relocated_section_contents) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *data, boolean relocateable, struct n64_tag_symbol_cache_entry **)


                                                  ;

  boolean (*_bfd_relax_section) (bfd *, struct n64_tag_sec *, struct n64_tag_bfd_link_info *, boolean *again)
                                                            ;



  struct n64_tag_bfd_link_hash_table *(*_bfd_link_hash_table_create) (bfd *);


  boolean (*_bfd_link_add_symbols) (bfd *, struct n64_tag_bfd_link_info *);



  boolean (*_bfd_final_link) (bfd *, struct n64_tag_bfd_link_info *);


  boolean (*_bfd_link_split_section) (bfd *, struct n64_tag_sec *);
  long (*_bfd_get_dynamic_symtab_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_symtab)
    (bfd *, struct n64_tag_symbol_cache_entry **);

  long (*_bfd_get_dynamic_reloc_upper_bound) (bfd *);

  long (*_bfd_canonicalize_dynamic_reloc)
    (bfd *, arelent **, struct n64_tag_symbol_cache_entry **);

 void * backend_data;
} bfd_target;
const bfd_target *
bfd_find_target (const char *target_name, bfd *abfd) asm("_bfd_find_target");

const char **
bfd_target_list (void) asm("_bfd_target_list");

boolean
bfd_check_format (bfd *abfd, bfd_format format) asm("_bfd_check_format");

boolean
bfd_check_format_matches (bfd *abfd, bfd_format format, char ***matching) asm("_bfd_check_format_matches");

boolean
bfd_set_format (bfd *abfd, bfd_format format) asm("_bfd_set_format");

const char *
bfd_format_string (bfd_format format) asm("_bfd_format_string");


























enum n64_cpp_enum_bfd_link_strip{
  strip_none,
  strip_debugger,
  strip_some,
  strip_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_strip) n64_enum_bfd_link_strip;




enum n64_cpp_enum_bfd_link_discard{
  discard_none,
  discard_l,
  discard_all
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_discard) n64_enum_bfd_link_discard;





enum n64_cpp_enum_bfd_link_hash_type{
  bfd_link_hash_new,
  bfd_link_hash_undefined,
  bfd_link_hash_undefweak,
  bfd_link_hash_defined,
  bfd_link_hash_defweak,
  bfd_link_hash_common,
  bfd_link_hash_indirect,
  bfd_link_hash_warning
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_hash_type) n64_enum_bfd_link_hash_type;





struct n64_tag_bfd_link_hash_common_entry
     {
       unsigned int alignment_power;
       asection *section;
     };
struct n64_tag_bfd_link_hash_entry
{

  struct n64_tag_bfd_hash_entry root;

  n64_enum_bfd_link_hash_type type;
  struct n64_tag_bfd_link_hash_entry *next;

  union
    {


      struct
 {
   bfd *abfd;
 } undef;

      struct
 {
   bfd_vma value;
   asection *section;
 } def;

      struct
 {
   struct n64_tag_bfd_link_hash_entry *link;
   const char *warning;
 } i;

      struct
 {
   bfd_size_type size;
   struct n64_tag_bfd_link_hash_common_entry *p;
 } c;
    } u;
};




struct n64_tag_bfd_link_hash_table
{

  struct n64_tag_bfd_hash_table table;




  const bfd_target *creator;


  struct n64_tag_bfd_link_hash_entry *undefs;

  struct n64_tag_bfd_link_hash_entry *undefs_tail;
};




extern struct n64_tag_bfd_link_hash_entry *bfd_link_hash_lookup
  (struct n64_tag_bfd_link_hash_table *, const char *, boolean create, boolean copy, boolean follow) asm("_bfd_link_hash_lookup")
                                  ;


extern void bfd_link_hash_traverse
  (struct n64_tag_bfd_link_hash_table *, boolean (*) (struct n64_tag_bfd_link_hash_entry *, void *), void *) asm("_bfd_link_hash_traverse")

         ;


extern void bfd_link_add_undef
  (struct n64_tag_bfd_link_hash_table *, struct n64_tag_bfd_link_hash_entry *) asm("_bfd_link_add_undef");




struct n64_tag_bfd_link_info
{

  const struct n64_tag_bfd_link_callbacks *callbacks;

  boolean relocateable;

  boolean shared;

  boolean symbolic;

  boolean static_link;

  n64_enum_bfd_link_strip strip;

  n64_enum_bfd_link_discard discard;

  unsigned int lprefix_len;
  const char *lprefix;


  boolean keep_memory;


  bfd *input_bfds;





  asection *create_object_symbols_section;

  struct n64_tag_bfd_link_hash_table *hash;


  struct n64_tag_bfd_hash_table *keep_hash;


  struct n64_tag_bfd_hash_table *notice_hash;


  void * base_file;
};
struct n64_tag_bfd_link_callbacks
{




  boolean (*add_archive_element) (struct n64_tag_bfd_link_info *, bfd *abfd, const char *name)

                         ;






  boolean (*multiple_definition) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, asection *osec, bfd_vma oval, bfd *nbfd, asection *nsec, bfd_vma nval)






                     ;
  boolean (*multiple_common) (struct n64_tag_bfd_link_info *, const char *name, bfd *obfd, n64_enum_bfd_link_hash_type otype, bfd_vma osize, bfd *nbfd, n64_enum_bfd_link_hash_type ntype, bfd_vma nsize)






                         ;






  boolean (*add_to_set) (struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_hash_entry *entry, bfd_reloc_code_real_type reloc, bfd *abfd, asection *sec, bfd_vma value)


                                              ;






  boolean (*constructor) (struct n64_tag_bfd_link_info *, boolean constructor, const char *name, bfd *abfd, asection *sec, bfd_vma value)


                     ;






  boolean (*warning) (struct n64_tag_bfd_link_info *, const char *warning, const char *symbol, bfd *abfd, asection *section, bfd_vma address)


                          ;




  boolean (*undefined_symbol) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)

                                               ;







  boolean (*reloc_overflow) (struct n64_tag_bfd_link_info *, const char *name, const char *reloc_name, bfd_vma addend, bfd *abfd, asection *section, bfd_vma address)



                          ;







  boolean (*reloc_dangerous) (struct n64_tag_bfd_link_info *, const char *message, bfd *abfd, asection *section, bfd_vma address)


                           ;






  boolean (*unattached_reloc) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)


                            ;




  boolean (*notice) (struct n64_tag_bfd_link_info *, const char *name, bfd *abfd, asection *section, bfd_vma address)
                                                       ;
};






enum n64_cpp_enum_bfd_link_order_type{
  bfd_undefined_link_order,
  bfd_indirect_link_order,
  bfd_fill_link_order,
  bfd_data_link_order,
  bfd_section_reloc_link_order,
  bfd_symbol_reloc_link_order
};
typedef __underlying_type(enum n64_cpp_enum_bfd_link_order_type) n64_enum_bfd_link_order_type;





struct n64_tag_bfd_link_order
{

  struct n64_tag_bfd_link_order *next;

  n64_enum_bfd_link_order_type type;

  bfd_vma offset;

  bfd_size_type size;

  union
    {
      struct
 {






   asection *section;
 } indirect;
      struct
 {

   unsigned int value;
 } fill;
      struct
 {


   bfd_byte *contents;
 } data;
      struct
 {



   struct n64_tag_bfd_link_order_reloc *p;
 } reloc;
    } u;
};
struct n64_tag_bfd_link_order_reloc
{

  bfd_reloc_code_real_type reloc;

  union
    {



      asection *section;


      const char *name;
    } u;






  bfd_vma addend;
};


extern struct n64_tag_bfd_link_order *bfd_new_link_order (bfd *, asection *) asm("_bfd_new_link_order");
struct n64_tag_artdata {
  file_ptr first_file_filepos;

  struct ar_cache *cache;
  bfd *archive_head;
  carsym *symdefs;
  symindex symdef_count;
  char *extended_names;

  long armap_timestamp;





  file_ptr armap_datepos;

  void * tdata;
};




struct n64_tag_areltdata {
  char * arch_header;
  unsigned int parsed_size;
  char *filename;
};



char *bfd_zmalloc (bfd_size_type size) asm("_bfd_zmalloc");

extern bfd_error_handler_type _bfd_error_handler;




void * bfd_alloc (bfd *abfd, size_t size) asm("_bfd_alloc");
void * bfd_zalloc (bfd *abfd, size_t size) asm("_bfd_zalloc");
void * bfd_realloc (bfd *abfd, void * orig, size_t size) asm("_bfd_realloc");
void bfd_alloc_grow (bfd *abfd, void * thing, size_t size) asm("_bfd_alloc_grow");
void * bfd_alloc_finish (bfd *abfd) asm("_bfd_alloc_finish");
void * bfd_alloc_by_size_t (bfd *abfd, size_t wanted) asm("_bfd_alloc_by_size_t");



bfd * _bfd_create_empty_archive_element_shell (bfd *obfd) asm("__bfd_create_empty_archive_element_shell");
bfd * _bfd_look_for_bfd_in_cache (bfd *arch_bfd, file_ptr index) asm("__bfd_look_for_bfd_in_cache");
boolean _bfd_add_bfd_to_archive_cache (bfd *, file_ptr, bfd *) asm("__bfd_add_bfd_to_archive_cache");
boolean _bfd_generic_mkarchive (bfd *abfd) asm("__bfd_generic_mkarchive");
const bfd_target *bfd_generic_archive_p (bfd *abfd) asm("_bfd_generic_archive_p");
boolean bfd_slurp_armap (bfd *abfd) asm("_bfd_slurp_armap");
boolean bfd_slurp_bsd_armap_f2 (bfd *abfd) asm("_bfd_slurp_bsd_armap_f2");


boolean _bfd_slurp_extended_name_table (bfd *abfd) asm("__bfd_slurp_extended_name_table");
extern boolean _bfd_construct_extended_name_table
  (bfd *, boolean, char **, bfd_size_type *) asm("__bfd_construct_extended_name_table");
boolean _bfd_write_archive_contents (bfd *abfd) asm("__bfd_write_archive_contents");
boolean _bfd_compute_and_write_armap (bfd *, unsigned int elength) asm("__bfd_compute_and_write_armap");
bfd *_bfd_get_elt_at_filepos (bfd *archive, file_ptr filepos) asm("__bfd_get_elt_at_filepos");
bfd * _bfd_new_bfd (void) asm("__bfd_new_bfd");

boolean bfd_false (bfd *ignore) asm("_bfd_false");
boolean bfd_true (bfd *ignore) asm("_bfd_true");
void * bfd_nullvoidptr (bfd *ignore) asm("_bfd_nullvoidptr");
int bfd_0 (bfd *ignore) asm("_bfd_0");
unsigned int bfd_0u (bfd *ignore) asm("_bfd_0u");
long bfd_0l (bfd *ignore) asm("_bfd_0l");
long _bfd_n1 (bfd *ignore) asm("__bfd_n1");
void bfd_void (bfd *ignore) asm("_bfd_void");

bfd *_bfd_new_bfd_contained_in (bfd *) asm("__bfd_new_bfd_contained_in");
const bfd_target *_bfd_dummy_target (bfd *abfd) asm("__bfd_dummy_target");

void bfd_dont_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_dont_truncate_arname")
                ;
void bfd_bsd_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_bsd_truncate_arname")
                ;
void bfd_gnu_truncate_arname (bfd *abfd, const char *filename, char *hdr) asm("_bfd_gnu_truncate_arname")
                ;

boolean bsd_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_bsd_write_armap")
                                                           ;

boolean coff_write_armap (bfd *arch, unsigned int elength, struct n64_tag_orl *map, unsigned int orl_count, int stridx) asm("_coff_write_armap")
                                                            ;

extern void * _bfd_generic_read_ar_hdr (bfd *) asm("__bfd_generic_read_ar_hdr");

bfd * bfd_generic_openr_next_archived_file (bfd *archive, bfd *last_file) asm("_bfd_generic_openr_next_archived_file")
                           ;

int bfd_generic_stat_arch_elt (bfd *, struct stat *) asm("_bfd_generic_stat_arch_elt");
extern boolean _bfd_generic_get_section_contents
  (bfd *, asection *, void * location, file_ptr offset, bfd_size_type count) asm("__bfd_generic_get_section_contents")
                         ;
extern boolean _bfd_generic_get_section_contents_in_window
  (bfd *, asection *, bfd_window *, file_ptr, bfd_size_type) asm("__bfd_generic_get_section_contents_in_window");
extern char *_bfd_nocore_core_file_failing_command (bfd *) asm("__bfd_nocore_core_file_failing_command");
extern int _bfd_nocore_core_file_failing_signal (bfd *) asm("__bfd_nocore_core_file_failing_signal");
extern boolean _bfd_nocore_core_file_matches_executable_p
  (bfd *, bfd *) asm("__bfd_nocore_core_file_matches_executable_p");
extern boolean _bfd_archive_bsd_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_bsd_construct_extended_name_table");







extern boolean _bfd_archive_bsd_update_armap_timestamp (bfd *) asm("__bfd_archive_bsd_update_armap_timestamp");







extern boolean _bfd_archive_coff_construct_extended_name_table
  (bfd *, char **, bfd_size_type *, const char **) asm("__bfd_archive_coff_construct_extended_name_table");
extern boolean _bfd_generic_set_section_contents
  (bfd *, asection *, void *, file_ptr, bfd_size_type) asm("__bfd_generic_set_section_contents");
extern boolean bfd_generic_is_local_label (bfd *, asymbol *) asm("_bfd_generic_is_local_label");


extern long _bfd_generic_read_minisymbols
  (bfd *, boolean, void * *, unsigned int *) asm("__bfd_generic_read_minisymbols");
extern asymbol *_bfd_generic_minisymbol_to_symbol
  (bfd *, boolean, const void *, asymbol *) asm("__bfd_generic_minisymbol_to_symbol");


extern struct n64_tag_bfd_hash_entry *_bfd_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *entry, struct n64_tag_bfd_hash_table *table, const char *string) asm("__bfd_link_hash_newfunc")

                        ;


extern boolean _bfd_link_hash_table_init
  (struct n64_tag_bfd_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_link_hash_table_init")


                          ;


extern struct n64_tag_bfd_link_hash_table *_bfd_generic_link_hash_table_create
  (bfd *) asm("__bfd_generic_link_hash_table_create");


extern boolean _bfd_generic_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols");




extern boolean _bfd_generic_link_add_symbols_collect
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_link_add_symbols_collect");


extern boolean _bfd_generic_link_add_archive_symbols
  (bfd *, struct n64_tag_bfd_link_info *, boolean (*checkfn) (bfd *, struct n64_tag_bfd_link_info *, boolean *)) asm("__bfd_generic_link_add_archive_symbols")
                                                                   ;


typedef struct n64_tag_bfd_link_hash_entry _bfd_link_hash_entry;


extern boolean _bfd_generic_link_add_one_symbol
  (struct n64_tag_bfd_link_info *, bfd *, const char *name, flagword, asection *, bfd_vma, const char *, boolean copy, boolean constructor, struct n64_tag_bfd_link_hash_entry **) asm("__bfd_generic_link_add_one_symbol")

                                                        ;


extern boolean _bfd_generic_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_generic_final_link");

extern boolean _bfd_generic_link_split_section
  (bfd *, struct n64_tag_sec *) asm("__bfd_generic_link_split_section");


extern boolean _bfd_generic_reloc_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_generic_reloc_link_order")
                             ;


extern boolean _bfd_default_link_order
  (bfd *, struct n64_tag_bfd_link_info *, asection *, struct n64_tag_bfd_link_order *) asm("__bfd_default_link_order")
                             ;


extern unsigned int _bfd_count_link_order_relocs
  (struct n64_tag_bfd_link_order *) asm("__bfd_count_link_order_relocs");


extern bfd_reloc_status_type _bfd_final_link_relocate
  (reloc_howto_type *, bfd *, asection *, bfd_byte *, bfd_vma address, bfd_vma value, bfd_vma addend) asm("__bfd_final_link_relocate")
                                                    ;


extern bfd_reloc_status_type _bfd_relocate_contents
  (reloc_howto_type *, bfd *, bfd_vma, bfd_byte *) asm("__bfd_relocate_contents");


extern struct bfd_strtab_hash *_bfd_stringtab_init (void) asm("__bfd_stringtab_init");


extern struct bfd_strtab_hash *_bfd_xcoff_stringtab_init (void) asm("__bfd_xcoff_stringtab_init");


extern void _bfd_stringtab_free (struct bfd_strtab_hash *) asm("__bfd_stringtab_free");


extern bfd_size_type _bfd_stringtab_size (struct bfd_strtab_hash *) asm("__bfd_stringtab_size");


extern bfd_size_type _bfd_stringtab_add
  (struct bfd_strtab_hash *, const char *, boolean hash, boolean copy) asm("__bfd_stringtab_add")
                  ;


extern boolean _bfd_stringtab_emit (bfd *, struct bfd_strtab_hash *) asm("__bfd_stringtab_emit");
void bfd_assert (const char*,int) asm("_bfd_assert");







FILE * bfd_cache_lookup_worker (bfd *) asm("_bfd_cache_lookup_worker");

extern bfd *bfd_last_cache;
extern const bfd_target * const bfd_target_vector[];
extern const bfd_target * const bfd_default_vector[];





struct n64_tag_ecoff_find_line;


extern boolean _bfd_ecoff_locate_line
  (bfd *, asection *, bfd_vma, struct n64_tag_ecoff_debug_info * const, const struct n64_tag_ecoff_debug_swap * const, struct n64_tag_ecoff_find_line *, const char **, const char **, unsigned int *) asm("__bfd_ecoff_locate_line")

                                                  ;
extern boolean _bfd_ecoff_get_accumulated_pdr (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_pdr");
extern boolean _bfd_ecoff_get_accumulated_sym (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_sym");
extern boolean _bfd_ecoff_get_accumulated_ss (void *, bfd_byte *) asm("__bfd_ecoff_get_accumulated_ss");



void
bfd_write_bigendian_4byte_int (bfd *abfd, int i) asm("_bfd_write_bigendian_4byte_int");

unsigned int
bfd_log2 (bfd_vma x) asm("_bfd_log2");


extern bfd *bfd_last_cache;





boolean
bfd_cache_init (bfd *abfd) asm("_bfd_cache_init");

boolean
bfd_cache_close (bfd *abfd) asm("_bfd_cache_close");

FILE*
bfd_open_file (bfd *abfd) asm("_bfd_open_file");

FILE *
bfd_cache_lookup_worker (bfd *abfd) asm("_bfd_cache_lookup_worker");
reloc_howto_type *
bfd_default_reloc_type_lookup
 (bfd *abfd, bfd_reloc_code_real_type code) asm("_bfd_default_reloc_type_lookup");

boolean
bfd_generic_relax_section
 (bfd *abfd, asection *section, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_generic_relax_section")


               ;

bfd_byte *

bfd_generic_get_relocated_section_contents (bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_generic_get_relocated_section_contents")




                       ;

extern const bfd_arch_info_type bfd_default_arch_struct;
boolean
bfd_default_set_arch_mach (bfd *abfd, n64_enum_bfd_architecture arch, unsigned long mach) asm("_bfd_default_set_arch_mach")

                        ;

const bfd_arch_info_type *
bfd_default_compatible
 (const bfd_arch_info_type *a, const bfd_arch_info_type *b) asm("_bfd_default_compatible")
                                 ;

boolean
bfd_default_scan (const struct n64_tag_bfd_arch_info *info, const char *string) asm("_bfd_default_scan");

struct n64_tag_elf_internal_shdr *
bfd_elf_find_section (bfd *abfd, char *name) asm("_bfd_elf_find_section");
struct n64_tag_internal_extra_pe_filehdr
{

  unsigned short e_magic;
  unsigned short e_cblp;
  unsigned short e_cp;
  unsigned short e_crlc;
  unsigned short e_cparhdr;
  unsigned short e_minalloc;
  unsigned short e_maxalloc;
  unsigned short e_ss;
  unsigned short e_sp;
  unsigned short e_csum;
  unsigned short e_ip;
  unsigned short e_cs;
  unsigned short e_lfarlc;
  unsigned short e_ovno;
  unsigned short e_res[4];
  unsigned short e_oemid;
  unsigned short e_oeminfo;
  unsigned short e_res2[10];
  bfd_vma e_lfanew;
  unsigned long dos_message[16];
  bfd_vma nt_signature;
};

struct n64_tag_internal_filehdr
{
  struct n64_tag_internal_extra_pe_filehdr pe;


  unsigned short f_magic;
  unsigned short f_nscns;
  long f_timdat;
  bfd_vma f_symptr;
  long f_nsyms;
  unsigned short f_opthdr;
  unsigned short f_flags;
};
typedef struct n64_tag__IMAGE_DATA_DIRECTORY
{
  bfd_vma VirtualAddress;
  long Size;
} IMAGE_DATA_DIRECTORY;
struct n64_tag_internal_extra_pe_aouthdr
{

  bfd_vma ImageBase;


  bfd_vma SectionAlignment;
  bfd_vma FileAlignment;
  short MajorOperatingSystemVersion;
  short MinorOperatingSystemVersion;
  short MajorImageVersion;
  short MinorImageVersion;
  short MajorSubsystemVersion;
  short MinorSubsystemVersion;
  long Reserved1;
  long SizeOfImage;
  long SizeOfHeaders;
  long CheckSum;
  short Subsystem;
  short DllCharacteristics;
  bfd_vma SizeOfStackReserve;
  bfd_vma SizeOfStackCommit;

  bfd_vma SizeOfHeapReserve;
  bfd_vma SizeOfHeapCommit;
  long LoaderFlags;
  long NumberOfRvaAndSizes;
  IMAGE_DATA_DIRECTORY DataDirectory[16];
};


struct n64_tag_internal_aouthdr
{
  short magic;
  short vstamp;
  bfd_vma tsize;
  bfd_vma dsize;
  bfd_vma bsize;
  bfd_vma entry;
  bfd_vma text_start;
  bfd_vma data_start;


  unsigned long tagentries;


  unsigned long o_toc;
  short o_snentry;
  short o_sntext;
  short o_sndata;
  short o_sntoc;
  short o_snloader;
  short o_snbss;
  short o_algntext;
  short o_algndata;
  short o_modtype;
  short o_cputype;
  unsigned long o_maxstack;
  unsigned long o_maxdata;


  bfd_vma bss_start;
  bfd_vma gp_value;
  unsigned long gprmask;
  unsigned long cprmask[4];
  unsigned long fprmask;


  long o_inlib;
  long o_sri;
  long vid[2];


  struct n64_tag_internal_extra_pe_aouthdr pe;

};
struct n64_tag_internal_scnhdr
{
  char s_name[8];
  bfd_vma s_paddr;
  bfd_vma s_vaddr;
  bfd_vma s_size;
  bfd_vma s_scnptr;
  bfd_vma s_relptr;
  bfd_vma s_lnnoptr;
  unsigned long s_nreloc;
  unsigned long s_nlnno;
  long s_flags;
  long s_align;
};
struct n64_tag_internal_lineno
{
  union
  {
    long l_symndx;
    long l_paddr;
  } l_addr;
  unsigned long l_lnno;
};







struct n64_tag_internal_syment
{
  union
  {
    char _n_name[8];
    struct
    {
      long _n_zeroes;
      long _n_offset;
    } _n_n;
    char *_n_nptr[2];
  } _n;
  long n_value;
  short n_scnum;
  unsigned short n_flags;
  unsigned short n_type;
  unsigned char n_sclass;
  unsigned char n_numaux;
};
union n64_tag_internal_auxent
{
  struct
  {

    union
    {
      long l;
      struct n64_tag_coff_ptr_struct *p;
    } x_tagndx;

    union
    {
      struct
      {
 unsigned short x_lnno;
 unsigned short x_size;
      } x_lnsz;
      long x_fsize;
    } x_misc;

    union
    {
      struct
      {
 long x_lnnoptr;
 union
 {
   long l;
   struct n64_tag_coff_ptr_struct *p;
 } x_endndx;
      } x_fcn;

      struct
      {
 unsigned short x_dimen[4];
      } x_ary;
    } x_fcnary;

    unsigned short x_tvndx;
  } x_sym;

  union
  {
    char x_fname[14];
    struct
    {
      long x_zeroes;
      long x_offset;
    } x_n;
  } x_file;

  struct
  {
    long x_scnlen;
    unsigned short x_nreloc;
    unsigned short x_nlinno;
  } x_scn;

  struct
  {
    long x_tvfill;
    unsigned short x_tvlen;
    unsigned short x_tvran[2];
  } x_tv;




  struct
  {
    union
      {
 long l;
 struct n64_tag_coff_ptr_struct *p;
      } x_scnlen;
    long x_parmhash;
    unsigned short x_snhash;
    unsigned char x_smtyp;


    unsigned char x_smclas;
    long x_stab;
    unsigned short x_snstab;
  } x_csect;
  struct
  {


    long x_stindx;
  } x_sc;

  struct
  {
    unsigned long x_balntry;
  } x_bal;

  struct
  {
    unsigned long x_timestamp;
    char x_idstring[20];
  } x_ident;

};



struct n64_tag_internal_reloc
{
  bfd_vma r_vaddr;
  long r_symndx;
  unsigned short r_type;
  unsigned char r_size;
  unsigned char r_extern;
  unsigned long r_offset;
};
typedef struct {
 short magic;
 short vstamp;
 long ilineMax;
 bfd_vma cbLine;
 bfd_vma cbLineOffset;
 long idnMax;
 bfd_vma cbDnOffset;
 long ipdMax;
 bfd_vma cbPdOffset;
 long isymMax;
 bfd_vma cbSymOffset;
 long ioptMax;
 bfd_vma cbOptOffset;
 long iauxMax;
 bfd_vma cbAuxOffset;
 long issMax;
 bfd_vma cbSsOffset;
 long issExtMax;
 bfd_vma cbSsExtOffset;
 long ifdMax;
 bfd_vma cbFdOffset;
 long crfd;
 bfd_vma cbRfdOffset;
 long iextMax;
 bfd_vma cbExtOffset;

 } HDRR, *pHDRR;
typedef struct n64_tag_fdr {
 bfd_vma adr;
 long rss;
 long issBase;
 bfd_vma cbSs;
 long isymBase;
 long csym;
 long ilineBase;
 long cline;
 long ioptBase;
 long copt;
 unsigned short ipdFirst;
 short cpd;
 long iauxBase;
 long caux;
 long rfdBase;
 long crfd;
 unsigned lang: 5;
 unsigned fMerge : 1;
 unsigned fReadin : 1;
 unsigned fBigendian : 1;

 unsigned glevel : 2;
 unsigned reserved : 22;
 bfd_vma cbLineOffset;
 bfd_vma cbLine;
 } FDR, *pFDR;
typedef struct n64_tag_pdr {
 bfd_vma adr;
 long isym;
 long iline;
 long regmask;
 long regoffset;
 long iopt;
 long fregmask;
 long fregoffset;
 long frameoffset;
 short framereg;
 short pcreg;
 long lnLow;
 long lnHigh;
 bfd_vma cbLineOffset;

 unsigned gp_prologue : 8;
 unsigned gp_used : 1;
 unsigned reg_frame : 1;
 unsigned prof : 1;
 unsigned reserved : 13;
 unsigned localoff : 8;
 } PDR, *pPDR;
typedef long LINER, *pLINER;
typedef struct {
 long iss;
 bfd_vma value;
 unsigned st : 6;
 unsigned sc : 5;
 unsigned reserved : 1;
 unsigned index : 20;
 } SYMR, *pSYMR;
typedef struct n64_tag_ecoff_extr {
 unsigned jmptbl:1;
 unsigned cobol_main:1;
 unsigned weakext:1;
 unsigned reserved:13;
 int ifd;
 SYMR asym;
 } EXTR, *pEXTR;
typedef struct {
 unsigned fBitfield : 1;
 unsigned continued : 1;
 unsigned bt : 6;
 unsigned tq4 : 4;
 unsigned tq5 : 4;

 unsigned tq0 : 4;
 unsigned tq1 : 4;
 unsigned tq2 : 4;
 unsigned tq3 : 4;
 } TIR, *pTIR;
typedef struct {
 unsigned rfd : 12;
 unsigned index : 20;
 } RNDXR, *pRNDXR;






typedef struct {
 unsigned long rfd;
 unsigned long index;
 } DNR, *pDNR;
typedef union {
 TIR ti;
 RNDXR rndx;
 long dnLow;
 long dnHigh;
 long isym;
 long iss;
 long width;
 long count;
 } AUXU, *pAUXU;
typedef struct {
 unsigned ot: 8;
 unsigned value: 24;
 RNDXR rndx;
 unsigned long offset;
 } OPTR, *pOPTR;
typedef long RFDT, *pRFDT;
typedef long FIT, *pFIT;
typedef struct n64_tag_coff_tdata
{
  struct n64_tag_coff_symbol_struct *symbols;
  unsigned int *conversion_table;
  int conv_table_size;
  file_ptr sym_filepos;

  struct n64_tag_coff_ptr_struct *raw_syments;
  unsigned int raw_syment_count;


  long int relocbase;




  unsigned local_n_btmask;
  unsigned local_n_btshft;
  unsigned local_n_tmask;
  unsigned local_n_tshift;
  unsigned local_symesz;
  unsigned local_auxesz;
  unsigned local_linesz;



  void * external_syms;

  boolean keep_syms;



  char *strings;

  boolean keep_strings;


  int pe;

  struct n64_tag_coff_link_hash_entry **sym_hashes;


  int *local_toc_sym_map;

  struct n64_tag_bfd_link_info *link_info;
} coff_data_type;


typedef struct n64_tag_pe_tdata
{
  coff_data_type coff;
  struct n64_tag_internal_extra_pe_aouthdr pe_opthdr;
  int dll;
  int has_reloc_section;
  boolean (*in_reloc_p) (bfd *, reloc_howto_type *);
  flagword real_flags;
} pe_data_type;





struct n64_tag_xcoff_tdata
{

  coff_data_type coff;


  boolean full_aouthdr;


  bfd_vma toc;


  asection *toc_section;


  asection *entry_section;


  int text_align_power;


  int data_align_power;


  short modtype;


  short cputype;


  bfd_size_type maxdata;


  bfd_size_type maxstack;


  asection **csects;
  unsigned long *debug_indices;
  unsigned int import_file_id;
};
struct n64_tag_coff_section_tdata
{

  struct n64_tag_internal_reloc *relocs;

  boolean keep_relocs;

  bfd_byte *contents;

  boolean keep_contents;

  bfd_vma offset;
  unsigned int i;
  const char *function;
  int line_base;

  void * tdata;
};







struct n64_tag_xcoff_section_tdata
{


  asection *enclosing;


  unsigned int lineno_count;


  unsigned long first_symndx;
  unsigned long last_symndx;
};







struct n64_tag_coff_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  unsigned short type;


  unsigned char cxx_class;


  char numaux;


  bfd *auxbfd;


  union n64_tag_internal_auxent *aux;
};



struct n64_tag_coff_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;
};
extern const bfd_target *coff_object_p (bfd *) asm("_coff_object_p");
extern struct n64_tag_sec *coff_section_from_bfd_index (bfd *, int) asm("_coff_section_from_bfd_index");
extern long coff_get_symtab_upper_bound (bfd *) asm("_coff_get_symtab_upper_bound");
extern long coff_get_symtab (bfd *, asymbol **) asm("_coff_get_symtab");
extern int coff_count_linenumbers (bfd *) asm("_coff_count_linenumbers");
extern struct n64_tag_coff_symbol_struct *coff_symbol_from (bfd *, asymbol *) asm("_coff_symbol_from");
extern boolean coff_renumber_symbols (bfd *, int *) asm("_coff_renumber_symbols");
extern void coff_mangle_symbols (bfd *) asm("_coff_mangle_symbols");
extern boolean coff_write_symbols (bfd *) asm("_coff_write_symbols");
extern boolean coff_write_linenumbers (bfd *) asm("_coff_write_linenumbers");
extern alent *coff_get_lineno (bfd *, asymbol *) asm("_coff_get_lineno");
extern asymbol *coff_section_symbol (bfd *, char *) asm("_coff_section_symbol");
extern boolean _bfd_coff_get_external_symbols (bfd *) asm("__bfd_coff_get_external_symbols");
extern const char *_bfd_coff_read_string_table (bfd *) asm("__bfd_coff_read_string_table");
extern boolean _bfd_coff_free_symbols (bfd *) asm("__bfd_coff_free_symbols");
extern struct n64_tag_coff_ptr_struct *coff_get_normalized_symtab (bfd *) asm("_coff_get_normalized_symtab");
extern long coff_get_reloc_upper_bound (bfd *, sec_ptr) asm("_coff_get_reloc_upper_bound");
extern asymbol *coff_make_empty_symbol (bfd *) asm("_coff_make_empty_symbol");
extern void coff_print_symbol (bfd *, void * filep, asymbol *, bfd_print_symbol_type how) asm("_coff_print_symbol")
                                      ;
extern void coff_get_symbol_info (bfd *, asymbol *, symbol_info *ret) asm("_coff_get_symbol_info")
                         ;
extern asymbol *coff_bfd_make_debug_symbol (bfd *, void *, unsigned long) asm("_coff_bfd_make_debug_symbol")
                         ;
extern boolean coff_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma offset, const char **filename_ptr, const char **functionname_ptr, unsigned int *line_ptr) asm("_coff_find_nearest_line")





                                    ;
extern int coff_sizeof_headers (bfd *, boolean reloc) asm("_coff_sizeof_headers");
extern boolean bfd_coff_reloc16_relax_section
  (bfd *, asection *, struct n64_tag_bfd_link_info *, boolean *) asm("_bfd_coff_reloc16_relax_section");
extern bfd_byte *bfd_coff_reloc16_get_relocated_section_contents
  (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean relocateable, asymbol **) asm("_bfd_coff_reloc16_get_relocated_section_contents")
                                                  ;
extern bfd_vma bfd_coff_reloc16_get_value (arelent *, struct n64_tag_bfd_link_info *, asection *) asm("_bfd_coff_reloc16_get_value")

                     ;
extern void bfd_perform_slip (bfd *abfd, unsigned int slip, asection *input_section, bfd_vma val) asm("_bfd_perform_slip")

                       ;



extern struct n64_tag_bfd_hash_entry *_bfd_coff_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_coff_link_hash_newfunc");
extern boolean _bfd_coff_link_hash_table_init
  (struct n64_tag_coff_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_coff_link_hash_table_init")


                          ;
extern struct n64_tag_bfd_link_hash_table *_bfd_coff_link_hash_table_create
  (bfd *) asm("__bfd_coff_link_hash_table_create");
extern const char *_bfd_coff_internal_syment_name
  (bfd *, const struct n64_tag_internal_syment *, char *) asm("__bfd_coff_internal_syment_name");
extern boolean _bfd_coff_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_coff_link_add_symbols");
extern boolean _bfd_coff_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_coff_final_link");
extern struct n64_tag_internal_reloc *_bfd_coff_read_internal_relocs
  (bfd *, asection *, boolean, bfd_byte *, boolean, struct n64_tag_internal_reloc *) asm("__bfd_coff_read_internal_relocs")
                             ;
extern boolean _bfd_coff_generic_relocate_section
  (bfd *, struct n64_tag_bfd_link_info *, bfd *, asection *, bfd_byte *, struct n64_tag_internal_reloc *, struct n64_tag_internal_syment *, asection **) asm("__bfd_coff_generic_relocate_section")
                                                                    ;






extern struct n64_tag_bfd_link_hash_table *_bfd_xcoff_bfd_link_hash_table_create
  (bfd *) asm("__bfd_xcoff_bfd_link_hash_table_create");
extern boolean _bfd_xcoff_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_xcoff_bfd_link_add_symbols");
extern boolean _bfd_xcoff_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_xcoff_bfd_final_link");
extern boolean _bfd_ppc_xcoff_relocate_section
  (bfd *, struct n64_tag_bfd_link_info *, bfd *, asection *, bfd_byte *, struct n64_tag_internal_reloc *, struct n64_tag_internal_syment *, asection **) asm("__bfd_ppc_xcoff_relocate_section")
                                                                    ;



typedef struct n64_tag_coff_ptr_struct
{



unsigned int offset;



unsigned int fix_value : 1;



unsigned int fix_tag : 1;



unsigned int fix_end : 1;



unsigned int fix_scnlen : 1;




unsigned int fix_line : 1;




union {
   union n64_tag_internal_auxent auxent;
   struct n64_tag_internal_syment syment;
 } u;
} combined_entry_type;




typedef struct n64_tag_coff_symbol_struct
{

asymbol symbol;


combined_entry_type *native;


struct n64_tag_lineno_cache_entry *lineno;


boolean done_lineno;
} coff_symbol_type;
typedef struct
{
  void (*_bfd_coff_swap_aux_in) ( bfd *abfd, void * ext, int type, int cxx_class, int indaux, int numaux, void * in)






                           ;

  void (*_bfd_coff_swap_sym_in) ( bfd *abfd , void * ext, void * in)


                           ;

  void (*_bfd_coff_swap_lineno_in) ( bfd *abfd, void * ext, void * in)


                           ;

 unsigned int (*_bfd_coff_swap_aux_out) ( bfd *abfd, void * in, int type, int cxx_class, int indaux, int numaux, void * ext)






                    ;

 unsigned int (*_bfd_coff_swap_sym_out) ( bfd *abfd, void * in, void * ext)


               ;

 unsigned int (*_bfd_coff_swap_lineno_out) ( bfd *abfd, void * in, void * ext)


          ;

 unsigned int (*_bfd_coff_swap_reloc_out) ( bfd *abfd, void * src, void * dst)


          ;

 unsigned int (*_bfd_coff_swap_filehdr_out) ( bfd *abfd, void * in, void * out)


           ;

 unsigned int (*_bfd_coff_swap_aouthdr_out) ( bfd *abfd, void * in, void * out)


          ;

 unsigned int (*_bfd_coff_swap_scnhdr_out) ( bfd *abfd, void * in, void * out)


          ;

 unsigned int _bfd_filhsz;
 unsigned int _bfd_aoutsz;
 unsigned int _bfd_scnhsz;
 unsigned int _bfd_symesz;
 unsigned int _bfd_auxesz;
 unsigned int _bfd_relsz;
 unsigned int _bfd_linesz;
 boolean _bfd_coff_long_filenames;
 void (*_bfd_coff_swap_filehdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_aouthdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_scnhdr_in) ( bfd *abfd, void * ext, void * in)


                   ;
 void (*_bfd_coff_swap_reloc_in) ( bfd *abfd, void * ext, void * in)


                   ;
 boolean (*_bfd_coff_bad_format_hook) ( bfd *abfd, void * internal_filehdr)

                                 ;
 boolean (*_bfd_coff_set_arch_mach_hook) ( bfd *abfd, void * internal_filehdr)

                                 ;
 void * (*_bfd_coff_mkobject_hook) ( bfd *abfd, void * internal_filehdr, void * internal_aouthdr)


                                 ;
 flagword (*_bfd_styp_to_sec_flags_hook) ( bfd *abfd, void * internal_scnhdr, const char *name)


                         ;
 void (*_bfd_set_alignment_hook) ( bfd *abfd, asection *sec, void * internal_scnhdr)


                                ;
 boolean (*_bfd_coff_slurp_symbol_table) ( bfd *abfd)
                      ;
 boolean (*_bfd_coff_symname_in_debug) ( bfd *abfd, struct n64_tag_internal_syment *sym)

                                    ;
 boolean (*_bfd_coff_pointerize_aux_hook) ( bfd *abfd, combined_entry_type *table_base, combined_entry_type *symbol, unsigned int indaux, combined_entry_type *aux)




                                 ;
 boolean (*_bfd_coff_print_aux) ( bfd *abfd, FILE *file, combined_entry_type *table_base, combined_entry_type *symbol, combined_entry_type *aux, unsigned int indaux)





                            ;
 void (*_bfd_coff_reloc16_extra_cases) ( bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, arelent *reloc, bfd_byte *data, unsigned int *src_ptr, unsigned int *dst_ptr)






                              ;
 int (*_bfd_coff_reloc16_estimate) ( bfd *abfd, asection *input_section, arelent *r, unsigned int shrink, struct n64_tag_bfd_link_info *link_info)




                                        ;
 boolean (*_bfd_coff_sym_is_global) ( bfd *abfd, struct n64_tag_internal_syment *)

                                 ;
 void (*_bfd_coff_compute_section_file_positions) ( bfd *abfd)
                  ;
 boolean (*_bfd_coff_start_final_link) ( bfd *output_bfd, struct n64_tag_bfd_link_info *info)

                                   ;
 boolean (*_bfd_coff_relocate_section) ( bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, struct n64_tag_internal_reloc *relocs, struct n64_tag_internal_syment *syms, asection **sections)







                            ;
 reloc_howto_type *(*_bfd_coff_rtype_to_howto) ( bfd *abfd, asection *sec, struct n64_tag_internal_reloc *rel, struct n64_tag_coff_link_hash_entry *h, struct n64_tag_internal_syment *sym, bfd_vma *addendp)





                         ;
 boolean (*_bfd_coff_adjust_symndx) ( bfd *obfd, struct n64_tag_bfd_link_info *info, bfd *ibfd, asection *sec, struct n64_tag_internal_reloc *reloc, boolean *adjustedp)





                           ;

} bfd_coff_backend_data;
struct n64_tag_tir_ext {
 unsigned char t_bits1[1];
 unsigned char t_tq45[1];
 unsigned char t_tq01[1];
 unsigned char t_tq23[1];
};
struct n64_tag_rndx_ext {
 unsigned char r_bits[4];
};
union n64_tag_aux_ext {
 struct n64_tag_tir_ext a_ti;
 struct n64_tag_rndx_ext a_rndx;
 unsigned char a_dnLow[4];
 unsigned char a_dnHigh[4];
 unsigned char a_isym[4];
 unsigned char a_iss[4];
 unsigned char a_width[4];
 unsigned char a_count[4];
};
struct n64_tag_ecoff_debug_info
{

  HDRR symbolic_header;
  unsigned char *line;
  void * external_dnr;
  void * external_pdr;
  void * external_sym;
  void * external_opt;
  union n64_tag_aux_ext *external_aux;
  char *ss;
  char *ssext;
  void * external_fdr;
  void * external_rfd;
  void * external_ext;



  char *ssext_end;
  void * external_ext_end;




  RFDT *ifdmap;





  FDR *fdr;







  struct n64_tag_ecoff_value_adjust *adjust;
};






struct n64_tag_ecoff_value_adjust
{

  struct n64_tag_ecoff_value_adjust *next;



  bfd_vma start;

  bfd_vma end;


  long adjust;
};



struct n64_tag_ecoff_fdrtab_entry
{

  bfd_vma base_addr;
  FDR *fdr;
};

struct n64_tag_ecoff_find_line
{

  char *find_buffer;


  long fdrtab_len;
  struct n64_tag_ecoff_fdrtab_entry *fdrtab;
};
struct n64_tag_ecoff_debug_swap
{

  int sym_magic;

  bfd_size_type debug_align;

  bfd_size_type external_hdr_size;
  bfd_size_type external_dnr_size;
  bfd_size_type external_pdr_size;
  bfd_size_type external_sym_size;
  bfd_size_type external_opt_size;
  bfd_size_type external_fdr_size;
  bfd_size_type external_rfd_size;
  bfd_size_type external_ext_size;

  void (*swap_hdr_in) (bfd *, void *, HDRR *);
  void (*swap_dnr_in) (bfd *, void *, DNR *);
  void (*swap_pdr_in) (bfd *, void *, PDR *);
  void (*swap_sym_in) (bfd *, void *, SYMR *);
  void (*swap_opt_in) (bfd *, void *, OPTR *);
  void (*swap_fdr_in) (bfd *, void *, FDR *);
  void (*swap_rfd_in) (bfd *, void *, RFDT *);
  void (*swap_ext_in) (bfd *, void *, EXTR *);
  void (*swap_tir_in) (int, const struct n64_tag_tir_ext *, TIR *);
  void (*swap_rndx_in) (int, const struct n64_tag_rndx_ext *, RNDXR *);

  void (*swap_hdr_out) (bfd *, const HDRR *, void *);
  void (*swap_dnr_out) (bfd *, const DNR *, void *);
  void (*swap_pdr_out) (bfd *, const PDR *, void *);
  void (*swap_sym_out) (bfd *, const SYMR *, void *);
  void (*swap_opt_out) (bfd *, const OPTR *, void *);
  void (*swap_fdr_out) (bfd *, const FDR *, void *);
  void (*swap_rfd_out) (bfd *, const RFDT *, void *);
  void (*swap_ext_out) (bfd *, const EXTR *, void *);
  void (*swap_tir_out) (int, const TIR *, struct n64_tag_tir_ext *);
  void (*swap_rndx_out) (int, const RNDXR *, struct n64_tag_rndx_ext *);



  boolean (*read_debug_info) (bfd *, asection *, struct n64_tag_ecoff_debug_info *)
                                     ;
};
struct n64_tag_ecoff_backend_data
{

  bfd_coff_backend_data coff;

  n64_enum_bfd_architecture arch;

  const char *armap_start;


  bfd_vma round;



  boolean rdata_in_text;

  unsigned int constructor_bitsize;

  reloc_howto_type *constructor_reloc;

  struct n64_tag_ecoff_debug_swap debug_swap;

  bfd_size_type external_reloc_size;

  void (*swap_reloc_in) (bfd *, void *, struct n64_tag_internal_reloc *);
  void (*swap_reloc_out) (bfd *, const struct n64_tag_internal_reloc *, void *);

  void (*adjust_reloc_in) (bfd *, const struct n64_tag_internal_reloc *, arelent *)
                  ;
  void (*adjust_reloc_out) (bfd *, const arelent *, struct n64_tag_internal_reloc *)
                                 ;

  boolean (*relocate_section) (bfd *output_bfd, struct n64_tag_bfd_link_info *, bfd *input_bfd, asection *input_section, bfd_byte *contents, void * external_relocs)


                                ;

  boolean (*adjust_headers) (bfd *, struct n64_tag_internal_filehdr *, struct n64_tag_internal_aouthdr *)
                                    ;
};





typedef struct n64_tag_ecoff_tdata
{


  file_ptr reloc_filepos;


  file_ptr sym_filepos;



  unsigned long text_start;
  unsigned long text_end;


  bfd_vma gp;




  unsigned int gp_size;





  unsigned long gprmask;
  unsigned long fprmask;
  unsigned long cprmask[4];


  struct n64_tag_ecoff_debug_info debug_info;


  void * raw_syments;


  struct n64_tag_ecoff_symbol_struct *canonical_symbols;



  struct n64_tag_ecoff_link_hash_entry **sym_hashes;



  asection **symndx_to_section;


  boolean linker;




  struct n64_tag_ecoff_find_line *find_line_info;

} ecoff_data_type;



typedef struct n64_tag_ecoff_symbol_struct
{

  asymbol symbol;


  FDR *fdr;


  boolean local;




  void * native;
} ecoff_symbol_type;
struct n64_tag_ecoff_section_tdata
{


  void * external_relocs;



  bfd_byte *contents;
  long *offsets;
};







struct n64_tag_ecoff_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;

  long indx;

  bfd *abfd;

  EXTR esym;

  char written;

  char small;
};



struct n64_tag_ecoff_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;
};


extern boolean _bfd_ecoff_mkobject (bfd *) asm("__bfd_ecoff_mkobject");


extern boolean _bfd_ecoff_slurp_symbolic_info
  (bfd *, asection *, struct n64_tag_ecoff_debug_info *) asm("__bfd_ecoff_slurp_symbolic_info");



extern boolean _bfd_ecoff_write_object_contents (bfd *abfd) asm("__bfd_ecoff_write_object_contents");
extern const bfd_target *_bfd_ecoff_archive_p (bfd *abfd) asm("__bfd_ecoff_archive_p");



extern boolean _bfd_ecoff_new_section_hook
  (bfd *, asection *) asm("__bfd_ecoff_new_section_hook");
extern boolean _bfd_ecoff_get_section_contents
  (bfd *, asection *, void * location, file_ptr, bfd_size_type) asm("__bfd_ecoff_get_section_contents");



extern boolean _bfd_ecoff_bfd_copy_private_bfd_data (bfd *, bfd *) asm("__bfd_ecoff_bfd_copy_private_bfd_data");
extern boolean _bfd_ecoff_slurp_armap (bfd *abfd) asm("__bfd_ecoff_slurp_armap");




extern boolean _bfd_ecoff_write_armap
  (bfd *, unsigned int, struct n64_tag_orl *, unsigned int, int) asm("__bfd_ecoff_write_armap");






extern long _bfd_ecoff_get_symtab_upper_bound (bfd *abfd) asm("__bfd_ecoff_get_symtab_upper_bound");
extern long _bfd_ecoff_get_symtab (bfd *abfd, asymbol **alocation) asm("__bfd_ecoff_get_symtab");
extern asymbol *_bfd_ecoff_make_empty_symbol (bfd *abfd) asm("__bfd_ecoff_make_empty_symbol");
extern void _bfd_ecoff_print_symbol
  (bfd *, void * filep, asymbol *, bfd_print_symbol_type) asm("__bfd_ecoff_print_symbol");
extern void _bfd_ecoff_get_symbol_info
  (bfd *, asymbol *, symbol_info *) asm("__bfd_ecoff_get_symbol_info");
extern boolean _bfd_ecoff_bfd_is_local_label
  (bfd *, asymbol *) asm("__bfd_ecoff_bfd_is_local_label");

extern boolean _bfd_ecoff_find_nearest_line
  (bfd *, asection *, asymbol **, bfd_vma offset, const char **filename_ptr, const char **fnname_ptr, unsigned int *retline_ptr) asm("__bfd_ecoff_find_nearest_line")

                               ;





extern long _bfd_ecoff_canonicalize_reloc
  (bfd *, asection *, arelent **, asymbol **symbols) asm("__bfd_ecoff_canonicalize_reloc");


extern boolean _bfd_ecoff_set_arch_mach
  (bfd *, n64_enum_bfd_architecture, unsigned long machine) asm("__bfd_ecoff_set_arch_mach");
extern boolean _bfd_ecoff_set_section_contents
  (bfd *, asection *, void * location, file_ptr, bfd_size_type) asm("__bfd_ecoff_set_section_contents");

extern int _bfd_ecoff_sizeof_headers (bfd *abfd, boolean reloc) asm("__bfd_ecoff_sizeof_headers");


extern struct n64_tag_bfd_link_hash_table *_bfd_ecoff_bfd_link_hash_table_create
  (bfd *) asm("__bfd_ecoff_bfd_link_hash_table_create");
extern boolean _bfd_ecoff_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_ecoff_bfd_link_add_symbols");
extern boolean _bfd_ecoff_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_ecoff_bfd_final_link");



extern void * _bfd_ecoff_mkobject_hook (bfd *, void * filehdr, void * aouthdr) asm("__bfd_ecoff_mkobject_hook");


extern boolean _bfd_ecoff_set_arch_mach_hook (bfd *abfd, void * filehdr) asm("__bfd_ecoff_set_arch_mach_hook");
extern flagword _bfd_ecoff_styp_to_sec_flags
  (bfd *abfd, void * hdr, const char *name) asm("__bfd_ecoff_styp_to_sec_flags");
extern boolean _bfd_ecoff_slurp_symbol_table (bfd *abfd) asm("__bfd_ecoff_slurp_symbol_table");




extern void _bfd_ecoff_swap_tir_in
  (int, const struct n64_tag_tir_ext *, TIR *) asm("__bfd_ecoff_swap_tir_in");
extern void _bfd_ecoff_swap_tir_out
  (int, const TIR *, struct n64_tag_tir_ext *) asm("__bfd_ecoff_swap_tir_out");
extern void _bfd_ecoff_swap_rndx_in
  (int, const struct n64_tag_rndx_ext *, RNDXR *) asm("__bfd_ecoff_swap_rndx_in");
extern void _bfd_ecoff_swap_rndx_out
  (int, const RNDXR *, struct n64_tag_rndx_ext *) asm("__bfd_ecoff_swap_rndx_out");

typedef struct n64_tag_elf_internal_ehdr {
  unsigned char e_ident[16];
  bfd_vma e_entry;
  bfd_signed_vma e_phoff;
  bfd_signed_vma e_shoff;
  unsigned long e_version;
  unsigned long e_flags;
  unsigned short e_type;
  unsigned short e_machine;
  unsigned short e_ehsize;
  unsigned short e_phentsize;
  unsigned short e_phnum;
  unsigned short e_shentsize;
  unsigned short e_shnum;
  unsigned short e_shstrndx;
} Elf_Internal_Ehdr;
struct n64_tag_elf_internal_phdr {
  unsigned long p_type;
  unsigned long p_flags;
  bfd_vma p_offset;
  bfd_vma p_vaddr;
  bfd_vma p_paddr;
  bfd_vma p_filesz;
  bfd_vma p_memsz;
  bfd_vma p_align;
};

typedef struct n64_tag_elf_internal_phdr Elf_Internal_Phdr;







typedef struct n64_tag_elf_internal_shdr {
  unsigned int sh_name;
  unsigned int sh_type;
  bfd_vma sh_flags;
  bfd_vma sh_addr;
  bfd_size_type sh_size;
  bfd_size_type sh_entsize;
  unsigned long sh_link;
  unsigned long sh_info;
  file_ptr sh_offset;
  unsigned int sh_addralign;


  asection * bfd_section;
  void * contents;
} Elf_Internal_Shdr;
struct n64_tag_elf_internal_sym {
  bfd_vma st_value;
  bfd_vma st_size;
  unsigned long st_name;
  unsigned char st_info;
  unsigned char st_other;
  unsigned short st_shndx;
};

typedef struct n64_tag_elf_internal_sym Elf_Internal_Sym;
typedef struct n64_tag_elf_internal_note {
  unsigned long namesz;
  unsigned long descsz;
  unsigned long type;
  char name[1];
} Elf_Internal_Note;





typedef struct n64_tag_elf_internal_rel {
  bfd_vma r_offset;

  bfd_vma r_info;
} Elf_Internal_Rel;






typedef struct n64_tag_elf_internal_rela {
  bfd_vma r_offset;
  bfd_vma r_info;
  bfd_signed_vma r_addend;
} Elf_Internal_Rela;
typedef struct n64_tag_elf_internal_dyn {

  bfd_vma d_tag;
  union {

    bfd_vma d_val;
    bfd_vma d_ptr;
  } d_un;
} Elf_Internal_Dyn;
typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[4];
  unsigned char e_phoff[4];
  unsigned char e_shoff[4];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf32_External_Ehdr;

typedef struct {
  unsigned char e_ident[16];
  unsigned char e_type[2];
  unsigned char e_machine[2];
  unsigned char e_version[4];
  unsigned char e_entry[8];
  unsigned char e_phoff[8];
  unsigned char e_shoff[8];
  unsigned char e_flags[4];
  unsigned char e_ehsize[2];
  unsigned char e_phentsize[2];
  unsigned char e_phnum[2];
  unsigned char e_shentsize[2];
  unsigned char e_shnum[2];
  unsigned char e_shstrndx[2];
} Elf64_External_Ehdr;



typedef struct {
  unsigned char p_type[4];
  unsigned char p_offset[4];
  unsigned char p_vaddr[4];
  unsigned char p_paddr[4];
  unsigned char p_filesz[4];
  unsigned char p_memsz[4];
  unsigned char p_flags[4];
  unsigned char p_align[4];
} Elf32_External_Phdr;

typedef struct {
  unsigned char p_type[4];
  unsigned char p_flags[4];
  unsigned char p_offset[8];
  unsigned char p_vaddr[8];
  unsigned char p_paddr[8];
  unsigned char p_filesz[8];
  unsigned char p_memsz[8];
  unsigned char p_align[8];
} Elf64_External_Phdr;



typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[4];
  unsigned char sh_addr[4];
  unsigned char sh_offset[4];
  unsigned char sh_size[4];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[4];
  unsigned char sh_entsize[4];
} Elf32_External_Shdr;

typedef struct {
  unsigned char sh_name[4];
  unsigned char sh_type[4];
  unsigned char sh_flags[8];
  unsigned char sh_addr[8];
  unsigned char sh_offset[8];
  unsigned char sh_size[8];
  unsigned char sh_link[4];
  unsigned char sh_info[4];
  unsigned char sh_addralign[8];
  unsigned char sh_entsize[8];
} Elf64_External_Shdr;



typedef struct {
  unsigned char st_name[4];
  unsigned char st_value[4];
  unsigned char st_size[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
} Elf32_External_Sym;

typedef struct {
  unsigned char st_name[4];
  unsigned char st_info[1];
  unsigned char st_other[1];
  unsigned char st_shndx[2];
  unsigned char st_value[8];
  unsigned char st_size[8];
} Elf64_External_Sym;



typedef struct {
  unsigned char namesz[4];
  unsigned char descsz[4];
  unsigned char type[4];
  char name[1];
} Elf_External_Note;


typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
} Elf32_External_Rel;

typedef struct {
  unsigned char r_offset[4];
  unsigned char r_info[4];
  unsigned char r_addend[4];
} Elf32_External_Rela;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
} Elf64_External_Rel;

typedef struct {
  unsigned char r_offset[8];
  unsigned char r_info[8];
  unsigned char r_addend[8];
} Elf64_External_Rela;



typedef struct {
  unsigned char d_tag[4];
  union {
    unsigned char d_val[4];
    unsigned char d_ptr[4];
  } d_un;
} Elf32_External_Dyn;

typedef struct {
  unsigned char d_tag[8];
  union {
    unsigned char d_val[8];
    unsigned char d_ptr[8];
  } d_un;
} Elf64_External_Dyn;
typedef struct
{

  asymbol symbol;

  Elf_Internal_Sym internal_elf_sym;

  union
    {
      unsigned int hppa_arg_reloc;
      void * mips_extr;
      void * any;
    }
  tc_data;
} elf_symbol_type;



struct n64_tag_elf_link_hash_entry
{
  struct n64_tag_bfd_link_hash_entry root;



  long indx;


  bfd_size_type size;



  long dynindx;


  unsigned long dynstr_index;




  struct n64_tag_elf_link_hash_entry *weakdef;





  bfd_vma got_offset;






  bfd_vma plt_offset;


  char type;


  unsigned char elf_link_hash_flags;
};



struct n64_tag_elf_link_hash_table
{
  struct n64_tag_bfd_link_hash_table root;


  boolean dynamic_sections_created;



  bfd *dynobj;


  size_t dynsymcount;


  struct bfd_strtab_hash *dynstr;


  size_t bucketcount;


  struct n64_tag_bfd_link_needed_list *needed;
};
struct n64_tag_elf_size_info {
  unsigned char sizeof_ehdr, sizeof_phdr, sizeof_shdr;
  unsigned char sizeof_rel, sizeof_rela, sizeof_sym, sizeof_dyn, sizeof_note;

  unsigned char arch_size, file_align;
  unsigned char elfclass, ev_current;
  int (*write_out_phdrs) (bfd *, Elf_Internal_Phdr *, int);
  boolean (*write_shdrs_and_ehdr) (bfd *);
  void (*write_relocs) (bfd *, asection *, void *);
  void (*swap_symbol_out) (bfd *, Elf_Internal_Sym *, void *);
  boolean (*slurp_reloc_table) (bfd *, asection *, asymbol **);
  long (*slurp_symbol_table) (bfd *, asymbol **, boolean);
};







struct n64_tag_elf_backend_data
{



  int use_rela_p;


  n64_enum_bfd_architecture arch;


  int elf_machine_code;


  bfd_vma maxpagesize;





  boolean collect;



  void (*elf_info_to_howto) (bfd *, arelent *, Elf_Internal_Rela *)
                              ;



  void (*elf_info_to_howto_rel) (bfd *, arelent *, Elf_Internal_Rel *)
                          ;






  boolean (*elf_backend_sym_is_global) (bfd *, asymbol *);
  boolean (*elf_backend_object_p) (bfd *);




  void (*elf_backend_symbol_processing) (bfd *, asymbol *);



  boolean (*elf_backend_symbol_table_processing) (bfd *, elf_symbol_type *, unsigned int)

                       ;





  boolean (*elf_backend_section_processing) (bfd *, Elf_Internal_Shdr *)
                                  ;



  boolean (*elf_backend_section_from_shdr) (bfd *, Elf_Internal_Shdr *, char *)

                  ;




  boolean (*elf_backend_fake_sections) (bfd *, Elf_Internal_Shdr *, asection *)
                  ;





  boolean (*elf_backend_section_from_bfd_section)
    (bfd *, Elf_Internal_Shdr *, asection *, int *retval);
  boolean (*elf_add_symbol_hook)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, const Elf_Internal_Sym *, const char **name, flagword *flags, asection **sec, bfd_vma *value)

                                                       ;



  boolean (*elf_backend_link_output_symbol_hook)
    (bfd *, struct n64_tag_bfd_link_info *info, const char *, Elf_Internal_Sym *, asection *)
                                      ;
  boolean (*elf_backend_create_dynamic_sections)
    (bfd *abfd, struct n64_tag_bfd_link_info *info);
  boolean (*check_relocs)
    (bfd *abfd, struct n64_tag_bfd_link_info *info, asection *o, const Elf_Internal_Rela *relocs)
                                       ;
  boolean (*elf_backend_adjust_dynamic_symbol)
    (struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h);
  boolean (*elf_backend_size_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);
  boolean (*elf_backend_relocate_section)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, bfd *input_bfd, asection *input_section, bfd_byte *contents, Elf_Internal_Rela *relocs, Elf_Internal_Sym *local_syms, asection **local_sections)


                                 ;
  boolean (*elf_backend_finish_dynamic_symbol)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info, struct n64_tag_elf_link_hash_entry *h, Elf_Internal_Sym *sym)
                                                            ;





  boolean (*elf_backend_finish_dynamic_sections)
    (bfd *output_bfd, struct n64_tag_bfd_link_info *info);



  void (*elf_backend_begin_write_processing)
    (bfd *, struct n64_tag_bfd_link_info *);




  void (*elf_backend_final_write_processing)
    (bfd *, boolean linker);






  int (*elf_backend_create_program_headers)
    (bfd *, Elf_Internal_Phdr *phdrs, int phdr_count);



  const struct n64_tag_ecoff_debug_swap *elf_backend_ecoff_debug_swap;


  int elf_machine_alt1;
  int elf_machine_alt2;

  const struct n64_tag_elf_size_info *s;

  unsigned want_got_plt : 1;
  unsigned plt_readonly : 1;
  unsigned want_plt_sym : 1;


  unsigned want_hdr_in_seg : 1;
};




struct n64_tag_bfd_elf_section_data {

  Elf_Internal_Shdr this_hdr;


  Elf_Internal_Shdr rel_hdr;


  int this_idx;


  int rel_idx;


  struct n64_tag_elf_link_hash_entry **rel_hashes;



  Elf_Internal_Rela *relocs;



  long dynindx;
};
struct n64_tag_elf_obj_tdata
{
  Elf_Internal_Ehdr elf_header[1];
  Elf_Internal_Shdr **elf_sect_ptr;
  Elf_Internal_Phdr *phdr;
  struct bfd_strtab_hash *strtab_ptr;
  int num_locals;
  int num_globals;
  asymbol **section_syms;
  Elf_Internal_Shdr symtab_hdr;
  Elf_Internal_Shdr shstrtab_hdr;
  Elf_Internal_Shdr strtab_hdr;
  Elf_Internal_Shdr dynsymtab_hdr;
  Elf_Internal_Shdr dynstrtab_hdr;
  unsigned int symtab_section, shstrtab_section;
  unsigned int strtab_section, dynsymtab_section;
  file_ptr next_file_pos;
  void *prstatus;
  void *prpsinfo;
  bfd_vma gp;
  unsigned int gp_size;



  boolean linker;




  struct n64_tag_elf_link_hash_entry **sym_hashes;



  bfd_vma *local_got_offsets;





  const char *dt_needed_name;






  boolean bad_symtab;


  bfd_size_type program_header_size;





  struct mips_elf_find_line *find_line_info;


  boolean ppc_flags_init;
};
extern char * bfd_elf_string_from_elf_section (bfd *, unsigned, unsigned) asm("_bfd_elf_string_from_elf_section");
extern char * bfd_elf_get_str_section (bfd *, unsigned) asm("_bfd_elf_get_str_section");

extern void bfd_elf_print_symbol (bfd *, void *, asymbol *, bfd_print_symbol_type) asm("_bfd_elf_print_symbol")
                              ;
extern unsigned long bfd_elf_hash (const unsigned char *) asm("_bfd_elf_hash");

extern bfd_reloc_status_type bfd_elf_generic_reloc (bfd *, arelent *, asymbol *, void *, asection *, bfd *, char **) asm("_bfd_elf_generic_reloc")





                    ;
extern boolean bfd_elf_mkobject (bfd *) asm("_bfd_elf_mkobject");
extern Elf_Internal_Shdr *bfd_elf_find_section (bfd *, char *) asm("_bfd_elf_find_section");
extern boolean _bfd_elf_make_section_from_shdr
  (bfd *abfd, Elf_Internal_Shdr *hdr, const char *name) asm("__bfd_elf_make_section_from_shdr");
extern struct n64_tag_bfd_hash_entry *_bfd_elf_link_hash_newfunc
  (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *) asm("__bfd_elf_link_hash_newfunc");
extern struct n64_tag_bfd_link_hash_table *_bfd_elf_link_hash_table_create
  (bfd *) asm("__bfd_elf_link_hash_table_create");
extern boolean _bfd_elf_link_hash_table_init
  (struct n64_tag_elf_link_hash_table *, bfd *, struct n64_tag_bfd_hash_entry *(*) (struct n64_tag_bfd_hash_entry *, struct n64_tag_bfd_hash_table *, const char *)) asm("__bfd_elf_link_hash_table_init")


                          ;

extern boolean _bfd_elf_copy_private_symbol_data
  (bfd *, asymbol *, bfd *, asymbol *) asm("__bfd_elf_copy_private_symbol_data");
extern boolean _bfd_elf_copy_private_section_data
  (bfd *, asection *, bfd *, asection *) asm("__bfd_elf_copy_private_section_data");
extern boolean _bfd_elf_write_object_contents (bfd *) asm("__bfd_elf_write_object_contents");
extern boolean _bfd_elf_set_section_contents (bfd *, sec_ptr, void *, file_ptr, bfd_size_type) asm("__bfd_elf_set_section_contents")

                            ;
extern long _bfd_elf_get_symtab_upper_bound (bfd *) asm("__bfd_elf_get_symtab_upper_bound");
extern long _bfd_elf_get_symtab (bfd *, asymbol **) asm("__bfd_elf_get_symtab");
extern long _bfd_elf_get_dynamic_symtab_upper_bound (bfd *) asm("__bfd_elf_get_dynamic_symtab_upper_bound");
extern long _bfd_elf_canonicalize_dynamic_symtab (bfd *, asymbol **) asm("__bfd_elf_canonicalize_dynamic_symtab");
extern long _bfd_elf_get_reloc_upper_bound (bfd *, sec_ptr) asm("__bfd_elf_get_reloc_upper_bound");
extern long _bfd_elf_canonicalize_reloc (bfd *, sec_ptr, arelent **, asymbol **) asm("__bfd_elf_canonicalize_reloc")
                                ;
extern asymbol *_bfd_elf_make_empty_symbol (bfd *) asm("__bfd_elf_make_empty_symbol");
extern void _bfd_elf_get_symbol_info (bfd *, asymbol *, symbol_info *) asm("__bfd_elf_get_symbol_info")
                           ;
extern alent *_bfd_elf_get_lineno (bfd *, asymbol *) asm("__bfd_elf_get_lineno");
extern boolean _bfd_elf_set_arch_mach (bfd *, n64_enum_bfd_architecture, unsigned long) asm("__bfd_elf_set_arch_mach")
                     ;
extern boolean _bfd_elf_find_nearest_line (bfd *, asection *, asymbol **, bfd_vma, const char **, const char **, unsigned int *) asm("__bfd_elf_find_nearest_line")



                          ;


extern int _bfd_elf_sizeof_headers (bfd *, boolean) asm("__bfd_elf_sizeof_headers");
extern boolean _bfd_elf_new_section_hook (bfd *, asection *) asm("__bfd_elf_new_section_hook");


extern void _bfd_elf_no_info_to_howto (bfd *, arelent *, Elf_Internal_Rela *) asm("__bfd_elf_no_info_to_howto")
                                 ;

asection *bfd_section_from_elf_index (bfd *, unsigned int) asm("_bfd_section_from_elf_index");
boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
struct bfd_strtab_hash *_bfd_elf_stringtab_init (void) asm("__bfd_elf_stringtab_init");
boolean
_bfd_elf_link_record_dynamic_symbol (struct n64_tag_bfd_link_info *, struct n64_tag_elf_link_hash_entry *) asm("__bfd_elf_link_record_dynamic_symbol")
                                        ;
boolean
_bfd_elf_compute_section_file_positions (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_compute_section_file_positions")
                               ;
void _bfd_elf_assign_file_positions_for_relocs (bfd *) asm("__bfd_elf_assign_file_positions_for_relocs");
file_ptr _bfd_elf_assign_file_position_for_section (Elf_Internal_Shdr *, file_ptr, boolean) asm("__bfd_elf_assign_file_position_for_section")

                    ;

boolean _bfd_elf_create_dynamic_sections (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_dynamic_sections")
                                ;
boolean _bfd_elf_create_got_section (bfd *, struct n64_tag_bfd_link_info *) asm("__bfd_elf_create_got_section")
                                  ;

extern const bfd_target *bfd_elf32_object_p (bfd *) asm("_bfd_elf32_object_p");
extern const bfd_target *bfd_elf32_core_file_p (bfd *) asm("_bfd_elf32_core_file_p");
extern char *bfd_elf32_core_file_failing_command (bfd *) asm("_bfd_elf32_core_file_failing_command");
extern int bfd_elf32_core_file_failing_signal (bfd *) asm("_bfd_elf32_core_file_failing_signal");
extern boolean bfd_elf32_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf32_core_file_matches_executable_p")
                ;

extern boolean bfd_elf32_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_link_add_symbols");
extern boolean bfd_elf32_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_bfd_final_link");

extern void bfd_elf32_swap_symbol_in
  (bfd *, Elf32_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf32_swap_symbol_in");
extern void bfd_elf32_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf32_swap_symbol_out");
extern void bfd_elf32_swap_reloc_in
  (bfd *, Elf32_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf32_swap_reloc_in");
extern void bfd_elf32_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf32_External_Rel *) asm("_bfd_elf32_swap_reloc_out");
extern void bfd_elf32_swap_reloca_in
  (bfd *, Elf32_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf32_swap_reloca_in");
extern void bfd_elf32_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf32_External_Rela *) asm("_bfd_elf32_swap_reloca_out");
extern void bfd_elf32_swap_phdr_in
  (bfd *, Elf32_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf32_swap_phdr_in");
extern void bfd_elf32_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf32_External_Phdr *) asm("_bfd_elf32_swap_phdr_out");
extern void bfd_elf32_swap_dyn_in
  (bfd *, const Elf32_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf32_swap_dyn_in");
extern void bfd_elf32_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf32_External_Dyn *) asm("_bfd_elf32_swap_dyn_out");
extern boolean bfd_elf32_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf32_add_dynamic_entry");
extern boolean bfd_elf32_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf32_link_create_dynamic_sections");

extern const bfd_target *bfd_elf64_object_p (bfd *) asm("_bfd_elf64_object_p");
extern const bfd_target *bfd_elf64_core_file_p (bfd *) asm("_bfd_elf64_core_file_p");
extern char *bfd_elf64_core_file_failing_command (bfd *) asm("_bfd_elf64_core_file_failing_command");
extern int bfd_elf64_core_file_failing_signal (bfd *) asm("_bfd_elf64_core_file_failing_signal");
extern boolean bfd_elf64_core_file_matches_executable_p (bfd *, bfd *) asm("_bfd_elf64_core_file_matches_executable_p")
                ;
extern boolean bfd_elf64_bfd_link_add_symbols
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_link_add_symbols");
extern boolean bfd_elf64_bfd_final_link
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_bfd_final_link");

extern void bfd_elf64_swap_symbol_in
  (bfd *, Elf64_External_Sym *, Elf_Internal_Sym *) asm("_bfd_elf64_swap_symbol_in");
extern void bfd_elf64_swap_symbol_out
  (bfd *, Elf_Internal_Sym *, void *) asm("_bfd_elf64_swap_symbol_out");
extern void bfd_elf64_swap_reloc_in
  (bfd *, Elf64_External_Rel *, Elf_Internal_Rel *) asm("_bfd_elf64_swap_reloc_in");
extern void bfd_elf64_swap_reloc_out
  (bfd *, Elf_Internal_Rel *, Elf64_External_Rel *) asm("_bfd_elf64_swap_reloc_out");
extern void bfd_elf64_swap_reloca_in
  (bfd *, Elf64_External_Rela *, Elf_Internal_Rela *) asm("_bfd_elf64_swap_reloca_in");
extern void bfd_elf64_swap_reloca_out
  (bfd *, Elf_Internal_Rela *, Elf64_External_Rela *) asm("_bfd_elf64_swap_reloca_out");
extern void bfd_elf64_swap_phdr_in
  (bfd *, Elf64_External_Phdr *, Elf_Internal_Phdr *) asm("_bfd_elf64_swap_phdr_in");
extern void bfd_elf64_swap_phdr_out
  (bfd *, Elf_Internal_Phdr *, Elf64_External_Phdr *) asm("_bfd_elf64_swap_phdr_out");
extern void bfd_elf64_swap_dyn_in
  (bfd *, const Elf64_External_Dyn *, Elf_Internal_Dyn *) asm("_bfd_elf64_swap_dyn_in");
extern void bfd_elf64_swap_dyn_out
  (bfd *, const Elf_Internal_Dyn *, Elf64_External_Dyn *) asm("_bfd_elf64_swap_dyn_out");
extern boolean bfd_elf64_add_dynamic_entry
  (struct n64_tag_bfd_link_info *, bfd_vma, bfd_vma) asm("_bfd_elf64_add_dynamic_entry");
extern boolean bfd_elf64_link_create_dynamic_sections
  (bfd *, struct n64_tag_bfd_link_info *) asm("_bfd_elf64_link_create_dynamic_sections");


extern char *strerror(...) asm("_strerror");

static bfd_error_type bfd_error = bfd_error_no_error;

extern const char *const bfd_errmsgs[] = {
                        "No error",
                        "System call error",
                        "Invalid bfd target",
                        "File in wrong format",
                        "Invalid operation",
                        "Memory exhausted",
                        "No symbols",
   "Archive has no index; run ranlib to add one",
                        "No more archived files",
                        "Malformed archive",
                        "File format not recognized",
                        "File format is ambiguous",
                        "Section has no contents",
                        "Nonrepresentable section on output",
   "Symbol needs debug section which does not exist",
   "Bad value",
   "File truncated",
   "File too big",
                        "#<Invalid error code>"
                       };
bfd_error_type
bfd_get_error(void) asm("_bfd_get_error");
bfd_error_type
bfd_get_error(void)
{
  return bfd_error;
}
void
bfd_set_error(bfd_error_type error_tag) asm("_bfd_set_error");
void
bfd_set_error(bfd_error_type error_tag)
{
  bfd_error = error_tag;
}
const char *
bfd_errmsg(bfd_error_type error_tag) asm("_bfd_errmsg");
const char *
bfd_errmsg(bfd_error_type error_tag)
{



  if (error_tag == bfd_error_system_call)
    return strerror (
                    (*_errno())
                         );

  if ((((int)error_tag <(int) bfd_error_no_error) ||
       ((int)error_tag > (int)bfd_error_invalid_error_code)))
    error_tag = bfd_error_invalid_error_code;

  return bfd_errmsgs [(int)error_tag];
}
void
bfd_perror(const char *message) asm("_bfd_perror");
void
bfd_perror(const char *message)
{
  if (bfd_get_error () == bfd_error_system_call)
    perror((char *)message);
  else {
    if (message == 
                  ((void *)0) 
                       || *message == '\0')
      fprintf (
              (__acrt_iob_func(2))
                    , "%s\n", bfd_errmsg (bfd_get_error ()));
    else
      fprintf (
              (__acrt_iob_func(2))
                    , "%s: %s\n", message, bfd_errmsg (bfd_get_error ()));
  }
}
static const char *_bfd_error_program_name;





static void _bfd_default_error_handler (const char *s, ...) asm("__bfd_default_error_handler");

static void
_bfd_default_error_handler (const char *s, ...) asm("__bfd_default_error_handler");
static void
_bfd_default_error_handler (const char *s, ...)
{
  va_list p;

  if (_bfd_error_program_name != 
                                ((void *)0)
                                    )
    fprintf (
            (__acrt_iob_func(2))
                  , "%s: ", _bfd_error_program_name);

  
 __builtin_va_start(
 p
 ,
 s
 )
                ;

  vfprintf (
           (__acrt_iob_func(2))
                 , s, p);

  
 __builtin_va_end(
 p
 )
           ;

  fprintf (
          (__acrt_iob_func(2))
                , "\n");
}
bfd_error_handler_type _bfd_error_handler = _bfd_default_error_handler;
bfd_error_handler_type
bfd_set_error_handler(bfd_error_handler_type pnew) asm("_bfd_set_error_handler");
bfd_error_handler_type
bfd_set_error_handler(bfd_error_handler_type pnew)
{
  bfd_error_handler_type pold;

  pold = _bfd_error_handler;
  _bfd_error_handler = pnew;
  return pold;
}
void
bfd_set_error_program_name(const char *name) asm("_bfd_set_error_program_name");
void
bfd_set_error_program_name(const char *name)
{
  _bfd_error_program_name = name;
}
long
bfd_get_reloc_upper_bound(bfd *abfd, sec_ptr asect) asm("_bfd_get_reloc_upper_bound");
long
bfd_get_reloc_upper_bound(bfd *abfd, sec_ptr asect)
{
  if (abfd->format != bfd_object) {
    bfd_set_error (bfd_error_invalid_operation);
    return -1;
  }

  return ((*((abfd)->xvec->_get_reloc_upper_bound)) (abfd, asect));
}
long
bfd_canonicalize_reloc(bfd *abfd, sec_ptr asect, arelent **location, asymbol **symbols) asm("_bfd_canonicalize_reloc");
long
bfd_canonicalize_reloc(bfd *abfd, sec_ptr asect, arelent **location, asymbol **symbols)
{
  if (abfd->format != bfd_object) {
    bfd_set_error (bfd_error_invalid_operation);
    return -1;
  }
  return ((*((abfd)->xvec->_bfd_canonicalize_reloc)) (abfd, asect, location, symbols))
                                      ;
}
void
bfd_set_reloc(bfd *ignore_abfd, sec_ptr asect, arelent **location, unsigned int count) asm("_bfd_set_reloc");
void
bfd_set_reloc(bfd *ignore_abfd, sec_ptr asect, arelent **location, unsigned int count)
{
  asect->orelocation = location;
  asect->reloc_count = count;
}
boolean
bfd_set_file_flags(bfd *abfd, flagword flags) asm("_bfd_set_file_flags");
boolean
bfd_set_file_flags(bfd *abfd, flagword flags)
{
  if (abfd->format != bfd_object) {
    bfd_set_error (bfd_error_wrong_format);
    return cxx_false;
  }

  if (((abfd)->direction == read_direction || (abfd)->direction == both_direction)) {
    bfd_set_error (bfd_error_invalid_operation);
    return cxx_false;
  }

  ((abfd)->flags) = flags;
  if ((flags & ((abfd)->xvec->object_flags)) != flags) {
    bfd_set_error (bfd_error_invalid_operation);
    return cxx_false;
  }

return cxx_true;
}

void
bfd_assert(const char *file, int line) asm("_bfd_assert");
void
bfd_assert(const char *file, int line)
{
  (*_bfd_error_handler) ("bfd assertion fail %s:%d", file, line);
}
boolean
bfd_set_start_address(bfd *abfd, bfd_vma vma) asm("_bfd_set_start_address");
boolean
bfd_set_start_address(bfd *abfd, bfd_vma vma)
{
  abfd->start_address = vma;
  return cxx_true;
}
long
bfd_get_mtime(bfd *abfd) asm("_bfd_get_mtime");
long
bfd_get_mtime(bfd *abfd)
{
  FILE *fp;
  struct stat buf;

  if (abfd->mtime_set)
    return abfd->mtime;

  fp = ((abfd)==bfd_last_cache? (FILE*)(bfd_last_cache->iostream): bfd_cache_lookup_worker(abfd));
  if (0 != fstat (fileno (fp), &buf))
    return 0;

  abfd->mtime = buf.st_mtime;
  return buf.st_mtime;
}
long
bfd_get_size(bfd *abfd) asm("_bfd_get_size");
long
bfd_get_size(bfd *abfd)
{
  FILE *fp;
  struct stat buf;

  fp = ((abfd)==bfd_last_cache? (FILE*)(bfd_last_cache->iostream): bfd_cache_lookup_worker(abfd));
  if (0 != fstat (fileno (fp), &buf))
    return 0;

  return buf.st_size;
}
int
bfd_get_gp_size(bfd *abfd) asm("_bfd_get_gp_size");
int
bfd_get_gp_size(bfd *abfd)
{
  if (abfd->format == bfd_object)
    {
      if (abfd->xvec->flavour == bfd_target_ecoff_flavour)
 return ((abfd)->tdata.ecoff_obj_data)->gp_size;
      else if (abfd->xvec->flavour == bfd_target_elf_flavour)
 return (((abfd) -> tdata.elf_obj_data) -> gp_size);
    }
  return 0;
}
void
bfd_set_gp_size(bfd *abfd, int i) asm("_bfd_set_gp_size");
void
bfd_set_gp_size(bfd *abfd, int i)
{

  if (abfd->format != bfd_object)
    return;
  if (abfd->xvec->flavour == bfd_target_ecoff_flavour)
    ((abfd)->tdata.ecoff_obj_data)->gp_size = i;
  else if (abfd->xvec->flavour == bfd_target_elf_flavour)
    (((abfd) -> tdata.elf_obj_data) -> gp_size) = i;
}
bfd_vma
bfd_scan_vma(const char *string, const char **end, int base) asm("_bfd_scan_vma");
bfd_vma
bfd_scan_vma(const char *string, const char **end, int base)
{
  bfd_vma value;
  int digit;


  if (sizeof(bfd_vma) <= sizeof(unsigned long))
    return (bfd_vma) strtoul (string, (char **) end, base);


  if ((base < 0) || (base > 16))
    return (bfd_vma) 0;

  if (base == 0)
    {
      if (string[0] == '0')
 {
   if ((string[1] == 'x') || (string[1] == 'X'))
     base = 16;

   else
     base = 8;
 }
      else
 base = 10;
    }
  if ((base == 16) &&
      (string[0] == '0') && ((string[1] == 'x') || (string[1] == 'X')))
    string += 2;
  for (value = 0; (digit = (isxdigit(*string) ? (isdigit(*string) ? (*string - '0') : (10 + *string - (islower(*string) ? 'a' : 'A'))) : 42)) < base; string++)
    {
      value = value * base + digit;
    }

  if (end)
    *end = string;

  return value;
}
bfd_byte *
bfd_get_relocated_section_contents(bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols) asm("_bfd_get_relocated_section_contents");
bfd_byte *
bfd_get_relocated_section_contents(bfd *abfd, struct n64_tag_bfd_link_info *link_info, struct n64_tag_bfd_link_order *link_order, bfd_byte *data, boolean relocateable, asymbol **symbols)
{
  bfd *abfd2;
  bfd_byte *(*fn) (bfd *, struct n64_tag_bfd_link_info *, struct n64_tag_bfd_link_order *, bfd_byte *, boolean, asymbol **)

                  ;

  if (link_order->type == bfd_indirect_link_order)
    {
      abfd2 = link_order->u.indirect.section->owner;
      if (abfd2 == 0)
 abfd2 = abfd;
    }
  else
    abfd2 = abfd;
  fn = abfd2->xvec->_bfd_get_relocated_section_contents;

  return (*fn) (abfd, link_info, link_order, data, relocateable, symbols);
}

