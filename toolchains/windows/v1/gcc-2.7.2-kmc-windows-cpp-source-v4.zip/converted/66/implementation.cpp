// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/bc-emit.c
/* Output bytecodes for GNU C-compiler.
   Copyright (C) 1993, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag__obstack_chunk;
struct n64_tag_argtype;
struct n64_tag_arityvec;
struct n64_tag_bc_label;
struct n64_tag_bc_labelref;
struct n64_tag_bc_seg;
struct n64_tag_bc_segreloc;
struct n64_tag_bc_segsym;
struct n64_tag_bc_sym;
struct n64_tag_bytecode;
struct n64_tag_callinfo;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
union n64_tag_stacktype;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");




enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");





typedef __signed__ char QItype;
typedef unsigned char QUtype;
typedef __signed__ short int HItype;
typedef unsigned short int HUtype;
typedef __signed__ long int SItype;
typedef unsigned long int SUtype;
typedef __signed__ long long int DItype;
typedef unsigned long long int DUtype;
typedef float SFtype;
typedef double DFtype;
typedef long double XFtype;
typedef char *Ptype;
typedef int Ttype;


typedef union n64_tag_stacktype
{
  QItype QIval;
  QUtype QUval;
  HItype HIval;
  HUtype HUval;
  SItype SIval;
  SUtype SUval;
  DItype DIval;
  DUtype DUval;
  SFtype SFval;
  DFtype DFval;
  XFtype XFval;
  Ptype Pval;
  Ttype Tval;
} stacktype;




struct n64_tag_bc_sym
{

  char *name;


  unsigned int defined:1;


  unsigned int global:1;


  unsigned int common:1;


  unsigned long int val;


  struct n64_tag_bc_sym *next;
};



struct n64_tag_bc_segsym
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *next;
};



struct n64_tag_bc_segreloc
{

  unsigned int offset;


  struct n64_tag_bc_sym *sym;

  struct n64_tag_bc_segreloc *next;
};



struct n64_tag_bc_seg
{

  unsigned int alloc;


  char *data;


  unsigned int size;


  struct n64_tag_bc_segsym *syms;


  struct n64_tag_bc_segreloc *relocs;
};



struct n64_tag_bc_label
{

  unsigned int offset;


  unsigned int defined:1;



  int uid;


  struct n64_tag_bc_label *next;
};






struct n64_tag_bc_labelref
{

  struct n64_tag_bc_label *label;


  unsigned int offset;


  struct n64_tag_bc_labelref *next;
};



extern void bc_initialize(void) asm("_bc_initialize");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern void bc_emit_bytecode(...) asm("_bc_emit_bytecode");
extern void bc_emit_bytecode_const(...) asm("_bc_emit_bytecode_const");
extern struct n64_tag_bc_label *bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
extern int bc_emit_bytecode_labeldef(...) asm("_bc_emit_bytecode_labeldef");
extern void bc_emit_bytecode_labelref(...) asm("_bc_emit_bytecode_labelref");
extern void bc_emit_code_labelref(...) asm("_bc_emit_code_labelref");
extern char *bc_end_function(void) asm("_bc_end_function");
extern void bc_align_const(...) asm("_bc_align_const");
extern void bc_emit_const(...) asm("_bc_emit_const");
extern void bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern void bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern void bc_align_data(...) asm("_bc_align_data");
extern void bc_emit_data(...) asm("_bc_emit_data");
extern void bc_emit_data_skip(...) asm("_bc_emit_data_skip");
extern int bc_emit_data_labeldef(...) asm("_bc_emit_data_labeldef");
extern void bc_emit_data_labelref(...) asm("_bc_emit_data_labelref");
extern int bc_define_pointer(...) asm("_bc_define_pointer");
extern int bc_emit_common(...) asm("_bc_emit_common");
extern void bc_globalize_label(...) asm("_bc_globalize_label");
extern void bc_text(void) asm("_bc_text");
extern void bc_data(void) asm("_bc_data");
extern void bc_align(...) asm("_bc_align");
extern void bc_emit(...) asm("_bc_emit");
extern void bc_emit_skip(...) asm("_bc_emit_skip");
extern int bc_emit_labeldef(...) asm("_bc_emit_labeldef");
extern void bc_emit_labelref(...) asm("_bc_emit_labelref");
extern void bc_write_file(...) asm("_bc_write_file");



enum n64_cpp_enum_bytecode_opcode{ neverneverland,
  drop,
  duplicate,
  over,
  setstackSI,
  adjstackSI,
  constQI,
  constHI,
  constSI,
  constDI,
  constSF,
  constDF,
  constXF,
  constP,
  loadQI,
  loadHI,
  loadSI,
  loadDI,
  loadSF,
  loadDF,
  loadXF,
  loadP,
  storeQI,
  storeHI,
  storeSI,
  storeDI,
  storeSF,
  storeDF,
  storeXF,
  storeP,
  storeBLK,
  clearBLK,
  addconstPSI,
  newlocalSI,
  localP,
  argP,
  convertQIHI,
  convertHISI,
  convertSIDI,
  convertQISI,
  convertQUHU,
  convertHUSU,
  convertSUDU,
  convertQUSU,
  convertSFDF,
  convertDFXF,
  convertHIQI,
  convertSIHI,
  convertDISI,
  convertSIQI,
  convertSUQU,
  convertDFSF,
  convertXFDF,
  convertSISF,
  convertSIDF,
  convertSIXF,
  convertSUSF,
  convertSUDF,
  convertSUXF,
  convertDISF,
  convertDIDF,
  convertDIXF,
  convertDUSF,
  convertDUDF,
  convertDUXF,
  convertSFSI,
  convertDFSI,
  convertXFSI,
  convertSFSU,
  convertDFSU,
  convertXFSU,
  convertSFDI,
  convertDFDI,
  convertXFDI,
  convertSFDU,
  convertDFDU,
  convertXFDU,
  convertPSI,
  convertSIP,
  convertSIT,
  convertDIT,
  convertSFT,
  convertDFT,
  convertXFT,
  convertPT,
  zxloadBI,
  sxloadBI,
  sstoreBI,
  addSI,
  addDI,
  addSF,
  addDF,
  addXF,
  addPSI,
  subSI,
  subDI,
  subSF,
  subDF,
  subXF,
  subPP,
  mulSI,
  mulDI,
  mulSU,
  mulDU,
  mulSF,
  mulDF,
  mulXF,
  divSI,
  divDI,
  divSU,
  divDU,
  divSF,
  divDF,
  divXF,
  modSI,
  modDI,
  modSU,
  modDU,
  andSI,
  andDI,
  iorSI,
  iorDI,
  xorSI,
  xorDI,
  lshiftSI,
  lshiftSU,
  lshiftDI,
  lshiftDU,
  rshiftSI,
  rshiftSU,
  rshiftDI,
  rshiftDU,
  ltSI,
  ltSU,
  ltDI,
  ltDU,
  ltSF,
  ltDF,
  ltXF,
  ltP,
  leSI,
  leSU,
  leDI,
  leDU,
  leSF,
  leDF,
  leXF,
  leP,
  geSI,
  geSU,
  geDI,
  geDU,
  geSF,
  geDF,
  geXF,
  geP,
  gtSI,
  gtSU,
  gtDI,
  gtDU,
  gtSF,
  gtDF,
  gtXF,
  gtP,
  eqSI,
  eqDI,
  eqSF,
  eqDF,
  eqXF,
  eqP,
  neSI,
  neDI,
  neSF,
  neDF,
  neXF,
  neP,
  negSI,
  negDI,
  negSF,
  negDF,
  negXF,
  notSI,
  notDI,
  notT,
  predecQI,
  predecHI,
  predecSI,
  predecDI,
  predecP,
  predecSF,
  predecDF,
  predecXF,
  predecBI,
  preincQI,
  preincHI,
  preincSI,
  preincDI,
  preincP,
  preincSF,
  preincDF,
  preincXF,
  preincBI,
  postdecQI,
  postdecHI,
  postdecSI,
  postdecDI,
  postdecP,
  postdecSF,
  postdecDF,
  postdecXF,
  postdecBI,
  postincQI,
  postincHI,
  postincSI,
  postincDI,
  postincP,
  postincSF,
  postincDF,
  postincXF,
  postincBI,
  xjumpif,
  xjumpifnot,
  jump,
  jumpP,
  caseSI,
  caseSU,
  caseDI,
  caseDU,
  call,
  returnP,
  ret,
  linenote,
  LAST_AND_UNUSED_OPCODE
};
typedef __underlying_type(enum n64_cpp_enum_bytecode_opcode) n64_enum_bytecode_opcode;

enum n64_cpp_enum_typecode{

QIcode,
QUcode,
HIcode,
HUcode,
SIcode,
SUcode,
DIcode,
DUcode,
SFcode,
DFcode,
XFcode,
Pcode,
Tcode,


  LAST_AND_UNUSED_TYPECODE
};
typedef __underlying_type(enum n64_cpp_enum_typecode) n64_enum_typecode;

struct n64_tag_arityvec
{
  char ninputs;
  char noutputs;
  char nliterals;
  char literals[5];
};

struct n64_tag_argtype
{
  int modealign;
  int size;
};

struct n64_tag_callinfo
{
  int nargs;
  struct n64_tag_argtype retvaltype;
  struct n64_tag_argtype argtypes[1];
};



struct n64_tag_bytecode
{
  int stacksize;
  int localsize;
  unsigned char *pc0;
  void **ptrlit;
  struct n64_tag_callinfo *callinfo;
};



extern char *xmalloc (...) asm("_xmalloc"), *xrealloc (...) asm("_xrealloc");
extern void free(...) asm("_free");

extern struct n64_tag_obstack *rtl_obstack;



extern n64_enum_machine_mode class_narrowest_mode[(int) MAX_MODE_CLASS];



extern n64_enum_machine_mode byte_mode;


extern n64_enum_machine_mode word_mode;


static struct n64_tag_arityvec arityvec[] = {
{ 0, 0, 0, {0}},
{ 1, 0, 0, {0}},
{ 1, 2, 0, {0}},
{ 1, 2, 0, {0}},
{ 0, 0, 1, {(char) SIcode, }},
{ 0, 0, 1, {(char) SIcode, }},
{ 0, 1, 1, {(char) QIcode, }},
{ 0, 1, 1, {(char) HIcode, }},
{ 0, 1, 1, {(char) SIcode, }},
{ 0, 1, 1, {(char) DIcode, }},
{ 0, 1, 1, {(char) SFcode, }},
{ 0, 1, 1, {(char) DFcode, }},
{ 0, 1, 1, {(char) XFcode, }},
{ 0, 1, 1, {(char) Pcode, }},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 3, 0, 0, {0}},
{ 2, 0, 0, {0}},
{ 1, 1, 1, {(char) SIcode, }},
{ 1, 1, 0, {0}},
{ 0, 1, 1, {(char) SIcode, }},
{ 0, 1, 1, {(char) SIcode, }},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 3, 1, 0, {0}},
{ 3, 1, 0, {0}},
{ 4, 0, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 1, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 4, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 4, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 4, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 2, 1, 0, {0}},
{ 4, 1, 0, {0}},
{ 1, 0, 1, {(char) SIcode, }},
{ 1, 0, 1, {(char) SIcode, }},
{ 0, 0, 1, {(char) SIcode, }},
{ 0, 0, 0, {0}},
{ 1, 0, 3, {(char) SIcode, (char) SIcode, (char) SIcode, }},
{ 1, 0, 3, {(char) SIcode, (char) SIcode, (char) SIcode, }},
{ 1, 0, 3, {(char) SIcode, (char) SIcode, (char) SIcode, }},
{ 1, 0, 3, {(char) SIcode, (char) SIcode, (char) SIcode, }},
{ 3, 0, 0, {0}},
{ 0, 1, 0, {0}},
{ 0, 0, 0, {0}},
{ 0, 0, 1, {(char) SIcode, }},
};


static void
prsym(FILE *file, char *s) asm("_prsym");
static void
prsym(FILE *file, char *s)
{
  if (*s == '*')
    fprintf (file, "%s", s + 1);
  else


    fprintf (file, "_%s", s);




}






static struct n64_tag_bc_sym *hashtab[509];

static unsigned int
hash(char *name) asm("_hash");
static unsigned int
hash(char *name)
{
  unsigned int hash = 0;

  while (*name)
    {
      hash = hash << 3 | hash >> 32 - 3;
      hash += *name++;
    }

  return hash % 509;
}



struct n64_tag_bc_sym *
sym_lookup(char *name) asm("_sym_lookup");
struct n64_tag_bc_sym *
sym_lookup(char *name)
{
  int i;
  struct n64_tag_bc_sym *s;

  i = hash (name);
  for (s = hashtab[i]; s; s = s->next)
    if (!strcmp (s->name, name))
      return s;

  s = (struct n64_tag_bc_sym *) xmalloc (sizeof (struct n64_tag_bc_sym));
  s->name = xmalloc (strlen (name) + 1);
  strcpy (s->name, name);
  s->defined = s->global = s->common = 0;
  s->val = 0;
  s->next = hashtab[i];
  hashtab[i] = s;
  return s;
}



static void
bc_sym_write(FILE *file) asm("_bc_sym_write");
static void
bc_sym_write(FILE *file)
{
  int i;
  struct n64_tag_bc_sym *s;

  for (i = 0; i < 509; ++i)
    for (s = hashtab[i]; s; s = s->next)
      {
 if (s->global)
   {
     fprintf (file, "\n\t.globl ");
     prsym (file, s->name);
     putc ('\n', file);
     if (s->common)
       {
  fprintf (file, "\n\t.comm ");
  prsym (file, s->name);
  fprintf (file, ", %lu\n", s->val);
       }
   }
 else if (s->common)
   {
     fprintf (file, "\n\t.lcomm ");
     prsym (file, s->name);
     fprintf (file, ", %lu\n", s->val);
   }
      }
}





static struct n64_tag_bc_seg *
seg_create(void) asm("_seg_create");
static struct n64_tag_bc_seg *
seg_create(void)
{
  struct n64_tag_bc_seg *result;

  result = (struct n64_tag_bc_seg *) xmalloc (sizeof (struct n64_tag_bc_seg));
  result->alloc = 256;
  result->data = xmalloc (result->alloc);
  result->size = 0;
  result->syms = 0;
  result->relocs = 0;
  return result;
}



static void
seg_align(struct n64_tag_bc_seg *seg, int log) asm("_seg_align");
static void
seg_align(struct n64_tag_bc_seg *seg, int log)
{
  unsigned int oldsize = seg->size;

  seg->size = seg->size + (1 << log) - 1 & ~((1 << log) - 1);
  if (seg->size > seg->alloc)
    {
      while (seg->size > seg->alloc)
 seg->alloc *= 2;
      seg->data = xrealloc (seg->data, seg->alloc);
    }
  memset (seg->data + oldsize,0,seg->size - oldsize);
}



static void
seg_data(struct n64_tag_bc_seg *seg, char *data, unsigned int size) asm("_seg_data");
static void
seg_data(struct n64_tag_bc_seg *seg, char *data, unsigned int size)
{
  if (seg->size + size > seg->alloc)
    {
      while (seg->size + size > seg->alloc)
 seg->alloc *= 2;
      seg->data = xrealloc (seg->data, seg->alloc);
    }

  memcpy (seg->data + seg->size,data,size);
  seg->size += size;
}



static void
seg_skip(struct n64_tag_bc_seg *seg, unsigned int size) asm("_seg_skip");
static void
seg_skip(struct n64_tag_bc_seg *seg, unsigned int size)
{
  if (seg->size + size > seg->alloc)
    {
      while (seg->size + size > seg->alloc)
 seg->alloc *= 2;
      seg->data = xrealloc (seg->data, seg->alloc);
    }

  memset (seg->data + seg->size, 0, size);
  seg->size += size;
}





static int
seg_defsym(struct n64_tag_bc_seg *seg, char *name) asm("_seg_defsym");
static int
seg_defsym(struct n64_tag_bc_seg *seg, char *name)
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *segsym;

  sym = sym_lookup (name);
  if (sym->defined)
    return 0;

  sym->defined = 1;
  sym->val = seg->size;
  segsym = (struct n64_tag_bc_segsym *) xmalloc (sizeof (struct n64_tag_bc_segsym));
  segsym->sym = sym;
  segsym->next = seg->syms;
  seg->syms = segsym;
  return 1;
}




static void
seg_refsym(struct n64_tag_bc_seg *seg, char *name, int offset) asm("_seg_refsym");
static void
seg_refsym(struct n64_tag_bc_seg *seg, char *name, int offset)
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segreloc *segreloc;

  sym = sym_lookup (name);
  segreloc = (struct n64_tag_bc_segreloc *) xmalloc (sizeof (struct n64_tag_bc_segreloc));
  segreloc->offset = seg->size;
  segreloc->sym = sym;
  segreloc->next = seg->relocs;
  seg->relocs = segreloc;
  seg_data (seg, (char *) &offset, sizeof offset);
}



static void
seg_concat(struct n64_tag_bc_seg *result, struct n64_tag_bc_seg *seg) asm("_seg_concat");
static void
seg_concat(struct n64_tag_bc_seg *result, struct n64_tag_bc_seg *seg)
{
  unsigned int fix;
  struct n64_tag_bc_segsym *segsym;
  struct n64_tag_bc_segreloc *segreloc;

  seg_align (result, 1);
  fix = result->size;
  seg_data (result, seg->data, seg->size);
  free (seg->data);



  if (seg->syms)
    {
      segsym = seg->syms;
      do
 segsym->sym->val += fix;
      while (segsym->next && (segsym = segsym->next));
      segsym->next = result->syms;
      result->syms = seg->syms;
    }
  if (seg->relocs)
    {
      segreloc = seg->relocs;
      do
 segreloc->offset += fix;
      while (segreloc->next && (segreloc = segreloc->next));
      segreloc->next = result->relocs;
      result->relocs = seg->relocs;
    }

  free ((char *) seg);
}


static void
bc_seg_write(struct n64_tag_bc_seg *seg, FILE *file) asm("_bc_seg_write");
static void
bc_seg_write(struct n64_tag_bc_seg *seg, FILE *file)
{
  struct n64_tag_bc_segsym *segsym, *nsegsym, *psegsym;
  struct n64_tag_bc_segreloc *segreloc, *nsegreloc, *psegreloc;
  int i, offset, flag;


  for (psegsym = 0, segsym = seg->syms; segsym; segsym = nsegsym)
    {
      nsegsym = segsym->next;
      segsym->next = psegsym;
      psegsym = segsym;
    }
  seg->syms = psegsym;


  for (psegreloc = 0, segreloc = seg->relocs; segreloc; segreloc = nsegreloc)
    {
      nsegreloc = segreloc->next;
      segreloc->next = psegreloc;
      psegreloc = segreloc;
    }
  seg->relocs = psegreloc;


  for (i = 0, segsym = seg->syms, segreloc = seg->relocs; i < seg->size; ++i)
    {
      while (segsym && segsym->sym->val == i)
 {
   if (i % 8 != 0)
     putc ('\n', file);

   (0);
   segsym = segsym->next;
   flag = 1;
 }
      if (segreloc && segreloc->offset == i)
 {
   if (i % 8 != 0)
     putc ('\n', file);

   memcpy ((char *) &offset,seg->data + i,sizeof (int));
   i += sizeof (int) - 1;

   (0);
   segreloc = segreloc->next;
   flag = 1;
 }
      else
 {
   if (i % 8 == 0 || flag)
     (0);

   (0)

             ;
   flag = 0;
   if (i % 8 == 7)
     putc ('\n', file);
 }
    }




  if (segsym || segreloc)
    abort ();
}




static struct n64_tag_bc_seg *bc_text_seg;
static struct n64_tag_bc_seg *bc_data_seg;


void
bc_initialize(void) asm("_bc_initialize");
void
bc_initialize(void)
{
  int min_class_size[(int) MAX_MODE_CLASS];
  n64_enum_machine_mode mode;
  int i;

  bc_init_mode_to_code_map ();

  bc_text_seg = seg_create ();
  bc_data_seg = seg_create ();

  dconst0 = ereal_atof ("0", DFmode);
  dconst1 = ereal_atof ("1", DFmode);
  dconst2 = ereal_atof ("2", DFmode);
  dconstm1 = ereal_atof ("-1", DFmode);




  for (i = 0; i < (int) MAX_MODE_CLASS; i++)
    min_class_size[i] = 1000;

  for (mode = VOIDmode; (int) mode < (int) MAX_MACHINE_MODE;
       mode = (n64_enum_machine_mode) ((int) mode + 1))
    {
      if ((mode_size[(int)(mode)]) < min_class_size[(int) (mode_class[(int)(mode)])])
 {
   class_narrowest_mode[(int) (mode_class[(int)(mode)])] = mode;
   min_class_size[(int) (mode_class[(int)(mode)])] = (mode_size[(int)(mode)]);
 }
      if ((mode_class[(int)(mode)]) == MODE_INT
   && (8 * mode_size[(int)(mode)]) == 8)
 byte_mode = mode;

      if ((mode_class[(int)(mode)]) == MODE_INT
   && (8 * mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 64 : 32))
 word_mode = mode;
    }
}
static struct n64_tag_bc_seg *ptrconsts;


struct n64_tag_bc_seg *trampoline;


struct n64_tag_bc_seg *bytecode;


struct n64_tag_bc_label *labels;


struct n64_tag_bc_labelref *labelrefs;





int
bc_define_pointer(char *p) asm("_bc_define_pointer");
int
bc_define_pointer(char *p)
{
  int offset = ptrconsts->size;

  seg_refsym (ptrconsts, p, 0);
  return offset;
}



int
bc_begin_function(char *name) asm("_bc_begin_function");
int
bc_begin_function(char *name)
{
  ptrconsts = seg_create ();
  trampoline = seg_create ();
  bytecode = seg_create ();
  return seg_defsym (trampoline, name);
}



void
bc_align_bytecode(int align) asm("_bc_align_bytecode");
void
bc_align_bytecode(int align)
{
  seg_align (bytecode, align);
}



void
bc_emit_bytecode_const(char *data, unsigned int size) asm("_bc_emit_bytecode_const");
void
bc_emit_bytecode_const(char *data, unsigned int size)
{
  if (bytecode)
    seg_data (bytecode, data, size);
}





struct n64_tag_bc_label *
bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
struct n64_tag_bc_label *
bc_get_bytecode_label(void)
{
  struct n64_tag_bc_label *result;

  result = (struct n64_tag_bc_label *) xmalloc (sizeof (struct n64_tag_bc_label));
  result->defined = 0;
  result->next = labels;
  result->uid = 0;
  labels = result;
  return result;
}



int
bc_emit_bytecode_labeldef(struct n64_tag_bc_label *label) asm("_bc_emit_bytecode_labeldef");
int
bc_emit_bytecode_labeldef(struct n64_tag_bc_label *label)
{
  extern int bc_new_uid(...) asm("_bc_new_uid");

  if (!label || label->defined)
    return 0;

  label->offset = bytecode->size;
  label->defined = 1;
  label->uid = bc_new_uid ();





  return 1;
}




void
bc_emit_bytecode_labelref(struct n64_tag_bc_label *label) asm("_bc_emit_bytecode_labelref");
void
bc_emit_bytecode_labelref(struct n64_tag_bc_label *label)
{
  struct n64_tag_bc_labelref *labelref;
  static int zero;

  labelref = (struct n64_tag_bc_labelref *) xmalloc (sizeof (struct n64_tag_bc_labelref));
  labelref->label = label;
  labelref->offset = bytecode->size;
  labelref->next = labelrefs;
  labelrefs = labelref;





  seg_data (bytecode, (char *) &zero, sizeof zero);
}




void
bc_emit_code_labelref(char *name, int offset) asm("_bc_emit_code_labelref");
void
bc_emit_code_labelref(char *name, int offset)
{
  int ptroff;

  ptroff = ptrconsts->size / sizeof (char *);
  seg_data (bytecode, (char *) &ptroff, sizeof ptroff);
  seg_refsym (ptrconsts, name, offset);




}





char *
bc_end_function(void) asm("_bc_end_function");
char *
bc_end_function(void)
{
  int addr;
  struct n64_tag_bc_label *label, *next;
  struct n64_tag_bc_labelref *ref, *nextref;
  char ptrconsts_label[20];
  static int nlab;


  for (ref = labelrefs; ref; ref = ref->next)
    if (ref->label->defined)
      {
 addr = ref->label->offset;
 memcpy (bytecode->data + ref->offset,(char *) &addr,sizeof addr);
      }


  for (ref = labelrefs; ref; ref = nextref)
    {
      nextref = ref->next;
      free ((char *) ref);
    }

  for (label = labels; label; label = next)
    {
      next = label->next;
      free ((char *) label);
    }

  seg_concat (trampoline, bytecode);
  seg_align (trampoline, 1);
  sprintf (ptrconsts_label, "*LP%d", nlab++);
  seg_defsym (trampoline, ptrconsts_label);
  seg_concat (trampoline, ptrconsts);
  seg_concat (bc_text_seg, trampoline);

  labels = 0;
  labelrefs = 0;
  trampoline = 0;
  bytecode = 0;
  ptrconsts = 0;

  return sym_lookup (ptrconsts_label)->name;
}


void
bc_align_const(int align) asm("_bc_align_const");
void
bc_align_const(int align)
{
  seg_align (bc_text_seg, align);
}


void
bc_emit_const(char *data, unsigned int size) asm("_bc_emit_const");
void
bc_emit_const(char *data, unsigned int size)
{
  seg_data (bc_text_seg, data, size);
}


void
bc_emit_const_skip(unsigned int size) asm("_bc_emit_const_skip");
void
bc_emit_const_skip(unsigned int size)
{
  seg_skip (bc_text_seg, size);
}


int
bc_emit_const_labeldef(char *name) asm("_bc_emit_const_labeldef");
int
bc_emit_const_labeldef(char *name)
{
  return seg_defsym (bc_text_seg, name);
}


void
bc_emit_const_labelref(char *name, int offset) asm("_bc_emit_const_labelref");
void
bc_emit_const_labelref(char *name, int offset)
{
  seg_refsym (bc_text_seg, name, offset);
}


void
bc_align_data(int align) asm("_bc_align_data");
void
bc_align_data(int align)
{
  seg_align (bc_data_seg, align);
}


void
bc_emit_data(char *data, unsigned int size) asm("_bc_emit_data");
void
bc_emit_data(char *data, unsigned int size)
{
  seg_data (bc_data_seg, data, size);
}


void
bc_emit_data_skip(unsigned int size) asm("_bc_emit_data_skip");
void
bc_emit_data_skip(unsigned int size)
{
  seg_skip (bc_data_seg, size);
}


int
bc_emit_data_labeldef(char *name) asm("_bc_emit_data_labeldef");
int
bc_emit_data_labeldef(char *name)
{
  return seg_defsym (bc_data_seg, name);
}


void
bc_emit_data_labelref(char *name, int offset) asm("_bc_emit_data_labelref");
void
bc_emit_data_labelref(char *name, int offset)
{
  seg_refsym (bc_data_seg, name, offset);
}




int
bc_emit_common(char *name, unsigned int size) asm("_bc_emit_common");
int
bc_emit_common(char *name, unsigned int size)
{
  struct n64_tag_bc_sym *sym;

  sym = sym_lookup (name);
  if (sym->defined)
    return 0;

  sym->defined = 1;
  sym->common = 1;
  sym->val = size;
  return 1;
}


void
bc_globalize_label(char *name) asm("_bc_globalize_label");
void
bc_globalize_label(char *name)
{
  struct n64_tag_bc_sym *sym;

  sym = sym_lookup (name);
  sym->global = 1;
}

enum n64_cpp_enum_anonymous_12{ in_text, in_data };
typedef __underlying_type(enum n64_cpp_enum_anonymous_12) n64_enum_anonymous_12;
static n64_enum_anonymous_12 section = in_text;

void
bc_text(void) asm("_bc_text");
void
bc_text(void)
{
  section = in_text;
}

void
bc_data(void) asm("_bc_data");
void
bc_data(void)
{
  section = in_data;
}

void
bc_align(int align) asm("_bc_align");
void
bc_align(int align)
{
  if (section == in_text)
    bc_align_const (align);
  else
    bc_align_data (align);
}

void
bc_emit(char *data, unsigned int size) asm("_bc_emit");
void
bc_emit(char *data, unsigned int size)
{
  if (section == in_text)
    bc_emit_const (data, size);
  else
    bc_emit_data (data, size);
}

void
bc_emit_skip(unsigned int size) asm("_bc_emit_skip");
void
bc_emit_skip(unsigned int size)
{
  if (section == in_text)
    bc_emit_const_skip (size);
  else
    bc_emit_data_skip (size);
}

int
bc_emit_labeldef(char *name) asm("_bc_emit_labeldef");
int
bc_emit_labeldef(char *name)
{
  if (section == in_text)
    return bc_emit_const_labeldef (name);
  else
    return bc_emit_data_labeldef (name);
}

void
bc_emit_labelref(char *name, int offset) asm("_bc_emit_labelref");
void
bc_emit_labelref(char *name, int offset)
{
  if (section == in_text)
    bc_emit_const_labelref (name, offset);
  else
    bc_emit_data_labelref (name, offset);
}

void
bc_write_file(FILE *file) asm("_bc_write_file");
void
bc_write_file(FILE *file)
{
  (0);
}





rtx
bc_gen_rtx(char *label, int offset, struct n64_tag_bc_label *bc_label) asm("_bc_gen_rtx");
rtx
bc_gen_rtx(char *label, int offset, struct n64_tag_bc_label *bc_label)
{
  rtx r;

  if (bc_label == 0)
    bc_label = (struct n64_tag_bc_label *) xmalloc (sizeof (struct n64_tag_bc_label));

  r = gen_rtx (CODE_LABEL, VOIDmode, label, bc_label);
  bc_label->offset = offset;

  return r;
}



void
bc_print_rtl(FILE *fp, rtx r) asm("_bc_print_rtl");
void
bc_print_rtl(FILE *fp, rtx r)
{





}



void
bc_emit_bytecode(n64_enum_bytecode_opcode bytecode) asm("_bc_emit_bytecode");
void
bc_emit_bytecode(n64_enum_bytecode_opcode bytecode)
{
  char byte;
  static int prev_lineno = -1;

  byte = (char) bytecode;
  bc_emit_bytecode_const (&byte, 1);

  if ((stack_depth -= arityvec[(int) bytecode].ninputs) >= 0)
    {
      if ((stack_depth += arityvec[(int) bytecode].noutputs) > max_stack_depth)
 max_stack_depth = stack_depth;
    }




}
void
bc_emit_instruction (n64_enum_bytecode_opcode opcode, ...) asm("_bc_emit_instruction");
void
bc_emit_instruction (n64_enum_bytecode_opcode opcode, ...)
{



  va_list arguments;
  int nliteral, instruction;

  
 __builtin_va_start(
 arguments
 ,
 opcode
 )
                             ;






  bc_emit_bytecode (opcode);
  instruction = (int) opcode;


  for (nliteral = 0; nliteral < arityvec[instruction].nliterals; nliteral++)
    {
      switch (arityvec[instruction].literals[nliteral])
 {
case QIcode: { SItype temp = 
__builtin_va_arg(
arguments
,
SItype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case QUcode: { SUtype temp = 
__builtin_va_arg(
arguments
,
SUtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case HIcode: { SItype temp = 
__builtin_va_arg(
arguments
,
SItype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case HUcode: { SUtype temp = 
__builtin_va_arg(
arguments
,
SUtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case SIcode: { SItype temp = 
__builtin_va_arg(
arguments
,
SItype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case SUcode: { SUtype temp = 
__builtin_va_arg(
arguments
,
SUtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case DIcode: { DItype temp = 
__builtin_va_arg(
arguments
,
DItype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case DUcode: { DUtype temp = 
__builtin_va_arg(
arguments
,
DUtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case SFcode: { SFtype temp = 
__builtin_va_arg(
arguments
,
SFtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case DFcode: { DFtype temp = 
__builtin_va_arg(
arguments
,
DFtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case XFcode: { XFtype temp = 
__builtin_va_arg(
arguments
,
XFtype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case Pcode: { Ptype temp = 
__builtin_va_arg(
arguments
,
Ptype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;
case Tcode: { SItype temp = 
__builtin_va_arg(
arguments
,
SItype
)
; bc_emit_bytecode_const ((void *) &temp, sizeof temp); ; } break;




 default:
   abort ();
 }
    }




}





char *
bc_emit_trampoline(char *callinfo) asm("_bc_emit_trampoline");
char *
bc_emit_trampoline(char *callinfo)
{
  char mylab[20];
  static int n;

  sprintf (mylab, "*LB%d", n++);

  (0);

  seg_defsym (bytecode, mylab);
  return sym_lookup (mylab)->name;
}



char *
bc_xstrdup(char *str) asm("_bc_xstrdup");
char *
bc_xstrdup(char *str)
{
  char *tmp = xmalloc (strlen (str) + 1);

  strcpy (tmp, str);
  return tmp;
}

