// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/init.c
/* Handle initialization things in C++.
   Copyright (C) 1987, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Contributed by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int warning(...) asm("_warning");
extern int expand_cleanups_to(...) asm("_expand_cleanups_to");
extern int do_pending_stack_adjust(...) asm("_do_pending_stack_adjust");
extern int start_sequence_for_rtl_expr(...) asm("_start_sequence_for_rtl_expr");
extern int error(...) asm("_error");
extern int compiler_error(...) asm("_compiler_error");
extern int expand_assignment(...) asm("_expand_assignment");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int fatal(...) asm("_fatal");
extern int sorry(...) asm("_sorry");
extern int pedwarn(...) asm("_pedwarn");
extern int error_with_file_and_line(...) asm("_error_with_file_and_line");
extern int signature_error(...) asm("_signature_error");
extern int use_variable(...) asm("_use_variable");
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line(...) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function(...) asm("_final_start_function");




extern void final_end_function(...) asm("_final_end_function");


extern void final(...) asm("_final");




extern rtx final_scan_insn(...) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const(...) asm("_output_addr_const");



extern void asm_fprintf (...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name(...) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
tree current_base_init_list, current_member_init_list;

void emit_base_init(...) asm("_emit_base_init");
void check_base_init(...) asm("_check_base_init");
static void expand_aggr_vbase_init(...) asm("_expand_aggr_vbase_init");
void expand_member_init(...) asm("_expand_member_init");
void expand_aggr_init(...) asm("_expand_aggr_init");

static void expand_aggr_init_1(...) asm("_expand_aggr_init_1");
static void expand_recursive_init_1(...) asm("_expand_recursive_init_1");
static void expand_recursive_init(...) asm("_expand_recursive_init");
static void expand_virtual_init (tree, tree) asm("_expand_virtual_init");
tree expand_vec_init(...) asm("_expand_vec_init");

static void add_friend (...) asm("_add_friend"), add_friends (...) asm("_add_friends");


static tree BIN, BID, BIVN, BIVD;


static tree nc_nelts_field_id;




static tree minus_one;




tree BI_header_type, BI_header_size;

void init_init_processing(void) asm("_init_init_processing");
void init_init_processing(void)
{
  tree fields[1];


  BIN = default_conversion (get_first_fn ((((struct n64_tag_lang_identifier *)(ansi_opname[(int) NEW_EXPR]))->global_value)));
  ((((BIN)->exp.operands[0]))->common.used_flag) = 0;
  BID = default_conversion (get_first_fn ((((struct n64_tag_lang_identifier *)(ansi_opname[(int) DELETE_EXPR]))->global_value)));
  ((((BID)->exp.operands[0]))->common.used_flag) = 0;
  BIVN = default_conversion (get_first_fn ((((struct n64_tag_lang_identifier *)(ansi_opname[(int) VEC_NEW_EXPR]))->global_value)));
  ((((BIVN)->exp.operands[0]))->common.used_flag) = 0;
  BIVD = default_conversion (get_first_fn ((((struct n64_tag_lang_identifier *)(ansi_opname[(int) VEC_DELETE_EXPR]))->global_value)));
  ((((BIVD)->exp.operands[0]))->common.used_flag) = 0;
  minus_one = build_int_2_wide ((int) (-1), (int) (-1));



  BI_header_type = make_lang_type (RECORD_TYPE);
  nc_nelts_field_id = get_identifier ("nelts");
  fields[0] = build_lang_field_decl (FIELD_DECL, nc_nelts_field_id, sizetype);
  finish_builtin_type (BI_header_type, "__new_cookie", fields,
         0, double_type_node);
  BI_header_size = size_in_bytes (BI_header_type);
}
void
expand_direct_vtbls_init(tree real_binfo, tree binfo, int init_self, int can_elide, tree addr) asm("_expand_direct_vtbls_init");
void
expand_direct_vtbls_init(tree real_binfo, tree binfo, int init_self, int can_elide, tree addr)
{
  tree real_binfos = (((real_binfo))->vec.a[4]);
  tree binfos = (((binfo))->vec.a[4]);
  int i, n_baselinks = real_binfos ? ((real_binfos)->vec.length) : 0;

  for (i = 0; i < n_baselinks; i++)
    {
      tree real_base_binfo = ((real_binfos)->vec.a[i]);
      tree base_binfo = ((binfos)->vec.a[i]);
      int is_not_base_vtable =
 i != (((((real_binfo)->common.type))->type.lang_specific)->vfield_parent);
      if (! ((real_base_binfo)->common.static_flag))
 expand_direct_vtbls_init (real_base_binfo, base_binfo,
      is_not_base_vtable, can_elide, addr);
    }






  if (init_self && (((((real_binfo)->common.type))->type.lang_specific)->vfields))
    {
      tree base_ptr = convert_pointer_to_real (binfo, addr);
      expand_virtual_init (real_binfo, base_ptr);
    }
}



static void
perform_member_init(tree member, tree name, tree init, int cxx_explicit, tree *protect_list) asm("_perform_member_init");
static void
perform_member_init(tree member, tree name, tree init, int cxx_explicit, tree *protect_list)
{
  tree decl;
  tree type = ((member)->common.type);

  if (((type)->type.needs_constructing_flag)
      || (init && (((type)->type.lang_flag_1))))
    {


      if (init != (tree) 0 && ((n64_enum_tree_code) (init)->common.code) != TREE_LIST)
 init = build_tree_list ((tree) 0, init);

      decl = build_component_ref (C_C_D, name, 0, cxx_explicit);

      if (cxx_explicit
   && ((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE
   && init != (tree) 0
   && ((init)->common.chain) == (tree) 0
   && ((n64_enum_tree_code) (((((init)->list.value))->common.type))->common.code) == ARRAY_TYPE)
 {

   expand_vec_init (((decl)->exp.operands[1]), decl,
      array_type_nelts (type), ((init)->list.value), 1);
 }
      else
 expand_aggr_init (decl, init, 0, 0);
    }
  else
    {
      if (init == (tree) 0)
 {
   if (cxx_explicit)
     {
       cp_error ("incomplete initializer for member `%D' of class `%T' which has no constructor",
   member, current_class_type);
       init = error_mark_node;
     }

   else if (((n64_enum_tree_code) (((member)->common.type))->common.code) == REFERENCE_TYPE)
     cp_pedwarn ("uninitialized reference member `%D'", member);
 }
      else if (((n64_enum_tree_code) (init)->common.code) == TREE_LIST)
 {


   if (((init)->common.chain))
     {
       warning ("initializer list treated as compound expression");
       init = build_compound_expr (init);
     }
   else
     init = ((init)->list.value);
 }



      if (init || cxx_explicit)
 {
   decl = build_component_ref (C_C_D, name, 0, cxx_explicit);
   expand_expr_stmt (build_modify_expr (decl, INIT_EXPR, init));
 }
    }
  expand_cleanups_to ((tree) 0);

  if ((((type)->type.lang_flag_4)))
    {
      tree expr = build_component_ref (C_C_D, name, 0, cxx_explicit);
      expr = build_delete (type, expr, integer_zero_node,
      (8)|(512), 0);

      if (expr != error_mark_node)
 {
   start_protect ();
   *protect_list = tree_cons ((tree) 0, expr, *protect_list);
 }
    }
}

extern int warn_reorder;


static tree
sort_member_init(tree t) asm("_sort_member_init");
static tree
sort_member_init(tree t)
{
  tree x, member, name, field, init;
  tree init_list = (tree) 0;
  tree fields_to_unmark = (tree) 0;
  int last_pos = 0;
  tree last_field;

  for (member = ((t)->type.values); member ; member = ((member)->common.chain))
    {
      int pos;




      if (((n64_enum_tree_code) (member)->common.code) != FIELD_DECL || !((member)->decl.name))
 continue;

      for (x = current_member_init_list, pos = 0; x; x = ((x)->common.chain), ++pos)
 {

   if (((x)->list.purpose) == (tree) 0)
     continue;
   name = ((x)->list.purpose);






   my_friendly_assert (((n64_enum_tree_code) (name)->common.code) != COMPONENT_REF, 348);
   field = (((struct n64_tag_lang_identifier *)(name))->class_value);



   if (((n64_enum_tree_code) (field)->common.code) == TREE_LIST)
     field = ((field)->list.value);

   if (field == member)
     {
       if (warn_reorder)
  {
    if (pos < last_pos)
      {
        cp_warning_at ("member initializers for `%#D'", last_field);
        cp_warning_at ("  and `%#D'", field);
        warning ("  will be re-ordered to match declaration order");
      }
    last_pos = pos;
    last_field = field;
  }


       ((x)->list.purpose) = (tree) 0;
       x = build_tree_list (name, ((x)->list.value));
       goto got_it;
     }
 }




      x = build_tree_list ((tree) 0, (tree) 0);
    got_it:
      init_list = chainon (init_list, x);
    }


  for (x = current_member_init_list ; x ; x = ((x)->common.chain))
    {
      name = ((x)->list.purpose);
      if (name)
 {
   if (purpose_member (name, init_list))
     {
       cp_error ("multiple initializations given for member `%D'",
   (((struct n64_tag_lang_identifier *)(name))->class_value));
       continue;
     }

   init_list = chainon (init_list,
          build_tree_list (name, ((x)->list.value)));
   ((x)->list.purpose) = (tree) 0;
 }
    }

  return init_list;
}

static void
sort_base_init(tree t, tree *rbase_ptr, tree *vbase_ptr) asm("_sort_base_init");
static void
sort_base_init(tree t, tree *rbase_ptr, tree *vbase_ptr)
{
  tree binfos = (((((t)->type.binfo)))->vec.a[4]);
  int n_baseclasses = binfos ? ((binfos)->vec.length) : 0;

  int i;
  tree x;
  tree last;


  int last_pos = 0;
  tree last_base = (tree) 0;

  tree rbases = (tree) 0;
  tree vbases = (tree) 0;




  last = tree_cons ((tree) 0, (tree) 0, current_base_init_list);
  for (x = ((last)->common.chain); x; x = ((x)->common.chain))
    {
      tree basename = ((x)->list.purpose);
      tree binfo;

      if (basename == (tree) 0)
 {


   switch (n_baseclasses)
     {
     case 0:
       cp_error ("`%T' does not have a base class to initialize",
   current_class_type);
       return;
     case 1:
       break;
     default:
       cp_error ("unnamed initializer ambiguous for `%T' which uses multiple inheritance",
   current_class_type);
       return;
     }
   binfo = ((binfos)->vec.a[0]);
 }
      else if (is_aggr_typedef (basename, 1))
 {
   binfo = binfo_or_else ((((basename)->common.type)), t);
   if (binfo == (tree) 0)
     continue;




   if (((binfo)->common.static_flag))
     {
       tree v = (((t)->type.lang_specific)->vbases);
       while (((v)->common.type) != ((binfo)->common.type))
  v = ((v)->common.chain);

       vbases = tree_cons (v, ((x)->list.value), vbases);
       continue;
     }
   else
     {

       for (i = n_baseclasses-1; i >= 0; i--)
  if (((binfo)->common.type) == ((((binfos)->vec.a[i]))->common.type))
    break;
       if (i < 0)
  {
    cp_error ("`%T' is not an immediate base class of `%T'",
       (((basename)->common.type)),
       current_class_type);
    continue;
  }
     }
 }
      else
 my_friendly_abort (365);

      ((x)->list.purpose) = binfo;
      ((last)->common.chain) = x;
      last = x;
    }
  ((last)->common.chain) = (tree) 0;



  for (i = 0; i < n_baseclasses; ++i)
    {
      tree base_binfo = ((binfos)->vec.a[i]);
      int pos;

      if (((base_binfo)->common.static_flag))
 continue;

      for (x = current_base_init_list, pos = 0; x; x = ((x)->common.chain), ++pos)
 {
   tree binfo = ((x)->list.purpose);

   if (binfo == (tree) 0)
     continue;

   if (binfo == base_binfo)
     {
       if (warn_reorder)
  {
    if (pos < last_pos)
      {
        cp_warning_at ("base initializers for `%#T'", last_base);
        cp_warning_at ("  and `%#T'", ((binfo)->common.type));
        warning ("  will be re-ordered to match inheritance order");
      }
    last_pos = pos;
    last_base = ((binfo)->common.type);
  }


       ((x)->list.purpose) = (tree) 0;
       x = build_tree_list (binfo, ((x)->list.value));
       goto got_it;
     }
 }




      x = build_tree_list ((tree) 0, (tree) 0);
    got_it:
      rbases = chainon (rbases, x);
    }

  *rbase_ptr = rbases;
  *vbase_ptr = vbases;
}


static tree
build_partial_cleanup_for(tree binfo) asm("_build_partial_cleanup_for");
static tree
build_partial_cleanup_for(tree binfo)
{
  tree expr = convert_pointer_to_real (binfo,
           build_unary_op (ADDR_EXPR, C_C_D, 0));

  return build_delete (((expr)->common.type),
         expr,
         integer_zero_node,
         (8)|(512), 0);
}
extern tree base_init_expr, rtl_expr_chain;

void
emit_base_init(tree t, int immediately) asm("_emit_base_init");
void
emit_base_init(tree t, int immediately)
{
  extern tree in_charge_identifier;

  tree member, x;
  tree mem_init_list;
  tree rbase_init_list, vbase_init_list;
  tree t_binfo = ((t)->type.binfo);
  tree binfos = (((t_binfo))->vec.a[4]);
  int i, n_baseclasses = binfos ? ((binfos)->vec.length) : 0;
  tree expr = (tree) 0;

  my_friendly_assert (protect_list == (tree) 0, 999);

  if (! immediately)
    {
      int momentary;
      do_pending_stack_adjust ();


      momentary = suspend_momentary ();
      expr = make_node (RTL_EXPR);
      resume_momentary (momentary);
      start_sequence_for_rtl_expr (expr);
    }

  if (write_symbols == NO_DEBUG)

    emit_note (0, -1);
  else

    emit_line_note_force (((current_function_decl)->decl.filename),
     ((current_function_decl)->decl.linenum));

  mem_init_list = sort_member_init (t);
  current_member_init_list = (tree) 0;

  sort_base_init (t, &rbase_init_list, &vbase_init_list);
  current_base_init_list = (tree) 0;

  if ((((t)->common.lang_flag_3)))
    {
      tree first_arg = ((((current_function_decl)->decl.arguments))->common.chain);

      expand_start_cond (first_arg, 0);
      expand_aggr_vbase_init (t_binfo, C_C_D, current_class_decl,
         vbase_init_list);
      expand_end_cond ();
    }


  for (i = 0; i < n_baseclasses; i++)
    {
      tree base = current_class_decl;
      tree base_binfo = ((binfos)->vec.a[i]);
      tree init = void_list_node;

      if (((base_binfo)->common.static_flag))
 continue;




      (((base_binfo))->vec.a[0]) = t_binfo;


      if (((rbase_init_list)->list.purpose))
 init = ((rbase_init_list)->list.value);
      else if (((((base_binfo)->common.type))->type.needs_constructing_flag))
 init = (tree) 0;

      if (init != void_list_node)
 {
   member = convert_pointer_to_real (base_binfo, current_class_decl);
   expand_aggr_init_1 (base_binfo, 0,
         build_indirect_ref (member, ((void *)0)), init,
         ((((base_binfo))->vec.a[1]) == integer_zero_node), (3));
   expand_cleanups_to ((tree) 0);
 }

      if ((((((base_binfo)->common.type))->type.lang_flag_4)))
 {
   start_protect ();
   protect_list = tree_cons ((tree) 0,
        build_partial_cleanup_for (base_binfo),
        protect_list);
 }

      rbase_init_list = ((rbase_init_list)->common.chain);
    }



  if ((((t)->common.lang_flag_3)))
    expand_indirect_vtbls_init (t_binfo, C_C_D, current_class_decl, 0);



  expand_direct_vtbls_init (t_binfo, t_binfo, 1, 1, current_class_decl);

  for (member = ((t)->type.values); member; member = ((member)->common.chain))
    {
      tree init, name;
      int from_init_list;




      if (((n64_enum_tree_code) (member)->common.code) != FIELD_DECL || !((member)->decl.name))
 continue;


      if (((mem_init_list)->list.purpose))
 {
   name = ((mem_init_list)->list.purpose);
   init = ((mem_init_list)->list.value);
   from_init_list = 1;




   my_friendly_assert (((n64_enum_tree_code) (name)->common.code) != COMPONENT_REF, 349);
 }
      else
 {
   name = ((member)->decl.name);
   init = ((member)->decl.initial);

   from_init_list = 0;
 }

      perform_member_init (member, name, init, from_init_list, &protect_list);
      mem_init_list = ((mem_init_list)->common.chain);
    }


  while (mem_init_list)
    {
      tree name, init, field;

      if (((mem_init_list)->list.purpose))
 {
   name = ((mem_init_list)->list.purpose);
   init = ((mem_init_list)->list.value);


   field = (((struct n64_tag_lang_identifier *)(name))->class_value);


   if (((n64_enum_tree_code) (field)->common.code) == TREE_LIST)
     {
       field = ((field)->list.value);
       if (decl_type_context (field) != current_class_type)
  cp_error ("field `%D' not in immediate context", field);
     }
   perform_member_init (field, name, init, 1, &protect_list);
 }
      mem_init_list = ((mem_init_list)->common.chain);
    }

  if (! immediately)
    {
      do_pending_stack_adjust ();
      my_friendly_assert (base_init_expr == 0, 207);
      base_init_expr = expr;
      ((expr)->common.type) = void_type_node;
      (*(struct n64_tag_rtx_def **) &(expr)->exp.operands[1]) = const0_rtx;
      (*(struct n64_tag_rtx_def **) &(expr)->exp.operands[0]) = get_insns ();
      rtl_expr_chain = tree_cons ((tree) 0, expr, rtl_expr_chain);
      end_sequence ();
      ((expr)->common.side_effects_flag) = 1;
    }



}



void
check_base_init(tree t) asm("_check_base_init");
void
check_base_init(tree t)
{
  tree member;
  for (member = ((t)->type.values); member; member = ((member)->common.chain))
    if (((member)->decl.name) && ((member)->common.used_flag))
      cp_error ("field `%D' used before initialized (after assignment to `this')",
  member);
}






static void
expand_virtual_init(tree binfo, tree decl) asm("_expand_virtual_init");
static void
expand_virtual_init(tree binfo, tree decl)
{
  tree type = ((binfo)->common.type);
  tree vtbl, vtbl_ptr;
  tree vtype, vtype_binfo;




  vtype = ((((type)->type.minval))->decl.context);
  vtype_binfo = get_binfo (vtype, ((((decl)->common.type))->common.type), 0);
  vtbl = (((binfo_value (((((type)->type.minval))->decl.context), binfo)))->vec.a[2]);
  assemble_external (vtbl);
  ((vtbl)->common.used_flag) = 1;
  vtbl = build1 (ADDR_EXPR, build_pointer_type (((vtbl)->common.type)), vtbl);
  decl = convert_pointer_to_real (vtype_binfo, decl);
  vtbl_ptr = build_vfield_ref (build_indirect_ref (decl, ((void *)0)), vtype);
  if (vtbl_ptr == error_mark_node)
    return;


  vtbl = convert_force (((vtbl_ptr)->common.type), vtbl, 0);
  expand_expr_stmt (build_modify_expr (vtbl_ptr, NOP_EXPR, vtbl));
}




static void
expand_aggr_vbase_init_1(tree binfo, tree exp, tree addr, tree init_list) asm("_expand_aggr_vbase_init_1");
static void
expand_aggr_vbase_init_1(tree binfo, tree exp, tree addr, tree init_list)
{
  tree init = purpose_member (binfo, init_list);
  tree ref = build_indirect_ref (addr, ((void *)0));
  if (init)
    init = ((init)->list.value);

  expand_aggr_init_1 (binfo, exp, ref, init, 0, (2));
  expand_cleanups_to ((tree) 0);
}





static void
expand_aggr_vbase_init(tree binfo, tree exp, tree addr, tree init_list) asm("_expand_aggr_vbase_init");
static void
expand_aggr_vbase_init(tree binfo, tree exp, tree addr, tree init_list)
{
  tree type = ((binfo)->common.type);

  if ((((type)->common.lang_flag_3)))
    {
      tree result = init_vbase_pointers (type, addr);
      tree vbases;

      if (result)
 expand_expr_stmt (build_compound_expr (result));

      for (vbases = (((type)->type.lang_specific)->vbases); vbases;
    vbases = ((vbases)->common.chain))
 {
   tree tmp = purpose_member (vbases, result);
   expand_aggr_vbase_init_1 (vbases, exp,
        ((((tmp)->list.value))->exp.operands[0]),
        init_list);
 }
    }
}





void
do_member_init(tree s_id, tree name, tree init) asm("_do_member_init");
void
do_member_init(tree s_id, tree name, tree init)
{
  tree binfo, base;

  if (current_class_type == (tree) 0
      || ! is_aggr_typedef (s_id, 1))
    return;
  binfo = get_binfo ((((s_id)->common.type)),
     current_class_type, 1);
  if (binfo == error_mark_node)
    return;
  if (binfo == 0)
    {
      error_not_base_type ((((s_id)->common.type)), current_class_type);
      return;
    }

  base = convert_pointer_to (binfo, current_class_decl);
  expand_member_init (build_indirect_ref (base, ((void *)0)), name, init);
}
static int
member_init_ok_or_else(tree field, tree type, char *member_name) asm("_member_init_ok_or_else");
static int
member_init_ok_or_else(tree field, tree type, char *member_name)
{
  if (field == error_mark_node)
    return 0;
  if (field == (tree) 0)
    {
      cp_error ("class `%T' does not have any field named `%s'", type,
  member_name);
      return 0;
    }
  if (((field)->decl.context) != type
      && ((((field)->decl.context))->type.needs_constructing_flag))
    {
      if (current_function_decl && (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
 cp_error ("initialization of `%D' inside constructor for `%T'",
    field, type);
      else
 cp_error ("member `%D' comes from base class needing constructor",
    field);
      return 0;
    }
  if (((field)->common.static_flag))
    {
      cp_error ("field `%#D' is static; only point of initialization is its declaration",
  field);
      return 0;
    }

  return 1;
}
void
expand_member_init(tree exp, tree name, tree init) asm("_expand_member_init");
void
expand_member_init(tree exp, tree name, tree init)
{
  extern tree ptr_type_node;

  tree basetype = (tree) 0, field;
  tree parm;
  tree rval, type;
  tree actual_name;

  if (exp == (tree) 0)
    return;

  type = ((((exp)->common.type))->type.main_variant);

  if (name == (tree) 0 && (((type)->type.lang_flag_5)))
    switch ((((((type)->type.binfo))->vec.a[4]) ? ((((((type)->type.binfo))->vec.a[4]))->vec.length) : 0))
      {
      case 0:
 error ("base class initializer specified, but no base class to initialize");
 return;
      case 1:
 basetype = (((((((((type)->type.binfo)))->vec.a[4]))->vec.a[(0)]))->common.type);
 break;
      default:
 error ("initializer for unnamed base class ambiguous");
 cp_error ("(type `%T' uses multiple inheritance)", type);
 return;
      }

  if (init)
    {







      if (init == void_type_node)
 init = (tree) 0;

      if (name == (tree) 0 || (((name)->common.type) ? 1 : 0))
 {
   tree base_init;

   if (name == (tree) 0)
     {
     }
   else
     {
       basetype = (((name)->common.type));
       if (basetype != type
    && ! binfo_member (basetype, ((type)->type.binfo))
    && ! binfo_member (basetype, (((type)->type.lang_specific)->vbases)))
  {
    if ((((struct n64_tag_lang_identifier *)(name))->class_value))
      goto try_member;
    if ((((type)->common.lang_flag_3)))
      error ("type `%s' is not an immediate or virtual basetype for `%s'",
      ((name)->identifier.pointer),
      ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
    else
      error ("type `%s' is not an immediate basetype for `%s'",
      ((name)->identifier.pointer),
      ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
    return;
  }
     }

   if (purpose_member (name, current_base_init_list))
     {
       error ("base class `%s' already initialized",
       ((name)->identifier.pointer));
       return;
     }

   base_init = build_tree_list (name, init);
   ((base_init)->common.type) = basetype;
   current_base_init_list = chainon (current_base_init_list, base_init);
 }
      else
 {
   tree member_init;

 try_member:
   field = lookup_field (type, name, 1, 0);

   if (! member_init_ok_or_else (field, type, ((name)->identifier.pointer)))
     return;

   if (purpose_member (name, current_member_init_list))
     {
       error ("field `%s' already initialized", ((name)->identifier.pointer));
       return;
     }

   member_init = build_tree_list (name, init);
   ((member_init)->common.type) = ((field)->common.type);
   current_member_init_list = chainon (current_member_init_list, member_init);
 }
      return;
    }
  else if (name == (tree) 0)
    {
      compiler_error ("expand_member_init: name == NULL_TREE");
      return;
    }

  basetype = type;
  field = lookup_field (basetype, name, 0, 0);

  if (! member_init_ok_or_else (field, basetype, ((name)->identifier.pointer)))
    return;




  if ((((((field)->common.type))->type.lang_flag_1)))
    {
      tree parmtypes, fndecl;

      if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL || ((n64_enum_tree_code) (exp)->common.code) == PARM_DECL)
 {

   ((exp)->decl.initial) = error_mark_node;
   ((exp)->common.used_flag) = 1;
 }
      type = ((((field)->common.type))->type.main_variant);
      actual_name = (((((type)->type.name))->decl.name));
      parm = build_component_ref (exp, name, 0, 0);


      fndecl = ((((type)->type.maxval))->vec.a[0]);

      if ((((type)->type.lang_flag_2)))
 fndecl = (((fndecl)->decl.lang_specific)->chain);

      if (fndecl)
 my_friendly_assert (((n64_enum_tree_code) (fndecl)->common.code) == FUNCTION_DECL, 209);



      if ((((fndecl)->decl.lang_specific)->chain) == (tree) 0)
 {




   my_friendly_abort (48);
   parmtypes = (((((((fndecl)->common.type))->type.values))->common.chain));
 }
      else
 {
   parmtypes = (tree) 0;
   fndecl = (tree) 0;
 }

      init = convert_arguments (parm, parmtypes, (tree) 0, fndecl, (3));
      if (init == (tree) 0 || ((init)->common.type) != error_mark_node)
 rval = build_method_call ((tree) 0, actual_name, init, (tree) 0, (3));
      else
 return;

      if (rval != error_mark_node)
 {

   ((((rval)->exp.operands[1]))->list.value)
     = build_unary_op (ADDR_EXPR, parm, 0);
   ((rval)->common.type) = ptr_type_node;
   ((rval)->common.side_effects_flag) = 1;
 }
    }
  else if (((((field)->common.type))->type.needs_constructing_flag))
    {
      parm = build_component_ref (exp, name, 0, 0);
      expand_aggr_init (parm, (tree) 0, 0, 0);
      rval = error_mark_node;
    }



  if (rval != error_mark_node)
    expand_expr_stmt (rval);
}
void
expand_aggr_init(tree exp, tree init, int alias_this, int flags) asm("_expand_aggr_init");
void
expand_aggr_init(tree exp, tree init, int alias_this, int flags)
{
  tree type = ((exp)->common.type);
  int was_const = ((exp)->common.readonly_flag);
  int was_volatile = ((exp)->common.volatile_flag);

  if (init == error_mark_node)
    return;

  ((exp)->common.readonly_flag) = 0;
  ((exp)->common.volatile_flag) = 0;

  if (init && ((n64_enum_tree_code) (init)->common.code) != TREE_LIST)
    flags |= (128);

  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {


      tree itype = init ? ((init)->common.type) : (tree) 0;
      if (((((type)->common.type))->common.readonly_flag) || ((((type)->common.type))->common.volatile_flag))
 {
   ((exp)->common.type) = ((type)->type.main_variant);
   if (init)
     ((init)->common.type) = ((itype)->type.main_variant);
 }
      if (init && ((init)->common.type) == (tree) 0)
 {
   error ("bad array initializer");
   return;
 }
      expand_vec_init (exp, exp, array_type_nelts (type), init,
         init && comptypes (((init)->common.type), ((exp)->common.type), 1));
      ((exp)->common.readonly_flag) = was_const;
      ((exp)->common.volatile_flag) = was_volatile;
      ((exp)->common.type) = type;
      if (init)
 ((init)->common.type) = itype;
      return;
    }

  if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL || ((n64_enum_tree_code) (exp)->common.code) == PARM_DECL)

    ((exp)->common.used_flag) = 1;
  ((exp)->common.type) = ((type)->type.main_variant);
  expand_aggr_init_1 (((type)->type.binfo), exp, exp,
        init, alias_this, (3)|flags);
  ((exp)->common.type) = type;
  ((exp)->common.readonly_flag) = was_const;
  ((exp)->common.volatile_flag) = was_volatile;
}

static void
expand_default_init(tree binfo, tree true_exp, tree exp, tree type, tree init, int alias_this, int flags) asm("_expand_default_init");
static void
expand_default_init(tree binfo, tree true_exp, tree exp, tree type, tree init, int alias_this, int flags)
{






  tree rval;
  tree parms;

  if (init == (tree) 0
      || (((n64_enum_tree_code) (init)->common.code) == TREE_LIST && ! ((init)->common.type)))
    {
      parms = init;
      if (parms)
 init = ((parms)->list.value);
    }
  else if (((n64_enum_tree_code) (init)->common.code) == INDIRECT_REF && (((init)->common.lang_flag_4))
    && ((type)->type.main_variant) == ((((init)->common.type))->type.main_variant))
    {
      rval = convert_for_initialization (exp, type, init, 0, 0, 0, 0);
      ((rval)->common.used_flag) = 1;
      expand_expr_stmt (rval);
      return;
    }
  else
    parms = build_tree_list ((tree) 0, init);

  if ((((type)->common.lang_flag_3)))
    {
      if (true_exp == exp)
 parms = tree_cons ((tree) 0, integer_one_node, parms);
      else
 parms = tree_cons ((tree) 0, integer_zero_node, parms);
      flags |= (32);
    }

  if (init && ((parms)->common.chain) == (tree) 0
      && ((((type)->type.lang_specific)->type_flags.has_init_ref) && ! (((type)->type.lang_specific)->type_flags.has_complex_init_ref))
      && ((type)->type.main_variant) == ((((init)->common.type))->type.main_variant))
    {
      rval = build (INIT_EXPR, type, exp, init);
      ((rval)->common.side_effects_flag) = 1;
      expand_expr_stmt (rval);
    }
  else
    {
      if (flags & (128))
 flags |= (512);
      rval = build_method_call (exp, constructor_name_full (type),
    parms, binfo, flags);


      if (rval == error_mark_node)
 {
   if (flags & (2))
     cp_error ("in base initialization for %sclass `%T'",
        ((binfo)->common.static_flag) ? "virtual base " : "",
        binfo);
 }
      else if (rval == (tree) 0)
 my_friendly_abort (361);
      else
 {


   if ((flag_this_is_variable & 1) && alias_this)
     {
       ((rval)->common.type) = ((current_class_decl)->common.type);
       expand_assignment (current_class_decl, rval, 0, 0);
     }
   else
     expand_expr_stmt (rval);
 }
    }
}
static void
expand_aggr_init_1(tree binfo, tree true_exp, tree exp, tree init, int alias_this, int flags) asm("_expand_aggr_init_1");
static void
expand_aggr_init_1(tree binfo, tree true_exp, tree exp, tree init, int alias_this, int flags)
{
  tree type = ((exp)->common.type);
  tree init_type = (tree) 0;

  my_friendly_assert (init != error_mark_node && type != error_mark_node, 211);






  if (init)
    {
      tree init_list = (tree) 0;

      if (((n64_enum_tree_code) (init)->common.code) == TREE_LIST)
 {
   init_list = init;
   if (((init)->common.chain) == (tree) 0)
     init = ((init)->list.value);
 }

      init_type = ((init)->common.type);

      if (((n64_enum_tree_code) (init)->common.code) != TREE_LIST)
 {
   if (((n64_enum_tree_code) (init_type)->common.code) == ERROR_MARK)
     return;
   if (((n64_enum_tree_code) (init)->common.code) == TARGET_EXPR)
     {
       if (((init_type)->type.main_variant) == ((type)->type.main_variant))
  {
    if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL
        || ((n64_enum_tree_code) (exp)->common.code) == RESULT_DECL)

      ((((init)->exp.operands[0]))->decl.rtl) = ((exp)->decl.rtl);
    else
      ((((init)->exp.operands[0]))->decl.rtl) = expand_expr (exp, (rtx) 0, 0, 0);

    expand_expr_stmt (init);
    return;
  }
       else
  {
    init = ((init)->exp.operands[1]);
    init = build (CALL_EXPR, init_type,
    ((init)->exp.operands[0]), ((init)->exp.operands[1]), 0);
    ((init)->common.side_effects_flag) = 1;
      if (init_list)
        ((init_list)->list.value) = init;
  }
     }

   if (init_type == type && ((n64_enum_tree_code) (init)->common.code) == CALL_EXPR





       )
     {







       expand_assignment (exp, init, 0, 0);
       if (exp == ((current_function_decl)->decl.result))
  {


    my_friendly_assert (((exp)->decl.initial) == (tree) 0
          || ((exp)->decl.initial) == error_mark_node,
          212);
    ((exp)->decl.initial) = init;
  }
       return;
     }
   else if (init_type == type
     && ((n64_enum_tree_code) (init)->common.code) == COND_EXPR)
     {



       ((init)->exp.operands[1])
  = build_modify_expr (exp, INIT_EXPR, ((init)->exp.operands[1]));
       if (exp == ((current_function_decl)->decl.result))
  ((exp)->decl.initial) = (tree) 0;
       ((init)->exp.operands[2])
  = build_modify_expr (exp, INIT_EXPR, ((init)->exp.operands[2]));
       if (exp == ((current_function_decl)->decl.result))
  ((exp)->decl.initial) = init;
       ((init)->common.side_effects_flag) = 1;
       expand_expr (init, const0_rtx, VOIDmode, 0);
       free_temp_slots ();
       return;
     }
 }


      if (((n64_enum_tree_code) (init)->common.code) == TARGET_EXPR)
 {
   tree tmp = ((((init)->exp.operands[1]))->exp.operands[1]);

   if (((n64_enum_tree_code) (((tmp)->list.value))->common.code) == NOP_EXPR
       && ((((tmp)->list.value))->exp.operands[0]) == integer_zero_node)
     {



       tree arg = build_unary_op (ADDR_EXPR, exp, 0);
       init = ((init)->exp.operands[1]);
       init = build (CALL_EXPR, build_pointer_type (((init)->common.type)),
       ((init)->exp.operands[0]), ((init)->exp.operands[1]), 0);
       ((init)->common.side_effects_flag) = 1;
       ((((init)->exp.operands[1]))->list.value)
  = convert_pointer_to (((((((tmp)->list.value))->common.type))->common.type), arg);

       if (alias_this)
  {
    expand_assignment (current_function_decl, init, 0, 0);
    return;
  }
       if (exp == ((current_function_decl)->decl.result))
  {
    if (((((current_function_decl)->decl.result))->decl.initial))
      fatal ("return value from function receives multiple initializations");
    ((exp)->decl.initial) = init;
  }
       expand_expr_stmt (init);
       return;
     }
 }

      if (((n64_enum_tree_code) (exp)->common.code) == VAR_DECL
   && ((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR
   && (((init)->common.lang_flag_4)))
 {
   tree t = store_init_value (exp, init);
   if (!t)
     {
       expand_decl_init (exp);
       return;
     }
   t = build (INIT_EXPR, type, exp, init);
   ((t)->common.side_effects_flag) = 1;
   expand_expr_stmt (t);
   return;
 }






      if (! ((type)->type.needs_constructing_flag) && ! (((type)->type.lang_flag_5)))
 {
   if (init_list && ((init_list)->common.chain))
     {
       warning ("initializer list being treated as compound expression");
       init = convert (type, build_compound_expr (init_list));
       if (init == error_mark_node)
  return;
     }

   expand_assignment (exp, init, 0, 0);

   return;
 }



      if (((n64_enum_tree_code) (init)->common.code) != TREE_LIST)
 {
   tree ttype = ((n64_enum_tree_code) (init_type)->common.code) == REFERENCE_TYPE
     ? ((init_type)->common.type) : init_type;

   if (ttype != type && (((ttype)->type.lang_flag_5)))
     {
       tree rval = build_type_conversion (CONVERT_EXPR, type, init, 0);

       if (rval)
  {


    tree parms = build_tree_list ((tree) 0, init);
    tree as_cons = (tree) 0;
    if ((((type)->type.lang_flag_1)))
      as_cons = build_method_call (exp, constructor_name_full (type),
       parms, binfo,
       (64)|(512));
    if (as_cons != (tree) 0 && as_cons != error_mark_node)

      cp_error ("ambiguity between conversion to `%T' and constructor",
         type);
    else
      expand_assignment (exp, rval, 0, 0);
    return;
  }
     }
 }
    }



  if (type == init_type && (((type)->type.lang_flag_5))
      && init && ((n64_enum_tree_code) (init)->common.code) != TREE_LIST)
    expand_default_init (binfo, true_exp, exp, type, init, alias_this, flags);

  else if ((((type)->type.lang_flag_1)))
    expand_default_init (binfo, true_exp, exp, type, init, alias_this, flags);
  else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
      if (((((type)->common.type))->type.needs_constructing_flag))
 expand_vec_init (exp, exp, array_type_nelts (type), init, 0);
      else if ((((((type)->common.type))->common.lang_flag_2)))
 sorry ("arrays of objects with virtual functions but no constructors");
    }
  else
    expand_recursive_init (binfo, true_exp, exp, init,
      (((type)->type.lang_specific)->base_init_list), alias_this);
}



static tree *init_ptr, init_null;






static void
expand_recursive_init_1(tree binfo, tree true_exp, tree addr, tree init_list, int alias_this) asm("_expand_recursive_init_1");
static void
expand_recursive_init_1(tree binfo, tree true_exp, tree addr, tree init_list, int alias_this)
{
  while (init_list)
    {
      if (((init_list)->list.purpose))
 {
   if (((n64_enum_tree_code) (((init_list)->list.purpose))->common.code) == FIELD_DECL)
     {
       tree member = ((init_list)->list.purpose);
       tree subexp = build_indirect_ref (convert_pointer_to (((init_list)->list.value), addr), ((void *)0));
       tree member_base = build (COMPONENT_REF, ((member)->common.type), subexp, member);
       if ((((((member)->common.type))->type.lang_flag_5)))
  expand_aggr_init (member_base, ((member)->decl.initial), 0, 0);
       else if (((n64_enum_tree_code) (((member)->common.type))->common.code) == ARRAY_TYPE
         && ((((member)->common.type))->type.needs_constructing_flag))
  {
    member_base = save_expr (default_conversion (member_base));
    expand_vec_init (member, member_base,
       array_type_nelts (((member)->common.type)),
       ((member)->decl.initial), 0);
  }
       else
  expand_expr_stmt (build_modify_expr (member_base, INIT_EXPR, ((member)->decl.initial)));
     }
   else if (((n64_enum_tree_code) (((init_list)->list.purpose))->common.code) == TREE_LIST)
     {
       expand_recursive_init_1 (binfo, true_exp, addr, ((init_list)->list.purpose), alias_this);
       expand_recursive_init_1 (binfo, true_exp, addr, ((init_list)->list.value), alias_this);
     }
   else if (((n64_enum_tree_code) (((init_list)->list.purpose))->common.code) == ERROR_MARK)
     {


       if (((init_list)->list.value))
  {





    expand_virtual_init (get_binfo (((init_list)->list.value), binfo, 0),
          addr);
    if (((init_list)->list.value) == binfo
        && (((((binfo)->common.type))->common.lang_flag_3)))
      expand_indirect_vtbls_init (binfo, true_exp, addr, 1);
  }
     }
   else
     my_friendly_abort (49);
 }
      else if (((init_list)->list.value)
        && ((n64_enum_tree_code) (((init_list)->list.value))->common.code) == TREE_VEC)
 {
   tree subexp = build_indirect_ref (convert_pointer_to (((init_list)->list.value), addr), ((void *)0));
   expand_aggr_init_1 (binfo, true_exp, subexp, *init_ptr,
         alias_this && ((((((init_list)->list.value)))->vec.a[1]) == integer_zero_node),
         (2));


   init_ptr = &init_null;
 }
      else
 my_friendly_abort (50);
      init_list = ((init_list)->common.chain);
    }
}
static void
expand_recursive_init(tree binfo, tree true_exp, tree exp, tree init, tree init_list, int alias_this) asm("_expand_recursive_init");
static void
expand_recursive_init(tree binfo, tree true_exp, tree exp, tree init, tree init_list, int alias_this)
{
  tree *old_init_ptr = init_ptr;
  tree addr = build_unary_op (ADDR_EXPR, exp, 0);
  init_ptr = &init;

  if (true_exp == exp && (((((binfo)->common.type))->common.lang_flag_3)))
    {
      expand_aggr_vbase_init (binfo, exp, addr, init_list);
      expand_indirect_vtbls_init (binfo, true_exp, addr, 1);
    }
  expand_recursive_init_1 (binfo, true_exp, addr, init_list, alias_this);

  if (*init_ptr)
    {
      tree type = ((exp)->common.type);

      if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
 type = ((type)->common.type);
      if ((((type)->type.lang_flag_5)))
 cp_error ("unexpected argument to constructor `%T'", type);
      else
 error ("unexpected argument to constructor");
    }
  init_ptr = old_init_ptr;
}



int
is_aggr_typedef(tree name, int or_else) asm("_is_aggr_typedef");
int
is_aggr_typedef(tree name, int or_else)
{
  tree type;

  if (name == error_mark_node)
    return 0;

  if ((((name)->common.type) ? 1 : 0))
    type = (((name)->common.type));
  else
    {
      if (or_else)
 cp_error ("`%T' is not an aggregate typedef", name);
      return 0;
    }

  if (! (((type)->type.lang_flag_5))
      && ((n64_enum_tree_code) (type)->common.code) != TEMPLATE_TYPE_PARM)
    {
      if (or_else)
 cp_error ("`%T' is not an aggregate type", type);
      return 0;
    }
  return 1;
}


tree
get_aggr_from_typedef(tree name, int or_else) asm("_get_aggr_from_typedef");
tree
get_aggr_from_typedef(tree name, int or_else)
{
  tree type;

  if (name == error_mark_node)
    return (tree) 0;

  if ((((name)->common.type) ? 1 : 0))
    type = (((name)->common.type));
  else
    {
      if (or_else)
 cp_error ("`%T' fails to be an aggregate typedef", name);
      return (tree) 0;
    }

  if (! (((type)->type.lang_flag_5))
      && ((n64_enum_tree_code) (type)->common.code) != TEMPLATE_TYPE_PARM)
    {
      if (or_else)
 cp_error ("type `%T' is of non-aggregate type", type);
      return (tree) 0;
    }
  return type;
}

tree
get_type_value(tree name) asm("_get_type_value");
tree
get_type_value(tree name)
{
  if (name == error_mark_node)
    return (tree) 0;

  if ((((name)->common.type) ? 1 : 0))
    return (((name)->common.type));
  else
    return (tree) 0;
}







tree
build_member_call(tree cname, tree name, tree parmlist) asm("_build_member_call");
tree
build_member_call(tree cname, tree name, tree parmlist)
{
  tree type, t;
  tree method_name = name;
  int dtor = 0;
  int dont_use_this = 0;
  tree basetype_path, decl;

  if (((n64_enum_tree_code) (method_name)->common.code) == BIT_NOT_EXPR)
    {
      method_name = ((method_name)->exp.operands[0]);
      dtor = 1;
    }

  if (((n64_enum_tree_code) (cname)->common.code) == SCOPE_REF)
    cname = resolve_scope_to_name ((tree) 0, cname);



  if (cname && get_aggr_from_typedef (cname, 0) == 0
      && ((n64_enum_tree_code) (cname)->common.code) == IDENTIFIER_NODE)
    {
      tree ns = lookup_name (cname, 0);
      if (ns && ((n64_enum_tree_code) (ns)->common.code) == NAMESPACE_DECL)
 {
   return build_x_function_call (build_offset_ref (cname, name), parmlist, current_class_decl);
 }
    }

  if (cname == (tree) 0 || ! (type = get_aggr_from_typedef (cname, 1)))
    return error_mark_node;


  if (name == (tree) 0)
    return error_mark_node;

  if (dtor)
    {






      cp_error ("cannot call destructor `%T::~%T' without object", type,
  method_name);
      return error_mark_node;
    }



  if (current_class_type == 0
      || get_base_distance (type, current_class_type, 0, &basetype_path) == -1)
    dont_use_this = 1;

  if (dont_use_this)
    {
      basetype_path = ((type)->type.binfo);
      decl = build1 (NOP_EXPR, build_pointer_type (type), error_mark_node);
    }
  else if (current_class_decl == 0)
    {
      dont_use_this = 1;
      decl = build1 (NOP_EXPR, build_pointer_type (type), error_mark_node);
    }
  else
    {
      tree olddecl = current_class_decl;
      tree oldtype = ((((olddecl)->common.type))->common.type);
      if (oldtype != type)
 {
   tree newtype = build_type_variant (type, ((oldtype)->common.readonly_flag),
          ((oldtype)->common.volatile_flag));
   decl = convert_force (build_pointer_type (newtype), olddecl, 0);
 }
      else
 decl = olddecl;
    }

  decl = build_indirect_ref (decl, ((void *)0));

  if (method_name == constructor_name (type)
      || method_name == constructor_name_full (type))
    return build_functional_cast (type, parmlist);
  if (t = lookup_fnfields (basetype_path, method_name, 0))
    return build_method_call (decl, method_name, parmlist, basetype_path,
         (3)|(8));
  if (((n64_enum_tree_code) (name)->common.code) == IDENTIFIER_NODE
      && ((t = lookup_field (((type)->type.binfo), name, 1, 0))))
    {
      if (t == error_mark_node)
 return error_mark_node;
      if (((n64_enum_tree_code) (t)->common.code) == FIELD_DECL)
 {
   if (dont_use_this)
     {
       cp_error ("invalid use of non-static field `%D'", t);
       return error_mark_node;
     }
   decl = build (COMPONENT_REF, ((t)->common.type), decl, t);
 }
      else if (((n64_enum_tree_code) (t)->common.code) == VAR_DECL)
 decl = t;
      else
 {
   cp_error ("invalid use of member `%D'", t);
   return error_mark_node;
 }
      if (((((decl)->common.type))->type.lang_specific)
   && (((((decl)->common.type))->type.lang_specific)->type_flags.has_call_overloaded))
 return build_opfncall (CALL_EXPR, (3), decl, parmlist, (tree) 0);
      return build_function_call (decl, parmlist);
    }
  else
    {
      cp_error ("no method `%T::%D'", type, name);
      return error_mark_node;
    }
}
tree
build_offset_ref(tree cname, tree name) asm("_build_offset_ref");
tree
build_offset_ref(tree cname, tree name)
{
  tree decl, type, fnfields, fields, t = error_mark_node;
  tree basetypes = (tree) 0;
  int dtor = 0;

  if (((n64_enum_tree_code) (cname)->common.code) == SCOPE_REF)
    cname = resolve_scope_to_name ((tree) 0, cname);


  if (((n64_enum_tree_code) (cname)->common.code) == IDENTIFIER_NODE
      && get_aggr_from_typedef (cname, 0) == 0)
    {
      tree ns = lookup_name (cname, 0);
      tree val;
      if (ns && ((n64_enum_tree_code) (ns)->common.code) == NAMESPACE_DECL)
 {
   val = lookup_namespace_name (ns, name);
   if (val)
     return val;
   cp_error ("namespace `%D' has no member named `%D'", ns, name);
   return error_mark_node;
 }
    }

  if (cname == (tree) 0 || ! is_aggr_typedef (cname, 1))
    return error_mark_node;

  type = (((cname)->common.type));

  if (((n64_enum_tree_code) (name)->common.code) == BIT_NOT_EXPR)
    {
      dtor = 1;
      name = ((name)->exp.operands[0]);
    }

  if (((type)->type.size) == 0)
    {
      t = (((struct n64_tag_lang_identifier *)(name))->class_value);
      if (t == 0)
 {
   cp_error ("incomplete type `%T' does not have member `%D'", type,
        name);
   return error_mark_node;
 }
      if (((n64_enum_tree_code) (t)->common.code) == TYPE_DECL || ((n64_enum_tree_code) (t)->common.code) == VAR_DECL
   || ((n64_enum_tree_code) (t)->common.code) == CONST_DECL)
 {
   ((t)->common.used_flag) = 1;
   return t;
 }
      if (((n64_enum_tree_code) (t)->common.code) == FIELD_DECL)
 sorry ("use of member in incomplete aggregate type");
      else if (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL)
 sorry ("use of member function in incomplete aggregate type");
      else
 my_friendly_abort (52);
      return error_mark_node;
    }
  if (current_class_type == 0
      || get_base_distance (type, current_class_type, 0, &basetypes) == -1)
    {
      basetypes = ((type)->type.binfo);
      decl = build1 (NOP_EXPR,
       (((cname)->common.type)),
       error_mark_node);
    }
  else if (current_class_decl == 0)
    decl = build1 (NOP_EXPR, (((cname)->common.type)),
     error_mark_node);
  else
    decl = C_C_D;

  fnfields = lookup_fnfields (basetypes, name, 1);
  fields = lookup_field (basetypes, name, 0, 0);

  if (fields == error_mark_node || fnfields == error_mark_node)
    return error_mark_node;



  if (fnfields)
    {
      basetypes = ((fnfields)->list.purpose);


      t = ((fnfields)->list.value);

      if (fields)
 {
   if (((fields)->decl.context) == ((t)->decl.context))
     {
       error ("ambiguous member reference: member `%s' defined as both field and function",
       ((name)->identifier.pointer));
       return error_mark_node;
     }
   if ((get_base_distance (((fields)->decl.context), ((t)->decl.context), 0, (tree *)0) >= 0))
     ;
   else if ((get_base_distance (((t)->decl.context), ((fields)->decl.context), 0, (tree *)0) >= 0))
     t = fields;
   else
     {
       error ("ambiguous member reference: member `%s' derives from distinct classes in multiple inheritance lattice");
       return error_mark_node;
     }
 }

      if (t == ((fnfields)->list.value))
 {
   extern int flag_save_memoized_contexts;

   if ((((t)->decl.lang_specific)->chain) == (tree) 0 || dtor)
     {
       n64_enum_access_type access;


     unique:
       access = compute_access (basetypes, t);
       if (access == access_protected)
  {
    cp_error_at ("member function `%#D' is protected", t);
    error ("in this context");
    return error_mark_node;
  }
       if (access == access_private)
  {
    cp_error_at ("member function `%#D' is private", t);
    error ("in this context");
    return error_mark_node;
  }
       assemble_external (t);
       return build (CP_OFFSET_REF, ((t)->common.type), decl, t);
     }


   if (cname == name)
     {
       if ((((type)->type.lang_flag_2))
    && ((((((t)->decl.lang_specific)->chain))->decl.lang_specific)->chain) == (tree) 0)
  {
    t = (((t)->decl.lang_specific)->chain);
    goto unique;
  }
     }
   if (!((fnfields)->common.permanent_flag)
       && ((flag_save_memoized_contexts && global_bindings_p ())
    || ! allocation_temporary_p ()))
     fnfields = copy_list (fnfields);

   for (t = ((fnfields)->list.value); t; t = (((t)->decl.lang_specific)->chain))
     assemble_external (t);

   t = build_tree_list (error_mark_node, fnfields);
   ((t)->common.type) = build_offset_type (type, unknown_type_node);
   return t;
 }
    }





  t = lookup_field (basetypes, name, 1, 0);

  if (t == error_mark_node)
    return error_mark_node;

  if (t == (tree) 0)
    {
      cp_error ("`%D' is not a member of type `%T'", name, type);
      return error_mark_node;
    }

  if (((n64_enum_tree_code) (t)->common.code) == TYPE_DECL)
    {
      ((t)->common.used_flag) = 1;
      return t;
    }


  if (((n64_enum_tree_code) (t)->common.code) == VAR_DECL || ((n64_enum_tree_code) (t)->common.code) == CONST_DECL)
    {
      assemble_external (t);
      ((t)->common.used_flag) = 1;
      return t;
    }

  if (((n64_enum_tree_code) (t)->common.code) == FIELD_DECL && ((t)->decl.bit_field_flag))
    {
      cp_error ("illegal pointer to bit field `%D'", t);
      return error_mark_node;
    }


  if (((n64_enum_tree_code) (t)->common.code) == FUNCTION_DECL && ((n64_enum_tree_code) (((t)->common.type))->common.code) == FUNCTION_TYPE)
    my_friendly_abort (53);



  return build (CP_OFFSET_REF, build_offset_type (type, ((t)->common.type)), decl, t);
}



tree
get_member_function(tree *exp_addr_ptr, tree exp, tree member) asm("_get_member_function");
tree
get_member_function(tree *exp_addr_ptr, tree exp, tree member)
{
  tree ctype = ((exp)->common.type);
  tree function = save_expr (build_unary_op (ADDR_EXPR, member, 0));

  if ((((ctype)->common.lang_flag_2))
      || (flag_all_virtual == 1 && (((ctype)->type.lang_specific)->type_flags.has_method_call_overloaded)))
    {
      tree e0, e1, e3;
      tree exp_addr;


      exp_addr = save_expr (*exp_addr_ptr);


      e0 = build1 (NOP_EXPR, integer_type_node, function);
      if (((target_flags & 0x00002000) ? 8 : 4) <= 1)
 my_friendly_abort (54);

      e1 = build (GT_EXPR, boolean_type_node, e0, integer_zero_node);
      e1 = build_compound_expr (tree_cons ((tree) 0, exp_addr,
        build_tree_list ((tree) 0, e1)));
      e1 = save_expr (e1);

      if (((*exp_addr_ptr)->common.side_effects_flag))
 {
   exp = build_indirect_ref (exp_addr, ((void *)0));
   *exp_addr_ptr = exp_addr;
 }
      e3 = build_vfn_ref (exp_addr_ptr, exp, e0);
      my_friendly_assert (e3 != error_mark_node, 213);



      ((e3)->common.type) = ((function)->common.type);



      *exp_addr_ptr = build_conditional_expr (e1, exp_addr, *exp_addr_ptr);

      function = build_conditional_expr (e1, function, e3);
    }
  return build_indirect_ref (function, ((void *)0));
}




tree
resolve_offset_ref(tree exp) asm("_resolve_offset_ref");
tree
resolve_offset_ref(tree exp)
{
  tree type = ((exp)->common.type);
  tree base = (tree) 0;
  tree member;
  tree basetype, addr;

  if (((n64_enum_tree_code) (exp)->common.code) == TREE_LIST)
    return build_unary_op (ADDR_EXPR, exp, 0);

  if (((n64_enum_tree_code) (exp)->common.code) != CP_OFFSET_REF)
    {
      my_friendly_assert (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE, 214);
      if (((type)->type.maxval) != current_class_type)
 {
   error ("object missing in use of pointer-to-member construct");
   return error_mark_node;
 }
      member = exp;
      type = ((type)->common.type);
      base = C_C_D;
    }
  else
    {
      member = ((exp)->exp.operands[1]);
      base = ((exp)->exp.operands[0]);
    }

  if ((((n64_enum_tree_code) (member)->common.code) == VAR_DECL
       && ! (((n64_enum_tree_code) (((member)->common.type))->common.code) == RECORD_TYPE && ((((member)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
      || ((n64_enum_tree_code) (((member)->common.type))->common.code) == FUNCTION_TYPE)
    {

      if (mark_addressable (member) == 0)
 return error_mark_node;
      return member;
    }



  if (((n64_enum_tree_code) (member)->common.code) == FIELD_DECL && C_C_D == (tree) 0)
    {
      if (((member)->common.addressable_flag) == 0)
 {
   cp_error_at ("member `%D' is non-static but referenced as a static member",
         member);
   error ("at this point in file");
   ((member)->common.addressable_flag) = 1;
 }
      return error_mark_node;
    }


  if (((n64_enum_tree_code) (member)->common.code) == FIELD_DECL
      && (base == C_C_D
   || (((n64_enum_tree_code) (base)->common.code) == NOP_EXPR
       && ((base)->exp.operands[0]) == error_mark_node)))
    {
      tree basetype_path;
      n64_enum_access_type access;

      if (((n64_enum_tree_code) (exp)->common.code) == CP_OFFSET_REF && ((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE)
 basetype = ((type)->type.maxval);
      else
 basetype = ((member)->decl.context);

      base = current_class_decl;

      if (get_base_distance (basetype, ((((base)->common.type))->common.type), 0, &basetype_path) < 0)
 {
   error_not_base_type (basetype, ((((base)->common.type))->common.type));
   return error_mark_node;
 }
      addr = convert_pointer_to (basetype, base);
      access = compute_access (basetype_path, member);
      if (access == access_public)
 return build (COMPONENT_REF, ((member)->common.type),
        build_indirect_ref (addr, ((void *)0)), member);
      if (access == access_protected)
 {
   cp_error_at ("member `%D' is protected", member);
   error ("in this context");
   return error_mark_node;
 }
      if (access == access_private)
 {
   cp_error_at ("member `%D' is private", member);
   error ("in this context");
   return error_mark_node;
 }
      my_friendly_abort (55);
    }





  addr = build_unary_op (ADDR_EXPR, base, 0);

  if (((n64_enum_tree_code) (((member)->common.type))->common.code) == METHOD_TYPE)
    {
      basetype = (((member)->decl.lang_specific)->decl_flags.context);
      addr = convert_pointer_to (basetype, addr);
      return build_unary_op (ADDR_EXPR, get_member_function (&addr, build_indirect_ref (addr, ((void *)0)), member), 0);
    }
  else if (((n64_enum_tree_code) (((member)->common.type))->common.code) == OFFSET_TYPE)
    {
      basetype = ((((member)->common.type))->type.maxval);
      addr = convert_pointer_to (basetype, addr);
      member = convert (ptrdiff_type_node,
   build_unary_op (ADDR_EXPR, member, 0));
      return build1 (INDIRECT_REF, type,
       build (PLUS_EXPR, build_pointer_type (type),
       addr, member));
    }
  else if ((((n64_enum_tree_code) (((member)->common.type))->common.code) == RECORD_TYPE && ((((member)->common.type))->type.lang_specific)->type_flags.ptrmemfunc_flag))
    {
      return get_member_function_from_ptrfunc (&addr, member);
    }
  my_friendly_abort (56);

  return (tree) 0;
}



tree
decl_constant_value(tree decl) asm("_decl_constant_value");
tree
decl_constant_value(tree decl)
{
  if (! ((decl)->common.volatile_flag)







      && ((decl)->decl.initial) != 0
      && ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) != ERROR_MARK



      && ((((decl)->decl.initial))->common.constant_flag)

      && ((n64_enum_tree_code) (((decl)->decl.initial))->common.code) != CONSTRUCTOR






      )
    return ((decl)->decl.initial);
  return decl;
}
int
is_friend_type(tree type1, tree type2) asm("_is_friend_type");
int
is_friend_type(tree type1, tree type2)
{
  return is_friend (type1, type2);
}

int
is_friend(tree type, tree supplicant) asm("_is_friend");
int
is_friend(tree type, tree supplicant)
{
  int declp;
  register tree list;

  if (supplicant == (tree) 0 || type == (tree) 0)
    return 0;

  declp = ((*tree_code_type[(int) (((n64_enum_tree_code) (supplicant)->common.code))]) == 'd');

  if (declp)

    {
      tree list = (((((type)->type.name))->decl.initial));
      tree name = ((supplicant)->decl.name);
      tree ctype;

      if ((((n64_enum_tree_code) (((supplicant)->common.type))->common.code) == METHOD_TYPE || (((supplicant)->decl.lang_specific)->decl_flags.static_function)))
 ctype = (((supplicant)->decl.lang_specific)->decl_flags.context);
      else
 ctype = (tree) 0;

      for (; list ; list = ((list)->common.chain))
 {
   if (name == ((list)->list.purpose))
     {
       tree friends = ((list)->list.value);
       name = ((supplicant)->decl.assembler_name);
       for (; friends ; friends = ((friends)->common.chain))
  {
    if (ctype == ((friends)->list.purpose))
      return 1;
    if (name == ((((friends)->list.value))->decl.assembler_name))
      return 1;
  }
       break;
     }
 }
    }
  else

    {
      if (type == supplicant)
 return 1;

      list = (((((((type)->type.name))->common.type))->type.lang_specific)->friend_classes);
      for (; list ; list = ((list)->common.chain))
 if (supplicant == ((list)->list.value))
   return 1;
    }

  {
    tree context;

    if (! declp)
      context = ((((supplicant)->type.name))->decl.context);
    else if ((((n64_enum_tree_code) (((supplicant)->common.type))->common.code) == METHOD_TYPE || (((supplicant)->decl.lang_specific)->decl_flags.static_function)))
      context = (((supplicant)->decl.lang_specific)->decl_flags.context);
    else
      context = (tree) 0;

    if (context)
      return is_friend (type, context);
  }

  return 0;
}



static void
add_friend(tree type, tree decl) asm("_add_friend");
static void
add_friend(tree type, tree decl)
{
  tree typedecl = ((type)->type.name);
  tree list = (((typedecl)->decl.initial));
  tree name = ((decl)->decl.name);

  while (list)
    {
      if (name == ((list)->list.purpose))
 {
   tree friends = ((list)->list.value);
   for (; friends ; friends = ((friends)->common.chain))
     {
       if (decl == ((friends)->list.value))
  {
    cp_warning ("`%D' is already a friend of class `%T'",
         decl, type);
    cp_warning_at ("previous friend declaration of `%D'",
     ((friends)->list.value));
    return;
  }
     }
   ((list)->list.value) = tree_cons (error_mark_node, decl,
      ((list)->list.value));
   return;
 }
      list = ((list)->common.chain);
    }
  (((typedecl)->decl.initial))
    = tree_cons (((decl)->decl.name), build_tree_list (error_mark_node, decl),
   (((typedecl)->decl.initial)));
  if (((decl)->decl.name) == ansi_opname[(int) MODIFY_EXPR])
    {
      tree parmtypes = ((((decl)->common.type))->type.values);
      (((((typedecl)->common.type))->type.lang_specific)->type_flags.has_assignment) = 1;
      if (parmtypes && ((parmtypes)->common.chain))
 {
   tree parmtype = ((((parmtypes)->common.chain))->list.value);
   if (((n64_enum_tree_code) (parmtype)->common.code) == REFERENCE_TYPE
       && ((parmtypes)->common.type) == ((typedecl)->common.type))
     (((((typedecl)->common.type))->type.lang_specific)->type_flags.has_assign_ref) = 1;
 }
    }
}



static void
add_friends(tree type, tree name, tree friend_type) asm("_add_friends");
static void
add_friends(tree type, tree name, tree friend_type)
{
  tree typedecl = ((type)->type.name);
  tree list = (((typedecl)->decl.initial));

  while (list)
    {
      if (name == ((list)->list.purpose))
 {
   tree friends = ((list)->list.value);
   while (friends && ((friends)->list.purpose) != friend_type)
     friends = ((friends)->common.chain);
   if (friends)
     if (friend_type)
       warning ("method `%s::%s' is already a friend of class",
         ((((((((friend_type)->type.name))->decl.name)))->identifier.pointer)),
         ((name)->identifier.pointer));
     else
       warning ("function `%s' is already a friend of class `%s'",
         ((name)->identifier.pointer),
         ((((typedecl)->decl.name))->identifier.pointer));
   else
     ((list)->list.value) = tree_cons (friend_type, (tree) 0,
        ((list)->list.value));
   return;
 }
      list = ((list)->common.chain);
    }
  (((typedecl)->decl.initial)) =
    tree_cons (name,
        build_tree_list (friend_type, (tree) 0),
        (((typedecl)->decl.initial)));
  if (! strncmp (((name)->identifier.pointer),
   ((ansi_opname[(int) MODIFY_EXPR])->identifier.pointer),
   strlen (((ansi_opname[(int) MODIFY_EXPR])->identifier.pointer))))
    {
      (((((typedecl)->common.type))->type.lang_specific)->type_flags.has_assignment) = 1;
      sorry ("declaring \"friend operator =\" will not find \"operator = (X&)\" if it exists");
    }
}





static void
xref_friend(tree type, tree decl, tree ctype) asm("_xref_friend");
static void
xref_friend(tree type, tree decl, tree ctype)
{
  tree friend_decl = ((ctype)->type.name);






  tree t = 0;

  ((friend_decl)->decl.rtl=(struct n64_tag_rtx_def*)tree_cons (type, t, ((tree)(friend_decl)->decl.rtl)))

                                               ;
  ((((tree)(friend_decl)->decl.rtl))->common.type) = decl;
}
void
make_friend_class(tree type, tree friend_type) asm("_make_friend_class");
void
make_friend_class(tree type, tree friend_type)
{
  tree classes;

  if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("`friend' declaration in signature definition");
      return;
    }
  if ((((friend_type)->type.lang_specific)?((friend_type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("signature type `%s' declared `friend'",
      ((((((friend_type)->type.name))->decl.name))->identifier.pointer));
      return;
    }
  if (type == friend_type)
    {
      pedwarn ("class `%s' is implicitly friends with itself",
        ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
      return;
    }

  GNU_xref_hier (((((((((type)->type.name))->decl.name)))->identifier.pointer)),
   ((((((((friend_type)->type.name))->decl.name)))->identifier.pointer)), 0, 0, 1);

  classes = (((type)->type.lang_specific)->friend_classes);
  while (classes && ((classes)->list.value) != friend_type)
    classes = ((classes)->common.chain);
  if (classes)
    warning ("class `%s' is already friends with class `%s'",
      ((((((((((classes)->list.value))->type.name))->decl.name)))->identifier.pointer)), ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
  else
    {
      (((type)->type.lang_specific)->friend_classes)
 = tree_cons ((tree) 0, friend_type, (((type)->type.lang_specific)->friend_classes));
    }
}
tree
do_friend(tree ctype, tree declarator, tree decl, tree parmdecls, n64_enum_overload_flags flags, tree quals) asm("_do_friend");
tree
do_friend(tree ctype, tree declarator, tree decl, tree parmdecls, n64_enum_overload_flags flags, tree quals)
{

  (((decl)->decl.lang_specific)->decl_flags.friend_attr) = 1;

  if (ctype)
    {
      tree cname = ((ctype)->type.name);
      if (((n64_enum_tree_code) (cname)->common.code) == TYPE_DECL)
 cname = ((cname)->decl.name);


      if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
 {
   if (flags == NO_SPECIAL && ctype && declarator == cname)
     (((decl)->decl.lang_specific)->decl_flags.constructor_attr) = 1;


   grokclassfn (ctype, cname, decl, flags, quals);
   if (((ctype)->type.size) != 0)
     check_classfn (ctype, cname, decl);

   if (((decl)->common.type) != error_mark_node)
     {
       if (((ctype)->type.size))
  {



    make_decl_rtl (decl, ((void *)0), 1);
    add_friend (current_class_type, decl);
  }
       else
  {
    register char *classname
      = ((((((ctype)->type.name))->decl.name))->identifier.pointer);

    error ("member declared as friend before type `%s' defined",
    classname);
  }
     }
 }
      else
 {



   tree ctype = (((cname)->common.type));


   if (((ctype)->type.size))
     {
       tree fields = lookup_fnfields (((ctype)->type.binfo), declarator, 0);
       if (fields)
  add_friends (current_class_type, declarator, ctype);
       else
  error ("method `%s' is not a member of class `%s'",
         ((declarator)->identifier.pointer),
         ((cname)->identifier.pointer));
     }
   else




     xref_friend (current_class_type, declarator, ctype);
   decl = void_type_node;
 }
    }
  else if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL
    && ((((declarator)->identifier.length) == 4
  && ((declarator)->identifier.pointer)[0] == 'm'
  && ! strcmp (((declarator)->identifier.pointer), "main"))
        || (((declarator)->identifier.length) > 10
     && ((declarator)->identifier.pointer)[0] == '_'
     && ((declarator)->identifier.pointer)[1] == '_'
     && strncmp (((declarator)->identifier.pointer)+2,
          "builtin_", 8) == 0)))
    {


      add_friend (current_class_type, decl);
      (((decl)->decl.lang_specific)->decl_flags.friend_attr) = 1;
      decl = void_type_node;
    }


  else if (((n64_enum_tree_code) (decl)->common.code) == FUNCTION_DECL)
    {





      ((decl)->decl.assembler_name)
 = build_decl_overload (declarator, ((((decl)->common.type))->type.values),
          ((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE);
      ((decl)->decl.arguments) = parmdecls;
      (((decl)->decl.lang_specific)->decl_flags.context) = current_class_type;



      decl = pushdecl (decl);

      make_decl_rtl (decl, ((void *)0), 1);
      add_friend (current_class_type, decl);

      (((decl)->decl.lang_specific)->decl_flags.friend_attr) = 1;



    }
  else
    {


      tree decl = lookup_name_nonclass (declarator);
      if (decl == (tree) 0)
 {
   warning ("implicitly declaring `%s' as struct",
     ((declarator)->identifier.pointer));
   decl = xref_tag (record_type_node, declarator, (tree) 0, 1);
   decl = ((decl)->type.name);
 }



      if (((n64_enum_tree_code) (decl)->common.code) == TREE_LIST && ((((decl)->list.purpose))->common.type))
 {
   warning ("`friend %s' archaic, use `friend class %s' instead",
     ((declarator)->identifier.pointer),
     ((declarator)->identifier.pointer));
   decl = ((((decl)->list.purpose))->common.type);
 }

      if (((n64_enum_tree_code) (decl)->common.code) == TREE_LIST)
 add_friends (current_class_type, ((decl)->list.purpose), (tree) 0);
      else
 make_friend_class (current_class_type, ((decl)->common.type));
      decl = void_type_node;
    }
  return decl;
}




void
embrace_waiting_friends(tree type) asm("_embrace_waiting_friends");
void
embrace_waiting_friends(tree type)
{
  tree decl = ((type)->type.name);
  tree waiters;

  if (((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
    return;

  for (waiters = ((tree)(decl)->decl.rtl); waiters;
       waiters = ((waiters)->common.chain))
    {
      tree waiter = ((waiters)->list.purpose);



      tree decl = ((waiters)->common.type);
      tree name = decl ? (((n64_enum_tree_code) (decl)->common.code) == IDENTIFIER_NODE
     ? decl : ((decl)->decl.name)) : (tree) 0;
      if (name)
 {



   tree field = lookup_fnfields (((type)->type.binfo), name, 0);
   if (field)
     if (decl == name)
       add_friends (waiter, name, type);
     else
       add_friend (waiter, decl);
   else
     error_with_file_and_line (((((waiter)->type.name))->decl.filename),
          ((((waiter)->type.name))->decl.linenum),
          "no method `%s' defined in class `%s' to be friend",
          ((((((waiters)->common.type))->decl.name))->identifier.pointer),
          ((((((((type)->type.name))->decl.name)))->identifier.pointer)));
 }
      else
 make_friend_class (type, waiter);







    }
}






tree
build_builtin_call(tree type, tree node, tree arglist) asm("_build_builtin_call");
tree
build_builtin_call(tree type, tree node, tree arglist)
{
  tree rval = build (CALL_EXPR, type, node, arglist, 0);
  ((rval)->common.side_effects_flag) = 1;
  assemble_external (((node)->exp.operands[0]));
  ((((node)->exp.operands[0]))->common.used_flag) = 1;
  return rval;
}
extern int flag_check_new;

tree
build_new(tree placement, tree decl, tree init, int use_global_new) asm("_build_new");
tree
build_new(tree placement, tree decl, tree init, int use_global_new)
{
  tree type, true_type, size, rval;
  tree nelts;
  tree alloc_expr, alloc_temp;
  int has_array = 0;
  n64_enum_tree_code code = NEW_EXPR;

  tree pending_sizes = (tree) 0;

  if (decl == error_mark_node)
    return error_mark_node;

  if (((n64_enum_tree_code) (decl)->common.code) == TREE_LIST)
    {
      tree absdcl = ((decl)->list.value);
      tree last_absdcl = (tree) 0;
      int old_immediate_size_expand;

      if (current_function_decl
   && (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
 {
   old_immediate_size_expand = immediate_size_expand;
   immediate_size_expand = 0;
 }

      nelts = integer_one_node;

      if (absdcl && ((n64_enum_tree_code) (absdcl)->common.code) == CALL_EXPR)
 my_friendly_abort (215);
      while (absdcl && ((n64_enum_tree_code) (absdcl)->common.code) == INDIRECT_REF)
 {
   last_absdcl = absdcl;
   absdcl = ((absdcl)->exp.operands[0]);
 }

      if (absdcl && ((n64_enum_tree_code) (absdcl)->common.code) == ARRAY_REF)
 {

   tree this_nelts;

   while (((absdcl)->exp.operands[0])
   && ((n64_enum_tree_code) (((absdcl)->exp.operands[0]))->common.code) == ARRAY_REF)
     {
       last_absdcl = absdcl;
       absdcl = ((absdcl)->exp.operands[0]);
     }

   has_array = 1;
   this_nelts = ((absdcl)->exp.operands[1]);
   if (this_nelts != error_mark_node)
     {
       if (this_nelts == (tree) 0)
  error ("new of array type fails to specify size");
       else
  {
    this_nelts = save_expr (convert (sizetype, this_nelts));
    absdcl = ((absdcl)->exp.operands[0]);
           if (this_nelts == integer_zero_node)
      {
        warning ("zero size array reserves no space");
        nelts = integer_zero_node;
      }
    else
      nelts = build_binary_op (MULT_EXPR, nelts, this_nelts, 1);
  }
     }
   else
     nelts = integer_zero_node;
 }

      if (last_absdcl)
 ((last_absdcl)->exp.operands[0]) = absdcl;
      else
 ((decl)->list.value) = absdcl;

      type = true_type = groktypename (decl);
      if (! type || type == error_mark_node)
 {
   immediate_size_expand = old_immediate_size_expand;
   return error_mark_node;
 }

      if (current_function_decl
   && (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
 {
   pending_sizes = get_pending_sizes ();
   immediate_size_expand = old_immediate_size_expand;
 }
    }
  else if (((n64_enum_tree_code) (decl)->common.code) == IDENTIFIER_NODE)
    {
      if ((((decl)->common.type) ? 1 : 0))
 {

   type = (((decl)->common.type));
   decl = ((type)->type.name);
 }
      else
 {

   decl = lookup_name (decl, 1);
   my_friendly_assert (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL, 215);
   type = ((decl)->common.type);
 }
      true_type = type;
    }
  else if (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL)
    {
      type = ((decl)->common.type);
      true_type = type;
    }
  else
    {
      type = decl;
      true_type = type;
      decl = ((type)->type.name);
    }




  if (((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    {
      error ("new cannot be applied to a reference type");
      type = true_type = ((type)->common.type);
    }

  if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
    {
      error ("new cannot be applied to a function type");
      return error_mark_node;
    }




  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && has_array == 0)
    {
      nelts = array_type_nelts_top (type);
      has_array = 1;
      type = true_type = ((type)->common.type);
    }

  if (((type)->common.readonly_flag) || ((type)->common.volatile_flag))
    type = ((type)->type.main_variant);



  while (((n64_enum_tree_code) (true_type)->common.code) == ARRAY_TYPE)
    {
      tree this_nelts = array_type_nelts_top (true_type);
      nelts = build_binary_op (MULT_EXPR, nelts, this_nelts, 1);
      true_type = ((true_type)->common.type);
    }
  if (has_array)
    size = fold (build_binary_op (MULT_EXPR, size_in_bytes (true_type),
      nelts, 1));
  else
    size = size_in_bytes (type);

  if (true_type == void_type_node)
    {
      error ("invalid type `void' for new");
      return error_mark_node;
    }

  if (((true_type)->type.size) == 0)
    {
      incomplete_type_error (0, true_type);
      return error_mark_node;
    }

  if (((true_type)->type.lang_specific)
      && (((true_type)->type.lang_specific)->abstract_virtuals))
    {
      abstract_virtuals_error ((tree) 0, true_type);
      return error_mark_node;
    }

  if (((true_type)->type.lang_specific) && (((true_type)->type.lang_specific)?((true_type)->type.lang_specific)->type_flags.is_signature:0))
    {
      signature_error ((tree) 0, true_type);
      return error_mark_node;
    }



  if (has_array && ((((true_type)->type.lang_flag_4)) || (((true_type)->type.lang_specific) && (((true_type)->type.lang_specific)->type_flags.vec_delete_takes_size))))
    {
      tree extra = BI_header_size;

      size = size_binop (PLUS_EXPR, size, extra);
    }

  if (has_array)
    code = VEC_NEW_EXPR;


  if (! use_global_new && ((true_type)->type.lang_specific)
      && ((((true_type)->type.lang_specific)->type_flags.gets_new) & (1 << has_array)))
    rval = build_opfncall (code, (3),
      build_pointer_type (true_type), size, placement);
  else if (placement)
    {
      rval = build_opfncall (code, (16)|(2),
        ptr_type_node, size, placement);
      rval = convert (build_pointer_type (true_type), rval);
    }
  else if (! has_array && flag_this_is_variable > 0
    && ((true_type)->type.needs_constructing_flag) && init != void_type_node)
    {
      if (init == (tree) 0 || ((n64_enum_tree_code) (init)->common.code) == TREE_LIST)
 rval = (tree) 0;
      else
 {
   error ("constructors take parameter lists");
   return error_mark_node;
 }
    }
  else
    {
      rval = build_builtin_call (build_pointer_type (true_type),
     has_array ? BIVN : BIN,
     build_tree_list ((tree) 0, size));
      (((rval)->common.lang_flag_1)) = 1;
    }

  if (flag_check_new && rval)
    {




      alloc_temp = get_temp_name (((rval)->common.type), 0);
      alloc_expr = build (MODIFY_EXPR, ((rval)->common.type), alloc_temp, rval);
      ((alloc_expr)->common.side_effects_flag) = 1;
      rval = alloc_temp;
    }
  else
    alloc_expr = (tree) 0;





  if (has_array && ((((true_type)->type.lang_flag_4)) || (((true_type)->type.lang_specific) && (((true_type)->type.lang_specific)->type_flags.vec_delete_takes_size))) && rval != (tree) 0)
    {
      tree extra = BI_header_size;
      tree cookie, exp1;
      rval = convert (ptr_type_node, rval);
      rval = convert (string_type_node, rval);
      rval = save_expr (build_binary_op (PLUS_EXPR, rval, extra, 1));

      cookie = build_indirect_ref (build (MINUS_EXPR, build_pointer_type (BI_header_type),
       rval, extra), ((void *)0));
      exp1 = build (MODIFY_EXPR, void_type_node,
      build_component_ref (cookie, nc_nelts_field_id, 0, 0),
      nelts);
      ((exp1)->common.side_effects_flag) = 1;
      rval = convert (build_pointer_type (true_type), rval);
      (((rval)->common.lang_flag_1)) = 1;
      ((rval)->common.side_effects_flag) = 1;
      rval = build_compound_expr (tree_cons ((tree) 0, exp1,
          build_tree_list ((tree) 0, rval)));
    }

  if (rval == error_mark_node)
    return error_mark_node;


  if (init == void_type_node)
    goto done;

  if (((type)->type.needs_constructing_flag) || init)
    {
      if (! ((type)->type.needs_constructing_flag)
   && ! (((type)->type.lang_flag_5)) && ! has_array)
 {


   tree deref;

   rval = save_expr (rval);
   deref = build_indirect_ref (rval, ((void *)0));
   ((deref)->common.readonly_flag) = 0;

   if (((init)->common.chain) != (tree) 0)
     pedwarn ("initializer list being treated as compound expression");
   else if (((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR)
     {
       pedwarn ("initializer list appears where operand should be used");
       init = ((init)->exp.operands[1]);
     }
   init = build_compound_expr (init);

   init = convert_for_initialization (deref, type, init, (3),
          "new", (tree) 0, 0);
   rval = build (COMPOUND_EXPR, ((rval)->common.type),
   build_modify_expr (deref, NOP_EXPR, init),
   rval);
   ((rval)->common.static_flag) = 1;
   ((rval)->common.side_effects_flag) = 1;
   (((rval)->common.lang_flag_1)) = 1;
 }
      else if (! has_array)
 {
   tree newrval;



   int flags = (3)|(8)|(2);

   if (rval && (((true_type)->common.lang_flag_3)))
     {
       init = tree_cons ((tree) 0, integer_one_node, init);
       flags |= (32);
     }

   newrval = rval;

   if (newrval && ((n64_enum_tree_code) (((newrval)->common.type))->common.code) == POINTER_TYPE)
     newrval = build_indirect_ref (newrval, ((void *)0));

   newrval = build_method_call (newrval, constructor_name_full (true_type),
           init, (tree) 0, flags);

   if (newrval)
     {
       rval = newrval;
       (((rval)->common.lang_flag_4)) = 1;
     }
   else
     rval = error_mark_node;
 }
      else if (current_function_decl == (tree) 0)
 {
   extern tree static_aggregates;


   rval = save_expr (rval);
   rval = copy_to_permanent (rval);
   init = copy_to_permanent (init);
   init = expand_vec_init (decl, rval,
      build_binary_op (MINUS_EXPR, nelts,
         integer_one_node, 1),
      init, 0);
   init = copy_to_permanent (init);
   static_aggregates = perm_tree_cons (init, rval, static_aggregates);
 }
      else
 {




   tree xval = make_node (RTL_EXPR);






   if (alloc_expr && ! ((nelts)->common.constant_flag))
     {
       tree xval = make_node (RTL_EXPR);
       rtx rtxval;
       ((xval)->common.type) = ((alloc_expr)->common.type);
       do_pending_stack_adjust ();
       start_sequence_for_rtl_expr (xval);
       emit_note (0, -1);
       rtxval = expand_expr (alloc_expr, 0, VOIDmode, 0);
       do_pending_stack_adjust ();
       ((xval)->common.side_effects_flag) = 1;
       (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[0]) = get_insns ();
       end_sequence ();
       (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[1]) = rtxval;
       ((xval)->common.type) = ((alloc_expr)->common.type);
       alloc_expr = xval;
     }

   ((xval)->common.type) = ((rval)->common.type);
   do_pending_stack_adjust ();
   start_sequence_for_rtl_expr (xval);


   emit_note (0, -1);

   rval = save_expr (rval);
   rval = expand_vec_init (decl, rval,
      build_binary_op (MINUS_EXPR, nelts,
         integer_one_node, 1),
      init, 0);

   do_pending_stack_adjust ();

   ((xval)->common.side_effects_flag) = 1;
   (((xval)->common.lang_flag_1)) = 1;
   (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[0]) = get_insns ();
   end_sequence ();

   if (((n64_enum_tree_code) (rval)->common.code) == SAVE_EXPR)
     {

       if ((*(struct n64_tag_rtx_def **) &(rval)->exp.operands[2]) == 0)
  (*(struct n64_tag_rtx_def **) &(rval)->exp.operands[2]) = const0_rtx;
       (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[1]) = (*(struct n64_tag_rtx_def **) &(rval)->exp.operands[2]);
     }
   else
     {
       my_friendly_assert (((n64_enum_tree_code) (rval)->common.code) == VAR_DECL, 217);
       (*(struct n64_tag_rtx_def **) &(xval)->exp.operands[1]) = ((rval)->decl.rtl);
     }
   rval = xval;
 }
    }
  else if (((true_type)->common.readonly_flag))
    cp_error ("uninitialized const in `new' of `%#T'", true_type);

 done:

  if (alloc_expr)
    {

      if (rval != alloc_temp)
 {
   tree ifexp = build_binary_op (NE_EXPR, alloc_expr,
     integer_zero_node, 1);
   rval = build_conditional_expr (ifexp, rval, alloc_temp);
 }
      else
 rval = alloc_expr;
    }

  if (rval && ((rval)->common.type) != build_pointer_type (type))
    {

      rval = build_c_cast (build_pointer_type (type), rval, 0);
    }

  if (pending_sizes)
    rval = build_compound_expr (chainon (pending_sizes,
      build_tree_list ((tree) 0, rval)));

  if (flag_gc)
    {
      extern tree gc_visible;
      tree objbits;
      tree update_expr;

      rval = save_expr (rval);


      objbits = build1 (INDIRECT_REF, unsigned_type_node,
   build (MINUS_EXPR, ptr_type_node,
          rval, c_sizeof_nowarn (unsigned_type_node)));
      update_expr = build_modify_expr (objbits, BIT_IOR_EXPR, gc_visible);
      rval = build_compound_expr (tree_cons ((tree) 0, rval,
          tree_cons ((tree) 0, update_expr,
       build_tree_list ((tree) 0, rval))));
    }

  return rval;
}

static tree
build_vec_delete_1(tree base, tree maxindex, tree type, tree auto_delete_vec, tree auto_delete, int use_global_delete) asm("_build_vec_delete_1");
static tree
build_vec_delete_1(tree base, tree maxindex, tree type, tree auto_delete_vec, tree auto_delete, int use_global_delete)
{
  tree virtual_size;
  tree ptype = build_pointer_type (type);
  tree size_exp = size_in_bytes (type);


  tree tbase, tbase_init;



  tree body;


  tree loop;


  tree deallocate_expr = 0;





  tree controller = (tree) 0;


  tree block;

  if (! (((type)->type.lang_flag_5)) || ! (((type)->type.lang_flag_4)))
    {
      loop = integer_zero_node;
      goto no_destructor;
    }


  virtual_size = fold (size_binop (MULT_EXPR, size_exp, maxindex));

  tbase = build_decl (VAR_DECL, (tree) 0, ptype);
  tbase_init = build_modify_expr (tbase, NOP_EXPR,
      fold (build (PLUS_EXPR, ptype,
            base,
            virtual_size)));
  ((tbase)->decl.regdecl_flag) = 1;
  controller = build (BIND_EXPR, void_type_node, tbase, 0, 0);
  ((controller)->common.side_effects_flag) = 1;
  block = build_block (tbase, 0, 0, 0, 0);
  add_block_current_level (block);

  if (auto_delete != integer_zero_node
      && auto_delete != integer_two_node)
    {
      tree base_tbd = convert (ptype,
          build_binary_op (MINUS_EXPR,
      convert (ptr_type_node, base),
      BI_header_size,
      1));

      virtual_size = size_binop (PLUS_EXPR, virtual_size, BI_header_size);
      body = build_tree_list ((tree) 0,
         build_x_delete (ptype, base_tbd,
           2 | use_global_delete,
           virtual_size));
      body = build (COND_EXPR, void_type_node,
      build (BIT_AND_EXPR, integer_type_node,
      auto_delete, integer_one_node),
      body, integer_zero_node);
    }
  else
    body = (tree) 0;

  body = tree_cons ((tree) 0,
      build_delete (ptype, tbase, auto_delete,
      (3)|(512), 1),
      body);

  body = tree_cons ((tree) 0,
      build_modify_expr (tbase, NOP_EXPR, build (MINUS_EXPR, ptype, tbase, size_exp)),
      body);

  body = tree_cons ((tree) 0,
      build (EXIT_EXPR, void_type_node,
      build (EQ_EXPR, boolean_type_node, base, tbase)),
      body);

  loop = build (LOOP_EXPR, void_type_node, build_compound_expr (body));

  loop = tree_cons ((tree) 0, tbase_init,
      tree_cons ((tree) 0, loop, (tree) 0));
  loop = build_compound_expr (loop);

 no_destructor:


  if (auto_delete_vec == integer_zero_node
      || auto_delete_vec == integer_two_node)
    deallocate_expr = integer_zero_node;
  else
    {
      tree base_tbd;


      virtual_size = fold (size_binop (MULT_EXPR, size_exp, maxindex));

      if (! ((((type)->type.lang_flag_4)) || (((type)->type.lang_specific) && (((type)->type.lang_specific)->type_flags.vec_delete_takes_size))))

 base_tbd = base;
      else
 {
   base_tbd = convert (ptype,
         build_binary_op (MINUS_EXPR,
            convert (string_type_node, base),
            BI_header_size,
            1));

   virtual_size = size_binop (PLUS_EXPR, virtual_size, BI_header_size);
 }
      deallocate_expr = build_x_delete (ptype, base_tbd,
     2 | use_global_delete,
     virtual_size);
      if (auto_delete_vec != integer_one_node)
 deallocate_expr = build (COND_EXPR, void_type_node,
     build (BIT_AND_EXPR, integer_type_node,
     auto_delete_vec, integer_one_node),
     deallocate_expr, integer_zero_node);
    }

  if (loop && deallocate_expr != integer_zero_node)
    {
      body = tree_cons ((tree) 0, loop,
   tree_cons ((tree) 0, deallocate_expr, (tree) 0));
      body = build_compound_expr (body);
    }
  else
    body = loop;


  body = build (COND_EXPR, void_type_node,
  build (NE_EXPR, boolean_type_node, base, integer_zero_node),
  body, integer_zero_node);
  body = build1 (NOP_EXPR, void_type_node, body);

  if (controller)
    {
      ((controller)->exp.operands[1]) = body;
      return controller;
    }
  else
    return convert (void_type_node, body);
}





static tree
build_array_eh_cleanup(tree base, tree count, tree type) asm("_build_array_eh_cleanup");
static tree
build_array_eh_cleanup(tree base, tree count, tree type)
{
  tree expr = build_vec_delete_1 (base, count, type, integer_two_node,
      integer_zero_node, 0);
  return expr;
}
tree
expand_vec_init(tree decl, tree base, tree maxindex, tree init, int from_array) asm("_expand_vec_init");
tree
expand_vec_init(tree decl, tree base, tree maxindex, tree init, int from_array)
{
  tree rval;
  tree iterator, base2 = (tree) 0;
  tree type = ((((base)->common.type))->common.type);
  tree size;

  maxindex = convert (integer_type_node, maxindex);
  if (maxindex == error_mark_node)
    return error_mark_node;

  if (current_function_decl == (tree) 0)
    {
      rval = make_tree_vec (3);
      ((rval)->vec.a[0]) = base;
      ((rval)->vec.a[1]) = maxindex;
      ((rval)->vec.a[2]) = init;
      return rval;
    }

  size = size_in_bytes (type);



  rval = get_temp_regvar (build_pointer_type (type),
     convert (build_pointer_type (type), null_pointer_node));
  base = default_conversion (base);
  base = convert (build_pointer_type (type), base);
  expand_assignment (rval, base, 0, 0);
  base = get_temp_regvar (build_pointer_type (type), base);

  if (init != (tree) 0
      && ((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR
      && ((init)->common.type) == ((decl)->common.type))
    {

      tree elts = ((init)->exp.operands[1]);
      tree baseref = build1 (INDIRECT_REF, type, base);
      tree baseinc = build (PLUS_EXPR, build_pointer_type (type), base, size);
      int host_i = ((maxindex)->int_cst.int_cst_low);

      if ((((type)->type.lang_flag_5)))
 {
   while (elts)
     {
       host_i -= 1;
       expand_aggr_init (baseref, ((elts)->list.value), 0, 0);

       expand_assignment (base, baseinc, 0, 0);
       elts = ((elts)->common.chain);
     }

   if (host_i >= 0)
     {
       if (((type)->type.needs_constructing_flag) == 0)
  {
    if (obey_regdecls)
      use_variable (((base)->decl.rtl));
    goto done_init;
  }

       iterator = get_temp_regvar (integer_type_node,
       build_int_2_wide ((int) (host_i), (int) (0)));
       init = (tree) 0;
       goto init_by_default;
     }
 }
      else
 while (elts)
   {
     expand_assignment (baseref, ((elts)->list.value), 0, 0);

     expand_assignment (base, baseinc, 0, 0);
     elts = ((elts)->common.chain);
   }

      if (obey_regdecls)
 use_variable (((base)->decl.rtl));
    }
  else
    {
      tree itype;

      iterator = get_temp_regvar (integer_type_node, maxindex);

    init_by_default:



      if (from_array)
 {

   if (decl == (tree) 0)
     {
       sorry ("initialization of array from dissimilar array type");
       return error_mark_node;
     }
   if (init)
     {
       base2 = default_conversion (init);
       itype = ((base2)->common.type);
       base2 = get_temp_regvar (itype, base2);
       itype = ((itype)->common.type);
     }
   else if (((type)->type.lang_specific)
     && ((type)->type.needs_constructing_flag)
     && ! (((type)->type.lang_specific)->type_flags.has_default_ctor))
     {
       error ("initializer ends prematurely");
       return error_mark_node;
     }
 }

      expand_start_cond (build (GE_EXPR, boolean_type_node,
    iterator, integer_zero_node), 0);
      if ((((type)->type.lang_flag_4)))
 start_protect ();
      expand_start_loop_continue_elsewhere (1);

      if (from_array)
 {
   tree to = build1 (INDIRECT_REF, type, base);
   tree from;

   if (base2)
     from = build1 (INDIRECT_REF, itype, base2);
   else
     from = (tree) 0;

   if (from_array == 2)
     expand_expr_stmt (build_modify_expr (to, NOP_EXPR, from));
   else if (((type)->type.needs_constructing_flag))
     expand_aggr_init (to, from, 0, 0);
   else if (from)
     expand_assignment (to, from, 0, 0);
   else
     my_friendly_abort (57);
 }
      else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
 {
   if (init != 0)
     sorry ("cannot initialize multi-dimensional array with initializer");
   expand_vec_init (decl, build1 (NOP_EXPR, build_pointer_type (((type)->common.type)), base),
      array_type_nelts (type), 0, 0);
 }
      else
 expand_aggr_init (build1 (INDIRECT_REF, type, base), init, 0, 0);

      expand_assignment (base,
    build (PLUS_EXPR, build_pointer_type (type), base, size),
    0, 0);
      if (base2)
 expand_assignment (base2,
      build (PLUS_EXPR, build_pointer_type (type), base2, size), 0, 0);
      expand_loop_continue_here ();
      expand_exit_loop_if_false (0, build (NE_EXPR, boolean_type_node,
        build (PREDECREMENT_EXPR, integer_type_node, iterator, integer_one_node), minus_one));

      if (obey_regdecls)
 {
   use_variable (((base)->decl.rtl));
   if (base2)
     use_variable (((base2)->decl.rtl));
 }
      expand_end_loop ();
      if ((((type)->type.lang_flag_4)))
 end_protect (build_array_eh_cleanup (rval,
          build_binary_op (MINUS_EXPR,
             maxindex,
             iterator,
             1),
          type));
      expand_end_cond ();
      if (obey_regdecls)
 use_variable (((iterator)->decl.rtl));
    }
 done_init:

  if (obey_regdecls)
    use_variable (((rval)->decl.rtl));
  return rval;
}
tree
build_x_delete(tree type, tree addr, int which_delete, tree virtual_size) asm("_build_x_delete");
tree
build_x_delete(tree type, tree addr, int which_delete, tree virtual_size)
{
  int use_global_delete = which_delete & 1;
  int use_vec_delete = !!(which_delete & 2);
  tree rval;
  n64_enum_tree_code code = use_vec_delete ? VEC_DELETE_EXPR : DELETE_EXPR;

  if (! use_global_delete && ((((type)->common.type))->type.lang_specific)
      && ((((((type)->common.type))->type.lang_specific)->type_flags.gets_delete) & (1 << use_vec_delete)))
    rval = build_opfncall (code, (3), addr, virtual_size, (tree) 0);
  else
    rval = build_builtin_call (void_type_node, use_vec_delete ? BIVD : BID,
          build_tree_list ((tree) 0, addr));
  return rval;
}
tree
build_delete(tree type, tree addr, tree auto_delete, int flags, int use_global_delete) asm("_build_delete");
tree
build_delete(tree type, tree addr, tree auto_delete, int flags, int use_global_delete)
{
  tree function, parms;
  tree member;
  tree expr;
  tree ref;
  int ptr;

  if (addr == error_mark_node)
    return error_mark_node;



  if (type == error_mark_node)
    return error_mark_node;

  type = ((type)->type.main_variant);

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE)
    {
      type = ((((type)->common.type))->type.main_variant);
      if (((type)->type.size) == 0)
 {
   incomplete_type_error (0, type);
   return error_mark_node;
 }
      if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
 goto handle_array;
      if (! (((type)->type.lang_flag_5)))
 {

   return build_builtin_call (void_type_node, BID,
         build_tree_list ((tree) 0, addr));
 }
      if (((addr)->common.side_effects_flag))
 addr = save_expr (addr);


      addr = convert_force (build_pointer_type (type), addr, 0);
      ref = build_indirect_ref (addr, ((void *)0));
      ptr = 1;
    }
  else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {
    handle_array:
      if (((addr)->common.side_effects_flag))
 addr = save_expr (addr);
      if (((type)->type.values) == (tree) 0)
 {
   error ("unknown array size in delete");
   return error_mark_node;
 }
      return build_vec_delete (addr, array_type_nelts (type),
          c_sizeof_nowarn (((type)->common.type)),
          auto_delete, integer_two_node,
          use_global_delete);
    }
  else
    {



      addr = build_unary_op (ADDR_EXPR, addr, 0);
      if (((addr)->common.side_effects_flag))
 addr = save_expr (addr);

      if (((addr)->common.constant_flag))
 addr = convert_pointer_to (type, addr);
      else
 addr = convert_force (build_pointer_type (type), addr, 0);

      if (((n64_enum_tree_code) (addr)->common.code) == NOP_EXPR
   && ((addr)->exp.operands[0]) == current_class_decl)
 ref = C_C_D;
      else
 ref = build_indirect_ref (addr, ((void *)0));
      ptr = 0;
    }

  my_friendly_assert ((((type)->type.lang_flag_5)), 220);

  if (! (((type)->type.lang_flag_4)))
    {
      if (auto_delete == integer_zero_node)
 return void_zero_node;



      if (((((type)->type.lang_specific)->type_flags.gets_delete) & 1) && !use_global_delete)
 {
   tree virtual_size = c_sizeof_nowarn (type);
   return build_opfncall (DELETE_EXPR, (3), addr,
     virtual_size, (tree) 0);
 }


      return build_builtin_call (void_type_node, BID,
     build_tree_list ((tree) 0, addr));
    }
  parms = build_tree_list ((tree) 0, addr);




  if ((((type)->type.lang_flag_2)))
    {
      tree dtor = (((((((type)->type.maxval))->vec.a[0]))->decl.lang_specific)->main_decl_variant);
      tree basetypes = ((type)->type.binfo);
      tree passed_auto_delete;
      tree do_delete = (tree) 0;

      if (use_global_delete)
 {
   tree cond = fold (build (BIT_AND_EXPR, integer_type_node,
       auto_delete, integer_one_node));
   tree call = build_builtin_call
     (void_type_node, BID, build_tree_list ((tree) 0, addr));

   cond = fold (build (COND_EXPR, void_type_node, cond,
         call, void_zero_node));
   if (cond != void_zero_node)
     do_delete = cond;

   passed_auto_delete = fold (build (BIT_AND_EXPR, integer_type_node,
         auto_delete, integer_two_node));
 }
      else
 passed_auto_delete = auto_delete;

      if (flags & (1))
 {
   n64_enum_access_type access = compute_access (basetypes, dtor);

   if (access == access_private)
     {
       if (flags & (2))
  cp_error ("destructor for type `%T' is private in this scope", type);
       return error_mark_node;
     }
   else if (access == access_protected)
     {
       if (flags & (2))
  cp_error ("destructor for type `%T' is protected in this scope", type);
       return error_mark_node;
     }
 }



      if (((dtor)->decl.vindex)
   && ! (flags & (8))
   && ((n64_enum_tree_code) (auto_delete)->common.code) != PARM_DECL
   && (ptr == 1 || ! resolves_to_fixed_type_p (ref, 0)))
 {
   tree binfo, basetype;




   dtor = ((((((dtor)->decl.context))->type.maxval))->vec.a[0]);
   basetype = (((dtor)->decl.lang_specific)->decl_flags.context);
   binfo = get_binfo (basetype,
        ((((((parms)->list.value))->common.type))->common.type),
        0);
   expr = convert_pointer_to_real (binfo, ((parms)->list.value));
   if (expr != ((parms)->list.value))
     {
       expr = fold (expr);
       ref = build_indirect_ref (expr, ((void *)0));
       ((parms)->list.value) = expr;
     }
   function = build_vfn_ref (&((parms)->list.value), ref, ((dtor)->decl.vindex));
   if (function == error_mark_node)
     return error_mark_node;
   ((function)->common.type) = build_pointer_type (((dtor)->common.type));
   ((parms)->common.chain) = build_tree_list ((tree) 0, passed_auto_delete);
   expr = build_function_call (function, parms);
   if (do_delete)
     expr = build (COMPOUND_EXPR, void_type_node, expr, do_delete);
   if (ptr && (flags & (512)) == 0)
     {




       tree ifexp = build_binary_op(NE_EXPR, addr, integer_zero_node,1);





       expr = build (COND_EXPR, void_type_node,
       ifexp, expr, void_zero_node);
     }
 }
      else
 {
   tree ifexp;

   if ((flags & (512))
       || ((n64_enum_tree_code) (ref)->common.code) == VAR_DECL
       || ((n64_enum_tree_code) (ref)->common.code) == PARM_DECL
       || ((n64_enum_tree_code) (ref)->common.code) == COMPONENT_REF
       || ((n64_enum_tree_code) (ref)->common.code) == ARRAY_REF)

     ifexp = integer_one_node;
   else


     ifexp = build_binary_op (NE_EXPR, addr, integer_zero_node, 1);



   my_friendly_assert (((dtor)->decl.initial) != void_type_node, 221);

   ((parms)->common.chain) = build_tree_list ((tree) 0, passed_auto_delete);
   expr = build_function_call (dtor, parms);
   if (do_delete)
     expr = build (COMPOUND_EXPR, void_type_node, expr, do_delete);

   if (ifexp != integer_one_node)
     expr = build (COND_EXPR, void_type_node,
     ifexp, expr, void_zero_node);
 }
      return expr;
    }
  else
    {

      tree binfos = (((((type)->type.binfo)))->vec.a[4]);
      int i, n_baseclasses = binfos ? ((binfos)->vec.length) : 0;
      tree base_binfo = n_baseclasses > 0 ? ((binfos)->vec.a[0]) : (tree) 0;
      tree exprstmt = (tree) 0;
      tree parent_auto_delete = auto_delete;
      tree cond;





      if (((((type)->type.lang_specific)->type_flags.gets_delete) & 1) && !use_global_delete)
 {
   parent_auto_delete = integer_zero_node;
   if (auto_delete == integer_zero_node)
     cond = (tree) 0;
   else
     {
       tree virtual_size;



       virtual_size = c_sizeof_nowarn (type);

       expr = build_opfncall (DELETE_EXPR, (3), addr,
         virtual_size, (tree) 0);
       if (expr == error_mark_node)
  return error_mark_node;
       if (auto_delete != integer_one_node)
  cond = build (COND_EXPR, void_type_node,
         build (BIT_AND_EXPR, integer_type_node,
         auto_delete, integer_one_node),
         expr, void_zero_node);
       else
  cond = expr;
     }
 }
      else if (base_binfo == (tree) 0
        || (((base_binfo)->common.static_flag) == 0
     && ! (((((base_binfo)->common.type))->type.lang_flag_4))))
 {
   tree virtual_size;



   virtual_size = c_sizeof_nowarn (type);

   cond = build (COND_EXPR, void_type_node,
   build (BIT_AND_EXPR, integer_type_node, auto_delete, integer_one_node),
   build_builtin_call (void_type_node, BID,
         build_tree_list ((tree) 0, addr)),
   void_zero_node);
 }
      else
 cond = (tree) 0;

      if (cond)
 exprstmt = build_tree_list ((tree) 0, cond);

      if (base_binfo
   && ! ((base_binfo)->common.static_flag)
   && (((((base_binfo)->common.type))->type.lang_flag_4)))
 {
   tree this_auto_delete;

   if (((((base_binfo))->vec.a[1]) == integer_zero_node))
     this_auto_delete = parent_auto_delete;
   else
     this_auto_delete = integer_zero_node;

   expr = build_delete (build_pointer_type (((base_binfo)->common.type)), addr,
          this_auto_delete, flags, 0);
   exprstmt = tree_cons ((tree) 0, expr, exprstmt);
 }


      for (i = 1; i < n_baseclasses; i++)
 {
   base_binfo = ((binfos)->vec.a[i]);
   if (! (((((base_binfo)->common.type))->type.lang_flag_4))
       || ((base_binfo)->common.static_flag))
     continue;


   expr = fold (build (PLUS_EXPR, build_pointer_type (((base_binfo)->common.type)),
         addr, (((base_binfo))->vec.a[1])));

   expr = build_delete (build_pointer_type (((base_binfo)->common.type)), expr,
          integer_zero_node,
          flags, 0);

   exprstmt = tree_cons ((tree) 0, expr, exprstmt);
 }

      for (member = ((type)->type.values); member; member = ((member)->common.chain))
 {
   if (((n64_enum_tree_code) (member)->common.code) != FIELD_DECL)
     continue;
   if ((((((member)->common.type))->type.lang_flag_4)))
     {
       tree this_member = build_component_ref (ref, ((member)->decl.name), 0, 0);
       tree this_type = ((member)->common.type);
       expr = build_delete (this_type, this_member, integer_two_node, flags, 0);
       exprstmt = tree_cons ((tree) 0, expr, exprstmt);
     }
 }

      if (exprstmt)
 return build_compound_expr (exprstmt);

      return void_zero_node;
    }
}



tree
build_vbase_delete(tree type, tree decl) asm("_build_vbase_delete");
tree
build_vbase_delete(tree type, tree decl)
{
  tree vbases = (((type)->type.lang_specific)->vbases);
  tree result = (tree) 0;
  tree addr = build_unary_op (ADDR_EXPR, decl, 0);

  my_friendly_assert (addr != error_mark_node, 222);

  while (vbases)
    {
      tree this_addr = convert_force (build_pointer_type (((vbases)->common.type)),
          addr, 0);
      result = tree_cons ((tree) 0,
     build_delete (((this_addr)->common.type), this_addr,
     integer_zero_node,
     (3)|(512), 0),
     result);
      vbases = ((vbases)->common.chain);
    }
  return build_compound_expr (nreverse (result));
}
tree
build_vec_delete(tree base, tree maxindex, tree elt_size, tree auto_delete_vec, tree auto_delete, int use_global_delete) asm("_build_vec_delete");
tree
build_vec_delete(tree base, tree maxindex, tree elt_size, tree auto_delete_vec, tree auto_delete, int use_global_delete)
{
  tree type;

  if (((n64_enum_tree_code) (base)->common.code) == CP_OFFSET_REF)
    base = resolve_offset_ref (base);

  type = ((base)->common.type);

  base = stabilize_reference (base);


  if (((base)->common.side_effects_flag))
    base = save_expr (base);

  if (((n64_enum_tree_code) (type)->common.code) == POINTER_TYPE)
    {

      tree cookie_addr = build (MINUS_EXPR, build_pointer_type (BI_header_type),
    base, BI_header_size);
      tree cookie = build_indirect_ref (cookie_addr, ((void *)0));
      maxindex = build_component_ref (cookie, nc_nelts_field_id, 0, 0);
      do
 type = ((type)->common.type);
      while (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE);
    }
  else if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    {

      maxindex = array_type_nelts_total (type);
      while (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
 type = ((type)->common.type);
      base = build_unary_op (ADDR_EXPR, base, 1);
    }
  else
    {
      error ("type to vector delete is neither pointer or array type");
      return error_mark_node;
    }

  return build_vec_delete_1 (base, maxindex, type, auto_delete_vec, auto_delete,
        use_global_delete);
}

