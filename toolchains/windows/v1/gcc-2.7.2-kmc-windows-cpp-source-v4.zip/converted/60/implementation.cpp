// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/emit-rtl.c
/* Emit RTL for the GNU C-Compiler expander.
   Copyright (C) 1987, 88, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int strict_memory_address_p(...) asm("_strict_memory_address_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int simplejump_p(...) asm("_simplejump_p");
extern int rtl_in_saveable_obstack(...) asm("_rtl_in_saveable_obstack");
struct n64_tag__obstack_chunk;
struct n64_tag_args_size;
struct n64_tag_bc_label;
struct n64_tag_bc_labelref;
struct n64_tag_bc_seg;
struct n64_tag_bc_segreloc;
struct n64_tag_bc_segsym;
struct n64_tag_bc_sym;
struct n64_tag_binary_operator;
struct n64_tag_function;
struct n64_tag_increment_operator;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_sequence_stack;
struct n64_tag_simple_obstack_stack;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_unary_operator;
struct n64_tag_var_refs_queue;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");




enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union n64_tag_tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_var_refs_queue
{
  rtx modified;
  n64_enum_machine_mode promoted_mode;
  int unsignedp;
  struct n64_tag_var_refs_queue *next;
};






struct n64_tag_sequence_stack
{

  rtx first, last;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *next;
};

extern struct n64_tag_sequence_stack *sequence_stack;



struct n64_tag_simple_obstack_stack
{
  struct n64_tag_obstack *obstack;
  struct n64_tag_simple_obstack_stack *next;
};




struct n64_tag_function
{
  struct n64_tag_function *next;


  char *name;
  tree decl;
  int pops_args;
  int returns_struct;
  int returns_pcc_struct;
  int needs_context;
  int calls_setjmp;
  int calls_longjmp;
  int calls_alloca;
  int has_nonlocal_label;
  int has_nonlocal_goto;
  int contains_functions;
  rtx nonlocal_goto_handler_slot;
  rtx nonlocal_goto_stack_level;
  tree nonlocal_labels;
  int args_size;
  int pretend_args_size;
  rtx arg_offset_rtx;
  int varargs;
  int stdarg;
  int max_parm_reg;
  rtx *parm_reg_stack_loc;
  int outgoing_args_size;
  rtx return_rtx;
  rtx cleanup_label;
  rtx return_label;
  rtx save_expr_regs;
  rtx stack_slot_list;
  rtx parm_birth_insn;
  int frame_offset;
  rtx tail_recursion_label;
  rtx tail_recursion_reentry;
  rtx internal_arg_pointer;
  rtx arg_pointer_save_area;
  tree rtl_expr_chain;
  rtx last_parm_insn;
  tree context_display;
  tree trampoline_list;
  int function_call_count;
  struct temp_slot *temp_slots;
  int temp_slot_level;


  struct n64_tag_var_refs_queue *fixup_var_refs_queue;


  struct nesting *block_stack;
  struct nesting *stack_block_stack;
  struct nesting *cond_stack;
  struct nesting *loop_stack;
  struct nesting *case_stack;
  struct nesting *nesting_stack;
  int nesting_depth;
  int block_start_count;
  tree last_expr_type;
  rtx last_expr_value;
  int expr_stmts_for_value;
  char *emit_filename;
  int emit_lineno;
  struct goto_fixup *goto_fixup_chain;


  int pending_stack_adjust;
  int inhibit_defer_pop;
  tree cleanups_this_call;
  rtx saveregs_value;
  rtx apply_args_value;
  rtx forced_labels;


  int reg_rtx_no;
  int first_label_num;
  rtx first_insn;
  rtx last_insn;
  tree sequence_rtl_expr;
  struct n64_tag_sequence_stack *sequence_stack;
  int cur_insn_uid;
  int last_linenum;
  char *last_filename;
  char *regno_pointer_flag;
  int regno_pointer_flag_length;
  rtx *regno_reg_rtx;


  tree permanent_type_chain;
  tree temporary_type_chain;
  tree permanent_type_end;
  tree temporary_type_end;
  tree pending_sizes;
  int immediate_size_expand;


  int all_types_permanent;
  struct momentary_level *momentary_stack;
  char *maybepermanent_firstobj;
  char *temporary_firstobj;
  char *momentary_firstobj;
  char *momentary_function_firstobj;
  struct n64_tag_obstack *current_obstack;
  struct n64_tag_obstack *function_obstack;
  struct n64_tag_obstack *function_maybepermanent_obstack;
  struct n64_tag_obstack *expression_obstack;
  struct n64_tag_obstack *saveable_obstack;
  struct n64_tag_obstack *rtl_obstack;
  struct n64_tag_simple_obstack_stack *inline_obstacks;


  int uses_const_pool;


  int uses_pic_offset_table;

  struct machine_function *machine;


  rtx epilogue_delay_list;


  struct constant_descriptor **const_rtx_hash_table;
  struct pool_sym **const_rtx_sym_hash_table;
  struct pool_constant *first_pool, *last_pool;
  int pool_offset;
};


extern tree inline_function_decl;




extern rtx return_label;



extern rtx stack_slot_list;



struct n64_tag_function *find_function_data (tree) asm("_find_function_data");


extern struct n64_tag_function *outer_function_chain;




extern tree *identify_blocks (tree, rtx) asm("_identify_blocks");




extern void (*save_machine_status)(...);
extern void (*restore_machine_status)(...);


extern void save_varasm_status (struct n64_tag_function *) asm("_save_varasm_status");
extern void restore_varasm_status (struct n64_tag_function *) asm("_restore_varasm_status");
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;






extern tree nonlocal_labels;







extern int pending_stack_adjust;




extern tree cleanups_this_call;






extern int target_temp_slot_level;





struct n64_tag_args_size
{
  int constant;
  tree var;
};
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;






enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;


typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];
extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");
extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");



extern void emit_push_insn (rtx, n64_enum_machine_mode, tree, rtx, int, int, rtx, int, rtx, rtx) asm("_emit_push_insn")
                               ;


extern void emit_library_call (rtx orgfun, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call")
                                             ;
extern rtx emit_library_call_value (rtx orgfun, rtx value, int no_queue, n64_enum_machine_mode outmode, int nargs, ...) asm("_emit_library_call_value")
                                             ;


extern rtx expand_assignment (tree, tree, int, int) asm("_expand_assignment");





extern rtx store_expr (tree, rtx, int) asm("_store_expr");





extern rtx force_operand (rtx, rtx) asm("_force_operand");





extern rtx expand_expr (tree, rtx, n64_enum_machine_mode, n64_enum_expand_modifier) asm("_expand_expr")
                               ;




extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");



extern void expand_cleanups_to (tree) asm("_expand_cleanups_to");


extern void jumpifnot (tree, rtx) asm("_jumpifnot");


extern void jumpif (tree, rtx) asm("_jumpif");



extern void do_jump (tree, rtx, rtx) asm("_do_jump");



extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");




extern rtx expr_size (tree) asm("_expr_size");

extern rtx lookup_static_chain (tree) asm("_lookup_static_chain");



extern rtx fix_lexical_addr (rtx, tree) asm("_fix_lexical_addr");


extern rtx trampoline_address (tree) asm("_trampoline_address");



extern rtx hard_function_value (tree, tree) asm("_hard_function_value");

extern rtx prepare_call_address (rtx, tree, rtx *, int) asm("_prepare_call_address");

extern rtx expand_call (tree, rtx, int) asm("_expand_call");

extern rtx expand_shift (n64_enum_tree_code, n64_enum_machine_mode, rtx, tree, rtx, int) asm("_expand_shift");
extern rtx expand_divmod (int, n64_enum_tree_code, n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_divmod");
extern void locate_and_pad_parm (n64_enum_machine_mode, tree, int, tree, struct n64_tag_args_size *, struct n64_tag_args_size *, struct n64_tag_args_size *) asm("_locate_and_pad_parm");
extern rtx expand_inline_function (tree, tree, rtx, int, tree, rtx) asm("_expand_inline_function");

extern rtx label_rtx (tree) asm("_label_rtx");



extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");



extern n64_enum_machine_mode promote_mode (tree, n64_enum_machine_mode, int *, int) asm("_promote_mode")
                      ;



extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");

extern int output_bytecode;
extern int stack_depth;
extern int max_stack_depth;
extern void bc_expand_expr(...) asm("_bc_expand_expr");
extern void bc_output_data_constructor(...) asm("_bc_output_data_constructor");
extern void bc_store_field(...) asm("_bc_store_field");
extern void bc_load_bit_field(...) asm("_bc_load_bit_field");
extern void bc_store_bit_field(...) asm("_bc_store_bit_field");
extern void bc_push_offset_and_size(...) asm("_bc_push_offset_and_size");
extern void bc_init_mode_to_code_map(void) asm("_bc_init_mode_to_code_map");



enum n64_cpp_enum_bytecode_opcode{ neverneverland,
  drop,
  duplicate,
  over,
  setstackSI,
  adjstackSI,
  constQI,
  constHI,
  constSI,
  constDI,
  constSF,
  constDF,
  constXF,
  constP,
  loadQI,
  loadHI,
  loadSI,
  loadDI,
  loadSF,
  loadDF,
  loadXF,
  loadP,
  storeQI,
  storeHI,
  storeSI,
  storeDI,
  storeSF,
  storeDF,
  storeXF,
  storeP,
  storeBLK,
  clearBLK,
  addconstPSI,
  newlocalSI,
  localP,
  argP,
  convertQIHI,
  convertHISI,
  convertSIDI,
  convertQISI,
  convertQUHU,
  convertHUSU,
  convertSUDU,
  convertQUSU,
  convertSFDF,
  convertDFXF,
  convertHIQI,
  convertSIHI,
  convertDISI,
  convertSIQI,
  convertSUQU,
  convertDFSF,
  convertXFDF,
  convertSISF,
  convertSIDF,
  convertSIXF,
  convertSUSF,
  convertSUDF,
  convertSUXF,
  convertDISF,
  convertDIDF,
  convertDIXF,
  convertDUSF,
  convertDUDF,
  convertDUXF,
  convertSFSI,
  convertDFSI,
  convertXFSI,
  convertSFSU,
  convertDFSU,
  convertXFSU,
  convertSFDI,
  convertDFDI,
  convertXFDI,
  convertSFDU,
  convertDFDU,
  convertXFDU,
  convertPSI,
  convertSIP,
  convertSIT,
  convertDIT,
  convertSFT,
  convertDFT,
  convertXFT,
  convertPT,
  zxloadBI,
  sxloadBI,
  sstoreBI,
  addSI,
  addDI,
  addSF,
  addDF,
  addXF,
  addPSI,
  subSI,
  subDI,
  subSF,
  subDF,
  subXF,
  subPP,
  mulSI,
  mulDI,
  mulSU,
  mulDU,
  mulSF,
  mulDF,
  mulXF,
  divSI,
  divDI,
  divSU,
  divDU,
  divSF,
  divDF,
  divXF,
  modSI,
  modDI,
  modSU,
  modDU,
  andSI,
  andDI,
  iorSI,
  iorDI,
  xorSI,
  xorDI,
  lshiftSI,
  lshiftSU,
  lshiftDI,
  lshiftDU,
  rshiftSI,
  rshiftSU,
  rshiftDI,
  rshiftDU,
  ltSI,
  ltSU,
  ltDI,
  ltDU,
  ltSF,
  ltDF,
  ltXF,
  ltP,
  leSI,
  leSU,
  leDI,
  leDU,
  leSF,
  leDF,
  leXF,
  leP,
  geSI,
  geSU,
  geDI,
  geDU,
  geSF,
  geDF,
  geXF,
  geP,
  gtSI,
  gtSU,
  gtDI,
  gtDU,
  gtSF,
  gtDF,
  gtXF,
  gtP,
  eqSI,
  eqDI,
  eqSF,
  eqDF,
  eqXF,
  eqP,
  neSI,
  neDI,
  neSF,
  neDF,
  neXF,
  neP,
  negSI,
  negDI,
  negSF,
  negDF,
  negXF,
  notSI,
  notDI,
  notT,
  predecQI,
  predecHI,
  predecSI,
  predecDI,
  predecP,
  predecSF,
  predecDF,
  predecXF,
  predecBI,
  preincQI,
  preincHI,
  preincSI,
  preincDI,
  preincP,
  preincSF,
  preincDF,
  preincXF,
  preincBI,
  postdecQI,
  postdecHI,
  postdecSI,
  postdecDI,
  postdecP,
  postdecSF,
  postdecDF,
  postdecXF,
  postdecBI,
  postincQI,
  postincHI,
  postincSI,
  postincDI,
  postincP,
  postincSF,
  postincDF,
  postincXF,
  postincBI,
  xjumpif,
  xjumpifnot,
  jump,
  jumpP,
  caseSI,
  caseSU,
  caseDI,
  caseDU,
  call,
  returnP,
  ret,
  linenote,
  LAST_AND_UNUSED_OPCODE
};
typedef __underlying_type(enum n64_cpp_enum_bytecode_opcode) n64_enum_bytecode_opcode;

enum n64_cpp_enum_typecode{

QIcode,
QUcode,
HIcode,
HUcode,
SIcode,
SUcode,
DIcode,
DUcode,
SFcode,
DFcode,
XFcode,
Pcode,
Tcode,


  LAST_AND_UNUSED_TYPECODE
};
typedef __underlying_type(enum n64_cpp_enum_typecode) n64_enum_typecode;

extern void bc_expand_conversion(...) asm("_bc_expand_conversion");
extern void bc_expand_truth_conversion(...) asm("_bc_expand_truth_conversion");
extern void bc_expand_binary_operation(...) asm("_bc_expand_binary_operation");
extern void bc_expand_unary_operation(...) asm("_bc_expand_unary_operation");

struct n64_tag_binary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
  n64_enum_typecode arg1;
};

extern struct n64_tag_binary_operator optab_plus_expr[];
extern struct n64_tag_binary_operator optab_minus_expr[];
extern struct n64_tag_binary_operator optab_mult_expr[];
extern struct n64_tag_binary_operator optab_trunc_div_expr[];
extern struct n64_tag_binary_operator optab_trunc_mod_expr[];
extern struct n64_tag_binary_operator optab_rdiv_expr[];
extern struct n64_tag_binary_operator optab_bit_and_expr[];
extern struct n64_tag_binary_operator optab_bit_ior_expr[];
extern struct n64_tag_binary_operator optab_bit_xor_expr[];
extern struct n64_tag_binary_operator optab_lshift_expr[];
extern struct n64_tag_binary_operator optab_rshift_expr[];
extern struct n64_tag_binary_operator optab_truth_and_expr[];
extern struct n64_tag_binary_operator optab_truth_or_expr[];
extern struct n64_tag_binary_operator optab_lt_expr[];
extern struct n64_tag_binary_operator optab_le_expr[];
extern struct n64_tag_binary_operator optab_ge_expr[];
extern struct n64_tag_binary_operator optab_gt_expr[];
extern struct n64_tag_binary_operator optab_eq_expr[];
extern struct n64_tag_binary_operator optab_ne_expr[];

struct n64_tag_unary_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode result;
  n64_enum_typecode arg0;
};

extern struct n64_tag_unary_operator optab_negate_expr[];
extern struct n64_tag_unary_operator optab_bit_not_expr[];
extern struct n64_tag_unary_operator optab_truth_not_expr[];

struct n64_tag_increment_operator
{
  n64_enum_bytecode_opcode opcode;
  n64_enum_typecode arg;
};

extern struct n64_tag_increment_operator optab_predecrement_expr[];
extern struct n64_tag_increment_operator optab_preincrement_expr[];
extern struct n64_tag_increment_operator optab_postdecrement_expr[];
extern struct n64_tag_increment_operator optab_postincrement_expr[];



struct n64_tag_bc_sym
{

  char *name;


  unsigned int defined:1;


  unsigned int global:1;


  unsigned int common:1;


  unsigned long int val;


  struct n64_tag_bc_sym *next;
};



struct n64_tag_bc_segsym
{
  struct n64_tag_bc_sym *sym;
  struct n64_tag_bc_segsym *next;
};



struct n64_tag_bc_segreloc
{

  unsigned int offset;


  struct n64_tag_bc_sym *sym;

  struct n64_tag_bc_segreloc *next;
};



struct n64_tag_bc_seg
{

  unsigned int alloc;


  char *data;


  unsigned int size;


  struct n64_tag_bc_segsym *syms;


  struct n64_tag_bc_segreloc *relocs;
};



struct n64_tag_bc_label
{

  unsigned int offset;


  unsigned int defined:1;



  int uid;


  struct n64_tag_bc_label *next;
};






struct n64_tag_bc_labelref
{

  struct n64_tag_bc_label *label;


  unsigned int offset;


  struct n64_tag_bc_labelref *next;
};



extern void bc_initialize(void) asm("_bc_initialize");
extern int bc_begin_function(...) asm("_bc_begin_function");
extern char *bc_emit_trampoline(...) asm("_bc_emit_trampoline");
extern void bc_emit_bytecode(...) asm("_bc_emit_bytecode");
extern void bc_emit_bytecode_const(...) asm("_bc_emit_bytecode_const");
extern struct n64_tag_bc_label *bc_get_bytecode_label(void) asm("_bc_get_bytecode_label");
extern int bc_emit_bytecode_labeldef(...) asm("_bc_emit_bytecode_labeldef");
extern void bc_emit_bytecode_labelref(...) asm("_bc_emit_bytecode_labelref");
extern void bc_emit_code_labelref(...) asm("_bc_emit_code_labelref");
extern char *bc_end_function(void) asm("_bc_end_function");
extern void bc_align_const(...) asm("_bc_align_const");
extern void bc_emit_const(...) asm("_bc_emit_const");
extern void bc_emit_const_skip(...) asm("_bc_emit_const_skip");
extern int bc_emit_const_labeldef(...) asm("_bc_emit_const_labeldef");
extern void bc_emit_const_labelref(...) asm("_bc_emit_const_labelref");
extern void bc_align_data(...) asm("_bc_align_data");
extern void bc_emit_data(...) asm("_bc_emit_data");
extern void bc_emit_data_skip(...) asm("_bc_emit_data_skip");
extern int bc_emit_data_labeldef(...) asm("_bc_emit_data_labeldef");
extern void bc_emit_data_labelref(...) asm("_bc_emit_data_labelref");
extern int bc_define_pointer(...) asm("_bc_define_pointer");
extern int bc_emit_common(...) asm("_bc_emit_common");
extern void bc_globalize_label(...) asm("_bc_globalize_label");
extern void bc_text(void) asm("_bc_text");
extern void bc_data(void) asm("_bc_data");
extern void bc_align(...) asm("_bc_align");
extern void bc_emit(...) asm("_bc_emit");
extern void bc_emit_skip(...) asm("_bc_emit_skip");
extern int bc_emit_labeldef(...) asm("_bc_emit_labeldef");
extern void bc_emit_labelref(...) asm("_bc_emit_labelref");
extern void bc_write_file(...) asm("_bc_write_file");


n64_enum_machine_mode byte_mode;
n64_enum_machine_mode word_mode;
n64_enum_machine_mode ptr_mode;




int reg_rtx_no = (((68)) + 3) + 1;




static int label_num = 1;



static int first_label_num;





static int last_label_num;




static int base_label_num;



static int no_line_numbers;






rtx pc_rtx;
rtx cc0_rtx;
rtx cc1_rtx;
rtx const0_rtx;
rtx const1_rtx;
rtx const2_rtx;
rtx constm1_rtx;
rtx const_true_rtx;





rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];

double dconst0;
double dconst1;
double dconst2;
double dconstm1;
rtx stack_pointer_rtx;
rtx frame_pointer_rtx;
rtx hard_frame_pointer_rtx;
rtx arg_pointer_rtx;
rtx struct_value_rtx;
rtx struct_value_incoming_rtx;
rtx static_chain_rtx;
rtx static_chain_incoming_rtx;
rtx pic_offset_table_rtx;

rtx virtual_incoming_args_rtx;
rtx virtual_stack_vars_rtx;
rtx virtual_stack_dynamic_rtx;
rtx virtual_outgoing_args_rtx;
static rtx const_int_rtx[64 * 2 + 1];







static rtx first_insn = 
                       ((void *)0)
                           ;
static rtx last_insn = 
                      ((void *)0)
                          ;





tree sequence_rtl_expr = 
                        ((void *)0)
                            ;




static int cur_insn_uid = 1;




static int last_linenum = 0;
static char *last_filename = 0;







char *regno_pointer_flag;
int regno_pointer_flag_length;




rtx *regno_reg_rtx;






struct n64_tag_sequence_stack *sequence_stack;
static struct n64_tag_sequence_stack *sequence_element_free_list;
static rtx sequence_result[5];

extern int rtx_equal_function_value_matters;



extern char *emit_filename;
extern int emit_lineno;

rtx change_address(...) asm("_change_address");
void init_emit(void) asm("_init_emit");

extern struct n64_tag_obstack *rtl_obstack;

extern int stack_depth;
extern int max_stack_depth;
rtx
gen_rtx (n64_enum_rtx_code code, n64_enum_machine_mode mode, ...) asm("_gen_rtx");
rtx
gen_rtx (n64_enum_rtx_code code, n64_enum_machine_mode mode, ...)
{




  va_list p;
  register int i;
  register char *fmt;
  register rtx rt_val;

  
 __builtin_va_start(
 p
 ,
 mode
 )
                   ;






  if (code == CONST_INT)
    {
      int arg = 
                         __builtin_va_arg(
                         p
                         ,
                         int
                         )
                                                  ;

      if (arg >= - 64 && arg <= 64)
 return const_int_rtx[arg + 64];

      if (const_true_rtx && arg == 1)
 return const_true_rtx;

      rt_val = rtx_alloc (code);
      ((rt_val)->fld[0].rtwint) = arg;
    }
  else if (code == REG)
    {
      int regno = 
                 __builtin_va_arg(
                 p
                 ,
                 int
                 )
                                ;
      if (frame_pointer_rtx && regno == (0 + 30) && mode == ((target_flags & 0x00000002) ? DImode : SImode)
   && ! reload_in_progress)
 return frame_pointer_rtx;






      if (arg_pointer_rtx && regno == 0 && mode == ((target_flags & 0x00000002) ? DImode : SImode)
   && ! reload_in_progress)
 return arg_pointer_rtx;

      if (stack_pointer_rtx && regno == (0 + 29) && mode == ((target_flags & 0x00000002) ? DImode : SImode)
   && ! reload_in_progress)
 return stack_pointer_rtx;
      else
 {
   rt_val = rtx_alloc (code);
   rt_val->mode = mode;
   ((rt_val)->fld[0].rtint) = regno;
   return rt_val;
 }
    }
  else
    {
      rt_val = rtx_alloc (code);
      rt_val->mode = mode;

      fmt = (rtx_format[(int)(code)]);
      for (i = 0; i < (rtx_length[(int)(code)]); i++)
 {
   switch (*fmt++)
     {
     case '0':
       break;

     case 'i':
       ((rt_val)->fld[i].rtint) = 
                         __builtin_va_arg(
                         p
                         ,
                         int
                         )
                                        ;
       break;

     case 'w':
       ((rt_val)->fld[i].rtwint) = 
                          __builtin_va_arg(
                          p
                          ,
                          int
                          )
                                                   ;
       break;

     case 's':
       ((rt_val)->fld[i].rtstr) = 
                         __builtin_va_arg(
                         p
                         ,
                         char *
                         )
                                           ;
       break;

     case 'e':
     case 'u':
       ((rt_val)->fld[i].rtx) = 
                         __builtin_va_arg(
                         p
                         ,
                         rtx
                         )
                                        ;
       break;

     case 'E':
       ((rt_val)->fld[i].rtvec) = 
                         __builtin_va_arg(
                         p
                         ,
                         rtvec
                         )
                                          ;
       break;

     default:
       abort ();
     }
 }
    }
  
 __builtin_va_end(
 p
 )
           ;
  return rt_val;
}
rtvec
gen_rtvec (int n, ...) asm("_gen_rtvec");
rtvec
gen_rtvec (int n, ...)
{



  int i;
  va_list p;
  rtx *vector;

  
 __builtin_va_start(
 p
 ,
 n
 )
                ;





  if (n == 0)
    return (rtvec) 0;

  vector = (rtx *) 
                  __builtin_alloca((
                  n * sizeof (rtx)
                  ))
                                           ;

  for (i = 0; i < n; i++)
    vector[i] = 
               __builtin_va_arg(
               p
               ,
               rtx
               )
                              ;
  
 __builtin_va_end(
 p
 )
           ;

  return gen_rtvec_v (n, vector);
}

rtvec
gen_rtvec_v(int n, rtx *argp) asm("_gen_rtvec_v");
rtvec
gen_rtvec_v(int n, rtx *argp)
{
  register int i;
  register rtvec rt_val;

  if (n == 0)
    return (rtvec) 0;

  rt_val = rtvec_alloc (n);

  for (i = 0; i < n; i++)
    rt_val->elem[i].rtx = *argp++;

  return rt_val;
}




rtx
gen_reg_rtx(n64_enum_machine_mode mode) asm("_gen_reg_rtx");
rtx
gen_reg_rtx(n64_enum_machine_mode mode)
{
  register rtx val;





  if (reload_in_progress || reload_completed)
    abort ();

  if ((mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT
      || (mode_class[(int)(mode)]) == MODE_COMPLEX_INT)
    {





      rtx realpart, imagpart;
      int size = (mode_unit_size[(int)(mode)]);
      n64_enum_machine_mode partmode
 = mode_for_size (size * 8,
    ((mode_class[(int)(mode)]) == MODE_COMPLEX_FLOAT
     ? MODE_FLOAT : MODE_INT),
    0);

      realpart = gen_reg_rtx (partmode);
      imagpart = gen_reg_rtx (partmode);
      return gen_rtx (CONCAT, mode, realpart, imagpart);
    }




  if (reg_rtx_no == regno_pointer_flag_length)
    {
      rtx *new1;
      char *cxx_new =
 (char *) oballoc (regno_pointer_flag_length * 2);
      memcpy (cxx_new,regno_pointer_flag,regno_pointer_flag_length);
      memset (&cxx_new[regno_pointer_flag_length],0,regno_pointer_flag_length);
      regno_pointer_flag = cxx_new;

      new1 = (rtx *) oballoc (regno_pointer_flag_length * 2 * sizeof (rtx));
      memcpy ((char *) new1,(char *) regno_reg_rtx,regno_pointer_flag_length * sizeof (rtx))
                                               ;
      memset ((char *) &new1[regno_pointer_flag_length],0,regno_pointer_flag_length * sizeof (rtx))
                                               ;
      regno_reg_rtx = new1;

      regno_pointer_flag_length *= 2;
    }

  val = gen_rtx (REG, mode, reg_rtx_no);
  regno_reg_rtx[reg_rtx_no++] = val;
  return val;
}



void
mark_reg_pointer(rtx reg) asm("_mark_reg_pointer");
void
mark_reg_pointer(rtx reg)
{
  regno_pointer_flag[((reg)->fld[0].rtint)] = 1;
}



int
max_reg_num(void) asm("_max_reg_num");
int
max_reg_num(void)
{
  return reg_rtx_no;
}



int
max_label_num(void) asm("_max_label_num");
int
max_label_num(void)
{
  if (last_label_num && label_num == base_label_num)
    return last_label_num;
  return label_num;
}



int
get_first_label_num(void) asm("_get_first_label_num");
int
get_first_label_num(void)
{
  return first_label_num;
}
rtx
gen_lowpart_common(n64_enum_machine_mode mode, register rtx x) asm("_gen_lowpart_common");
rtx
gen_lowpart_common(n64_enum_machine_mode mode, register rtx x)
{
  int word = 0;

  if (((x)->mode) == mode)
    return x;


  if (((x)->mode) != VOIDmode
      && (((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4)
   > (((mode_size[(int)(((x)->mode))]) + (((target_flags & 0x00002000) ? 8 : 4) - 1))
      / ((target_flags & 0x00002000) ? 8 : 4))))
    return 0;

  if (((target_flags & 0x00010000) != 0) && (mode_size[(int)(((x)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
    word = (((mode_size[(int)(((x)->mode))])
      - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))))
     / ((target_flags & 0x00002000) ? 8 : 4));

  if ((((x)->code) == ZERO_EXTEND || ((x)->code) == SIGN_EXTEND)
      && ((mode_class[(int)(mode)]) == MODE_INT
   || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT))
    {
      if (((((x)->fld[0].rtx))->mode) == mode)
 return ((x)->fld[0].rtx);
      else if ((mode_size[(int)(mode)]) < (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
 return gen_lowpart_common (mode, ((x)->fld[0].rtx));
      else if ((mode_size[(int)(mode)]) < (mode_size[(int)(((x)->mode))]))
 return gen_rtx (((x)->code), mode, ((x)->fld[0].rtx));
    }
  else if (((x)->code) == SUBREG
    && ((mode_size[(int)(mode)]) <= ((target_flags & 0x00002000) ? 8 : 4)
        || (mode_size[(int)(mode)]) == (mode_unit_size[(int)(((x)->mode))])))
    return (((((x)->fld[0].rtx))->mode) == mode && ((x)->fld[1].rtint) == 0
     ? ((x)->fld[0].rtx)
     : gen_rtx (SUBREG, mode, ((x)->fld[0].rtx), ((x)->fld[1].rtint)));
  else if (((x)->code) == REG)
    {






      if (((x)->fld[0].rtint) < 68
   && ! mips_hard_regno_mode_ok[ (int)(mode) ][ (((x)->fld[0].rtint) + word) ]
   && mips_hard_regno_mode_ok[ (int)(((x)->mode)) ][ (((x)->fld[0].rtint)) ])
 return 0;
      else if (((x)->fld[0].rtint) < 68

        && (! ((x)->integrated)
     || ! rtx_equal_function_value_matters)


        && x != frame_pointer_rtx

        && x != arg_pointer_rtx

        && x != stack_pointer_rtx)
 return gen_rtx (REG, mode, ((x)->fld[0].rtint) + word);
      else
 return gen_rtx (SUBREG, mode, x, word);
    }


  else if (((mode_class[(int)(mode)]) == MODE_INT
     || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT)
    && ((x)->mode) == VOIDmode
    && (((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE))
    {
      if ((8 * mode_size[(int)(mode)]) >= 2 * 32)
 return x;
      else if ((8 * mode_size[(int)(mode)]) > 32)
 return 0;
      else if ((8 * mode_size[(int)(mode)]) == 32)
 return (((x)->code) == CONST_INT ? x
  : gen_rtx (CONST_INT, VOIDmode, (int) (((x)->fld[2].rtwint))));
      else
 {

   int width = (8 * mode_size[(int)(mode)]);
   int val = (((x)->code) == CONST_INT ? ((x)->fld[0].rtwint)
          : ((x)->fld[2].rtwint));

   if (((val & ((int) (-1) << (width - 1)))
        != ((int) (-1) << (width - 1))))
     val &= ((int) 1 << width) - 1;

   return (((x)->code) == CONST_INT && ((x)->fld[0].rtwint) == val ? x
    : gen_rtx (CONST_INT, VOIDmode, (int) (val)));
 }
    }







  else if (((1 == 1
      && 32 == ((target_flags & 0x00002000) ? 64 : 32))
     || flag_pretend_float)
    && (mode_class[(int)(mode)]) == MODE_FLOAT
    && (mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 8 : 4)
    && ((x)->code) == CONST_INT
    && sizeof (float) * 8 == 32)

    {
      double r;
      int i;

      i = ((x)->fld[0].rtwint);
      r = (ereal_from_float (i));
      return immed_real_const_1 (r, mode);
    }
  else if (((1 == 1
      && 32 == ((target_flags & 0x00002000) ? 64 : 32))
     || flag_pretend_float)
    && (mode_class[(int)(mode)]) == MODE_FLOAT
    && (mode_size[(int)(mode)]) == 2 * ((target_flags & 0x00002000) ? 8 : 4)
    && (((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE)
    && ((x)->mode) == VOIDmode
    && (sizeof (double) * 8
        == 2 * 32))

    {
      double r;
      int i[2];
      int low, high;

      if (((x)->code) == CONST_INT)
 low = ((x)->fld[0].rtwint), high = low >> (32 -1);
      else
 low = ((x)->fld[2].rtwint), high = ((x)->fld[3].rtwint);



      if (((target_flags & 0x00010000) != 0))
 i[0] = high, i[1] = low;
      else
 i[0] = low, i[1] = high;

      r = (ereal_from_double (i));
      return immed_real_const_1 (r, mode);
    }
  else if (((1 == 1
      && 32 == ((target_flags & 0x00002000) ? 64 : 32))
     || flag_pretend_float)
    && ((mode_class[(int)(mode)]) == MODE_INT
        || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT)
    && ((x)->code) == CONST_DOUBLE
    && (mode_class[(int)(((x)->mode))]) == MODE_FLOAT
    && (8 * mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 64 : 32))
    return operand_subword (x, 0, 0, ((x)->mode));






  else if (((1 == 1
      && 32 == ((target_flags & 0x00002000) ? 64 : 32))
     || flag_pretend_float)
    && ((mode_class[(int)(mode)]) == MODE_INT
        || (mode_class[(int)(mode)]) == MODE_PARTIAL_INT)
    && ((x)->code) == CONST_DOUBLE
    && (mode_class[(int)(((x)->mode))]) == MODE_FLOAT
    && (8 * mode_size[(int)(mode)]) == 2 * ((target_flags & 0x00002000) ? 64 : 32))
    {
      rtx lowpart = operand_subword (x, ((target_flags & 0x00010000) != 0), 0, ((x)->mode));
      rtx highpart = operand_subword (x, ! ((target_flags & 0x00010000) != 0), 0, ((x)->mode));

      if (lowpart && ((lowpart)->code) == CONST_INT
   && highpart && ((highpart)->code) == CONST_INT)
 return immed_double_const (((lowpart)->fld[0].rtwint), ((highpart)->fld[0].rtwint), mode);
    }


  return 0;
}




rtx
gen_realpart(n64_enum_machine_mode mode, register rtx x) asm("_gen_realpart");
rtx
gen_realpart(n64_enum_machine_mode mode, register rtx x)
{
  if (((x)->code) == CONCAT && ((((x)->fld[0].rtx))->mode) == mode)
    return ((x)->fld[0].rtx);
  else if (((target_flags & 0x00010000) != 0))
    return gen_highpart (mode, x);
  else
    return gen_lowpart (mode, x);
}




rtx
gen_imagpart(n64_enum_machine_mode mode, register rtx x) asm("_gen_imagpart");
rtx
gen_imagpart(n64_enum_machine_mode mode, register rtx x)
{
  if (((x)->code) == CONCAT && ((((x)->fld[0].rtx))->mode) == mode)
    return ((x)->fld[1].rtx);
  else if (((target_flags & 0x00010000) != 0))
    return gen_lowpart (mode, x);
  else
    return gen_highpart (mode, x);
}






int
subreg_realpart_p(rtx x) asm("_subreg_realpart_p");
int
subreg_realpart_p(rtx x)
{
  if (((x)->code) != SUBREG)
    abort ();

  return ((x)->fld[1].rtint) == 0;
}
rtx
gen_lowpart(n64_enum_machine_mode mode, register rtx x) asm("_gen_lowpart");
rtx
gen_lowpart(n64_enum_machine_mode mode, register rtx x)
{
  rtx result = gen_lowpart_common (mode, x);

  if (result)
    return result;
  else if (((x)->code) == REG)
    {

      result = gen_lowpart_common (mode, copy_to_reg (x));
      if (result == 0)
 abort ();
    }
  else if (((x)->code) == MEM)
    {

      register int offset = 0;
      if (((target_flags & 0x00010000) != 0))
 offset = ((((mode_size[(int)(((x)->mode))])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(((x)->mode))])) : (((target_flags & 0x00002000) ? 8 : 4)))
    - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))));

      if (((target_flags & 0x00010000) != 0))


 offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)])))
     - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((x)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((x)->mode))]))));

      return change_address (x, mode, plus_constant_wide (((x)->fld[0].rtx), (int) (offset)));
    }
  else
    abort ();
}




rtx
gen_highpart(n64_enum_machine_mode mode, register rtx x) asm("_gen_highpart");
rtx
gen_highpart(n64_enum_machine_mode mode, register rtx x)
{


  if ((mode_size[(int)(mode)]) > ((target_flags & 0x00002000) ? 8 : 4)
      && (mode_size[(int)(mode)]) != (mode_unit_size[(int)(((x)->mode))]))
    abort ();
  if (((x)->code) == CONST_DOUBLE



      )
    return gen_rtx (CONST_INT, VOIDmode,
      ((x)->fld[3].rtwint) & (((8 * mode_size[(int)(mode)]) >= 32) ?(int) ~0 : (((int) 1 << (8 * mode_size[(int)(mode)])) - 1)));
  else if (((x)->code) == CONST_INT)
    return const0_rtx;
  else if (((x)->code) == MEM)
    {
      register int offset = 0;
      if (! ((target_flags & 0x00010000) != 0))
 offset = ((((mode_size[(int)(((x)->mode))])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(((x)->mode))])) : (((target_flags & 0x00002000) ? 8 : 4)))
    - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))));

      if (! ((target_flags & 0x00010000) != 0)
   && (mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4))
 offset -= ((mode_size[(int)(mode)])
     - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((x)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((x)->mode))])))
                                  );

      return change_address (x, mode, plus_constant_wide (((x)->fld[0].rtx), (int) (offset)));
    }
  else if (((x)->code) == SUBREG)
    {



      if (((x)->fld[1].rtint) != 0)
 abort ();
      return gen_highpart (mode, ((x)->fld[0].rtx));
    }
  else if (((x)->code) == REG)
    {
      int word = 0;

      if (! ((target_flags & 0x00010000) != 0)
   && (mode_size[(int)(((x)->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
 word = (((mode_size[(int)(((x)->mode))])
   - (((mode_size[(int)(mode)])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(mode)])) : (((target_flags & 0x00002000) ? 8 : 4))))
  / ((target_flags & 0x00002000) ? 8 : 4));







      if (((x)->fld[0].rtint) < 68

   && (! ((x)->integrated)
       || ! rtx_equal_function_value_matters)

   && x != frame_pointer_rtx

   && x != arg_pointer_rtx

   && x != stack_pointer_rtx)
 return gen_rtx (REG, mode, ((x)->fld[0].rtint) + word);
      else
 return gen_rtx (SUBREG, mode, x, word);
    }
  else
    abort ();
}





int
subreg_lowpart_p(rtx x) asm("_subreg_lowpart_p");
int
subreg_lowpart_p(rtx x)
{
  if (((x)->code) != SUBREG)
    return 1;

  if (((target_flags & 0x00010000) != 0)
      && (mode_size[(int)(((((x)->fld[0].rtx))->mode))]) > ((target_flags & 0x00002000) ? 8 : 4))
    return (((x)->fld[1].rtint)
     == (((mode_size[(int)(((((x)->fld[0].rtx))->mode))])
   - (((mode_size[(int)(((x)->mode))])) > (((target_flags & 0x00002000) ? 8 : 4)) ? ((mode_size[(int)(((x)->mode))])) : (((target_flags & 0x00002000) ? 8 : 4))))
  / ((target_flags & 0x00002000) ? 8 : 4)));

  return ((x)->fld[1].rtint) == 0;
}
rtx
operand_subword(rtx op, int i, int validate_address, n64_enum_machine_mode mode) asm("_operand_subword");
rtx
operand_subword(rtx op, int i, int validate_address, n64_enum_machine_mode mode)
{
  int val;
  int size_ratio = 32 / ((target_flags & 0x00002000) ? 64 : 32);

  if (mode == VOIDmode)
    mode = ((op)->mode);

  if (mode == VOIDmode)
    abort ();


  if (mode != BLKmode
      && ((mode_size[(int)(mode)]) < ((target_flags & 0x00002000) ? 8 : 4)
   || (i + 1) * ((target_flags & 0x00002000) ? 8 : 4) > (mode_size[(int)(mode)])))
    return 0;


  if ((mode_class[(int)(mode)]) == MODE_INT
      && (mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 8 : 4))
    return op;


  if (((op)->code) == REG)
    {


      if (((op)->fld[0].rtint) < 68
   && ! mips_hard_regno_mode_ok[ (int)(word_mode) ][ (((op)->fld[0].rtint) + i) ])
 return 0;
      else if (((op)->fld[0].rtint) >= 68
        || (((op)->integrated)
     && rtx_equal_function_value_matters)


        || op == frame_pointer_rtx

        || op == arg_pointer_rtx

        || op == stack_pointer_rtx)
 return gen_rtx (SUBREG, word_mode, op, i);
      else
 return gen_rtx (REG, word_mode, ((op)->fld[0].rtint) + i);
    }
  else if (((op)->code) == SUBREG)
    return gen_rtx (SUBREG, word_mode, ((op)->fld[0].rtx), i + ((op)->fld[1].rtint));
  else if (((op)->code) == CONCAT)
    {
      int partwords = (mode_unit_size[(int)(((op)->mode))]) / ((target_flags & 0x00002000) ? 8 : 4);
      if (i < partwords)
 return operand_subword (((op)->fld[0].rtx), i, validate_address, mode);
      return operand_subword (((op)->fld[1].rtx), i - partwords,
         validate_address, mode);
    }


  if (((op)->code) == MEM)
    {
      rtx addr = plus_constant_wide (((op)->fld[0].rtx), (int) (i * ((target_flags & 0x00002000) ? 8 : 4)));
      rtx cxx_new;

      if (validate_address)
 {
   if (reload_completed)
     {
       if (! strict_memory_address_p (word_mode, addr))
  return 0;
     }
   else
     addr = memory_address (word_mode, addr);
 }

      cxx_new = gen_rtx (MEM, word_mode, addr);

      ((cxx_new)->volatil) = ((op)->volatil);
      ((cxx_new)->in_struct) = ((op)->in_struct);
      ((cxx_new)->unchanging) = ((op)->unchanging);

      return cxx_new;
    }
  if (32 >= ((target_flags & 0x00002000) ? 64 : 32)
      && (mode_class[(int)(mode)]) == MODE_FLOAT
      && (8 * mode_size[(int)(mode)]) == 64
      && ((op)->code) == CONST_DOUBLE)
    {
      long k[2];
      double rv;

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); rv = u.d; } while (0);
      (etardouble ((rv), (k)));






      if (((target_flags & 0x00002000) ? 64 : 32) == 32)
 return gen_rtx (CONST_INT, VOIDmode, (int) ((int) k[i]));





      else if (((target_flags & 0x00002000) ? 64 : 32) == 16)
 {
   long value;
   value = k[i >> 1];
   if ((i & 0x1) == 0)
     value >>= 16;
   value &= 0xffff;
   return gen_rtx (CONST_INT, VOIDmode, (int) ((int) value));
 }
      else
 abort ();
    }
  if ((mode_class[(int)(mode)]) == MODE_FLOAT
      && (8 * mode_size[(int)(mode)]) == 32
      && ((op)->code) == CONST_DOUBLE)
    {
      long l;
      double rv;

      do { union n64_tag_real_extract u; memcpy ((uint8_t *) &u,(uint8_t *) &(((op))->fld[2].rtwint),(sizeof u) / 2); memcpy (((uint8_t *) &u) + (sizeof u / 2),(uint8_t *) &(((op))->fld[3].rtwint),(sizeof u) / 2); rv = u.d; } while (0);
      ((l) = etarsingle ((rv)));
      return gen_rtx (CONST_INT, VOIDmode, (int) ((int) l));
    }
  if (op == const0_rtx)
    return op;

  if ((mode_class[(int)(mode)]) != MODE_INT
      || (((op)->code) != CONST_INT && ((op)->code) != CONST_DOUBLE)
      || ((target_flags & 0x00002000) ? 64 : 32) > 32)
    return 0;

  if (((target_flags & 0x00010000) != 0))
    i = (mode_size[(int)(mode)]) / ((target_flags & 0x00002000) ? 8 : 4) - 1 - i;



  val = (i / size_ratio == 0
  ? (((op)->code) == CONST_INT ? ((op)->fld[0].rtwint) : ((op)->fld[2].rtwint))
  : (((op)->code) == CONST_INT
     ? (((op)->fld[0].rtwint) < 0 ? ~0 : 0) : ((op)->fld[3].rtwint)));


  if (((target_flags & 0x00002000) ? 64 : 32) < 32)
    val = ((val >> ((i % size_ratio) * ((target_flags & 0x00002000) ? 64 : 32)))
    & (((int) 1
        << (((target_flags & 0x00002000) ? 64 : 32) % 32)) - 1));

  return gen_rtx (CONST_INT, VOIDmode, (int) (val));
}
rtx
operand_subword_force(rtx op, int i, n64_enum_machine_mode mode) asm("_operand_subword_force");
rtx
operand_subword_force(rtx op, int i, n64_enum_machine_mode mode)
{
  rtx result = operand_subword (op, i, 1, mode);

  if (result)
    return result;

  if (mode != BLKmode && mode != VOIDmode)
    op = force_reg (mode, op);

  result = operand_subword (op, i, 1, mode);
  if (result == 0)
    abort ();

  return result;
}




void
reverse_comparison(rtx insn) asm("_reverse_comparison");
void
reverse_comparison(rtx insn)
{
  rtx body = ((insn)->fld[3].rtx);
  rtx comp;

  if (((body)->code) == SET)
    comp = ((body)->fld[1].rtx);
  else
    comp = ((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx);

  if (((comp)->code) == COMPARE)
    {
      rtx op0 = ((comp)->fld[0].rtx);
      rtx op1 = ((comp)->fld[1].rtx);
      ((comp)->fld[0].rtx) = op1;
      ((comp)->fld[1].rtx) = op0;
    }
  else
    {
      rtx cxx_new = gen_rtx (COMPARE, VOIDmode,
    (const_tiny_rtx[0][(int) (((comp)->mode))]), comp);
      if (((body)->code) == SET)
 ((body)->fld[1].rtx) = cxx_new;
      else
 ((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx) = cxx_new;
    }
}






rtx
change_address(rtx memref, n64_enum_machine_mode mode, rtx addr) asm("_change_address");
rtx
change_address(rtx memref, n64_enum_machine_mode mode, rtx addr)
{
  rtx cxx_new;

  if (((memref)->code) != MEM)
    abort ();
  if (mode == VOIDmode)
    mode = ((memref)->mode);
  if (addr == 0)
    addr = ((memref)->fld[0].rtx);



  if (reload_completed || reload_in_progress)
    {
      if (! memory_address_p (mode, addr))
 abort ();
    }
  else
    addr = memory_address (mode, addr);

  cxx_new = gen_rtx (MEM, mode, addr);
  ((cxx_new)->volatil) = ((memref)->volatil);
  ((cxx_new)->unchanging) = ((memref)->unchanging);
  ((cxx_new)->in_struct) = ((memref)->in_struct);
  return cxx_new;
}



rtx
gen_label_rtx(void) asm("_gen_label_rtx");
rtx
gen_label_rtx(void)
{
  register rtx label;

  label = (output_bytecode
    ? gen_rtx (CODE_LABEL, VOIDmode, 
                                    ((void *)0)
                                        , bc_get_bytecode_label ())
    : gen_rtx (CODE_LABEL, VOIDmode, 0, 0, 0, label_num++, ((void *)0)));

  ((label)->fld[5].rtint) = 0;
  return label;
}






rtx
gen_inline_header_rtx(rtx first_insn, rtx first_parm_insn, int first_labelno, int last_labelno, int max_parm_regnum, int max_regnum, int args_size, int pops_args, rtx stack_slots, rtx forced_labels, int function_flags, int outgoing_args_size, rtvec original_arg_vector, rtx original_decl_initial) asm("_gen_inline_header_rtx");
rtx
gen_inline_header_rtx(rtx first_insn, rtx first_parm_insn, int first_labelno, int last_labelno, int max_parm_regnum, int max_regnum, int args_size, int pops_args, rtx stack_slots, rtx forced_labels, int function_flags, int outgoing_args_size, rtvec original_arg_vector, rtx original_decl_initial)
{
  rtx header = gen_rtx (INLINE_HEADER, VOIDmode,
   cur_insn_uid++, (rtx) 0,
   first_insn, first_parm_insn,
   first_labelno, last_labelno,
   max_parm_regnum, max_regnum, args_size, pops_args,
   stack_slots, forced_labels, function_flags,
   outgoing_args_size,
   original_arg_vector, original_decl_initial);
  return header;
}




void
set_new_first_and_last_insn(rtx first, rtx last) asm("_set_new_first_and_last_insn");
void
set_new_first_and_last_insn(rtx first, rtx last)
{
  first_insn = first;
  last_insn = last;
}




void
set_new_first_and_last_label_num(int first, int last) asm("_set_new_first_and_last_label_num");
void
set_new_first_and_last_label_num(int first, int last)
{
  base_label_num = label_num;
  first_label_num = first;
  last_label_num = last;
}




void
save_emit_status(struct n64_tag_function *p) asm("_save_emit_status");
void
save_emit_status(struct n64_tag_function *p)
{
  p->reg_rtx_no = reg_rtx_no;
  p->first_label_num = first_label_num;
  p->first_insn = first_insn;
  p->last_insn = last_insn;
  p->sequence_rtl_expr = sequence_rtl_expr;
  p->sequence_stack = sequence_stack;
  p->cur_insn_uid = cur_insn_uid;
  p->last_linenum = last_linenum;
  p->last_filename = last_filename;
  p->regno_pointer_flag = regno_pointer_flag;
  p->regno_pointer_flag_length = regno_pointer_flag_length;
  p->regno_reg_rtx = regno_reg_rtx;
}




void
restore_emit_status(struct n64_tag_function *p) asm("_restore_emit_status");
void
restore_emit_status(struct n64_tag_function *p)
{
  int i;

  reg_rtx_no = p->reg_rtx_no;
  first_label_num = p->first_label_num;
  last_label_num = 0;
  first_insn = p->first_insn;
  last_insn = p->last_insn;
  sequence_rtl_expr = p->sequence_rtl_expr;
  sequence_stack = p->sequence_stack;
  cur_insn_uid = p->cur_insn_uid;
  last_linenum = p->last_linenum;
  last_filename = p->last_filename;
  regno_pointer_flag = p->regno_pointer_flag;
  regno_pointer_flag_length = p->regno_pointer_flag_length;
  regno_reg_rtx = p->regno_reg_rtx;


  sequence_element_free_list = 0;
  for (i = 0; i < 5; i++)
    sequence_result[i] = 0;
}





void
unshare_all_rtl(register rtx insn) asm("_unshare_all_rtl");
void
unshare_all_rtl(register rtx insn)
{
  for (; insn; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN
 || ((insn)->code) == CALL_INSN)
      {
 ((insn)->fld[3].rtx) = copy_rtx_if_shared (((insn)->fld[3].rtx));
 ((insn)->fld[6].rtx) = copy_rtx_if_shared (((insn)->fld[6].rtx));
 ((insn)->fld[5].rtx) = copy_rtx_if_shared (((insn)->fld[5].rtx));
      }
  copy_rtx_if_shared (stack_slot_list);
}




rtx
copy_rtx_if_shared(rtx orig) asm("_copy_rtx_if_shared");
rtx
copy_rtx_if_shared(rtx orig)
{
  register rtx x = orig;
  register int i;
  register n64_enum_rtx_code code;
  register char *format_ptr;
  int copied = 0;

  if (x == 0)
    return 0;

  code = ((x)->code);



  switch (code)
    {
    case REG:
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
    case SCRATCH:

      return x;

    case CONST:


      if (((((x)->fld[0].rtx))->code) == PLUS
   && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == SYMBOL_REF
   && ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT)
 return x;
      break;

    case INSN:
    case JUMP_INSN:
    case CALL_INSN:
    case NOTE:
    case BARRIER:

      return x;

    case MEM:


      if (((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == HIGH || (((((x)->fld[0].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((x)->fld[0].rtx))) && ! 0)) && (!0 || !0))
   || ((x)->fld[0].rtx) == virtual_stack_vars_rtx
   || ((x)->fld[0].rtx) == virtual_incoming_args_rtx)
 return x;

      if (((((x)->fld[0].rtx))->code) == PLUS
   && (((((x)->fld[0].rtx))->fld[0].rtx) == virtual_stack_vars_rtx
       || ((((x)->fld[0].rtx))->fld[0].rtx) == virtual_incoming_args_rtx)
   && ((((((((x)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == SYMBOL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == HIGH || (((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST && ! (flag_pic && pic_address_needs_scratch (((((x)->fld[0].rtx))->fld[1].rtx))) && ! 0)) && (!0 || !0)))
 {


   if (! x->used)
     ((x)->fld[0].rtx) = copy_rtx_if_shared (((x)->fld[0].rtx));
   x->used = 1;
   return x;
 }
    }




  if (x->used)
    {
      register rtx copy;

      copy = rtx_alloc (code);
      memcpy ((char *) copy,(char *) x,(sizeof (*copy) - sizeof (copy->fld) + sizeof (copy->fld[0]) * (rtx_length[(int)(code)])))

                                                        ;
      x = copy;
      copied = 1;
    }
  x->used = 1;






  format_ptr = (rtx_format[(int)(code)]);

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   ((x)->fld[i].rtx) = copy_rtx_if_shared (((x)->fld[i].rtx));
   break;

 case 'E':
   if (((x)->fld[i].rtvec) != 
                     ((void *)0)
                         )
     {
       register int j;
       int len = ((x)->fld[i].rtvec->num_elem);

       if (copied && len > 0)
  ((x)->fld[i].rtvec) = gen_rtvec_v (len, &((x)->fld[i].rtvec->elem[0].rtx));
       for (j = 0; j < len; j++)
  ((x)->fld[i].rtvec->elem[j].rtx) = copy_rtx_if_shared (((x)->fld[i].rtvec->elem[j].rtx));
     }
   break;
 }
    }
  return x;
}




void
reset_used_flags(rtx x) asm("_reset_used_flags");
void
reset_used_flags(rtx x)
{
  register int i, j;
  register n64_enum_rtx_code code;
  register char *format_ptr;

  if (x == 0)
    return;

  code = ((x)->code);




  switch (code)
    {
    case REG:
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
      return;

    case INSN:
    case JUMP_INSN:
    case CALL_INSN:
    case NOTE:
    case LABEL_REF:
    case BARRIER:

      return;
    }

  x->used = 0;

  format_ptr = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   reset_used_flags (((x)->fld[i].rtx));
   break;

 case 'E':
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     reset_used_flags (((x)->fld[i].rtvec->elem[j].rtx));
   break;
 }
    }
}





rtx
make_safe_from(rtx x, rtx other) asm("_make_safe_from");
rtx
make_safe_from(rtx x, rtx other)
{
  while (1)
    switch (((other)->code))
      {
      case SUBREG:
 other = ((other)->fld[0].rtx);
 break;
      case STRICT_LOW_PART:
      case SIGN_EXTEND:
      case ZERO_EXTEND:
 other = ((other)->fld[0].rtx);
 break;
      default:
 goto done;
      }
 done:
  if ((((other)->code) == MEM
       && ! (((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH)
       && ((x)->code) != REG
       && ((x)->code) != SUBREG)
      || (((other)->code) == REG
   && (((other)->fld[0].rtint) < 68
       || reg_mentioned_p (other, x))))
    {
      rtx temp = gen_reg_rtx (((x)->mode));
      emit_move_insn (temp, x);
      return temp;
    }
  return x;
}





rtx
get_insns(void) asm("_get_insns");
rtx
get_insns(void)
{
  return first_insn;
}



rtx
get_last_insn(void) asm("_get_last_insn");
rtx
get_last_insn(void)
{
  return last_insn;
}



void
set_last_insn(rtx insn) asm("_set_last_insn");
void
set_last_insn(rtx insn)
{
  if (((insn)->fld[2].rtx) != 0)
    abort ();
  last_insn = insn;
}



rtx
get_last_insn_anywhere(void) asm("_get_last_insn_anywhere");
rtx
get_last_insn_anywhere(void)
{
  struct n64_tag_sequence_stack *stack;
  if (last_insn)
    return last_insn;
  for (stack = sequence_stack; stack; stack = stack->next)
    if (stack->last != 0)
      return stack->last;
  return 0;
}



int
get_max_uid(void) asm("_get_max_uid");
int
get_max_uid(void)
{
  return cur_insn_uid;
}




rtx
next_insn(rtx insn) asm("_next_insn");
rtx
next_insn(rtx insn)
{
  if (insn)
    {
      insn = ((insn)->fld[2].rtx);
      if (insn && ((insn)->code) == INSN
   && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
 insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx);
    }

  return insn;
}




rtx
previous_insn(rtx insn) asm("_previous_insn");
rtx
previous_insn(rtx insn)
{
  if (insn)
    {
      insn = ((insn)->fld[1].rtx);
      if (insn && ((insn)->code) == INSN
   && ((((insn)->fld[3].rtx))->code) == SEQUENCE)
 insn = ((((insn)->fld[3].rtx))->fld[0].rtvec->elem[((((insn)->fld[3].rtx))->fld[0].rtvec->num_elem) - 1].rtx);
    }

  return insn;
}




rtx
next_nonnote_insn(rtx insn) asm("_next_nonnote_insn");
rtx
next_nonnote_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[2].rtx);
      if (insn == 0 || ((insn)->code) != NOTE)
 break;
    }

  return insn;
}




rtx
prev_nonnote_insn(rtx insn) asm("_prev_nonnote_insn");
rtx
prev_nonnote_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[1].rtx);
      if (insn == 0 || ((insn)->code) != NOTE)
 break;
    }

  return insn;
}





rtx
next_real_insn(rtx insn) asm("_next_real_insn");
rtx
next_real_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[2].rtx);
      if (insn == 0 || ((insn)->code) == INSN
   || ((insn)->code) == CALL_INSN || ((insn)->code) == JUMP_INSN)
 break;
    }

  return insn;
}





rtx
prev_real_insn(rtx insn) asm("_prev_real_insn");
rtx
prev_real_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[1].rtx);
      if (insn == 0 || ((insn)->code) == INSN || ((insn)->code) == CALL_INSN
   || ((insn)->code) == JUMP_INSN)
 break;
    }

  return insn;
}





rtx
next_active_insn(rtx insn) asm("_next_active_insn");
rtx
next_active_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[2].rtx);
      if (insn == 0
   || ((insn)->code) == CALL_INSN || ((insn)->code) == JUMP_INSN
   || (((insn)->code) == INSN
       && (! reload_completed
    || (((((insn)->fld[3].rtx))->code) != USE
        && ((((insn)->fld[3].rtx))->code) != CLOBBER))))
 break;
    }

  return insn;
}





rtx
prev_active_insn(rtx insn) asm("_prev_active_insn");
rtx
prev_active_insn(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[1].rtx);
      if (insn == 0
   || ((insn)->code) == CALL_INSN || ((insn)->code) == JUMP_INSN
   || (((insn)->code) == INSN
       && (! reload_completed
    || (((((insn)->fld[3].rtx))->code) != USE
        && ((((insn)->fld[3].rtx))->code) != CLOBBER))))
 break;
    }

  return insn;
}



rtx
next_label(rtx insn) asm("_next_label");
rtx
next_label(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[2].rtx);
      if (insn == 0 || ((insn)->code) == CODE_LABEL)
 break;
    }

  return insn;
}



rtx
prev_label(rtx insn) asm("_prev_label");
rtx
prev_label(rtx insn)
{
  while (insn)
    {
      insn = ((insn)->fld[1].rtx);
      if (insn == 0 || ((insn)->code) == CODE_LABEL)
 break;
    }

  return insn;
}
rtx
try_split(rtx pat, rtx trial, int last) asm("_try_split");
rtx
try_split(rtx pat, rtx trial, int last)
{
  rtx before = ((trial)->fld[1].rtx);
  rtx after = ((trial)->fld[2].rtx);
  rtx seq = split_insns (pat, trial);
  int has_barrier = 0;
  rtx tem;



  if (after && ((after)->code) == BARRIER)
    {
      has_barrier = 1;
      after = ((after)->fld[2].rtx);
    }

  if (seq)
    {



      if (((seq)->code) == SEQUENCE)
 {



   int i;

   if (((trial)->code) == JUMP_INSN)
     for (i = ((seq)->fld[0].rtvec->num_elem) - 1; i >= 0; i--)
       if (((((seq)->fld[0].rtvec->elem[i].rtx))->code) == JUMP_INSN)
  {
    ((((seq)->fld[0].rtvec->elem[i].rtx))->fld[7].rtx) = ((trial)->fld[7].rtx);

    if (((trial)->fld[7].rtx))
      ((((trial)->fld[7].rtx))->fld[5].rtint)++;
  }

   tem = emit_insn_after (seq, before);

   delete_insn (trial);
   if (has_barrier)
     emit_barrier_after (tem);






   for (tem = ((before)->fld[2].rtx); tem != after;
        tem = ((tem)->fld[2].rtx))
     if (! ((tem)->volatil))
       tem = try_split (((tem)->fld[3].rtx), tem, 1);
 }

      else if (rtx_equal_p (seq, pat))
 return trial;
      else
 {
   ((trial)->fld[3].rtx) = seq;
   ((trial)->fld[4].rtint) = -1;
   try_split (seq, trial, last);
 }



      return last ? prev_active_insn (after) : next_active_insn (before);
    }

  return trial;
}




rtx
make_insn_raw(rtx pattern) asm("_make_insn_raw");
rtx
make_insn_raw(rtx pattern)
{
  register rtx insn;

  insn = rtx_alloc (INSN);
  ((insn)->fld[0].rtint) = cur_insn_uid++;

  ((insn)->fld[3].rtx) = pattern;
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[5].rtx) = 
                    ((void *)0)
                        ;
  ((insn)->fld[6].rtx) = 
                    ((void *)0)
                        ;

  return insn;
}



static rtx
make_jump_insn_raw(rtx pattern) asm("_make_jump_insn_raw");
static rtx
make_jump_insn_raw(rtx pattern)
{
  register rtx insn;

  insn = rtx_alloc (JUMP_INSN);
  ((insn)->fld[0].rtint) = cur_insn_uid++;

  ((insn)->fld[3].rtx) = pattern;
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[5].rtx) = 
                    ((void *)0)
                        ;
  ((insn)->fld[6].rtx) = 
                    ((void *)0)
                        ;
  ((insn)->fld[7].rtx) = 
                     ((void *)0)
                         ;

  return insn;
}



static rtx
make_call_insn_raw(rtx pattern) asm("_make_call_insn_raw");
static rtx
make_call_insn_raw(rtx pattern)
{
  register rtx insn;

  insn = rtx_alloc (CALL_INSN);
  ((insn)->fld[0].rtint) = cur_insn_uid++;

  ((insn)->fld[3].rtx) = pattern;
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[5].rtx) = 
                    ((void *)0)
                        ;
  ((insn)->fld[6].rtx) = 
                    ((void *)0)
                        ;
  ((insn)->fld[7].rtx) = 
                                   ((void *)0)
                                       ;

  return insn;
}




void
add_insn(register rtx insn) asm("_add_insn");
void
add_insn(register rtx insn)
{
  ((insn)->fld[1].rtx) = last_insn;
  ((insn)->fld[2].rtx) = 0;

  if (
     ((void *)0) 
          != last_insn)
    ((last_insn)->fld[2].rtx) = insn;

  if (
     ((void *)0) 
          == first_insn)
    first_insn = insn;

  last_insn = insn;
}






void
add_insn_after(rtx insn, rtx after) asm("_add_insn_after");
void
add_insn_after(rtx insn, rtx after)
{
  rtx next = ((after)->fld[2].rtx);

  if (optimize && ((after)->volatil))
    abort ();

  ((insn)->fld[2].rtx) = next;
  ((insn)->fld[1].rtx) = after;

  if (next)
    {
      ((next)->fld[1].rtx) = insn;
      if (((next)->code) == INSN && ((((next)->fld[3].rtx))->code) == SEQUENCE)
 ((((((next)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx) = insn;
    }
  else if (last_insn == after)
    last_insn = insn;
  else
    {
      struct n64_tag_sequence_stack *stack = sequence_stack;

      for (; stack; stack = stack->next)
 if (after == stack->last)
   {
     stack->last = insn;
     break;
   }

      if (stack == 0)
 abort ();
    }

  ((after)->fld[2].rtx) = insn;
  if (((after)->code) == INSN && ((((after)->fld[3].rtx))->code) == SEQUENCE)
    {
      rtx sequence = ((after)->fld[3].rtx);
      ((((sequence)->fld[0].rtvec->elem[((sequence)->fld[0].rtvec->num_elem) - 1].rtx))->fld[2].rtx) = insn;
    }
}






void
add_insn_before(rtx insn, rtx before) asm("_add_insn_before");
void
add_insn_before(rtx insn, rtx before)
{
  rtx prev = ((before)->fld[1].rtx);

  if (optimize && ((before)->volatil))
    abort ();

  ((insn)->fld[1].rtx) = prev;
  ((insn)->fld[2].rtx) = before;

  if (prev)
    {
      ((prev)->fld[2].rtx) = insn;
      if (((prev)->code) == INSN && ((((prev)->fld[3].rtx))->code) == SEQUENCE)
 {
   rtx sequence = ((prev)->fld[3].rtx);
   ((((sequence)->fld[0].rtvec->elem[((sequence)->fld[0].rtvec->num_elem) - 1].rtx))->fld[2].rtx) = insn;
 }
    }
  else if (first_insn == before)
    first_insn = insn;
  else
    {
      struct n64_tag_sequence_stack *stack = sequence_stack;

      for (; stack; stack = stack->next)
 if (before == stack->first)
   {
     stack->first = insn;
     break;
   }

      if (stack == 0)
 abort ();
    }

  ((before)->fld[1].rtx) = insn;
  if (((before)->code) == INSN && ((((before)->fld[3].rtx))->code) == SEQUENCE)
    ((((((before)->fld[3].rtx))->fld[0].rtvec->elem[0].rtx))->fld[1].rtx) = insn;
}




void
delete_insns_since(rtx from) asm("_delete_insns_since");
void
delete_insns_since(rtx from)
{
  if (from == 0)
    first_insn = 0;
  else
    ((from)->fld[2].rtx) = 0;
  last_insn = from;
}
void
reorder_insns(rtx from, rtx to, rtx after) asm("_reorder_insns");
void
reorder_insns(rtx from, rtx to, rtx after)
{

  if (((from)->fld[1].rtx))
    ((((from)->fld[1].rtx))->fld[2].rtx) = ((to)->fld[2].rtx);
  if (((to)->fld[2].rtx))
    ((((to)->fld[2].rtx))->fld[1].rtx) = ((from)->fld[1].rtx);
  if (last_insn == to)
    last_insn = ((from)->fld[1].rtx);
  if (first_insn == from)
    first_insn = ((to)->fld[2].rtx);


  if (((after)->fld[2].rtx))
    ((((after)->fld[2].rtx))->fld[1].rtx) = to;

  ((to)->fld[2].rtx) = ((after)->fld[2].rtx);
  ((from)->fld[1].rtx) = after;
  ((after)->fld[2].rtx) = from;
  if (after == last_insn)
    last_insn = to;
}



static rtx
find_line_note(rtx insn) asm("_find_line_note");
static rtx
find_line_note(rtx insn)
{
  if (no_line_numbers)
    return 0;

  for (; insn; insn = ((insn)->fld[1].rtx))
    if (((insn)->code) == NOTE
        && ((insn)->fld[4].rtint) >= 0)
      break;

  return insn;
}





void
reorder_insns_with_line_notes(rtx from, rtx to, rtx after) asm("_reorder_insns_with_line_notes");
void
reorder_insns_with_line_notes(rtx from, rtx to, rtx after)
{
  rtx from_line = find_line_note (from);
  rtx after_line = find_line_note (after);

  reorder_insns (from, to, after);

  if (from_line == after_line)
    return;

  if (from_line)
    emit_line_note_after (((from_line)->fld[3].rtstr),
     ((from_line)->fld[4].rtint),
     after);
  if (after_line)
    emit_line_note_after (((after_line)->fld[3].rtstr),
     ((after_line)->fld[4].rtint),
     to);
}







rtx
emit_insn_before(register rtx pattern, register rtx before) asm("_emit_insn_before");
rtx
emit_insn_before(register rtx pattern, register rtx before)
{
  register rtx insn = before;

  if (((pattern)->code) == SEQUENCE)
    {
      register int i;

      for (i = 0; i < ((pattern)->fld[0].rtvec->num_elem); i++)
 {
   insn = ((pattern)->fld[0].rtvec->elem[i].rtx);
   add_insn_before (insn, before);
 }
      if (((pattern)->fld[0].rtvec->num_elem) < 5)
 sequence_result[((pattern)->fld[0].rtvec->num_elem)] = pattern;
    }
  else
    {
      insn = make_insn_raw (pattern);
      add_insn_before (insn, before);
    }

  return insn;
}




rtx
emit_jump_insn_before(register rtx pattern, register rtx before) asm("_emit_jump_insn_before");
rtx
emit_jump_insn_before(register rtx pattern, register rtx before)
{
  register rtx insn;

  if (((pattern)->code) == SEQUENCE)
    insn = emit_insn_before (pattern, before);
  else
    {
      insn = make_jump_insn_raw (pattern);
      add_insn_before (insn, before);
    }

  return insn;
}




rtx
emit_call_insn_before(register rtx pattern, register rtx before) asm("_emit_call_insn_before");
rtx
emit_call_insn_before(register rtx pattern, register rtx before)
{
  register rtx insn;

  if (((pattern)->code) == SEQUENCE)
    insn = emit_insn_before (pattern, before);
  else
    {
      insn = make_call_insn_raw (pattern);
      add_insn_before (insn, before);
      ((insn)->code = (CALL_INSN));
    }

  return insn;
}




rtx
emit_barrier_before(register rtx before) asm("_emit_barrier_before");
rtx
emit_barrier_before(register rtx before)
{
  register rtx insn = rtx_alloc (BARRIER);

  ((insn)->fld[0].rtint) = cur_insn_uid++;

  add_insn_before (insn, before);
  return insn;
}



rtx
emit_note_before(int subtype, rtx before) asm("_emit_note_before");
rtx
emit_note_before(int subtype, rtx before)
{
  register rtx note = rtx_alloc (NOTE);
  ((note)->fld[0].rtint) = cur_insn_uid++;
  ((note)->fld[3].rtstr) = 0;
  ((note)->fld[4].rtint) = subtype;

  add_insn_before (note, before);
  return note;
}




rtx
emit_insn_after(register rtx pattern, register rtx after) asm("_emit_insn_after");
rtx
emit_insn_after(register rtx pattern, register rtx after)
{
  register rtx insn = after;

  if (((pattern)->code) == SEQUENCE)
    {
      register int i;

      for (i = 0; i < ((pattern)->fld[0].rtvec->num_elem); i++)
 {
   insn = ((pattern)->fld[0].rtvec->elem[i].rtx);
   add_insn_after (insn, after);
   after = insn;
 }
      if (((pattern)->fld[0].rtvec->num_elem) < 5)
 sequence_result[((pattern)->fld[0].rtvec->num_elem)] = pattern;
    }
  else
    {
      insn = make_insn_raw (pattern);
      add_insn_after (insn, after);
    }

  return insn;
}




void
emit_insn_after_with_line_notes(rtx pattern, rtx after, rtx from) asm("_emit_insn_after_with_line_notes");
void
emit_insn_after_with_line_notes(rtx pattern, rtx after, rtx from)
{
  rtx from_line = find_line_note (from);
  rtx after_line = find_line_note (after);
  rtx insn = emit_insn_after (pattern, after);

  if (from_line)
    emit_line_note_after (((from_line)->fld[3].rtstr),
     ((from_line)->fld[4].rtint),
     after);

  if (after_line)
    emit_line_note_after (((after_line)->fld[3].rtstr),
     ((after_line)->fld[4].rtint),
     insn);
}




rtx
emit_jump_insn_after(register rtx pattern, register rtx after) asm("_emit_jump_insn_after");
rtx
emit_jump_insn_after(register rtx pattern, register rtx after)
{
  register rtx insn;

  if (((pattern)->code) == SEQUENCE)
    insn = emit_insn_after (pattern, after);
  else
    {
      insn = make_jump_insn_raw (pattern);
      add_insn_after (insn, after);
    }

  return insn;
}




rtx
emit_barrier_after(register rtx after) asm("_emit_barrier_after");
rtx
emit_barrier_after(register rtx after)
{
  register rtx insn = rtx_alloc (BARRIER);

  ((insn)->fld[0].rtint) = cur_insn_uid++;

  add_insn_after (insn, after);
  return insn;
}



rtx
emit_label_after(rtx label, rtx after) asm("_emit_label_after");
rtx
emit_label_after(rtx label, rtx after)
{



  if (((label)->fld[0].rtint) == 0)
    {
      ((label)->fld[0].rtint) = cur_insn_uid++;
      add_insn_after (label, after);
    }

  return label;
}



rtx
emit_note_after(int subtype, rtx after) asm("_emit_note_after");
rtx
emit_note_after(int subtype, rtx after)
{
  register rtx note = rtx_alloc (NOTE);
  ((note)->fld[0].rtint) = cur_insn_uid++;
  ((note)->fld[3].rtstr) = 0;
  ((note)->fld[4].rtint) = subtype;
  add_insn_after (note, after);
  return note;
}



rtx
emit_line_note_after(char *file, int line, rtx after) asm("_emit_line_note_after");
rtx
emit_line_note_after(char *file, int line, rtx after)
{
  register rtx note;

  if (no_line_numbers && line > 0)
    {
      cur_insn_uid++;
      return 0;
    }

  note = rtx_alloc (NOTE);
  ((note)->fld[0].rtint) = cur_insn_uid++;
  ((note)->fld[3].rtstr) = file;
  ((note)->fld[4].rtint) = line;
  add_insn_after (note, after);
  return note;
}
rtx
emit_insn(rtx pattern) asm("_emit_insn");
rtx
emit_insn(rtx pattern)
{
  rtx insn = last_insn;

  if (((pattern)->code) == SEQUENCE)
    {
      register int i;

      for (i = 0; i < ((pattern)->fld[0].rtvec->num_elem); i++)
 {
   insn = ((pattern)->fld[0].rtvec->elem[i].rtx);
   add_insn (insn);
 }
      if (((pattern)->fld[0].rtvec->num_elem) < 5)
 sequence_result[((pattern)->fld[0].rtvec->num_elem)] = pattern;
    }
  else
    {
      insn = make_insn_raw (pattern);
      add_insn (insn);
    }

  return insn;
}




rtx
emit_insns(rtx insn) asm("_emit_insns");
rtx
emit_insns(rtx insn)
{
  rtx last = 0;

  while (insn)
    {
      rtx next = ((insn)->fld[2].rtx);
      add_insn (insn);
      last = insn;
      insn = next;
    }

  return last;
}




rtx
emit_insns_before(rtx insn, rtx before) asm("_emit_insns_before");
rtx
emit_insns_before(rtx insn, rtx before)
{
  rtx last = 0;

  while (insn)
    {
      rtx next = ((insn)->fld[2].rtx);
      add_insn_before (insn, before);
      last = insn;
      insn = next;
    }

  return last;
}




rtx
emit_insns_after(register rtx first, register rtx after) asm("_emit_insns_after");
rtx
emit_insns_after(register rtx first, register rtx after)
{
  register rtx last;
  register rtx after_after;

  if (!after)
    abort ();

  if (!first)
    return first;

  for (last = first; ((last)->fld[2].rtx); last = ((last)->fld[2].rtx))
    continue;

  after_after = ((after)->fld[2].rtx);

  ((after)->fld[2].rtx) = first;
  ((first)->fld[1].rtx) = after;
  ((last)->fld[2].rtx) = after_after;
  if (after_after)
    ((after_after)->fld[1].rtx) = last;

  if (after == last_insn)
    last_insn = last;
  return last;
}




rtx
emit_jump_insn(rtx pattern) asm("_emit_jump_insn");
rtx
emit_jump_insn(rtx pattern)
{
  if (((pattern)->code) == SEQUENCE)
    return emit_insn (pattern);
  else
    {
      register rtx insn = make_jump_insn_raw (pattern);
      add_insn (insn);
      return insn;
    }
}




rtx
emit_call_insn(rtx pattern) asm("_emit_call_insn");
rtx
emit_call_insn(rtx pattern)
{
  if (((pattern)->code) == SEQUENCE)
    return emit_insn (pattern);
  else
    {
      register rtx insn = make_call_insn_raw (pattern);
      add_insn (insn);
      ((insn)->code = (CALL_INSN));
      return insn;
    }
}



rtx
emit_label(rtx label) asm("_emit_label");
rtx
emit_label(rtx label)
{



  if (((label)->fld[0].rtint) == 0)
    {
      ((label)->fld[0].rtint) = cur_insn_uid++;
      add_insn (label);
    }
  return label;
}




rtx
emit_barrier(void) asm("_emit_barrier");
rtx
emit_barrier(void)
{
  register rtx barrier = rtx_alloc (BARRIER);
  ((barrier)->fld[0].rtint) = cur_insn_uid++;
  add_insn (barrier);
  return barrier;
}






rtx
emit_line_note(char *file, int line) asm("_emit_line_note");
rtx
emit_line_note(char *file, int line)
{
  if (output_bytecode)
    {


      return 0;
    }

  emit_filename = file;
  emit_lineno = line;






  return emit_note (file, line);
}






rtx
emit_note(char *file, int line) asm("_emit_note");
rtx
emit_note(char *file, int line)
{
  register rtx note;

  if (line > 0)
    {
      if (file && last_filename && !strcmp (file, last_filename)
   && line == last_linenum)
 return 0;
      last_filename = file;
      last_linenum = line;
    }

  if (no_line_numbers && line > 0)
    {
      cur_insn_uid++;
      return 0;
    }

  note = rtx_alloc (NOTE);
  ((note)->fld[0].rtint) = cur_insn_uid++;
  ((note)->fld[3].rtstr) = file;
  ((note)->fld[4].rtint) = line;
  add_insn (note);
  return note;
}



rtx
emit_line_note_force(char *file, int line) asm("_emit_line_note_force");
rtx
emit_line_note_force(char *file, int line)
{
  last_linenum = -1;
  return emit_line_note (file, line);
}




void
force_next_line_note(void) asm("_force_next_line_note");
void
force_next_line_note(void)
{
  last_linenum = -1;
}




n64_enum_rtx_code
classify_insn(rtx x) asm("_classify_insn");
n64_enum_rtx_code
classify_insn(rtx x)
{
  if (((x)->code) == CODE_LABEL)
    return CODE_LABEL;
  if (((x)->code) == CALL)
    return CALL_INSN;
  if (((x)->code) == RETURN)
    return JUMP_INSN;
  if (((x)->code) == SET)
    {
      if (((x)->fld[0].rtx) == pc_rtx)
 return JUMP_INSN;
      else if (((((x)->fld[1].rtx))->code) == CALL)
 return CALL_INSN;
      else
 return INSN;
    }
  if (((x)->code) == PARALLEL)
    {
      register int j;
      for (j = ((x)->fld[0].rtvec->num_elem) - 1; j >= 0; j--)
 if (((((x)->fld[0].rtvec->elem[j].rtx))->code) == CALL)
   return CALL_INSN;
 else if (((((x)->fld[0].rtvec->elem[j].rtx))->code) == SET
   && ((((x)->fld[0].rtvec->elem[j].rtx))->fld[0].rtx) == pc_rtx)
   return JUMP_INSN;
 else if (((((x)->fld[0].rtvec->elem[j].rtx))->code) == SET
   && ((((((x)->fld[0].rtvec->elem[j].rtx))->fld[1].rtx))->code) == CALL)
   return CALL_INSN;
    }
  return INSN;
}




rtx
emit(rtx x) asm("_emit");
rtx
emit(rtx x)
{
  n64_enum_rtx_code code = classify_insn (x);

  if (code == CODE_LABEL)
    return emit_label (x);
  else if (code == INSN)
    return emit_insn (x);
  else if (code == JUMP_INSN)
    {
      register rtx insn = emit_jump_insn (x);
      if (simplejump_p (insn) || ((x)->code) == RETURN)
 return emit_barrier ();
      return insn;
    }
  else if (code == CALL_INSN)
    return emit_call_insn (x);
  else
    abort ();
}



void
start_sequence(void) asm("_start_sequence");
void
start_sequence(void)
{
  struct n64_tag_sequence_stack *tem;

  if (sequence_element_free_list)
    {

      tem = sequence_element_free_list;
      sequence_element_free_list = tem->next;
    }
  else
    tem = (struct n64_tag_sequence_stack *) permalloc (sizeof (struct n64_tag_sequence_stack));

  tem->next = sequence_stack;
  tem->first = first_insn;
  tem->last = last_insn;
  tem->sequence_rtl_expr = sequence_rtl_expr;

  sequence_stack = tem;

  first_insn = 0;
  last_insn = 0;
}




void
start_sequence_for_rtl_expr(tree t) asm("_start_sequence_for_rtl_expr");
void
start_sequence_for_rtl_expr(tree t)
{
  start_sequence ();

  sequence_rtl_expr = t;
}




void
push_to_sequence(rtx first) asm("_push_to_sequence");
void
push_to_sequence(rtx first)
{
  rtx last;

  start_sequence ();

  for (last = first; last && ((last)->fld[2].rtx); last = ((last)->fld[2].rtx));

  first_insn = first;
  last_insn = last;
}




void
push_topmost_sequence(void) asm("_push_topmost_sequence");
void
push_topmost_sequence(void)
{
  struct n64_tag_sequence_stack *stack, *top;

  start_sequence ();

  for (stack = sequence_stack; stack; stack = stack->next)
    top = stack;

  first_insn = top->first;
  last_insn = top->last;
  sequence_rtl_expr = top->sequence_rtl_expr;
}




void
pop_topmost_sequence(void) asm("_pop_topmost_sequence");
void
pop_topmost_sequence(void)
{
  struct n64_tag_sequence_stack *stack, *top;

  for (stack = sequence_stack; stack; stack = stack->next)
    top = stack;

  top->first = first_insn;
  top->last = last_insn;


  end_sequence ();
}






void
end_sequence(void) asm("_end_sequence");
void
end_sequence(void)
{
  struct n64_tag_sequence_stack *tem = sequence_stack;

  first_insn = tem->first;
  last_insn = tem->last;
  sequence_rtl_expr = tem->sequence_rtl_expr;
  sequence_stack = tem->next;

  tem->next = sequence_element_free_list;
  sequence_element_free_list = tem;
}



int
in_sequence_p(void) asm("_in_sequence_p");
int
in_sequence_p(void)
{
  return sequence_stack != 0;
}







rtx
gen_sequence(void) asm("_gen_sequence");
rtx
gen_sequence(void)
{
  rtx result;
  rtx tem;
  int i;
  int len;


  len = 0;
  for (tem = first_insn; tem; tem = ((tem)->fld[2].rtx))
    len++;




  if (len == 1
      && (((first_insn)->code) == INSN
   || ((first_insn)->code) == JUMP_INSN

   || (((first_insn)->code) == CALL_INSN
       && ((first_insn)->fld[7].rtx) == (rtx) 0)))
    return ((first_insn)->fld[3].rtx);



  if (len < 5 && (result = sequence_result[len]) != 0)
    sequence_result[len] = 0;
  else
    {


      push_obstacks_nochange ();
      rtl_in_saveable_obstack ();
      result = gen_rtx (SEQUENCE, VOIDmode, rtvec_alloc (len));
      pop_obstacks ();
    }

  for (i = 0, tem = first_insn; tem; tem = ((tem)->fld[2].rtx), i++)
    ((result)->fld[0].rtvec->elem[i].rtx) = tem;

  return result;
}
static void restore_reg_data_1(...) asm("_restore_reg_data_1");

void
restore_reg_data(rtx first) asm("_restore_reg_data");
void
restore_reg_data(rtx first)
{
  register rtx insn;
  int i;
  register int max_uid = 0;

  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    {
      if (((insn)->fld[0].rtint) >= max_uid)
 max_uid = ((insn)->fld[0].rtint);

      switch (((insn)->code))
 {
 case NOTE:
 case CODE_LABEL:
 case BARRIER:
   break;

 case JUMP_INSN:
 case CALL_INSN:
 case INSN:
   restore_reg_data_1 (((insn)->fld[3].rtx));
   break;
 }
    }


  cur_insn_uid = max_uid + 1;






  for (i = 68; i < reg_rtx_no; i++)
    if (regno_reg_rtx[i] == 0)
      regno_reg_rtx[i] = gen_rtx (REG, word_mode, i);
}

static void
restore_reg_data_1(rtx orig) asm("_restore_reg_data_1");
static void
restore_reg_data_1(rtx orig)
{
  register rtx x = orig;
  register int i;
  register n64_enum_rtx_code code;
  register char *format_ptr;

  code = ((x)->code);

  switch (code)
    {
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
    case LABEL_REF:
      return;

    case REG:
      if (((x)->fld[0].rtint) >= 68)
 {


   if (((x)->fld[0].rtint) >= reg_rtx_no)
     {
       reg_rtx_no = ((x)->fld[0].rtint);

       if (reg_rtx_no >= regno_pointer_flag_length)
  {
    int newlen = ((regno_pointer_flag_length * 2) > (reg_rtx_no + 30) ? (regno_pointer_flag_length * 2) : (reg_rtx_no + 30))
                        ;
    rtx *new1;
    char *cxx_new = (char *) oballoc (newlen);
    memset (cxx_new,0,newlen);
    memcpy (cxx_new,regno_pointer_flag,regno_pointer_flag_length);

    new1 = (rtx *) oballoc (newlen * sizeof (rtx));
    memset ((char *) new1,0,newlen * sizeof (rtx));
    memcpy ((char *) new1,(char *) regno_reg_rtx,regno_pointer_flag_length * sizeof (rtx))
                                             ;

    regno_pointer_flag = cxx_new;
    regno_reg_rtx = new1;
    regno_pointer_flag_length = newlen;
  }
       reg_rtx_no ++;
     }
   regno_reg_rtx[((x)->fld[0].rtint)] = x;
 }
      return;

    case MEM:
      if (((((x)->fld[0].rtx))->code) == REG)
 mark_reg_pointer (((x)->fld[0].rtx));
      restore_reg_data_1 (((x)->fld[0].rtx));
      return;
    }



  format_ptr = (rtx_format[(int)(code)]);

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   restore_reg_data_1 (((x)->fld[i].rtx));
   break;

 case 'E':
   if (((x)->fld[i].rtvec) != 
                     ((void *)0)
                         )
     {
       register int j;

       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  restore_reg_data_1 (((x)->fld[i].rtvec->elem[j].rtx));
     }
   break;
 }
    }
}




void
init_emit(void) asm("_init_emit");
void
init_emit(void)
{
  int i;

  first_insn = 
              ((void *)0)
                  ;
  last_insn = 
             ((void *)0)
                 ;
  sequence_rtl_expr = 
                     ((void *)0)
                         ;
  cur_insn_uid = 1;
  reg_rtx_no = (((68)) + 3) + 1;
  last_linenum = 0;
  last_filename = 0;
  first_label_num = label_num;
  last_label_num = 0;
  sequence_stack = 
                  ((void *)0)
                      ;


  sequence_element_free_list = 0;
  for (i = 0; i < 5; i++)
    sequence_result[i] = 0;



  regno_pointer_flag_length = (((68)) + 3) + 101;

  regno_pointer_flag
    = (char *) oballoc (regno_pointer_flag_length);
  memset (regno_pointer_flag,0,regno_pointer_flag_length);

  regno_reg_rtx
    = (rtx *) oballoc (regno_pointer_flag_length * sizeof (rtx));
  memset ((char *) regno_reg_rtx,0,regno_pointer_flag_length * sizeof (rtx));


  regno_reg_rtx[((68))] = virtual_incoming_args_rtx;
  regno_reg_rtx[(((68)) + 1)] = virtual_stack_vars_rtx;
  regno_reg_rtx[(((68)) + 2)] = virtual_stack_dynamic_rtx;
  regno_reg_rtx[(((68)) + 3)] = virtual_outgoing_args_rtx;



  regno_pointer_flag[(0 + 29)] = 1;
  regno_pointer_flag[(0 + 30)] = 1;
  regno_pointer_flag[(0 + 30)] = 1;
  regno_pointer_flag[0] = 1;

  regno_pointer_flag[((68))] = 1;
  regno_pointer_flag[(((68)) + 1)] = 1;
  regno_pointer_flag[(((68)) + 2)] = 1;
  regno_pointer_flag[(((68)) + 3)] = 1;


  embedded_pic_fnaddr_rtx = 
 ((void *)0)
 ;;

}




void
init_emit_once(int line_numbers) asm("_init_emit_once");
void
init_emit_once(int line_numbers)
{
  int i;
  n64_enum_machine_mode mode;

  no_line_numbers = ! line_numbers;

  sequence_stack = 
                  ((void *)0)
                      ;



  byte_mode = VOIDmode;
  word_mode = VOIDmode;

  for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    {
      if ((8 * mode_size[(int)(mode)]) == 8
   && byte_mode == VOIDmode)
 byte_mode = mode;

      if ((8 * mode_size[(int)(mode)]) == ((target_flags & 0x00002000) ? 64 : 32)
   && word_mode == VOIDmode)
 word_mode = mode;
    }

  ptr_mode = mode_for_size (((target_flags & 0x00000002) ? 64 : 32), (mode_class[(int)(((target_flags & 0x00000002) ? DImode : SImode))]), 0);



  pc_rtx = gen_rtx (PC, VOIDmode);
  cc0_rtx = gen_rtx (CC0, VOIDmode);



  for (i = - 64; i <= 64; i++)
    {
      const_int_rtx[i + 64] = rtx_alloc (CONST_INT);
      ((const_int_rtx[i + 64])->mode = (VOIDmode));
      ((const_int_rtx[i + 64])->fld[0].rtwint) = i;
    }


  const0_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (0));
  const1_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (1));
  const2_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (2));
  constm1_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (-1));


  const_true_rtx = gen_rtx (CONST_INT, VOIDmode, (int) (1));

  dconst0 = ereal_atof ("0", DFmode);
  dconst1 = ereal_atof ("1", DFmode);
  dconst2 = ereal_atof ("2", DFmode);
  dconstm1 = ereal_atof ("-1", DFmode);

  for (i = 0; i <= 2; i++)
    {
      for (mode = class_narrowest_mode[(int)(MODE_FLOAT)]; mode != VOIDmode;
    mode = (mode_wider_mode[(int)(mode)]))
 {
   rtx tem = rtx_alloc (CONST_DOUBLE);
   union n64_tag_real_extract u;

   memset ((char *) &u,0,sizeof u);
   u.d = i == 0 ? dconst0 : i == 1 ? dconst1 : dconst2;

   memcpy ((char *) &((tem)->fld[2].rtwint),(char *) &u,sizeof u / 2);
   memcpy ((char *) &((tem)->fld[3].rtwint),(char *) &u + (sizeof u / 2),sizeof u / 2);
   ((tem)->fld[0].rtx) = cc0_rtx;
   ((tem)->mode = (mode));

   const_tiny_rtx[i][(int) mode] = tem;
 }

      const_tiny_rtx[i][(int) VOIDmode] = gen_rtx (CONST_INT, VOIDmode, (int) (i));

      for (mode = class_narrowest_mode[(int)(MODE_INT)]; mode != VOIDmode;
    mode = (mode_wider_mode[(int)(mode)]))
 const_tiny_rtx[i][(int) mode] = gen_rtx (CONST_INT, VOIDmode, (int) (i));

      for (mode = class_narrowest_mode[(int)(MODE_PARTIAL_INT)];
    mode != VOIDmode;
    mode = (mode_wider_mode[(int)(mode)]))
 const_tiny_rtx[i][(int) mode] = gen_rtx (CONST_INT, VOIDmode, (int) (i));
    }

  for (mode = class_narrowest_mode[(int)(MODE_CC)]; mode != VOIDmode;
       mode = (mode_wider_mode[(int)(mode)]))
    const_tiny_rtx[0][(int) mode] = const0_rtx;

  stack_pointer_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 29));
  frame_pointer_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 30));

  if ((0 + 30) == (0 + 30))
    hard_frame_pointer_rtx = frame_pointer_rtx;
  else
    hard_frame_pointer_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 30));

  if ((0 + 30) == 0)
    arg_pointer_rtx = frame_pointer_rtx;
  else if ((0 + 30) == 0)
    arg_pointer_rtx = hard_frame_pointer_rtx;
  else if ((0 + 29) == 0)
    arg_pointer_rtx = stack_pointer_rtx;
  else
    arg_pointer_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), 0);




  virtual_incoming_args_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode),
           ((68)));
  virtual_stack_vars_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode),
        (((68)) + 1));
  virtual_stack_dynamic_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode),
           (((68)) + 2));
  virtual_outgoing_args_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode),
           (((68)) + 3));


  struct_value_rtx = 0;
  struct_value_incoming_rtx = struct_value_rtx;




  static_chain_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 2));






    static_chain_incoming_rtx = static_chain_rtx;
  pic_offset_table_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 28));

}

