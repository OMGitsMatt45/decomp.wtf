// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/lex.c
/* Separate lexical analyzer for GNU C++.
   Copyright (C) 1987, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.
   Hacked by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdio.h>
#include <errno.h>
#include <setjmp.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
int cxx_getch(void) asm("_getch");
extern int getch(...) asm("_getch");
extern int error(...) asm("_error");
extern int get_run_time(...) asm("_get_run_time");
extern int cadillac_start(...) asm("_cadillac_start");
extern int init_repo(...) asm("_init_repo");
extern int set_identifier_size(...) asm("_set_identifier_size");
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int synthesize_method(...) asm("_synthesize_method");
extern int pedwarn(...) asm("_pedwarn");
extern int peekyylex(...) asm("_peekyylex");
extern int error_with_file_and_line(...) asm("_error_with_file_and_line");
extern int repo_template_used(...) asm("_repo_template_used");
extern int warning(...) asm("_warning");
extern int handle_sysv_pragma(...) asm("_handle_sysv_pragma");
extern int dwarfout_define(...) asm("_dwarfout_define");
extern int dwarfout_undef(...) asm("_dwarfout_undef");
extern int sorry(...) asm("_sorry");
extern int cadillac_note_source(...) asm("_cadillac_note_source");
extern int dwarfout_start_new_source_file(...) asm("_dwarfout_start_new_source_file");
extern int cadillac_push_source(...) asm("_cadillac_push_source");
extern int cadillac_pop_source(...) asm("_cadillac_pop_source");
extern int dwarfout_resume_previous_source_file(...) asm("_dwarfout_resume_previous_source_file");
extern int cadillac_switch_source(...) asm("_cadillac_switch_source");
extern int set_float_handler(...) asm("_set_float_handler");
extern int target_isinf(...) asm("_target_isinf");
extern int int_fits_type_p(...) asm("_int_fits_type_p");
extern int print_time(...) asm("_print_time");
extern int count_error(...) asm("_count_error");
extern int report_error_function(...) asm("_report_error_function");
struct n64_tag__obstack_chunk;
struct n64_tag_file_stack;
struct n64_tag_impl_files;
struct n64_tag_input_source;
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_obstack;
struct n64_tag_pending_inline;
struct n64_tag_pending_input;
union n64_tag_real_extract;
struct n64_tag_resword;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;
struct n64_tag_try_type;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct rtx_def *mips_load_reg;
extern struct rtx_def *mips_load_reg2;
extern struct rtx_def *mips_load_reg3;
extern struct rtx_def *mips_load_reg4;
extern struct rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
extern char *input_filename;


extern char *main_input_filename;


extern int lineno;


extern FILE *finput;

struct n64_tag_file_stack
  {
    char *name;
    struct n64_tag_file_stack *next;
    int line;
  };



extern struct n64_tag_file_stack *input_file_stack;


extern int input_file_stack_tick;
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct n64_tag_obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_BOOL,
  RID_CHAR,
  RID_WCHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,


  RID_CLASS,
  RID_RECORD,
  RID_UNION,
  RID_ENUM,
  RID_LONGLONG,





  RID_EXTERN,
  RID_CONST,
  RID_LONG,
  RID_TYPEDEF,
  RID_UNSIGNED,
  RID_SHORT,
  RID_INLINE,

  RID_STATIC,

  RID_REGISTER,
  RID_VOLATILE,
  RID_FRIEND,
  RID_VIRTUAL,
  RID_EXPLICIT,
  RID_SIGNED,
  RID_AUTO,
  RID_MUTABLE,



  RID_PUBLIC,
  RID_PRIVATE,
  RID_PROTECTED,
  RID_EXCEPTION,
  RID_TEMPLATE,
  RID_SIGNATURE,


  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

typedef struct { unsigned long idata[2]; }
     RID_BIT_TYPE;
extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;


extern int looking_for_typename;
extern int looking_for_template;


extern tree got_scope;
extern tree got_object;



extern int pending_lang_change;

extern tree make_pointer_declarator (...) asm("_make_pointer_declarator"), make_reference_declarator (...) asm("_make_reference_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern void reinit_parse_for_method(...) asm("_reinit_parse_for_method");
extern int yylex(void) asm("_yylex");
typedef union {long itype; tree ttype; char *strtype; n64_enum_tree_code code; } YYSTYPE;
extern YYSTYPE yylval;
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct rtx_def *, struct rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
enum n64_cpp_enum_pragma_state{
  ps_start,
  ps_done,
  ps_bad,
  ps_weak,
  ps_name,
  ps_equals,
  ps_value,
  ps_pack,
  ps_left,
  ps_align,
  ps_right
};
typedef __underlying_type(enum n64_cpp_enum_pragma_state) n64_enum_pragma_state;



extern void handle_pragma_weak (n64_enum_pragma_state, char *, char *) asm("_handle_pragma_weak");


extern void handle_pragma_token (char *, tree) asm("_handle_pragma_token");
extern jmp_buf toplevel;




extern struct n64_tag_obstack *expression_obstack, permanent_obstack;
extern struct n64_tag_obstack *current_obstack, *saveable_obstack;

extern double atof(...) asm("_atof");

extern char *get_directive_line(...) asm("_get_directive_line");
extern char *strchr(...) asm("_strchr");
extern char *strrchr(...) asm("_strrchr");

void extract_interface_info(void) asm("_extract_interface_info");
void yyerror(...) asm("_yyerror");



struct n64_tag_obstack inline_text_obstack;
static char *inline_text_firstobj;




struct n64_tag_obstack synth_obstack;
static char *synth_firstobj;

int end_of_file;



int pending_lang_change = 0;


static int c_header_level = 0;

extern int first_token;
extern struct n64_tag_obstack token_obstack;



extern FILE *finput;

struct n64_tag_pending_input *save_pending_input(void) asm("_save_pending_input");
void restore_pending_input(...) asm("_restore_pending_input");

struct n64_tag_input_source {

  char *str;
  int length;

  int offset;

  struct n64_tag_obstack *obstack;

  struct n64_tag_input_source *next;

  char *filename;
  int lineno;
  struct n64_tag_pending_input *input;
  int putback_char;
};

static struct n64_tag_input_source *input, *free_inputs;

extern char *input_filename;
extern int lineno;







static  struct n64_tag_input_source *
allocate_input(void) asm("_allocate_input");
static  struct n64_tag_input_source *
allocate_input(void)
{
  struct n64_tag_input_source *inp;
  if (free_inputs)
    {
      inp = free_inputs;
      free_inputs = inp->next;
      inp->next = 0;
      return inp;
    }
  inp = (struct n64_tag_input_source *) xmalloc (sizeof (struct n64_tag_input_source));
  inp->next = 0;
  inp->obstack = 0;
  return inp;
}

static  void
free_input(struct n64_tag_input_source *inp) asm("_free_input");
static  void
free_input(struct n64_tag_input_source *inp)
{
  if (inp->obstack)
    __extension__ ({ struct n64_tag_obstack *__o = (inp->obstack); void *__obj = (inp->str); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  inp->obstack = 0;
  inp->str = 0;
  inp->length = 0;
  inp->next = free_inputs;
  free_inputs = inp;
}

static int putback_char = -1;





void
feed_input(char *str, int len, struct n64_tag_obstack *cxx_delete) asm("_feed_input");
void
feed_input(char *str, int len, struct n64_tag_obstack *cxx_delete)
{
  struct n64_tag_input_source *inp = allocate_input ();


  while (len && !str[len-1])
    len--;

  inp->str = str;
  inp->length = len;
  inp->obstack = cxx_delete;
  inp->offset = 0;
  inp->next = input;
  inp->filename = input_filename;
  inp->lineno = lineno;
  inp->input = save_pending_input ();
  inp->putback_char = putback_char;
  putback_char = -1;
  input = inp;
}

struct n64_tag_pending_input *to_be_restored;
extern int end_of_file;

static  int
sub_getch(void) asm("_sub_getch");
static  int
sub_getch(void)
{
  if (putback_char != -1)
    {
      int ch = putback_char;
      putback_char = -1;
      return ch;
    }
  if (input)
    {
      if (input->offset == input->length)
 {
   struct n64_tag_input_source *inp = input;
   my_friendly_assert (putback_char == -1, 223);
   to_be_restored = inp->input;
   input->offset++;
   return 
         (-1)
            ;
 }
      else if (input->offset > input->length)
 {
   struct n64_tag_input_source *inp = input;

   end_of_file = 0;
   input = inp->next;
   input_filename = inp->filename;
   lineno = inp->lineno;

   extract_interface_info ();
   putback_char = inp->putback_char;
   free_input (inp);
   return cxx_getch ();
 }
      if (input)
 return input->str[input->offset++];
    }
  return getc (finput);
}


void
put_back(int ch) asm("_put_back");
void
put_back(int ch)
{
  if (ch != 
           (-1)
              )
    {
      my_friendly_assert (putback_char == -1, 224);
      putback_char = ch;
    }
}

extern int linemode;

int
cxx_getch(void) asm("_getch");
int
cxx_getch(void)
{
  int ch = sub_getch ();
  if (linemode && ch == '\n')
    {
      put_back (ch);
      ch = 
          (-1)
             ;
    }
  return ch;
}


int
input_redirected(void) asm("_input_redirected");
int
input_redirected(void)
{
  return input != 0;
}
char **opname_tab;
char **assignop_tab;

extern int yychar;
extern YYSTYPE yylval;
tree lastiddecl;




tree ridpointers[(int) RID_MAX];


static int header_time, body_time;
static tree get_time_identifier(...) asm("_get_time_identifier");
static tree filename_times;
static tree this_filename_time;


tree current_unit_name;
tree current_unit_language;


extern int *token_count;


static void default_copy_constructor_body(...) asm("_default_copy_constructor_body");
static void default_assign_ref_body(...) asm("_default_assign_ref_body");
tree
make_pointer_declarator(tree type_quals, tree target) asm("_make_pointer_declarator");
tree
make_pointer_declarator(tree type_quals, tree target)
{
  if (target && ((n64_enum_tree_code) (target)->common.code) == IDENTIFIER_NODE
      && (((target)->identifier.pointer)[0] == '.' && ((target)->identifier.pointer)[1] == '_'))
    error ("type name expected before `*'");
  target = build_parse_node (INDIRECT_REF, target);
  ((target)->common.type) = type_quals;
  return target;
}
tree
make_reference_declarator(tree type_quals, tree target) asm("_make_reference_declarator");
tree
make_reference_declarator(tree type_quals, tree target)
{
  if (target)
    {
      if (((n64_enum_tree_code) (target)->common.code) == ADDR_EXPR)
 {
   error ("cannot declare references to references");
   return target;
 }
      if (((n64_enum_tree_code) (target)->common.code) == INDIRECT_REF)
 {
   error ("cannot declare pointers to references");
   return target;
 }
      if (((n64_enum_tree_code) (target)->common.code) == IDENTIFIER_NODE && (((target)->identifier.pointer)[0] == '.' && ((target)->identifier.pointer)[1] == '_'))
   error ("type name expected before `&'");
    }
  target = build_parse_node (ADDR_EXPR, target);
  ((target)->common.type) = type_quals;
  return target;
}



tree ansi_opname[LAST_CPLUS_TREE_CODE];
tree ansi_assopname[LAST_CPLUS_TREE_CODE];

char *
operator_name_string(tree name) asm("_operator_name_string");
char *
operator_name_string(tree name)
{
  char *opname = ((name)->identifier.pointer) + 2;
  tree *opname_table;
  int i, assign;


  if ((((struct n64_tag_lang_identifier *)(name))->global_value)
      && ((n64_enum_tree_code) ((((struct n64_tag_lang_identifier *)(name))->global_value))->common.code) == TYPE_DECL)
    return ((name)->identifier.pointer);

  if (opname[0] == 'a' && opname[2] != '\0' && opname[2] != '_')
    {
      opname += 1;
      assign = 1;
      opname_table = ansi_assopname;
    }
  else
    {
      assign = 0;
      opname_table = ansi_opname;
    }

  for (i = 0; i < (int) LAST_CPLUS_TREE_CODE; i++)
    {
      if (opname[0] == ((opname_table[i])->identifier.pointer)[2+assign]
   && opname[1] == ((opname_table[i])->identifier.pointer)[3+assign])
 break;
    }

  if (i == LAST_CPLUS_TREE_CODE)
    return "<invalid operator>";

  if (assign)
    return assignop_tab[i];
  else
    return opname_tab[i];
}

int interface_only;

int interface_unknown;





extern FILE *asm_out_file;
static int maxtoken;
char *token_buffer;





struct n64_tag_resword { char *name; short token; n64_enum_rid rid;};


static unsigned int
hash(register char *str, register unsigned int len) asm("_hash");
static unsigned int
hash(register char *str, register unsigned int len)
{
  static unsigned char asso_values[] =
    {
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 220, 220, 220, 220, 220,
     220, 220, 220, 220, 220, 0, 220, 88, 16, 19,
      52, 0, 9, 72, 1, 77, 220, 0, 0, 38,
      13, 44, 38, 30, 27, 57, 1, 14, 0, 2,
       2, 7, 220, 220, 220, 220, 220, 220,
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 7:
        hval += asso_values[str[6]];
      case 6:
      case 5:
      case 4:
        hval += asso_values[str[3]];
      case 3:
      case 2:
      case 1:
        hval += asso_values[str[0]];
    }
  return hval + asso_values[str[len - 1]];
}




struct n64_tag_resword *
is_reserved_word(register char *str, register unsigned int len) asm("_is_reserved_word");
struct n64_tag_resword *
is_reserved_word(register char *str, register unsigned int len)
{
  static struct n64_tag_resword wordlist[] =
    {
      {"",}, {"",}, {"",}, {"",},
      {"else", 269, RID_UNUSED,},
      {"true", 295, RID_UNUSED,},
      {"",},
      {"while", 270, RID_UNUSED,},
      {"virtual", 260, RID_VIRTUAL,},
      {"",}, {"",},
      {"try", 328, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",},
      {"typeof", 282, RID_UNUSED,},
      {"not", '!', RID_UNUSED,},
      {"new", 291, RID_UNUSED,},
      {"extern", 260, RID_EXTERN,},
      {"bool", 261, RID_BOOL,},
      {"",}, {"",},
      {"case", 274, RID_UNUSED,},
      {"__alignof__", 283, RID_UNUSED},
      {"",},
      {"typedef", 260, RID_TYPEDEF,},
      {"",},
      {"__extension__", 286, RID_UNUSED},
      {"",}, {"",},
      {"__alignof", 283, RID_UNUSED},
      {"xor", '^', RID_UNUSED,},
      {"",},
      {"__inline", 260, RID_INLINE},
      {"",},
      {"__inline__", 260, RID_INLINE},
      {"",},
      {"xor_eq", 312, RID_UNUSED,},
      {"for", 272, RID_UNUSED,},
      {"",}, {"",},
      {"continue", 277, RID_UNUSED,},
      {"",},
      {"catch", 329, RID_UNUSED,},
      {"private", 289, RID_PRIVATE,},
      {"",},
      {"typename", 298, RID_UNUSED,},
      {"template", 301, RID_TEMPLATE,},
      {"not_eq", 316, RID_UNUSED,},
      {"",}, {"",},
      {"throw", 311, RID_UNUSED,},
      {"__const", 262, RID_CONST},
      {"__const__", 262, RID_CONST},
      {"__volatile", 262, RID_VOLATILE},
      {"__wchar_t", 261, RID_WCHAR ,},
      {"__volatile__", 262, RID_VOLATILE},
      {"delete", 290, RID_UNUSED,},
      {"typeid", 302, RID_UNUSED,},
      {"return", 278, RID_UNUSED,},
      {"__typeof__", 282, RID_UNUSED},
      {"compl", '~', RID_UNUSED,},
      {"public", 289, RID_PUBLIC,},
      {"__asm__", 281, RID_UNUSED},
      {"switch", 273, RID_UNUSED,},
      {"",},
      {"friend", 260, RID_FRIEND,},
      {"__typeof", 282, RID_UNUSED},
      {"",},
      {"static_cast", 304, RID_UNUSED,},
      {"false", 296, RID_UNUSED,},
      {"sizeof", 266, RID_UNUSED,},
      {"or", 313, RID_UNUSED,},
      {"double", 261, RID_DOUBLE,},
      {"",},
      {"union", 288, RID_UNION,},
      {"char", 261, RID_CHAR,},
      {"struct", 288, RID_RECORD,},
      {"or_eq", 312, RID_UNUSED,},
      {"enum", 267, RID_UNUSED,},
      {"int", 261, RID_INT,},
      {"const", 262, RID_CONST,},
      {"static", 260, RID_STATIC,},
      {"reinterpret_cast", 305, RID_UNUSED,},
      {"",},
      {"explicit", 260, RID_EXPLICIT,},
      {"__signed__", 261, RID_SIGNED},
      {"if", 268, RID_UNUSED,},
      {"__attribute", 285, RID_UNUSED},
      {"short", 261, RID_SHORT,},
      {"__attribute__", 285, RID_UNUSED},
      {"bitor", '|', RID_UNUSED,},
      {"signature", 288, RID_SIGNATURE ,},
      {"",},
      {"__sigof__", 284, RID_UNUSED ,},
      {"volatile", 262, RID_VOLATILE,},
      {"__label__", 287, RID_UNUSED},
      {"do", 271, RID_UNUSED,},
      {"",},
      {"__asm", 281, RID_UNUSED},
      {"protected", 289, RID_PROTECTED,},
      {"",},
      {"float", 261, RID_FLOAT,},
      {"using", 299, RID_UNUSED,},
      {"",},
      {"const_cast", 306, RID_UNUSED,},
      {"",},
      {"void", 261, RID_VOID,},
      {"break", 276, RID_UNUSED,},
      {"namespace", 297, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",},
      {"sigof", 284, RID_UNUSED ,},
      {"",}, {"",}, {"",},
      {"this", 293, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",},
      {"and_eq", 312, RID_UNUSED,},
      {"",}, {"",}, {"",},
      {"signed", 261, RID_SIGNED,},
      {"asm", 280, RID_UNUSED,},
      {"",}, {"",}, {"",},
      {"mutable", 260, RID_MUTABLE,},
      {"",}, {"",}, {"",},
      {"__signed", 261, RID_SIGNED},
      {"class", 288, RID_CLASS,},
      {"register", 260, RID_REGISTER,},
      {"",}, {"",}, {"",},
      {"and", 314, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",},
      {"long", 261, RID_LONG,},
      {"default", 275, RID_UNUSED,},
      {"operator", 294, RID_UNUSED,},
      {"unsigned", 261, RID_UNSIGNED,},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"inline", 260, RID_INLINE,},
      {"",},
      {"bitand", '&', RID_UNUSED,},
      {"",},
      {"goto", 279, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"dynamic_cast", 303, RID_UNUSED,},
      {"",}, {"",}, {"",}, {"",}, {"",},
      {"__signature__", 288, RID_SIGNATURE ,},
      {"",},
      {"auto", 260, RID_AUTO,},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",}, {"",},
      {"",}, {"",},
      {"overload", 292, RID_UNUSED,},
    };

  if (len <= 16 && len >= 2)
    {
      register int key = hash (str, len);

      if (key <= 219 && key >= 0)
        {
          register char *s = wordlist[key].name;

          if (*s == *str && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}

int check_newline(void) asm("_check_newline");


static int ignore_escape_flag = 0;

static int skip_white_space(...) asm("_skip_white_space");

static tree
get_time_identifier(char *name) asm("_get_time_identifier");
static tree
get_time_identifier(char *name)
{
  tree time_identifier;
  int len = strlen (name);
  char *buf = (char *) 
                      __builtin_alloca((
                      len + 6
                      ))
                                      ;
  strcpy (buf, "file ");
  memcpy (buf+5,name,len);
  buf[len+5] = '\0';
  time_identifier = get_identifier (buf);
  if ((((struct n64_tag_lang_identifier *)(time_identifier))->local_value) == (tree) 
                                                 ((void *)0)
                                                          )
    {
      push_obstacks_nochange ();
      end_temporary_allocation ();
      (((struct n64_tag_lang_identifier *)(time_identifier))->local_value) = build_int_2_wide ((int) (0), (int) (0));
      (((struct n64_tag_lang_identifier *)(time_identifier))->class_value) = build_int_2_wide ((int) (0), (int) (1));
      (((struct n64_tag_lang_identifier *)(time_identifier))->global_value) = filename_times;
      filename_times = time_identifier;
      pop_obstacks ();
    }
  return time_identifier;
}




static int
my_get_run_time(void) asm("_my_get_run_time");
static int
my_get_run_time(void)
{
  int old_quiet_flag = quiet_flag;
  int this_time;
  quiet_flag = 0;
  this_time = get_run_time ();
  quiet_flag = old_quiet_flag;
  return this_time;
}







char *cplus_tree_code_type[] = {
  "x",
"r",




"e",
"e",
"e",





"r",




"r",



"e",




"e",
"e",



"e",
"d",



"t",



"c",







"t",
"d",


"d",
};
int cplus_tree_code_length[] = {
  0,
2,




2,
2,
1,





2,




2,



1,




3,
3,



1,
0,



0,



2,







0,
0,


0,
};






char *cplus_tree_code_name[] = {
  "@@dummy",
"cp_offset_ref",




"dl_expr",
"vec_dl_expr",
"unsave_expr",





"scope_ref",




"member_ref",



"type_expr",




"nw_expr",
"vec_nw_expr",



"throw_expr",
"template_decl",



"template_type_parm",



"template_const_parm",







"uninstantiated_p_type",
"thunk_decl",


"namespace_decl",
};




void
lang_init(void) asm("_lang_init");
void
lang_init(void)
{



  put_back (check_newline ());

  if (flag_cadillac)
    cadillac_start ();
  if (flag_gnu_xref) GNU_xref_begin (input_filename);
  init_repo (input_filename);
}

void
lang_finish(void) asm("_lang_finish");
void
lang_finish(void)
{
  extern int errorcount, sorrycount;
  if (flag_gnu_xref) GNU_xref_end (errorcount+sorrycount);
}

char *
lang_identify(void) asm("_lang_identify");
char *
lang_identify(void)
{
  return "cplusplus";
}

void
init_filename_times(void) asm("_init_filename_times");
void
init_filename_times(void)
{
  this_filename_time = get_time_identifier ("<top level>");
  if (flag_detailed_statistics)
    {
      header_time = 0;
      body_time = my_get_run_time ();
      (((((struct n64_tag_lang_identifier *)(this_filename_time))->local_value))->int_cst.int_cst_low) = body_time;
    }
}




void
reinit_lang_specific(void) asm("_reinit_lang_specific");
void
reinit_lang_specific(void)
{
  init_filename_times ();
  reinit_search_statistics ();
}

void
init_lex(void) asm("_init_lex");
void
init_lex(void)
{
  extern char *(*decl_printable_name)(...);
  extern int flag_no_gnu_keywords;
  extern int flag_operator_names;

  int i;


  init_spew ();


  set_identifier_size (sizeof (struct n64_tag_lang_identifier));
  decl_printable_name = lang_printable_name;

  init_cplus_expand ();

  tree_code_type
    = (char **) realloc (tree_code_type,
    sizeof (char *) * LAST_CPLUS_TREE_CODE);
  tree_code_length
    = (int *) realloc (tree_code_length,
         sizeof (int) * LAST_CPLUS_TREE_CODE);
  tree_code_name
    = (char **) realloc (tree_code_name,
    sizeof (char *) * LAST_CPLUS_TREE_CODE);
  memcpy ((char *)(tree_code_type + (int) LAST_AND_UNUSED_TREE_CODE),(char *)cplus_tree_code_type,(LAST_CPLUS_TREE_CODE - (int)LAST_AND_UNUSED_TREE_CODE) * sizeof (char *))

                                                                            ;
  memcpy ((char *)(tree_code_length + (int) LAST_AND_UNUSED_TREE_CODE),(char *)cplus_tree_code_length,(LAST_CPLUS_TREE_CODE - (int)LAST_AND_UNUSED_TREE_CODE) * sizeof (int))

                                                                         ;
  memcpy ((char *)(tree_code_name + (int) LAST_AND_UNUSED_TREE_CODE),(char *)cplus_tree_code_name,(LAST_CPLUS_TREE_CODE - (int)LAST_AND_UNUSED_TREE_CODE) * sizeof (char *))

                                                                            ;

  opname_tab = (char **)oballoc ((int)LAST_CPLUS_TREE_CODE * sizeof (char *));
  memset ((char *)opname_tab,0,(int)LAST_CPLUS_TREE_CODE * sizeof (char *));
  assignop_tab = (char **)oballoc ((int)LAST_CPLUS_TREE_CODE * sizeof (char *));
  memset ((char *)assignop_tab,0,(int)LAST_CPLUS_TREE_CODE * sizeof (char *));

  ansi_opname[0] = get_identifier ("<invalid operator>");
  for (i = 0; i < (int) LAST_CPLUS_TREE_CODE; i++)
    {
      ansi_opname[i] = ansi_opname[0];
      ansi_assopname[i] = ansi_opname[0];
    }

  ansi_opname[(int) MULT_EXPR] = get_identifier ("__ml");
  ((ansi_opname[(int) MULT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) INDIRECT_REF] = ansi_opname[(int) MULT_EXPR];
  ansi_assopname[(int) MULT_EXPR] = get_identifier ("__aml");
  ((ansi_assopname[(int) MULT_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) INDIRECT_REF] = ansi_assopname[(int) MULT_EXPR];
  ansi_opname[(int) TRUNC_MOD_EXPR] = get_identifier ("__md");
  ((ansi_opname[(int) TRUNC_MOD_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) TRUNC_MOD_EXPR] = get_identifier ("__amd");
  ((ansi_assopname[(int) TRUNC_MOD_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) CEIL_MOD_EXPR] = ansi_opname[(int) TRUNC_MOD_EXPR];
  ansi_opname[(int) FLOOR_MOD_EXPR] = ansi_opname[(int) TRUNC_MOD_EXPR];
  ansi_opname[(int) ROUND_MOD_EXPR] = ansi_opname[(int) TRUNC_MOD_EXPR];
  ansi_opname[(int) MINUS_EXPR] = get_identifier ("__mi");
  ((ansi_opname[(int) MINUS_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) NEGATE_EXPR] = ansi_opname[(int) MINUS_EXPR];
  ansi_assopname[(int) MINUS_EXPR] = get_identifier ("__ami");
  ((ansi_assopname[(int) MINUS_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) NEGATE_EXPR] = ansi_assopname[(int) MINUS_EXPR];
  ansi_opname[(int) RSHIFT_EXPR] = get_identifier ("__rs");
  ((ansi_opname[(int) RSHIFT_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) RSHIFT_EXPR] = get_identifier ("__ars");
  ((ansi_assopname[(int) RSHIFT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) NE_EXPR] = get_identifier ("__ne");
  ((ansi_opname[(int) NE_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) GT_EXPR] = get_identifier ("__gt");
  ((ansi_opname[(int) GT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) GE_EXPR] = get_identifier ("__ge");
  ((ansi_opname[(int) GE_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) BIT_IOR_EXPR] = get_identifier ("__or");
  ((ansi_opname[(int) BIT_IOR_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) BIT_IOR_EXPR] = get_identifier ("__aor");
  ((ansi_assopname[(int) BIT_IOR_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) TRUTH_ANDIF_EXPR] = get_identifier ("__aa");
  ((ansi_opname[(int) TRUTH_ANDIF_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) TRUTH_NOT_EXPR] = get_identifier ("__nt");
  ((ansi_opname[(int) TRUTH_NOT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) PREINCREMENT_EXPR] = get_identifier ("__pp");
  ((ansi_opname[(int) PREINCREMENT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) POSTINCREMENT_EXPR] = ansi_opname[(int) PREINCREMENT_EXPR];
  ansi_opname[(int) MODIFY_EXPR] = get_identifier ("__as");
  ((ansi_opname[(int) MODIFY_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) NOP_EXPR] = ansi_opname[(int) MODIFY_EXPR];
  ansi_opname[(int) COMPOUND_EXPR] = get_identifier ("__cm");
  ((ansi_opname[(int) COMPOUND_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) EXACT_DIV_EXPR] = get_identifier ("__dv");
  ((ansi_opname[(int) EXACT_DIV_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) EXACT_DIV_EXPR] = get_identifier ("__adv");
  ((ansi_assopname[(int) EXACT_DIV_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) TRUNC_DIV_EXPR] = ansi_opname[(int) EXACT_DIV_EXPR];
  ansi_opname[(int) CEIL_DIV_EXPR] = ansi_opname[(int) EXACT_DIV_EXPR];
  ansi_opname[(int) FLOOR_DIV_EXPR] = ansi_opname[(int) EXACT_DIV_EXPR];
  ansi_opname[(int) ROUND_DIV_EXPR] = ansi_opname[(int) EXACT_DIV_EXPR];
  ansi_opname[(int) PLUS_EXPR] = get_identifier ("__pl");
  ansi_assopname[(int) TRUNC_DIV_EXPR] = ansi_assopname[(int) EXACT_DIV_EXPR];
  ansi_assopname[(int) CEIL_DIV_EXPR] = ansi_assopname[(int) EXACT_DIV_EXPR];
  ansi_assopname[(int) FLOOR_DIV_EXPR] = ansi_assopname[(int) EXACT_DIV_EXPR];
  ansi_assopname[(int) ROUND_DIV_EXPR] = ansi_assopname[(int) EXACT_DIV_EXPR];
  ((ansi_opname[(int) PLUS_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) PLUS_EXPR] = get_identifier ("__apl");
  ((ansi_assopname[(int) PLUS_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) CONVERT_EXPR] = ansi_opname[(int) PLUS_EXPR];
  ansi_assopname[(int) CONVERT_EXPR] = ansi_assopname[(int) PLUS_EXPR];
  ansi_opname[(int) LSHIFT_EXPR] = get_identifier ("__ls");
  ((ansi_opname[(int) LSHIFT_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) LSHIFT_EXPR] = get_identifier ("__als");
  ((ansi_assopname[(int) LSHIFT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) EQ_EXPR] = get_identifier ("__eq");
  ((ansi_opname[(int) EQ_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) LT_EXPR] = get_identifier ("__lt");
  ((ansi_opname[(int) LT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) LE_EXPR] = get_identifier ("__le");
  ((ansi_opname[(int) LE_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) BIT_AND_EXPR] = get_identifier ("__ad");
  ((ansi_opname[(int) BIT_AND_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) BIT_AND_EXPR] = get_identifier ("__aad");
  ((ansi_assopname[(int) BIT_AND_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) ADDR_EXPR] = ansi_opname[(int) BIT_AND_EXPR];
  ansi_assopname[(int) ADDR_EXPR] = ansi_assopname[(int) BIT_AND_EXPR];
  ansi_opname[(int) BIT_XOR_EXPR] = get_identifier ("__er");
  ((ansi_opname[(int) BIT_XOR_EXPR])->common.lang_flag_2) = 1;
  ansi_assopname[(int) BIT_XOR_EXPR] = get_identifier ("__aer");
  ((ansi_assopname[(int) BIT_XOR_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) TRUTH_ORIF_EXPR] = get_identifier ("__oo");
  ((ansi_opname[(int) TRUTH_ORIF_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) BIT_NOT_EXPR] = get_identifier ("__co");
  ((ansi_opname[(int) BIT_NOT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) PREDECREMENT_EXPR] = get_identifier ("__mm");
  ((ansi_opname[(int) PREDECREMENT_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) POSTDECREMENT_EXPR] = ansi_opname[(int) PREDECREMENT_EXPR];
  ansi_opname[(int) COMPONENT_REF] = get_identifier ("__rf");
  ((ansi_opname[(int) COMPONENT_REF])->common.lang_flag_2) = 1;
  ansi_opname[(int) MEMBER_REF] = get_identifier ("__rm");
  ((ansi_opname[(int) MEMBER_REF])->common.lang_flag_2) = 1;
  ansi_opname[(int) CALL_EXPR] = get_identifier ("__cl");
  ((ansi_opname[(int) CALL_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) ARRAY_REF] = get_identifier ("__vc");
  ((ansi_opname[(int) ARRAY_REF])->common.lang_flag_2) = 1;
  ansi_opname[(int) NEW_EXPR] = get_identifier ("__nw");
  ((ansi_opname[(int) NEW_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) DELETE_EXPR] = get_identifier ("__dl");
  ((ansi_opname[(int) DELETE_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) VEC_NEW_EXPR] = get_identifier ("__vn");
  ((ansi_opname[(int) VEC_NEW_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) VEC_DELETE_EXPR] = get_identifier ("__vd");
  ((ansi_opname[(int) VEC_DELETE_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) TYPE_EXPR] = get_identifier ("__op");
  ((ansi_opname[(int) TYPE_EXPR])->common.lang_flag_2) = 1;



  ansi_opname[(int) MIN_EXPR] = get_identifier ("__mn");
  ((ansi_opname[(int) MIN_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) MAX_EXPR] = get_identifier ("__mx");
  ((ansi_opname[(int) MAX_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) COND_EXPR] = get_identifier ("__cn");
  ((ansi_opname[(int) COND_EXPR])->common.lang_flag_2) = 1;
  ansi_opname[(int) METHOD_CALL_EXPR] = get_identifier ("__wr");
  ((ansi_opname[(int) METHOD_CALL_EXPR])->common.lang_flag_2) = 1;

  init_method ();
  init_error ();
  gcc_obstack_init (&inline_text_obstack);
  inline_text_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&inline_text_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  gcc_obstack_init (&synth_obstack);
  synth_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&synth_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });



  lineno = 0;
  input_filename = "<internal>";
  current_function_decl = 
                         ((void *)0)
                             ;

  maxtoken = 40;
  token_buffer = (char *) xmalloc (maxtoken + 2);

  ridpointers[(int) RID_INT] = get_identifier ("int");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INT]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INT]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INT]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_INT])))
                                                             ;
  ridpointers[(int) RID_BOOL] = get_identifier ("bool");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_BOOL]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_BOOL]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_BOOL]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_BOOL])))
                                                              ;
  ridpointers[(int) RID_CHAR] = get_identifier ("char");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CHAR]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CHAR]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CHAR]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_CHAR])))
                                                              ;
  ridpointers[(int) RID_VOID] = get_identifier ("void");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOID]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOID]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOID]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_VOID])))
                                                              ;
  ridpointers[(int) RID_FLOAT] = get_identifier ("float");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FLOAT]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FLOAT]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FLOAT]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_FLOAT])))
                                                               ;
  ridpointers[(int) RID_DOUBLE] = get_identifier ("double");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_DOUBLE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_DOUBLE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_DOUBLE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_DOUBLE])))
                                                                ;
  ridpointers[(int) RID_SHORT] = get_identifier ("short");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SHORT]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SHORT]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SHORT]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_SHORT])))
                                                               ;
  ridpointers[(int) RID_LONG] = get_identifier ("long");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_LONG]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_LONG]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_LONG]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_LONG])))
                                                              ;
  ridpointers[(int) RID_UNSIGNED] = get_identifier ("unsigned");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_UNSIGNED]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_UNSIGNED]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_UNSIGNED]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_UNSIGNED])))
                                                                  ;
  ridpointers[(int) RID_SIGNED] = get_identifier ("signed");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SIGNED]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SIGNED]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_SIGNED]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_SIGNED])))
                                                                ;
  ridpointers[(int) RID_INLINE] = get_identifier ("inline");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INLINE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INLINE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_INLINE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_INLINE])))
                                                                ;
  ridpointers[(int) RID_CONST] = get_identifier ("const");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CONST]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CONST]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_CONST]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_CONST])))
                                                               ;
  ridpointers[(int) RID_VOLATILE] = get_identifier ("volatile");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOLATILE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOLATILE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VOLATILE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_VOLATILE])))
                                                                  ;
  ridpointers[(int) RID_AUTO] = get_identifier ("auto");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_AUTO]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_AUTO]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_AUTO]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_AUTO])))
                                                              ;
  ridpointers[(int) RID_STATIC] = get_identifier ("static");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_STATIC]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_STATIC]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_STATIC]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_STATIC])))
                                                                ;
  ridpointers[(int) RID_EXTERN] = get_identifier ("extern");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXTERN]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXTERN]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXTERN]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_EXTERN])))
                                                                ;
  ridpointers[(int) RID_TYPEDEF] = get_identifier ("typedef");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TYPEDEF]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TYPEDEF]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TYPEDEF]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_TYPEDEF])))
                                                                 ;
  ridpointers[(int) RID_REGISTER] = get_identifier ("register");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_REGISTER]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_REGISTER]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_REGISTER]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_REGISTER])))
                                                                  ;


  ridpointers[(int) RID_WCHAR] = get_identifier ("__wchar_t");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_WCHAR]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_WCHAR]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_WCHAR]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_WCHAR])))
                                                               ;
  class_type_node = build_int_2_wide ((int) (class_type), (int) (0));
  ((class_type_node)->common.type) = class_type_node;
  ridpointers[(int) RID_CLASS] = class_type_node;

  record_type_node = build_int_2_wide ((int) (record_type), (int) (0));
  ((record_type_node)->common.type) = record_type_node;
  ridpointers[(int) RID_RECORD] = record_type_node;

  union_type_node = build_int_2_wide ((int) (union_type), (int) (0));
  ((union_type_node)->common.type) = union_type_node;
  ridpointers[(int) RID_UNION] = union_type_node;

  enum_type_node = build_int_2_wide ((int) (enum_type), (int) (0));
  ((enum_type_node)->common.type) = enum_type_node;
  ridpointers[(int) RID_ENUM] = enum_type_node;

  ridpointers[(int) RID_VIRTUAL] = get_identifier ("virtual");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VIRTUAL]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VIRTUAL]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_VIRTUAL]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_VIRTUAL])))
                                                                 ;
  ridpointers[(int) RID_EXPLICIT] = get_identifier ("explicit");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXPLICIT]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXPLICIT]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_EXPLICIT]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_EXPLICIT])))
                                                                  ;
  ridpointers[(int) RID_FRIEND] = get_identifier ("friend");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FRIEND]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FRIEND]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_FRIEND]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_FRIEND])))
                                                                ;

  ridpointers[(int) RID_PUBLIC] = get_identifier ("public");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PUBLIC]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PUBLIC]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PUBLIC]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_PUBLIC])))
                                                                ;
  ridpointers[(int) RID_PRIVATE] = get_identifier ("private");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PRIVATE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PRIVATE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PRIVATE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_PRIVATE])))
                                                                 ;
  ridpointers[(int) RID_PROTECTED] = get_identifier ("protected");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PROTECTED]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PROTECTED]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_PROTECTED]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_PROTECTED])))
                                                                   ;
  ridpointers[(int) RID_TEMPLATE] = get_identifier ("template");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TEMPLATE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TEMPLATE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_TEMPLATE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_TEMPLATE])))
                                                                  ;

  ridpointers[(int) RID_MUTABLE] = get_identifier ("mutable");
  (((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_MUTABLE]))->x == 0 ? ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_MUTABLE]))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(ridpointers[(int) RID_MUTABLE]))->x->as_list = (build_tree_list ((tree) 
 ((void *)0)
 , ridpointers[(int) RID_MUTABLE])))
                                                                 ;


  signature_type_node = build_int_2_wide ((int) (signature_type), (int) (0));
  ((signature_type_node)->common.type) = signature_type_node;
  ridpointers[(int) RID_SIGNATURE] = signature_type_node;

  opname_tab[(int) COMPONENT_REF] = "->";
  opname_tab[(int) MEMBER_REF] = "->*";
  opname_tab[(int) METHOD_CALL_EXPR] = "->()";
  opname_tab[(int) INDIRECT_REF] = "(unary *)";
  opname_tab[(int) ARRAY_REF] = "[]";
  opname_tab[(int) MODIFY_EXPR] = "=";
  opname_tab[(int) NEW_EXPR] = "new";
  opname_tab[(int) DELETE_EXPR] = "delete";
  opname_tab[(int) VEC_NEW_EXPR] = "new []";
  opname_tab[(int) VEC_DELETE_EXPR] = "delete []";
  opname_tab[(int) COND_EXPR] = "... ? ... : ...";
  opname_tab[(int) CALL_EXPR] = "()";
  opname_tab[(int) PLUS_EXPR] = "+";
  opname_tab[(int) MINUS_EXPR] = "-";
  opname_tab[(int) MULT_EXPR] = "*";
  opname_tab[(int) TRUNC_DIV_EXPR] = "/";
  opname_tab[(int) CEIL_DIV_EXPR] = "(ceiling /)";
  opname_tab[(int) FLOOR_DIV_EXPR] = "(floor /)";
  opname_tab[(int) ROUND_DIV_EXPR] = "(round /)";
  opname_tab[(int) TRUNC_MOD_EXPR] = "%";
  opname_tab[(int) CEIL_MOD_EXPR] = "(ceiling %)";
  opname_tab[(int) FLOOR_MOD_EXPR] = "(floor %)";
  opname_tab[(int) ROUND_MOD_EXPR] = "(round %)";
  opname_tab[(int) NEGATE_EXPR] = "-";
  opname_tab[(int) MIN_EXPR] = "<?";
  opname_tab[(int) MAX_EXPR] = ">?";
  opname_tab[(int) ABS_EXPR] = "abs";
  opname_tab[(int) FFS_EXPR] = "ffs";
  opname_tab[(int) LSHIFT_EXPR] = "<<";
  opname_tab[(int) RSHIFT_EXPR] = ">>";
  opname_tab[(int) BIT_IOR_EXPR] = "|";
  opname_tab[(int) BIT_XOR_EXPR] = "^";
  opname_tab[(int) BIT_AND_EXPR] = "&";
  opname_tab[(int) BIT_ANDTC_EXPR] = "&~";
  opname_tab[(int) BIT_NOT_EXPR] = "~";
  opname_tab[(int) TRUTH_ANDIF_EXPR] = "&&";
  opname_tab[(int) TRUTH_ORIF_EXPR] = "||";
  opname_tab[(int) TRUTH_AND_EXPR] = "strict &&";
  opname_tab[(int) TRUTH_OR_EXPR] = "strict ||";
  opname_tab[(int) TRUTH_NOT_EXPR] = "!";
  opname_tab[(int) LT_EXPR] = "<";
  opname_tab[(int) LE_EXPR] = "<=";
  opname_tab[(int) GT_EXPR] = ">";
  opname_tab[(int) GE_EXPR] = ">=";
  opname_tab[(int) EQ_EXPR] = "==";
  opname_tab[(int) NE_EXPR] = "!=";
  opname_tab[(int) IN_EXPR] = "in";
  opname_tab[(int) RANGE_EXPR] = "..";
  opname_tab[(int) CONVERT_EXPR] = "(unary +)";
  opname_tab[(int) ADDR_EXPR] = "(unary &)";
  opname_tab[(int) PREDECREMENT_EXPR] = "--";
  opname_tab[(int) PREINCREMENT_EXPR] = "++";
  opname_tab[(int) POSTDECREMENT_EXPR] = "--";
  opname_tab[(int) POSTINCREMENT_EXPR] = "++";
  opname_tab[(int) COMPOUND_EXPR] = ",";

  assignop_tab[(int) NOP_EXPR] = "=";
  assignop_tab[(int) PLUS_EXPR] = "+=";
  assignop_tab[(int) CONVERT_EXPR] = "+=";
  assignop_tab[(int) MINUS_EXPR] = "-=";
  assignop_tab[(int) NEGATE_EXPR] = "-=";
  assignop_tab[(int) MULT_EXPR] = "*=";
  assignop_tab[(int) INDIRECT_REF] = "*=";
  assignop_tab[(int) TRUNC_DIV_EXPR] = "/=";
  assignop_tab[(int) EXACT_DIV_EXPR] = "(exact /=)";
  assignop_tab[(int) CEIL_DIV_EXPR] = "(ceiling /=)";
  assignop_tab[(int) FLOOR_DIV_EXPR] = "(floor /=)";
  assignop_tab[(int) ROUND_DIV_EXPR] = "(round /=)";
  assignop_tab[(int) TRUNC_MOD_EXPR] = "%=";
  assignop_tab[(int) CEIL_MOD_EXPR] = "(ceiling %=)";
  assignop_tab[(int) FLOOR_MOD_EXPR] = "(floor %=)";
  assignop_tab[(int) ROUND_MOD_EXPR] = "(round %=)";
  assignop_tab[(int) MIN_EXPR] = "<?=";
  assignop_tab[(int) MAX_EXPR] = ">?=";
  assignop_tab[(int) LSHIFT_EXPR] = "<<=";
  assignop_tab[(int) RSHIFT_EXPR] = ">>=";
  assignop_tab[(int) BIT_IOR_EXPR] = "|=";
  assignop_tab[(int) BIT_XOR_EXPR] = "^=";
  assignop_tab[(int) BIT_AND_EXPR] = "&=";
  assignop_tab[(int) ADDR_EXPR] = "&=";

  init_filename_times ();
  if (! (flag_gc || flag_rtti) || flag_no_gnu_keywords)
    {
      do { struct n64_tag_resword *s = is_reserved_word ("classof", sizeof ("classof") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("headof", sizeof ("headof") - 1); if (s) s->name = ""; } while (0);
    }
  if (! flag_handle_signatures || flag_no_gnu_keywords)
    {


      do { struct n64_tag_resword *s = is_reserved_word ("signature", sizeof ("signature") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("sigof", sizeof ("sigof") - 1); if (s) s->name = ""; } while (0);
    }
  if (flag_no_asm || flag_no_gnu_keywords)
    do { struct n64_tag_resword *s = is_reserved_word ("typeof", sizeof ("typeof") - 1); if (s) s->name = ""; } while (0);
  if (! flag_operator_names)
    {

      do { struct n64_tag_resword *s = is_reserved_word ("and", sizeof ("and") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("and_eq", sizeof ("and_eq") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("bitand", sizeof ("bitand") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("bitor", sizeof ("bitor") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("compl", sizeof ("compl") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("not", sizeof ("not") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("not_eq", sizeof ("not_eq") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("or", sizeof ("or") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("or_eq", sizeof ("or_eq") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("xor", sizeof ("xor") - 1); if (s) s->name = ""; } while (0);
      do { struct n64_tag_resword *s = is_reserved_word ("xor_eq", sizeof ("xor_eq") - 1); if (s) s->name = ""; } while (0);
    }
  if (! flag_traditional)
    do { struct n64_tag_resword *s = is_reserved_word ("overload", sizeof ("overload") - 1); if (s) s->name = ""; } while (0);

  token_count = init_parse ();
  interface_unknown = 1;
}

void
reinit_parse_for_function(void) asm("_reinit_parse_for_function");
void
reinit_parse_for_function(void)
{
  current_base_init_list = (tree) 
                          ((void *)0)
                                   ;
  current_member_init_list = (tree) 
                            ((void *)0)
                                     ;
}




void
yyprint(FILE *file, int yychar, YYSTYPE yylval) asm("_yyprint");
void
yyprint(FILE *file, int yychar, YYSTYPE yylval)
{
  tree t;
  switch (yychar)
    {
    case 258:
    case 259:
    case 261:
    case 309:
    case 336:
    case 335:
    case 337:
    case 330:
    case 260:
    case 334:
      t = yylval.ttype;
      my_friendly_assert (((n64_enum_tree_code) (t)->common.code) == IDENTIFIER_NODE, 224);
      if (((t)->identifier.pointer))
   fprintf (file, " `%s'", ((t)->identifier.pointer));
      break;
    case 288:
      if (yylval.ttype == class_type_node)
 fprintf (file, " `class'");
      else if (yylval.ttype == record_type_node)
 fprintf (file, " `struct'");
      else if (yylval.ttype == union_type_node)
 fprintf (file, " `union'");
      else if (yylval.ttype == enum_type_node)
 fprintf (file, " `enum'");
      else if (yylval.ttype == signature_type_node)
 fprintf (file, " `signature'");
      else
 my_friendly_abort (80);
      break;
    }
}

static int *reduce_count;
int *token_count;




int *
init_parse(void) asm("_init_parse");
int *
init_parse(void)
{
  return token_count;
}
void
print_parse_statistics(void) asm("_print_parse_statistics");
void
print_parse_statistics(void)
{
}




void
set_yydebug(int value) asm("_set_yydebug");
void
set_yydebug(int value)
{

  extern int yydebug;
  yydebug = value;



}
struct n64_tag_impl_files
{
  char *filename;
  struct n64_tag_impl_files *next;
};

static struct n64_tag_impl_files *impl_file_chain;



void
extract_interface_info(void) asm("_extract_interface_info");
void
extract_interface_info(void)
{
  tree fileinfo = 0;

  if (flag_alt_external_templates)
    {
      struct n64_tag_tinst_level *til = tinst_for_decl ();

      if (til)
 fileinfo = get_time_identifier (til->file);
    }
  if (!fileinfo)
    fileinfo = get_time_identifier (input_filename);
  fileinfo = (((struct n64_tag_lang_identifier *)(fileinfo))->class_value);
  interface_only = ((fileinfo)->int_cst.int_cst_low);
  if (!processing_template_defn || flag_external_templates)
    interface_unknown = ((fileinfo)->int_cst.int_cst_high);
}



static int
interface_strcmp(char *s) asm("_interface_strcmp");
static int
interface_strcmp(char *s)
{

  struct n64_tag_impl_files *ifiles;
  char *s1;

  for (ifiles = impl_file_chain; ifiles; ifiles = ifiles->next)
    {
      char *t1 = ifiles->filename;
      s1 = s;

      if (*s1 != *t1 || *s1 == 0)
 continue;

      while (*s1 == *t1 && *s1 != 0)
 s1++, t1++;


      if (*s1 == *t1)
 return 0;


      if (strchr (s1, '.') || strchr (t1, '.'))
 continue;

      if (*s1 == '\0' || s1[-1] != '.' || t1[-1] != '.')
 continue;


      return 0;
    }


  return 1;
}

void
set_typedecl_interface_info(tree prev, tree vars) asm("_set_typedecl_interface_info");
void
set_typedecl_interface_info(tree prev, tree vars)
{
  tree id = get_time_identifier (((vars)->decl.filename));
  tree fileinfo = (((struct n64_tag_lang_identifier *)(id))->class_value);
  tree type = ((vars)->common.type);

  (((type)->type.lang_specific)->type_flags.interface_only) = ((fileinfo)->int_cst.int_cst_low)
    = interface_strcmp ((strrchr (((vars)->decl.filename), '/') != 0 ? strrchr (((vars)->decl.filename), '/') + 1 : ((vars)->decl.filename)));
}

void
set_vardecl_interface_info(tree prev, tree vars) asm("_set_vardecl_interface_info");
void
set_vardecl_interface_info(tree prev, tree vars)
{
  tree type = ((vars)->decl.context);

  if ((((type)->type.lang_specific)->type_flags.interface_unknown == 0))
    {
      if ((((type)->type.lang_specific)->type_flags.interface_only))
 set_typedecl_interface_info (prev, ((type)->type.name));
      else
 (((type)->type.lang_specific)->type_flags.vtable_needs_writing) = 1;
      ((vars)->decl.external_flag) = (((type)->type.lang_specific)->type_flags.interface_only);
      ((vars)->common.public_flag) = 1;
    }
}





void
do_pending_inlines(void) asm("_do_pending_inlines");
void
do_pending_inlines(void)
{
  struct n64_tag_pending_inline *t;


  if (yychar == 331)
    return;



  {
    struct n64_tag_pending_inline *prev = 0, *tail, *bottom = 0;
    t = pending_inlines;
    pending_inlines = 0;

    for (; t; t = tail)
      {
 tail = t->next;
 t->next = prev;
 t->deja_vu = 1;
 prev = t;
      }



    for (t = prev; t; t = t->next)
      {
 if (t->lineno <= 0)
   {
     tree f = t->fndecl;
     (((f)->decl.lang_specific)->pending_inline_info) = 0;
     interface_unknown = t->interface == 1;
     interface_only = t->interface == 0;
     synthesize_method (f);
     if (tail)
       tail->next = t->next;
     else
       prev = t->next;
     if (! bottom)
       bottom = t;
   }
 else
   tail = t;
      }
    if (bottom)
      {
 __extension__ ({ struct n64_tag_obstack *__o = (&synth_obstack); void *__obj = (bottom); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
 extract_interface_info ();
      }
    t = prev;
  }

  if (t == 0)
    return;


  my_friendly_assert ((t->parm_vec == (tree) 
                                     ((void *)0)
                                              ) == (t->bindings == (tree) 
                                                                   ((void *)0)
                                                                            ),
        226);
  if (t->parm_vec)
    push_template_decls (t->parm_vec, t->bindings, 0);
  if (t->len > 0)
    {
      feed_input (t->buf, t->len, t->can_free ? &inline_text_obstack : 0);
      lineno = t->lineno;
      input_filename = t->filename;
      interface_unknown = t->interface == 1;
      interface_only = t->interface == 0;

      yychar = 331;
    }


  yylval.ttype = build_tree_list ((tree) t, t->fndecl);







  (((t->fndecl)->decl.lang_specific)->pending_inline_info) = 0;
}

extern struct n64_tag_pending_input *to_be_restored;
static int nextchar = -1;




void
process_next_inline(tree t) asm("_process_next_inline");
void
process_next_inline(tree t)
{
  struct n64_tag_pending_inline *i = (struct n64_tag_pending_inline *) ((t)->list.purpose);
  my_friendly_assert ((i->parm_vec == (tree) 
                                     ((void *)0)
                                              ) == (i->bindings == (tree) 
                                                                   ((void *)0)
                                                                            ),
        227);
  if (i->parm_vec)
    pop_template_decls (i->parm_vec, i->bindings, 0);
  i = i->next;
  if (yychar == -2)
    yychar = yylex ();
  if (yychar != 339)
    {
      error ("parse error at end of saved function text");






      nextchar = -1;
    }
  yychar = -2;
  if (to_be_restored == 0)
    my_friendly_abort (123);
  restore_pending_input (to_be_restored);
  to_be_restored = 0;
  if (i && i->fndecl != (tree) 
                       ((void *)0)
                                )
    {
      my_friendly_assert ((i->parm_vec == (tree) 
                                         ((void *)0)
                                                  ) == (i->bindings == (tree) 
                                                                       ((void *)0)
                                                                                ),
     228);
      if (i->parm_vec)
 push_template_decls (i->parm_vec, i->bindings, 0);
      feed_input (i->buf, i->len, i->can_free ? &inline_text_obstack : 0);
      lineno = i->lineno;
      input_filename = i->filename;
      yychar = 331;
      yylval.ttype = build_tree_list ((tree) i, i->fndecl);







      (((i->fndecl)->decl.lang_specific)->pending_inline_info) = 0;
    }
  if (i)
    {
      interface_unknown = i->interface == 1;
      interface_only = i->interface == 0;
    }
  else
    extract_interface_info ();
}
static void
consume_string(register struct n64_tag_obstack *this_obstack, int matching_char) asm("_consume_string");
static void
consume_string(register struct n64_tag_obstack *this_obstack, int matching_char)
{
  register int c;
  int starting_lineno = lineno;
  do
    {
      c = cxx_getch ();
      if (c == 
              (-1)
                 )
 {
   int save_lineno = lineno;
   lineno = starting_lineno;
   if (matching_char == '"')
     error ("end of file encountered inside string constant");
   else
     error ("end of file encountered inside character constant");
   lineno = save_lineno;
   return;
 }
      if (c == '\\')
 {
   __extension__ ({ struct n64_tag_obstack *__o = (this_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
   c = cxx_getch ();
   __extension__ ({ struct n64_tag_obstack *__o = (this_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });


   c = 0;
   continue;
 }
      if (c == '\n')
 {
   if (pedantic)
     pedwarn ("ANSI C++ forbids newline in string constant");
   lineno++;
 }
      __extension__ ({ struct n64_tag_obstack *__o = (this_obstack); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
    }
  while (c != matching_char);
}

static int nextyychar = -2;
static YYSTYPE nextyylval;

struct n64_tag_pending_input {
  int nextchar, yychar, nextyychar, eof;
  YYSTYPE yylval, nextyylval;
  struct n64_tag_obstack token_obstack;
  int first_token;
};

struct n64_tag_pending_input *
save_pending_input(void) asm("_save_pending_input");
struct n64_tag_pending_input *
save_pending_input(void)
{
  struct n64_tag_pending_input *p;
  p = (struct n64_tag_pending_input *) xmalloc (sizeof (struct n64_tag_pending_input));
  p->nextchar = nextchar;
  p->yychar = yychar;
  p->nextyychar = nextyychar;
  p->yylval = yylval;
  p->nextyylval = nextyylval;
  p->eof = end_of_file;
  yychar = nextyychar = -2;
  nextchar = -1;
  p->first_token = first_token;
  p->token_obstack = token_obstack;

  first_token = 0;
  gcc_obstack_init (&token_obstack);
  end_of_file = 0;
  return p;
}

void
restore_pending_input(struct n64_tag_pending_input *p) asm("_restore_pending_input");
void
restore_pending_input(struct n64_tag_pending_input *p)
{
  my_friendly_assert (nextchar == -1, 229);
  nextchar = p->nextchar;
  my_friendly_assert (yychar == -2 || yychar == 339, 230);
  yychar = p->yychar;
  my_friendly_assert (nextyychar == -2, 231);
  nextyychar = p->nextyychar;
  yylval = p->yylval;
  nextyylval = p->nextyylval;
  first_token = p->first_token;
  __extension__ ({ struct n64_tag_obstack *__o = (&token_obstack); void *__obj = ((char *) 0); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
  token_obstack = p->token_obstack;
  end_of_file = p->eof;
  free (p);
}



static int
yynextch(void) asm("_yynextch");
static int
yynextch(void)
{
  int c;

  if (nextchar >= 0)
    {
      c = nextchar;
      nextchar = -1;
    }
  else c = cxx_getch ();
  return skip_white_space (c);
}




void
yyungetc(int ch, int rescan) asm("_yyungetc");
void
yyungetc(int ch, int rescan)
{

  if (yychar == -2 || rescan == 0)
    {
      if (nextchar >= 0)
 put_back (nextchar);
      nextchar = ch;
    }
  else
    {
      my_friendly_assert (nextyychar == -2, 232);
      nextyychar = yychar;
      nextyylval = yylval;
      yychar = ch;
    }
}
static void
store_pending_inline(tree decl, struct n64_tag_pending_inline *t) asm("_store_pending_inline");
static void
store_pending_inline(tree decl, struct n64_tag_pending_inline *t)
{
  extern int processing_template_defn;
  int delay_to_eof = 0;
  struct n64_tag_pending_inline **inlines;

  t->fndecl = decl;

  t->parm_vec = t->bindings = 0;
  if (processing_template_defn)
    {
      tree type = current_class_type;


      while (type && (*tree_code_type[(int) (((n64_enum_tree_code) (type)->common.code))]) == 't')
 {
   tree decl = ((type)->type.name);
   tree tmpl = (((struct n64_tag_lang_identifier *)(((decl)->decl.name)))->class_template_info);
   if (tmpl)
     {
       t->parm_vec = (((((tmpl)->list.purpose))->decl.lang_specific)->template_info)->parm_vec;
       t->bindings = ((tmpl)->list.value);
     }
   type = ((decl)->decl.context);
 }
      if (((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE
   || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == FUNCTION_TYPE)
 {
   if (((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE)
     my_friendly_assert (((((decl)->common.type))->type.maxval) == current_class_type,
    233);






   if ((((decl)->decl.lang_specific)->decl_flags.declared_inline))
                            ;
   else if (current_class_type && !interface_unknown)
     {
       if (interface_only)
  {



    if (t->can_free)
      __extension__ ({ struct n64_tag_obstack *__o = (&inline_text_obstack); void *__obj = (t->buf); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
    (((decl)->decl.lang_specific)->pending_inline_info) = 0;
    return;
  }
     }

   else if (((decl)->decl.vindex) == (tree) 
                                 ((void *)0)
                                          )
     delay_to_eof = 1;
 }
      else
 my_friendly_abort (58);
    }

  if (delay_to_eof)
    {
      extern struct n64_tag_pending_inline *pending_template_expansions;

      if (t->can_free)
 {
   char *free_to = t->buf;
   t->buf = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((t->len + 1)); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ((t->buf)),__len); __o->next_free += __len; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                  ;
   t = (struct n64_tag_pending_inline *) __extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (*t))); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (((char *)t)),__len); __o->next_free += __len; } (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                   ;
   __extension__ ({ struct n64_tag_obstack *__o = (&inline_text_obstack); void *__obj = (free_to); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
 }
      inlines = &pending_template_expansions;
      t->can_free = 0;
    }
  else
    {
      inlines = &pending_inlines;
      (((decl)->decl.lang_specific)->pending_inline_info) = t;
    }


  t->next = *inlines;
  *inlines = t;
}

void reinit_parse_for_block(...) asm("_reinit_parse_for_block");

void
reinit_parse_for_method(int yychar, tree decl) asm("_reinit_parse_for_method");
void
reinit_parse_for_method(int yychar, tree decl)
{
  int len;
  int starting_lineno = lineno;
  char *starting_filename = input_filename;

  reinit_parse_for_block (yychar, &inline_text_obstack, 0);

  len = __extension__ ({ struct n64_tag_obstack *__o = (&inline_text_obstack); __o->alloc_failed ? 0 : (unsigned) (__o->next_free - __o->object_base); });
  current_base_init_list = (tree) 
                          ((void *)0)
                                   ;
  current_member_init_list = (tree) 
                            ((void *)0)
                                     ;
  if (decl == void_type_node
      || (current_class_type && (((current_class_type)->type.lang_specific)->type_flags.redefined)))
    {


      char *buf = __extension__ ({ struct n64_tag_obstack *__o1 = (&inline_text_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });
      __extension__ ({ struct n64_tag_obstack *__o = (&inline_text_obstack); void *__obj = (buf); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
      return;
    }
  else
    {
      struct n64_tag_pending_inline *t;
      char *buf = __extension__ ({ struct n64_tag_obstack *__o1 = (&inline_text_obstack); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; });

      t = (struct n64_tag_pending_inline *) __extension__ ({ struct n64_tag_obstack *__h = (&inline_text_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_pending_inline))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); })
                                        ;
      t->lineno = starting_lineno;
      t->filename = starting_filename;
      t->token = -2;
      t->token_value = 0;
      t->buf = buf;
      t->len = len;
      t->can_free = 1;
      t->deja_vu = 0;
      if (interface_unknown && processing_template_defn && flag_external_templates && ! ((decl)->decl.in_system_header_flag))
 warn_if_unknown_interface (decl);
      t->interface = (interface_unknown ? 1 : (interface_only ? 0 : 2));
      store_pending_inline (decl, t);
    }
}







void
reinit_parse_for_block(int pyychar, struct n64_tag_obstack *obstackp, int is_template) asm("_reinit_parse_for_block");
void
reinit_parse_for_block(int pyychar, struct n64_tag_obstack *obstackp, int is_template)
{
  register int c = 0;
  int blev = 1;
  int starting_lineno = lineno;
  char *starting_filename = input_filename;
  int len;
  int look_for_semicolon = 0;
  int look_for_lbrac = 0;

  if (pyychar == '{')
    __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('{'); (void) 0; });
  else if (pyychar == '=')
    look_for_semicolon = 1;
  else if (pyychar == ':')
    {
      __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (pyychar); (void) 0; });
      look_for_lbrac = 1;
      blev = 0;
    }
  else if (pyychar == 278 && !is_template)
    {
      __extension__ ({ struct n64_tag_obstack *__o = (obstackp); int __len = (6); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("return"),__len); __o->next_free += __len; } (void) 0; });
      look_for_lbrac = 1;
      blev = 0;
    }
  else if (pyychar == 328 && !is_template)
    {
      __extension__ ({ struct n64_tag_obstack *__o = (obstackp); int __len = (3); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) ("try"),__len); __o->next_free += __len; } (void) 0; });
      look_for_lbrac = 1;
      blev = 0;
    }
  else
    {
      yyerror (is_template
        ? "parse error in template specification"
        : "parse error in method specification");
      __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('{'); (void) 0; });
    }

  if (nextchar != 
                 (-1)
                    )
    {
      c = nextchar;
      nextchar = 
                (-1)
                   ;
    }
  else
    c = cxx_getch ();

  while (c != 
             (-1)
                )
    {
      int this_lineno = lineno;

      c = skip_white_space (c);


      if (lineno == this_lineno + 1)
 __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\n'); (void) 0; });
      else if (lineno == this_lineno)
 ;
      else if (lineno - this_lineno < 10)
 {
   int i;
   for (i = lineno - this_lineno; i > 0; i--)
     __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\n'); (void) 0; });
 }
      else
 {
   char buf[16];
   sprintf (buf, "\n# %d \"", lineno);
   len = strlen (buf);
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (buf),__len); __o->next_free += __len; } (void) 0; });

   len = strlen (input_filename);
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); int __len = (len); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (input_filename),__len); __o->next_free += __len; } (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\"'); (void) 0; });
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\n'); (void) 0; });
 }

      while (c > ' ')
 {
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
   if (c == '{')
     {
       look_for_lbrac = 0;
       blev++;
     }
   else if (c == '}')
     {
       blev--;
       if (blev == 0 && !look_for_semicolon)
  {
    if (pyychar == 328)
      {
        if (peekyylex () == 329)
   {
     yylex ();
     __extension__ ({ struct n64_tag_obstack *__o = (obstackp); int __len = (7); if (__o->next_free + __len > __o->chunk_limit) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) { memcpy (__o->next_free,(char *) (" catch "),__len); __o->next_free += __len; } (void) 0; });
     look_for_lbrac = 1;
   }
        else
   {
     yychar = '{';
     goto done;
   }
      }
    else
      {
        goto done;
      }
  }
     }
   else if (c == '\\')
     {


       c = cxx_getch ();
       if (c == 
               (-1)
                  )
  {
    error_with_file_and_line (starting_filename,
         starting_lineno,
         "end of file read inside definition");
    goto done;
  }
       __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
     }
   else if (c == '\"')
     consume_string (obstackp, c);
   else if (c == '\'')
     consume_string (obstackp, c);
   else if (c == ';')
     {
       if (look_for_lbrac)
  {
    error (is_template
    ? "template body missing"
    : "function body for constructor missing");
    __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('{'); (void) 0; });
    __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('}'); (void) 0; });
    len += 2;
    goto done;
  }
       else if (look_for_semicolon && blev == 0)
  goto done;
     }
   c = cxx_getch ();
 }

      if (c == 
              (-1)
                 )
 {
   error_with_file_and_line (starting_filename,
        starting_lineno,
        "end of file read inside definition");
   goto done;
 }
      else if (c != '\n')
 {
   __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = (c); (void) 0; });
   c = cxx_getch ();
 }
    }
 done:
  __extension__ ({ struct n64_tag_obstack *__o = (obstackp); if (__o->next_free + 1 > __o->chunk_limit) _obstack_newchunk (__o, 1); if (!__o->alloc_failed) *(__o->next_free)++ = ('\0'); (void) 0; });
}
tree
cons_up_default_function(tree type, tree full_name, int kind) asm("_cons_up_default_function");
tree
cons_up_default_function(tree type, tree full_name, int kind)
{
  extern tree void_list_node;
  char *func_buf = 
                  ((void *)0)
                      ;
  int func_len = 0;
  tree declspecs = (tree) 
                  ((void *)0)
                           ;
  tree fn, args;
  tree argtype;
  int retref = 0;
  int complex = 0;
  tree name = constructor_name (full_name);

  switch (kind)
    {

    case 1:
      declspecs = build_decl_list ((tree) 
                                  ((void *)0)
                                           , ridpointers [(int) RID_VIRTUAL]);

    case 0:
      name = build_parse_node (BIT_NOT_EXPR, name);
      args = void_list_node;
      break;

    case 2:

      args = void_list_node;
      complex = ((type)->type.needs_constructing_flag);
      break;

    case 3:
      type = build_type_variant (type, 1, 0);

    case 4:


      argtype = build_reference_type (type);
      args = tree_cons ((tree) 
                       ((void *)0)
                                ,
   build_tree_list (hash_tree_chain (argtype, (tree) 
                                             ((void *)0)
                                                      ),
      get_identifier ("_ctor_arg")),
   void_list_node);
      complex = (((type)->type.lang_specific)->type_flags.has_complex_init_ref);
      break;

    case 5:
      type = build_type_variant (type, 1, 0);

    case 6:
      retref = 1;
      declspecs = build_decl_list ((tree) 
                                  ((void *)0)
                                           , full_name);

      name = ansi_opname [(int) MODIFY_EXPR];

      argtype = build_reference_type (type);
      args = tree_cons ((tree) 
                       ((void *)0)
                                ,
   build_tree_list (hash_tree_chain (argtype, (tree) 
                                             ((void *)0)
                                                      ),
      get_identifier ("_ctor_arg")),
   void_list_node);
      complex = (((type)->type.lang_specific)->type_flags.has_complex_assign_ref);
      break;

    default:
      my_friendly_abort (59);
    }

  declspecs = decl_tree_cons ((tree) 
                             ((void *)0)
                                      , ridpointers [(int) RID_INLINE],
         declspecs);

  ((args)->common.unsigned_flag) = 1;

  {
    tree declarator = build_parse_node (CALL_EXPR, name, args, (tree) 
                                                              ((void *)0)
                                                                       );
    if (retref)
      declarator = build_parse_node (ADDR_EXPR, declarator);

    fn = grokfield (declarator, declspecs, (tree) 
                                          ((void *)0)
                                                   , (tree) 
                                                     ((void *)0)
                                                              ,
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         );
  }

  if (fn == void_type_node)
    return fn;

  if (processing_template_defn)
    {
      ((((fn)->decl.lang_specific)->decl_flags.use_template) = 1);
      repo_template_used (fn);
    }

  if ((((type)->type.lang_specific)->type_flags.interface_unknown == 0))
    {
      ((fn)->decl.lang_flag_5) = 1;
      (((fn)->decl.lang_specific)->decl_flags.not_really_extern) = (!(((type)->type.lang_specific)->type_flags.interface_only)
         && flag_implement_inlines);
    }
  else
    (((fn)->decl.lang_specific)->decl_flags.not_really_extern) = 1;
    mark_inline_for_output (fn);
  (((fn)->decl.artificial_flag) = 1);

  return fn;
}




void
check_for_missing_semicolon(tree type) asm("_check_for_missing_semicolon");
void
check_for_missing_semicolon(tree type)
{
  if (yychar < 0)
    yychar = yylex ();

  if ((yychar > 255
       && yychar != 260
       && yychar != 258
       && yychar != 259)
      || end_of_file)
    {
      if (((((((((type)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((type)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
 error ("semicolon missing after %s declaration",
        ((n64_enum_tree_code) (type)->common.code) == ENUMERAL_TYPE ? "enum" : "struct");
      else
 cp_error ("semicolon missing after declaration of `%T'", type);
      shadow_tag (build_tree_list (0, type));
    }

  clear_anon_tags ();
}

void
note_got_semicolon(tree type) asm("_note_got_semicolon");
void
note_got_semicolon(tree type)
{
  if ((*tree_code_type[(int) (((n64_enum_tree_code) (type)->common.code))]) != 't')
    my_friendly_abort (60);
  if ((((type)->type.lang_flag_5)))
    (((type)->type.lang_specific)->type_flags.got_semicolon) = 1;
}

void
note_list_got_semicolon(tree declspecs) asm("_note_list_got_semicolon");
void
note_list_got_semicolon(tree declspecs)
{
  tree link;

  for (link = declspecs; link; link = ((link)->common.chain))
    {
      tree type = ((link)->list.value);
      if ((*tree_code_type[(int) (((n64_enum_tree_code) (type)->common.code))]) == 't')
 note_got_semicolon (type);
    }
  clear_anon_tags ();
}




static int
skip_white_space(register int c) asm("_skip_white_space");
static int
skip_white_space(register int c)
{
  for (;;)
    {
      switch (c)
 {
 case '\n':
   c = check_newline ();
   break;

 case ' ':
 case '\t':
 case '\f':
 case '\r':
 case '\v':
 case '\b':
   do
     c = cxx_getch ();
   while (c == ' ' || c == '\t');
   break;

 case '\\':
   c = cxx_getch ();
   if (c == '\n')
     lineno++;
   else
     error ("stray '\\' in program");
   c = cxx_getch ();
   break;

 default:
   return (c);
 }
    }
}
static char *
extend_token_buffer(char *p) asm("_extend_token_buffer");
static char *
extend_token_buffer(char *p)
{
  int offset = p - token_buffer;

  maxtoken = maxtoken * 2 + 10;
  token_buffer = (char *) xrealloc (token_buffer, maxtoken + 2);

  return token_buffer + offset;
}

static int
get_last_nonwhite_on_line(void) asm("_get_last_nonwhite_on_line");
static int
get_last_nonwhite_on_line(void)
{
  register int c;


  if (nextchar >= 0)
    c = nextchar, nextchar = -1;
  else
    c = cxx_getch ();

  while (c == ' ' || c == '\t')
    c = cxx_getch ();
  return c;
}






int linemode;

int
check_newline(void) asm("_check_newline");
int
check_newline(void)
{
  register int c;
  register int token;




  do
    c = cxx_getch ();
  while (c == ' ' || c == '\t');

  lineno++;

  if (c != '#')
    {

      return c;
    }


  linemode = 1;



  do
    c = cxx_getch ();
  while (c == ' ' || c == '\t');





  if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    {
      if (c == 'p')
 {
   if (cxx_getch () == 'r'
       && cxx_getch () == 'a'
       && cxx_getch () == 'g'
       && cxx_getch () == 'm'
       && cxx_getch () == 'a')
     {


       do
  c = cxx_getch ();
       while (c == ' ' || c == '\t');

       if (c == 'v'
    && cxx_getch () == 't'
    && cxx_getch () == 'a'
    && cxx_getch () == 'b'
    && cxx_getch () == 'l'
    && cxx_getch () == 'e'
    && ((c = cxx_getch ()) == ' ' || c == '\t'))
  {
    extern tree pending_vtables;


    token = real_yylex ();
    if (token != 264 || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
      {
        error ("invalid #pragma vtable");
        goto skipline;
      }
    if (write_virtuals != 2)
      {
        warning ("use `+e2' option to enable #pragma vtable");
        goto skipline;
      }
    pending_vtables = perm_tree_cons ((tree) 
                                     ((void *)0)
                                              , get_identifier (((yylval.ttype)->string.pointer)), pending_vtables);
    if (nextchar < 0)
      nextchar = cxx_getch ();
    c = nextchar;
    if (c != 
            (-1)
               )
      warning ("trailing characters ignored");
  }
       else if (c == 'u'
         && cxx_getch () == 'n'
         && cxx_getch () == 'i'
         && cxx_getch () == 't'
         && ((c = cxx_getch ()) == ' ' || c == '\t'))
  {

    token = real_yylex ();
    if (token != 264 || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
      {
        error ("invalid #pragma unit");
        goto skipline;
      }
    current_unit_name = get_identifier (((yylval.ttype)->string.pointer));
    current_unit_language = current_lang_name;
    if (nextchar < 0)
      nextchar = cxx_getch ();
    c = nextchar;
    if (c != 
            (-1)
               )
      warning ("trailing characters ignored");
  }
       else if (c == 'i')
  {
    tree fileinfo = (((struct n64_tag_lang_identifier *)(get_time_identifier (input_filename)))->class_value);
    c = cxx_getch ();

    if (c == 'n'
        && cxx_getch () == 't'
        && cxx_getch () == 'e'
        && cxx_getch () == 'r'
        && cxx_getch () == 'f'
        && cxx_getch () == 'a'
        && cxx_getch () == 'c'
        && cxx_getch () == 'e'
        && ((c = cxx_getch ()) == ' ' || c == '\t' || c == 
                                                      (-1)
                                                         ))
      {
        int warned_already = 0;
        char *main_filename = input_filename;

        main_filename = (strrchr (main_filename, '/') != 0 ? strrchr (main_filename, '/') + 1 : main_filename);
        while (c == ' ' || c == '\t')
   c = cxx_getch ();
        if (c != 
                (-1)
                   )
   {
     put_back (c);
     token = real_yylex ();
     if (token != 264
         || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
       {
         error ("invalid `#pragma interface'");
         goto skipline;
       }
     main_filename = ((yylval.ttype)->string.pointer);
     c = cxx_getch();
     put_back (c);
   }

        while (c == ' ' || c == '\t')
   c = cxx_getch ();

        while (c != 
                   (-1)
                      )
   {
     if (!warned_already && extra_warnings
         && c != ' ' && c != '\t')
       {
         warning ("garbage after `#pragma interface' ignored");
         warned_already = 1;
       }
     c = cxx_getch ();
   }

        write_virtuals = 3;

        if (impl_file_chain == 0)
   {


     if (main_input_filename == 0)
       main_input_filename = input_filename;
   }

        interface_only = interface_strcmp (main_filename);
        interface_unknown = 0;
        ((fileinfo)->int_cst.int_cst_low) = interface_only;
        ((fileinfo)->int_cst.int_cst_high) = interface_unknown;
      }
    else if (c == 'm'
      && cxx_getch () == 'p'
      && cxx_getch () == 'l'
      && cxx_getch () == 'e'
      && cxx_getch () == 'm'
      && cxx_getch () == 'e'
      && cxx_getch () == 'n'
      && cxx_getch () == 't'
      && cxx_getch () == 'a'
      && cxx_getch () == 't'
      && cxx_getch () == 'i'
      && cxx_getch () == 'o'
      && cxx_getch () == 'n'
      && ((c = cxx_getch ()) == ' ' || c == '\t' || c == 
                                                    (-1)
                                                       ))
      {
        int warned_already = 0;
        char *main_filename = main_input_filename ? main_input_filename : input_filename;

        main_filename = (strrchr (main_filename, '/') != 0 ? strrchr (main_filename, '/') + 1 : main_filename);
        while (c == ' ' || c == '\t')
   c = cxx_getch ();
        if (c != 
                (-1)
                   )
   {
     put_back (c);
     token = real_yylex ();
     if (token != 264
         || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
       {
         error ("invalid `#pragma implementation'");
         goto skipline;
       }
     main_filename = ((yylval.ttype)->string.pointer);
     c = cxx_getch();
     put_back (c);
   }

        while (c == ' ' || c == '\t')
   c = cxx_getch ();

        while (c != 
                   (-1)
                      )
   {
     if (!warned_already && extra_warnings
         && c != ' ' && c != '\t')
       {
         warning ("garbage after `#pragma implementation' ignored");
         warned_already = 1;
       }
     c = cxx_getch ();
   }

        if (write_virtuals == 3)
   {
     struct n64_tag_impl_files *ifiles = impl_file_chain;
     while (ifiles)
       {
         if (! strcmp (ifiles->filename, main_filename))
    break;
         ifiles = ifiles->next;
       }
     if (ifiles == 0)
       {
         ifiles = (struct n64_tag_impl_files*) permalloc (sizeof (struct n64_tag_impl_files));
         ifiles->filename = main_filename;
         ifiles->next = impl_file_chain;
         impl_file_chain = ifiles;
       }
   }
        else if ((main_input_filename != 0
    && ! strcmp (main_input_filename, input_filename))
          || ! strcmp (input_filename, main_filename))
   {
     write_virtuals = 3;
     if (impl_file_chain == 0)
       {
         impl_file_chain = (struct n64_tag_impl_files*) permalloc (sizeof (struct n64_tag_impl_files));
         impl_file_chain->filename = main_filename;
         impl_file_chain->next = 0;
       }
   }
        else
   error ("`#pragma implementation' can only appear at top-level");
        interface_only = 0;




        interface_unknown = 1;





        ((fileinfo)->int_cst.int_cst_low) = interface_only;
        ((fileinfo)->int_cst.int_cst_high) = interface_unknown;
      }
  }

       else
  {
    put_back (c);
    handle_sysv_pragma ();
  }
       goto skipline;
     }
 }
      else if (c == 'd')
 {
   if (cxx_getch () == 'e'
       && cxx_getch () == 'f'
       && cxx_getch () == 'i'
       && cxx_getch () == 'n'
       && cxx_getch () == 'e'
       && ((c = cxx_getch ()) == ' ' || c == '\t'))
     {

       if ((debug_info_level == DINFO_LEVEL_VERBOSE)
    && (write_symbols == DWARF_DEBUG))
         dwarfout_define (lineno, get_directive_line (finput));

       goto skipline;
     }
 }
      else if (c == 'u')
 {
   if (cxx_getch () == 'n'
       && cxx_getch () == 'd'
       && cxx_getch () == 'e'
       && cxx_getch () == 'f'
       && ((c = cxx_getch ()) == ' ' || c == '\t'))
     {

       if ((debug_info_level == DINFO_LEVEL_VERBOSE)
    && (write_symbols == DWARF_DEBUG))
         dwarfout_undef (lineno, get_directive_line (finput));

       goto skipline;
     }
 }
      else if (c == 'l')
 {
   if (cxx_getch () == 'i'
       && cxx_getch () == 'n'
       && cxx_getch () == 'e'
       && ((c = cxx_getch ()) == ' ' || c == '\t'))
     goto linenum;
 }
      else if (c == 'i')
 {
   if (cxx_getch () == 'd'
       && cxx_getch () == 'e'
       && cxx_getch () == 'n'
       && cxx_getch () == 't'
       && ((c = cxx_getch ()) == ' ' || c == '\t'))
     {

              extern FILE *asm_out_file;






       while (c == ' ' || c == '\t')
  c = cxx_getch ();


       if (c == 
               (-1)
                  )
  goto skipline;

       put_back (c);
       token = real_yylex ();
       if (token != 264
    || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
  {
    error ("invalid #ident");
    goto skipline;
  }

       if (! flag_no_ident)
  {

    fprintf (asm_out_file, "\t%s\t\"%s\"\n", ".ident", ((yylval.ttype)->string.pointer));
                                           ;

  }


       goto skipline;
     }
 }
      else if (c == 'n')
 {
   if (cxx_getch () == 'e'
       && cxx_getch () == 'w'
       && cxx_getch () == 'w'
       && cxx_getch () == 'o'
       && cxx_getch () == 'r'
       && cxx_getch () == 'l'
       && cxx_getch () == 'd'
       && ((c = cxx_getch ()) == ' ' || c == '\t'))
     {

       sorry ("#pragma newworld");
       goto skipline;
     }
 }
      error ("undefined or invalid # directive");
      goto skipline;
    }

linenum:



  while (c == ' ' || c == '\t')
    c = cxx_getch ();



  if (c == 
          (-1)
             )
    goto skipline;



  put_back (c);
  token = real_yylex ();

  if (token == 263
      && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST)
    {
      int old_lineno = lineno;
      enum n64_cpp_enum_anonymous_19{ act_none, act_push, act_pop };
typedef __underlying_type(enum n64_cpp_enum_anonymous_19) n64_enum_anonymous_19;
n64_enum_anonymous_19 action = act_none;
      int entering_system_header = 0;
      int entering_c_header = 0;




      int l = ((yylval.ttype)->int_cst.int_cst_low) - 1;
      c = get_last_nonwhite_on_line ();
      if (c == 
              (-1)
                 )
 {

   lineno = l;
   goto skipline;
 }
      put_back (c);




      ignore_escape_flag = 1;
      token = real_yylex ();
      ignore_escape_flag = 0;

      if (token != 264 || ((n64_enum_tree_code) (yylval.ttype)->common.code) != STRING_CST)
 {
   error ("invalid #line");
   goto skipline;
 }




      if (flag_detailed_statistics)
 {
   int this_time = my_get_run_time ();
   tree time_identifier = get_time_identifier (((yylval.ttype)->string.pointer));
   header_time += this_time - body_time;
   (((((struct n64_tag_lang_identifier *)(this_filename_time))->local_value))->int_cst.int_cst_low)
     += this_time - body_time;
   this_filename_time = time_identifier;
   body_time = this_time;
 }

      if (flag_cadillac)
 cadillac_note_source ();

      input_filename
 = (char *) permalloc (((yylval.ttype)->string.length) + 1);
      strcpy (input_filename, ((yylval.ttype)->string.pointer));
      lineno = l;
      GNU_xref_file (input_filename);

      if (main_input_filename == 0)
 {
   struct n64_tag_impl_files *ifiles = impl_file_chain;

   if (ifiles)
     {
       while (ifiles->next)
  ifiles = ifiles->next;
       ifiles->filename = (strrchr (input_filename, '/') != 0 ? strrchr (input_filename, '/') + 1 : input_filename);
     }

   main_input_filename = input_filename;
   if (write_virtuals == 3)
     walk_vtables (set_typedecl_interface_info, set_vardecl_interface_info);
 }

      extract_interface_info ();

      c = get_last_nonwhite_on_line ();
      if (c == 
              (-1)
                 )
 {

   if (input_file_stack)
     input_file_stack->name = input_filename;
 }
      else
 {
   put_back (c);

   token = real_yylex ();




   if (token == 263
       && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST)
     {
       if (((yylval.ttype)->int_cst.int_cst_low) == 1)
  action = act_push;
       else if (((yylval.ttype)->int_cst.int_cst_low) == 2)
  action = act_pop;

       if (action)
  {
    c = get_last_nonwhite_on_line ();
    if (c != 
            (-1)
               )
      {
        put_back (c);
        token = real_yylex ();
      }
  }
     }



   if (token == 263
       && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST
       && ((yylval.ttype)->int_cst.int_cst_low) == 3)
     {
       entering_system_header = 1;

       c = get_last_nonwhite_on_line ();
       if (c != 
               (-1)
                  )
  {
    put_back (c);
    token = real_yylex ();
  }
     }



   if (token == 263
       && ((n64_enum_tree_code) (yylval.ttype)->common.code) == INTEGER_CST
       && ((yylval.ttype)->int_cst.int_cst_low) == 4)
     {
       entering_c_header = 1;

       c = get_last_nonwhite_on_line ();
       if (c != 
               (-1)
                  )
  {
    put_back (c);
    token = real_yylex ();
  }
     }



   if (action == act_push)
     {

       struct n64_tag_file_stack *p;

       p = (struct n64_tag_file_stack *) xmalloc (sizeof (struct n64_tag_file_stack));
       input_file_stack->line = old_lineno;
       p->next = input_file_stack;
       p->name = input_filename;
       input_file_stack = p;
       input_file_stack_tick++;

       if (debug_info_level == DINFO_LEVEL_VERBOSE
    && write_symbols == DWARF_DEBUG)
  dwarfout_start_new_source_file (input_filename);

       if (flag_cadillac)
  cadillac_push_source ();
       in_system_header = entering_system_header;
       if (c_header_level)
  ++c_header_level;
       else if (entering_c_header)
  {
    c_header_level = 1;
    ++pending_lang_change;
  }
     }
   else if (action == act_pop)
     {

       if (input_file_stack->next)
  {
    struct n64_tag_file_stack *p;

    if (c_header_level && --c_header_level == 0)
      {
        if (entering_c_header)
   warning ("badly nested C headers from preprocessor");
        --pending_lang_change;
      }
    if (flag_cadillac)
      cadillac_pop_source ();
    in_system_header = entering_system_header;

    p = input_file_stack;
    input_file_stack = p->next;
    free (p);
    input_file_stack_tick++;

    if (debug_info_level == DINFO_LEVEL_VERBOSE
        && write_symbols == DWARF_DEBUG)
      dwarfout_resume_previous_source_file (input_file_stack->line);

  }
       else
  error ("#-lines for entering and leaving files don't match");
     }
   else
     {
       in_system_header = entering_system_header;
       if (flag_cadillac)
  cadillac_switch_source (-1);
     }
 }


      if (nextchar == 
                     (-1)
                        )
 c = 
    (-1)
       ;
    }
  else
    error ("invalid #-line");


 skipline:
  linemode = 0;
  end_of_file = 0;
  while ((c = cxx_getch ()) != 
                          (-1) 
                              && c != '\n');
  return c;
}

void
do_pending_lang_change(void) asm("_do_pending_lang_change");
void
do_pending_lang_change(void)
{
  for (; pending_lang_change > 0; --pending_lang_change)
    push_lang_context (lang_name_c);
  for (; pending_lang_change < 0; ++pending_lang_change)
    pop_lang_context ();
}













static int
readescape(int *ignore_ptr) asm("_readescape");
static int
readescape(int *ignore_ptr)
{
  register int c = cxx_getch ();
  register int code;
  register unsigned count;
  unsigned firstdig;
  int nonnull;

  switch (c)
    {
    case 'x':
      if (warn_traditional)
 warning ("the meaning of `\\x' varies with -traditional");

      if (flag_traditional)
 return c;

      code = 0;
      count = 0;
      nonnull = 0;
      while (1)
 {
   c = cxx_getch ();
   if (! isxdigit (c))
     {
       put_back (c);
       break;
     }
   code *= 16;
   if (c >= 'a' && c <= 'f')
     code += c - 'a' + 10;
   if (c >= 'A' && c <= 'F')
     code += c - 'A' + 10;
   if (c >= '0' && c <= '9')
     code += c - '0';
   if (code != 0 || count != 0)
     {
       if (count == 0)
  firstdig = code;
       count++;
     }
   nonnull = 1;
 }
      if (! nonnull)
 error ("\\x used with no following hex digits");
      else if (count == 0)

 ;
      else if ((count - 1) * 4 >= ((integer_type_node)->type.precision)
        || (count > 1
     && ((1 << (((integer_type_node)->type.precision) - (count - 1) * 4))
         <= firstdig)))
 pedwarn ("hex escape out of range");
      return code;

    case '0': case '1': case '2': case '3': case '4':
    case '5': case '6': case '7':
      code = 0;
      count = 0;
      while ((c <= '7') && (c >= '0') && (count++ < 3))
 {
   code = (code * 8) + (c - '0');
   c = cxx_getch ();
 }
      put_back (c);
      return code;

    case '\\': case '\'': case '"':
      return c;

    case '\n':
      lineno++;
      *ignore_ptr = 1;
      return 0;

    case 'n':
      return 012;

    case 't':
      return 011;

    case 'r':
      return 015;

    case 'f':
      return 014;

    case 'b':
      return 010;

    case 'a':
      if (warn_traditional)
 warning ("the meaning of `\\a' varies with -traditional");

      if (flag_traditional)
 return c;
      return 007;

    case 'v':
      return 013;

    case 'e':
    case 'E':
      if (pedantic)
 pedwarn ("non-ANSI-standard escape sequence, `\\%c'", c);
      return 033;

    case '?':
      return c;


    case '(':
    case '{':
    case '[':

    case '%':
      if (pedantic)
 pedwarn ("unknown escape sequence `\\%c'", c);
      return c;
    }
  if (c >= 040 && c < 0177)
    pedwarn ("unknown escape sequence `\\%c'", c);
  else
    pedwarn ("unknown escape sequence: `\\' followed by char code 0x%x", c);
  return c;
}




int looking_for_typename = 0;
extern  int identifier_type (...) asm("_identifier_type");


int
identifier_type(tree decl) asm("_identifier_type");
int
identifier_type(tree decl)
{
  if (((n64_enum_tree_code) (decl)->common.code) == TEMPLATE_DECL
      && (((decl)->decl.result) == (tree) 
        ((void *)0)
        ))
    return 309;
  if (((n64_enum_tree_code) (decl)->common.code) == NAMESPACE_DECL)
    return 310;
  if (((n64_enum_tree_code) (decl)->common.code) != TYPE_DECL)
    return 258;
  return 259;
}

void
see_typename(void) asm("_see_typename");
void
see_typename(void)
{
  looking_for_typename = 1;
  if (yychar < 0)
    if ((yychar = yylex()) < 0) yychar = 0;
  looking_for_typename = 0;
  if (yychar == 258)
    {
      lastiddecl = lookup_name (yylval.ttype, -2);
      if (lastiddecl == 0)
 {
   if (flag_labels_ok)
     lastiddecl = (((struct n64_tag_lang_identifier *)(yylval.ttype))->x ? ((struct n64_tag_lang_identifier *)(yylval.ttype))->x->label_value : 0);
 }
      else
 yychar = identifier_type (lastiddecl);
    }
}

tree
do_identifier(register tree token) asm("_do_identifier");
tree
do_identifier(register tree token)
{
  register tree id = lastiddecl;

  if (yychar == -2)
    yychar = yylex ();


  if (id == (((struct n64_tag_lang_identifier *)(token))->global_value)
      && current_class_type != 0
      && ((current_class_type)->type.size) == 0
      && ((n64_enum_tree_code) (current_class_type)->common.code) != UNINSTANTIATED_P_TYPE)
    {

      tree field = lookup_field (current_class_type, token, 1, 0);
      if (field == 0)
 ;
      else if (field == error_mark_node)


 id = lookup_field (current_class_type, token, 0, 0);
      else if (((n64_enum_tree_code) (field)->common.code) == VAR_DECL
        || ((n64_enum_tree_code) (field)->common.code) == CONST_DECL)
 id = field;
      else if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
 my_friendly_abort (61);
      else
 {
   cp_error ("invalid use of member `%D' from base class `%T'", field,
        ((field)->decl.context));
   id = error_mark_node;
   return id;
 }
    }



  if (id && current_class_type
      && (((current_class_type)->type.lang_specific)->type_flags.being_defined)
      && ! (((struct n64_tag_lang_identifier *)(token))->class_value))
    pushdecl_class_level (id);

  if (!id || id == error_mark_node)
    {
      if (id == error_mark_node && current_class_type != (tree) 
                                                        ((void *)0)
                                                                 )
 {
   id = lookup_nested_field (token, 1);


   if (id && id != error_mark_node && ((id)->common.type) == error_mark_node)
     return id;
 }
      if (yychar == '(' || yychar == 300)
 {
   id = implicitly_declare (token);
 }
      else if (current_function_decl == 0)
 {
   cp_error ("`%D' was not declared in this scope", token);
   id = error_mark_node;
 }
      else
 {
   if ((((struct n64_tag_lang_identifier *)(token))->global_value) != error_mark_node
       || (((struct n64_tag_lang_identifier *)(token))->x ? ((struct n64_tag_lang_identifier *)(token))->x->error_locus : 0) != current_function_decl)
     {
       static int undeclared_variable_notice;

       cp_error ("`%D' undeclared (first use this function)", token);

       if (! undeclared_variable_notice)
  {
    error ("(Each undeclared identifier is reported only once");
    error ("for each function it appears in.)");
    undeclared_variable_notice = 1;
  }
     }
   id = error_mark_node;

   (((struct n64_tag_lang_identifier *)(token))->global_value) = error_mark_node;
   (((struct n64_tag_lang_identifier *)(token))->x == 0 ? ((struct n64_tag_lang_identifier *)(token))->x = (struct n64_tag_lang_id2 *)perm_calloc (1, sizeof (struct n64_tag_lang_id2)) : 0, ((struct n64_tag_lang_identifier *)(token))->x->error_locus = (current_function_decl));
 }
    }

  if (((n64_enum_tree_code) (id)->common.code) == VAR_DECL && ((id)->decl.lang_flag_7))
    {
      tree shadowed = ((id)->decl.result);
      if (shadowed)
 {
   if (!((id)->decl.lang_flag_0))
     {
       warning ("name lookup of `%s' changed",
         ((token)->identifier.pointer));
       cp_warning_at ("  matches this `%D' under current ANSI rules",
        shadowed);
       cp_warning_at ("  matches this `%D' under old rules", id);
       ((id)->decl.lang_flag_0) = 1;
     }
   id = shadowed;
 }
      else if (!((id)->decl.lang_flag_0))
 {
   static char msg[]
     = "name lookup of `%s' changed for new ANSI `for' scoping";
   ((id)->decl.lang_flag_0) = 1;
   if ((((((id)->common.type))->type.lang_flag_4)))
     {
       error (msg, ((token)->identifier.pointer));
       cp_error_at ("  cannot use obsolete binding at `%D' because it has a destructor", id);
       id = error_mark_node;
     }
   else
     {
       pedwarn (msg, ((token)->identifier.pointer));
       cp_pedwarn_at ("  using obsolete binding at `%D'", id);
     }
 }
    }

  if (((n64_enum_tree_code) (id)->common.code) == CONST_DECL)
    {
      if ((((struct n64_tag_lang_identifier *)(token))->class_value) == id)
 {

   n64_enum_access_type access
     = compute_access (((current_class_type)->type.binfo), id);
   if (access == access_private)
     cp_error ("enum `%D' is private", id);

 }
      id = ((id)->decl.initial);
    }
  else
    id = hack_identifier (id, token, yychar);
  return id;
}

tree
identifier_typedecl_value(tree node) asm("_identifier_typedecl_value");
tree
identifier_typedecl_value(tree node)
{
  tree t, type;
  type = (((node)->common.type));
  if (type == (tree) 
             ((void *)0)
                      )
    return (tree) 
          ((void *)0)
                   ;






  { t = ((((struct n64_tag_lang_identifier *)(node))->local_value)); if (t && ((n64_enum_tree_code) (t)->common.code) == TYPE_DECL && ((t)->common.type) == type) return t; };
  { t = ((((struct n64_tag_lang_identifier *)(node))->class_value)); if (t && ((n64_enum_tree_code) (t)->common.code) == TYPE_DECL && ((t)->common.type) == type) return t; };
  { t = ((((struct n64_tag_lang_identifier *)(node))->global_value)); if (t && ((n64_enum_tree_code) (t)->common.code) == TYPE_DECL && ((t)->common.type) == type) return t; };


  if (((type)->type.name))
    return ((type)->type.name);



  return (tree) 
        ((void *)0)
                 ;
}

struct n64_tag_try_type
{
  tree *node_var;
  char unsigned_flag;
  char long_flag;
  char long_long_flag;
};

struct n64_tag_try_type type_sequence[] =
{
  { &integer_type_node, 0, 0, 0},
  { &unsigned_type_node, 1, 0, 0},
  { &long_integer_type_node, 0, 1, 0},
  { &long_unsigned_type_node, 1, 1, 0},
  { &long_long_integer_type_node, 0, 1, 1},
  { &long_long_unsigned_type_node, 1, 1, 1}
};

int
real_yylex(void) asm("_real_yylex");
int
real_yylex(void)
{
  register int c;
  register int value;
  int wide_flag = 0;
  int dollar_seen = 0;
  int i;

  if (nextchar >= 0)
    c = nextchar, nextchar = -1;
  else
    c = cxx_getch ();



  while (1)
    switch (c)
      {
      case ' ':
      case '\t':
      case '\f':
      case '\v':
      case '\b':
 c = cxx_getch ();
 break;

      case '\r':


      case '\n':
      case '/':
      case '\\':
 c = skip_white_space (c);
      default:
 goto found_nonwhite;
      }
 found_nonwhite:

  token_buffer[0] = c;
  token_buffer[1] = 0;



  switch (c)
    {
    case 
        (-1)
           :
      token_buffer[0] = '\0';
      end_of_file = 1;
      if (input_redirected ())
 value = 339;
      else if (linemode)
 value = 338;
      else if (do_pending_expansions ())

 return yychar;
      else
 value = -1;
      break;

    case '$':
      if (dollars_in_ident)
 {
   dollar_seen = 1;
   goto letter;
 }
      value = '$';
      goto done;

    case 'L':

      {
 register int c = cxx_getch ();
 if (c == '\'')
   {
     wide_flag = 1;
     goto char_constant;
   }
 if (c == '"')
   {
     wide_flag = 1;
     goto string_constant;
   }
 put_back (c);
      }

    case 'A': case 'B': case 'C': case 'D': case 'E':
    case 'F': case 'G': case 'H': case 'I': case 'J':
    case 'K': case 'M': case 'N': case 'O':
    case 'P': case 'Q': case 'R': case 'S': case 'T':
    case 'U': case 'V': case 'W': case 'X': case 'Y':
    case 'Z':
    case 'a': case 'b': case 'c': case 'd': case 'e':
    case 'f': case 'g': case 'h': case 'i': case 'j':
    case 'k': case 'l': case 'm': case 'n': case 'o':
    case 'p': case 'q': case 'r': case 's': case 't':
    case 'u': case 'v': case 'w': case 'x': case 'y':
    case 'z':
    case '_':
    letter:
      {
 register char *p;

 p = token_buffer;
 if (input == 0)
   {




     *p++ = c;
     c = cxx_getch ();




     while (isalnum (c) || (c == '_') || c == '$')
       {
  if (c == '$' && ! dollars_in_ident)
    break;
  if (p >= token_buffer + maxtoken)
    p = extend_token_buffer (p);

  *p++ = c;
  c = getc (finput);
       }

     if (linemode && c == '\n')
       {
  put_back (c);
  c = 
     (-1)
        ;
       }
   }
 else
   {


     *p++ = c;
     c = cxx_getch ();

     while (isalnum (c) || (c == '_') || c == '$')
       {
  if (c == '$' && ! dollars_in_ident)
    break;
  if (p >= token_buffer + maxtoken)
    p = extend_token_buffer (p);

  *p++ = c;
  c = cxx_getch ();
       }
   }

 *p = 0;
 nextchar = c;

 value = 258;
 yylval.itype = 0;



 {
   register struct n64_tag_resword *ptr;

   if (ptr = is_reserved_word (token_buffer, p - token_buffer))
     {
       if (ptr->rid)
  {
    tree old_ttype = ridpointers[(int) ptr->rid];



    if (((n64_enum_tree_code) (old_ttype)->common.code) == IDENTIFIER_NODE
        && (((struct n64_tag_lang_identifier *)(old_ttype))->global_value) != 0
        && ((n64_enum_tree_code) ((((struct n64_tag_lang_identifier *)(old_ttype))->global_value))->common.code) == TYPE_DECL)
      looking_for_typename = 0;
    else if (ptr->token == 288 || ptr->token == 267)
      looking_for_typename = 1;



    nextchar = skip_white_space (nextchar);
    if (nextchar == '"')
      {







        if (ptr->rid != RID_EXTERN)
   error ("invalid modifier `%s' for language string",
          ptr->name);
        real_yylex ();
        value = 332;
        yylval.ttype = get_identifier (((yylval.ttype)->string.pointer));
        break;
      }
    if (ptr->token == 289)
      {
        switch (ptr->rid)
   {
   case RID_PUBLIC:
     yylval.itype = access_public;
     break;
   case RID_PRIVATE:
     yylval.itype = access_private;
     break;
   case RID_PROTECTED:
     yylval.itype = access_protected;
     break;
   default:
     my_friendly_abort (63);
   }
      }
    else
      yylval.ttype = old_ttype;
  }
       else if (ptr->token == 316)
  {
    yylval.code = NE_EXPR;
    token_buffer[0] = '!';
    token_buffer[1] = '=';
    token_buffer[2] = 0;
  }
       else if (ptr->token == 312)
  {
    if (strcmp ("and_eq", token_buffer) == 0)
      {
        yylval.code = BIT_AND_EXPR;
        token_buffer[0] = '&';
      }
    else if (strcmp ("or_eq", token_buffer) == 0)
      {
        yylval.code = BIT_IOR_EXPR;
        token_buffer[0] = '|';
      }
    else if (strcmp ("xor_eq", token_buffer) == 0)
      {
        yylval.code = BIT_XOR_EXPR;
        token_buffer[0] = '^';
      }
    token_buffer[1] = '=';
    token_buffer[2] = 0;
  }
       else if (ptr->token == '&')
  {
    yylval.code = BIT_AND_EXPR;
    token_buffer[0] = '&';
    token_buffer[1] = 0;
  }
       else if (ptr->token == '|')
  {
    yylval.code = BIT_IOR_EXPR;
    token_buffer[0] = '|';
    token_buffer[1] = 0;
  }
       else if (ptr->token == '^')
  {
    yylval.code = BIT_XOR_EXPR;
    token_buffer[0] = '^';
    token_buffer[1] = 0;
  }

       value = (int) ptr->token;
     }
 }




 if (strcmp ("catch", token_buffer) == 0
     || strcmp ("throw", token_buffer) == 0
     || strcmp ("try", token_buffer) == 0)
   {
     static int did_warn = 0;
     if (! did_warn && ! flag_handle_exceptions)
       {
  pedwarn ("`catch', `throw', and `try' are all C++ reserved words");
  did_warn = 1;
       }
   }

 if (value == 258 || value == 261)
   GNU_xref_ref (current_function_decl, token_buffer);

 if (value == 258)
   {
     register tree tmp = get_identifier (token_buffer);




     if ('.' == '$'
  && dollar_seen
  && ((strcmp(((tmp)->identifier.pointer), "this") == 0)
      || (((tmp)->identifier.pointer)[0] == '.' && ((tmp)->identifier.pointer)[1] == 'v')
      || (((tmp)->identifier.pointer)[1] == '.' && ((tmp)->identifier.pointer)[2] == '_')
      || (((tmp)->identifier.pointer)[1] == 'v' && ((tmp)->identifier.pointer)[2] == 't' && ((tmp)->identifier.pointer)[3] == '.')
      || (!strncmp (((tmp)->identifier.pointer), "_.tmp_", sizeof ("_.tmp_")-1))
      || (((tmp)->identifier.pointer)[0] == '.' && ((tmp)->identifier.pointer)[1] == '_')
      || (((tmp)->identifier.pointer)[0] == '_' && ((tmp)->identifier.pointer)[1] <= '9')))
       warning ("identifier name `%s' conflicts with GNU C++ internal naming strategy",
         token_buffer);


     yylval.ttype = tmp;
     tmp = (((struct n64_tag_lang_identifier *)(yylval.ttype))->local_value);
     if (tmp != (tree) 
               ((void *)0)
  
 && ((n64_enum_tree_code) (tmp)->common.code) == VAR_DECL
  && ((tmp)->decl.ignored_flag)
  && ((tmp)->common.readonly_flag)
  && ((tmp)->decl.initial) != (tree) 
                          ((void *)0)
  
 && ((n64_enum_tree_code) (((tmp)->decl.initial))->common.code) == STRING_CST)
       {
  yylval.ttype = ((tmp)->decl.initial);
  value = 264;
       }
   }
 if (value == 291 && ! global_bindings_p ())
   {
     value = 291;
     goto done;
   }
      }
      break;

    case '.':
      {
 register int c1 = cxx_getch ();
 token_buffer[0] = c;
 token_buffer[1] = c1;
 if (c1 == '*')
   {
     value = 321;
     token_buffer[2] = 0;
     goto done;
   }
 if (c1 == '.')
   {
     c1 = cxx_getch ();
     if (c1 == '.')
       {
  token_buffer[2] = c1;
  token_buffer[3] = 0;
  value = 265;
  goto done;
       }
     error ("parse error at `..'");
   }
 if (isdigit (c1))
   {
     put_back (c1);
     goto resume_numerical_scan;
   }
 nextchar = c1;
 value = '.';
 token_buffer[1] = 0;
 goto done;
      }
    case '0': case '1':

      {
 register int c1 = cxx_getch ();
 if (! isalnum (c1) && c1 != '.')
   {

     token_buffer[0] = c;
     token_buffer[1] = 0;
     if (c == '0')
       yylval.ttype = integer_zero_node;
     else
       yylval.ttype = integer_one_node;
     nextchar = c1;
     value = 263;
     goto done;
   }
 put_back (c1);
      }

     case '2': case '3': case '4':
    case '5': case '6': case '7': case '8': case '9':
    resume_numerical_scan:
      {
 register char *p;
 int base = 10;
 int count = 0;
 int largest_digit = 0;
 int numdigits = 0;







 int parts[((32 / 8) * 2 + 2)];
 int overflow = 0;

 enum n64_cpp_enum_anon1{ NOT_FLOAT, AFTER_POINT, TOO_MANY_POINTS};
typedef __underlying_type(enum n64_cpp_enum_anon1) n64_enum_anon1;
n64_enum_anon1 floatflag
   = NOT_FLOAT;

 p = token_buffer;
 *p++ = c;

 for (count = 0; count < ((32 / 8) * 2 + 2); count++)
   parts[count] = 0;

 if (c == '0')
   {
     *p++ = (c = cxx_getch ());
     if ((c == 'x') || (c == 'X'))
       {
  base = 16;
  *p++ = (c = cxx_getch ());
       }

     else if (c >= '0' && c <= '9')
       {
  base = 8;
  numdigits++;
       }
     else
       numdigits++;
   }



 while (c == '.'
        || (isalnum (c) && (c != 'l') && (c != 'L')
     && (c != 'u') && (c != 'U')
     && (floatflag == NOT_FLOAT || ((c != 'f') && (c != 'F')))))
   {
     if (c == '.')
       {
  if (base == 16)
    error ("floating constant may not be in radix 16");
  if (floatflag == AFTER_POINT)
    {
      error ("malformed floating constant");
      floatflag = TOO_MANY_POINTS;
    }
  else
    floatflag = AFTER_POINT;

  base = 10;
  *p++ = c = cxx_getch ();




  if (p == token_buffer + 2 && !isdigit (c))
    {
      if (c == '.')
        {
   c = cxx_getch ();
   if (c == '.')
     {
       *p++ = '.';
       *p = '\0';
       value = 265;
       goto done;
     }
   error ("parse error at `..'");
        }
      nextchar = c;
      token_buffer[1] = '\0';
      value = '.';
      goto done;
    }
       }
     else
       {



  if (isdigit (c))
    {
      c = c - '0';
    }
  else if (base <= 10)
    {
      if (c == 'e' || c == 'E')
        {
   base = 10;
   floatflag = AFTER_POINT;
   break;
        }
      error ("nondigits in number and not hexadecimal");
      c = 0;
    }
  else if (c >= 'a')
    {
      c = c - 'a' + 10;
    }
  else
    {
      c = c - 'A' + 10;
    }
  if (c >= largest_digit)
    largest_digit = c;
  numdigits++;

  for (count = 0; count < ((32 / 8) * 2 + 2); count++)
    {
      parts[count] *= base;
      if (count)
        {
   parts[count]
     += (parts[count-1] >> 8);
   parts[count-1]
     &= (1 << 8) - 1;
        }
      else
        parts[0] += c;
    }



  if (parts[((32 / 8) * 2 + 2) - 1] != 0)
    overflow = 1;

  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = (c = cxx_getch ());
       }
   }

 if (numdigits == 0)
   error ("numeric constant with no digits");

 if (largest_digit >= base)
   error ("numeric constant contains digits beyond the radix");


 *--p = 0;

 if (floatflag != NOT_FLOAT)
   {
     tree type = double_type_node;
     char f_seen = 0;
     char l_seen = 0;
     int garbage_chars = 0;
     double value;
     jmp_buf handler;



     if ((c == 'e') || (c == 'E'))
       {
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = cxx_getch ();
  if ((c == '+') || (c == '-'))
    {
      *p++ = c;
      c = cxx_getch ();
    }
  if (! isdigit (c))
    error ("floating constant exponent has no digits");
         while (isdigit (c))
    {
      if (p >= token_buffer + maxtoken - 3)
        p = extend_token_buffer (p);
      *p++ = c;
      c = cxx_getch ();
    }
       }

     *p = 0;
     
    (*_errno()) 
          = 0;


     if (
        _setjmp3((
        handler
        ), ((void *)0))
                        )
       {
  error ("floating constant out of range");
  value = dconst0;
       }
     else
       {
  set_float_handler (handler);





  switch (c)
    {
    case 'f': case 'F':
      type = float_type_node;
      value = ereal_atof (token_buffer, ((type)->type.mode));
      garbage_chars = -1;
      break;

    case 'l': case 'L':
      type = long_double_type_node;
      value = ereal_atof (token_buffer, ((type)->type.mode));
      garbage_chars = -1;
      break;

    default:
      value = ereal_atof (token_buffer, ((type)->type.mode));
    }
  set_float_handler (((void *)0));
       }
     if (pedantic
  && ((target_isinf (value))

      || (1 != 1
   && 
     (*_errno()) 
           == 
              34


   
  && ((ereal_cmp ((dconst1), (value)) == -1)
       || (ereal_cmp ((value), (dconstm1)) == -1)))

      ))
       {
  pedwarn ("floating point number exceeds range of `%s'",
    ((((((type)->type.name))->decl.name))->identifier.pointer));
       }

     while (isalnum (c))
       {
  if (c == 'f' || c == 'F')
    {
      if (f_seen)
        error ("two `f's in floating constant");
      f_seen = 1;
    }
  if (c == 'l' || c == 'L')
    {
      if (l_seen)
        error ("two `l's in floating constant");
      l_seen = 1;
    }
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = cxx_getch ();
  garbage_chars++;
       }

     if (garbage_chars > 0)
       error ("garbage at end of number");


     yylval.ttype = build_real (type, value);

     put_back (c);
     *p = 0;
   }
 else
   {
     tree type;
     int high, low;
     int spec_unsigned = 0;
     int spec_long = 0;
     int spec_long_long = 0;
     int bytes, warn;

     while (1)
       {
  if (c == 'u' || c == 'U')
    {
      if (spec_unsigned)
        error ("two `u's in integer constant");
      spec_unsigned = 1;
    }
  else if (c == 'l' || c == 'L')
    {
      if (spec_long)
        {
   if (spec_long_long)
     error ("three `l's in integer constant");
   else if (pedantic)
     pedwarn ("ANSI C++ forbids long long integer constants");
   spec_long_long = 1;
        }
      spec_long = 1;
    }
  else
    {
      if (isalnum (c))
        {
   error ("garbage at end of number");
   while (isalnum (c))
     {
       if (p >= token_buffer + maxtoken - 3)
         p = extend_token_buffer (p);
       *p++ = c;
       c = cxx_getch ();
     }
        }
      break;
    }
  if (p >= token_buffer + maxtoken - 3)
    p = extend_token_buffer (p);
  *p++ = c;
  c = cxx_getch ();
       }

     put_back (c);
     if (spec_long_long)
       bytes = ((long_long_integer_type_node)->type.precision) / 8;
     else
       bytes = ((long_integer_type_node)->type.precision) / 8;

     warn = overflow;
     for (i = bytes; i < ((32 / 8) * 2 + 2); i++)
       if (parts[i])
  warn = 1;
     if (warn)
       pedwarn ("integer constant out of range");



     high = low = 0;

     for (i = 0; i < 32 / 8; i++)
       {
  high |= ((int) parts[i + (32
          / 8)]
    << (i * 8));
  low |= (int) parts[i] << (i * 8);
       }


     yylval.ttype = build_int_2_wide ((int) (low), (int) (high));
     ((yylval.ttype)->common.type) = long_long_unsigned_type_node;
     if (!spec_long && !spec_unsigned
  && !(flag_traditional && base != 10)
  && int_fits_type_p (yylval.ttype, integer_type_node))
       {




  type = integer_type_node;
       }
     else if (!spec_long && (base != 10 || spec_unsigned)
       && int_fits_type_p (yylval.ttype, unsigned_type_node))
       {

  type = unsigned_type_node;
       }

     else if (!spec_unsigned && !spec_long_long
       && int_fits_type_p (yylval.ttype, long_integer_type_node))
       type = long_integer_type_node;

     else if (! spec_long_long
       && int_fits_type_p (yylval.ttype,
      long_unsigned_type_node))
       {




  if (flag_traditional && !spec_unsigned)
    type = long_integer_type_node;
  else
    type = long_unsigned_type_node;
       }

     else if (! spec_unsigned

       && ((yylval.ttype)->int_cst.int_cst_high) >= 0
       && int_fits_type_p (yylval.ttype,
      long_long_integer_type_node))
       type = long_long_integer_type_node;

     else if (int_fits_type_p (yylval.ttype,
          long_long_unsigned_type_node))
       {





  if (flag_traditional && !spec_unsigned)
    type = long_long_integer_type_node;
  else
    type = long_long_unsigned_type_node;
       }

     else
       {
  type = long_long_integer_type_node;
  warning ("integer constant out of range");

  if (base == 10 && ! spec_unsigned && ((type)->common.unsigned_flag))
    warning ("decimal integer constant is so large that it is unsigned");
       }


     ((yylval.ttype)->common.type) = type;
     *p = 0;
   }

 value = 263; break;
      }

    case '\'':
    char_constant:
      {
 register int result = 0;
 register int num_chars = 0;
 unsigned width = ((char_type_node)->type.precision);
 int max_chars;

 if (wide_flag)
   {
     width = ((target_flags & 0x00002000) ? 64 : 32);



     max_chars = 1;

   }
 else
   max_chars = ((integer_type_node)->type.precision) / width;

 while (1)
   {
   tryagain:

     c = cxx_getch ();

     if (c == '\'' || c == 
                          (-1)
                             )
       break;

     if (c == '\\')
       {
  int ignore = 0;
  c = readescape (&ignore);
  if (ignore)
    goto tryagain;
  if (width < 32
      && (unsigned) c >= (1 << width))
    warning ("escape sequence out of range for character");




       }
     else if (c == '\n')
       {
  if (pedantic)
    pedwarn ("ANSI C++ forbids newline in character constant");
  lineno++;
       }





     num_chars++;
     if (num_chars > maxtoken - 4)
       extend_token_buffer (token_buffer);

     token_buffer[num_chars] = c;


     if (num_chars < max_chars + 1)
       {
  if (width < 32)
    result = (result << width) | (c & ((1 << width) - 1));
  else
    result = c;
       }
   }

 token_buffer[num_chars + 1] = '\'';
 token_buffer[num_chars + 2] = 0;

 if (c != '\'')
   error ("malformatted character constant");
 else if (num_chars == 0)
   error ("empty character constant");
 else if (num_chars > max_chars)
   {
     num_chars = max_chars;
     error ("character constant too long");
   }
 else if (num_chars != 1 && ! flag_traditional)
   warning ("multi-character character constant");


 if (! wide_flag)
   {
     int num_bits = num_chars * width;
     if (num_bits == 0)

       yylval.ttype = build_int_2_wide ((int) (0), (int) (0));
     else if (((char_type_node)->common.unsigned_flag)
       || ((result >> (num_bits - 1)) & 1) == 0)
       yylval.ttype
  = build_int_2_wide ((int) (result & ((unsigned int) ~0 >> (32 - num_bits))), (int) (0))

            ;
     else
       yylval.ttype
  = build_int_2_wide ((int) (result | ~((unsigned int) ~0 >> (32 - num_bits))), (int) (-1))

             ;
     if (num_chars<=1)
       ((yylval.ttype)->common.type) = char_type_node;
     else
       ((yylval.ttype)->common.type) = integer_type_node;
   }
 else
   {
     yylval.ttype = build_int_2_wide ((int) (result), (int) (0));
     ((yylval.ttype)->common.type) = wchar_type_node;
   }

 value = 263;
 break;
      }

    case '"':
    string_constant:
      {
 register char *p;

 c = cxx_getch ();
 p = token_buffer + 1;

 while (c != '"' && c >= 0)
   {

     if (!ignore_escape_flag && c == '\\')
       {
  int ignore = 0;
  c = readescape (&ignore);
  if (ignore)
    goto skipnewline;
  if (!wide_flag
      && ((char_type_node)->type.precision) < 32
      && c >= ((unsigned) 1 << ((char_type_node)->type.precision)))
    warning ("escape sequence out of range for character");
       }
     else if (c == '\n')
       {
  if (pedantic)
    pedwarn ("ANSI C++ forbids newline in string constant");
  lineno++;
       }

     if (p == token_buffer + maxtoken)
       p = extend_token_buffer (p);
     *p++ = c;

   skipnewline:
     c = cxx_getch ();
     if (c == 
             (-1)
                ) {
  error("Unterminated string");
  break;
     }
   }
 *p = 0;




 if (wide_flag)
   {


     char *widep = (char *) 
                           __builtin_alloca((
                           (p - token_buffer) * (((target_flags & 0x00002000) ? 64 : 32) / 8)
                           ))
                                                                    ;
     int len;
     {
       union { long l; char c[sizeof (long)]; } u;
       int big_endian;
       char *wp, *cp;


       u.l = 1;
       big_endian = u.c[sizeof (long) - 1];
       wp = widep + (big_endian ? (((target_flags & 0x00002000) ? 64 : 32) / 8) - 1 : 0);

       memset (widep,0,(p - token_buffer) * (((target_flags & 0x00002000) ? 64 : 32) / 8));
       for (cp = token_buffer + 1; cp < p; cp++)
  *wp = *cp, wp += (((target_flags & 0x00002000) ? 64 : 32) / 8);
       len = p - token_buffer - 1;
     }

     yylval.ttype = build_string ((len + 1) * (((target_flags & 0x00002000) ? 64 : 32) / 8), widep);
     ((yylval.ttype)->common.type) = wchar_array_type_node;
   }
 else
   {
     yylval.ttype = build_string (p - token_buffer, token_buffer + 1);
     ((yylval.ttype)->common.type) = char_array_type_node;
   }

 *p++ = '"';
 *p = 0;

 value = 264; break;
      }

    case '+':
    case '-':
    case '&':
    case '|':
    case '<':
    case '>':
    case '*':
    case '/':
    case '%':
    case '^':
    case '!':
    case '=':
      {
 register int c1;

      combine:

 switch (c)
   {
   case '+':
     yylval.code = PLUS_EXPR; break;
   case '-':
     yylval.code = MINUS_EXPR; break;
   case '&':
     yylval.code = BIT_AND_EXPR; break;
   case '|':
     yylval.code = BIT_IOR_EXPR; break;
   case '*':
     yylval.code = MULT_EXPR; break;
   case '/':
     yylval.code = TRUNC_DIV_EXPR; break;
   case '%':
     yylval.code = TRUNC_MOD_EXPR; break;
   case '^':
     yylval.code = BIT_XOR_EXPR; break;
   case 318:
     yylval.code = LSHIFT_EXPR; break;
   case 319:
     yylval.code = RSHIFT_EXPR; break;
   case '<':
     yylval.code = LT_EXPR; break;
   case '>':
     yylval.code = GT_EXPR; break;
   }

 token_buffer[1] = c1 = cxx_getch ();
 token_buffer[2] = 0;

 if (c1 == '=')
   {
     switch (c)
       {
       case '<':
  value = 317; yylval.code = LE_EXPR; goto done;
       case '>':
  value = 317; yylval.code = GE_EXPR; goto done;
       case '!':
  value = 316; yylval.code = NE_EXPR; goto done;
       case '=':
  value = 316; yylval.code = EQ_EXPR; goto done;
       }
     value = 312; goto done;
   }
 else if (c == c1)
   switch (c)
     {
     case '+':
       value = 323; goto done;
     case '-':
       value = 324; goto done;
     case '&':
       value = 314; goto done;
     case '|':
       value = 313; goto done;
     case '<':
       c = 318;
       goto combine;
     case '>':
       c = 319;
       goto combine;
     }
 else if ((c == '-') && (c1 == '>'))
   {
     nextchar = cxx_getch ();
     if (nextchar == '*')
       {
  nextchar = -1;
  value = 320;
       }
     else
       value = 327;
     goto done;
   }
 else if (c1 == '?' && (c == '<' || c == '>'))
   {
     token_buffer[3] = 0;

     c1 = cxx_getch ();
     yylval.code = (c == '<' ? MIN_EXPR : MAX_EXPR);
     if (c1 == '=')
       {

  token_buffer[2] = c1;
  value = 312;
       }
     else
       {
  value = 315;
  nextchar = c1;
       }
     if (pedantic)
       pedwarn ("use of `operator %s' is not standard C++",
         token_buffer);
     goto done;
   }

 else if (c == '<' && c1 == '%')
   { value = '{'; goto done; }
 else if (c == '<' && c1 == ':')
   { value = '['; goto done; }
 else if (c == '%' && c1 == '>')
   { value = '}'; goto done; }
 else if (c == '%' && c1 == ':')
   { value = '#'; goto done; }

 nextchar = c1;
 token_buffer[1] = 0;

 value = c;
 goto done;
      }

    case ':':
      c = cxx_getch ();
      if (c == ':')
 {
   token_buffer[1] = ':';
   token_buffer[2] = '\0';
   value = 307;
   yylval.itype = 1;
 }
      else if (c == '>')
 {
   value = ']';
   goto done;
 }
      else
 {
   nextchar = c;
   value = ':';
 }
      break;

    case 0:

      value = 1;
      break;

    case '(':

      nextchar = skip_white_space (cxx_getch ());
      if (nextchar == '*')
 {
   int next_c = skip_white_space (cxx_getch ());
   if (next_c == ')')
     {
       nextchar = -1;
       yylval.ttype = build1 (INDIRECT_REF, 0, 0);
       value = 326;
     }
   else
     {
       put_back (next_c);
       value = c;
     }
 }
      else if (nextchar == ')')
 {
   nextchar = -1;
   yylval.ttype = (tree) 
                 ((void *)0)
                          ;
   value = 300;
 }
      else value = c;
      break;

    default:
      value = c;
    }

done:





  return value;
}

enum n64_cpp_enum_anonymous_21{
  d_kind, t_kind, s_kind, r_kind, e_kind, c_kind,
  id_kind, op_id_kind, perm_list_kind, temp_list_kind,
  vec_kind, x_kind, lang_decl, lang_type, all_kinds
};
typedef __underlying_type(enum n64_cpp_enum_anonymous_21) n64_enum_anonymous_21;
typedef n64_enum_anonymous_21 tree_node_kind;
extern int tree_node_counts[];
extern int tree_node_sizes[];
extern char *tree_node_kind_names[];



tree free_lang_decl_chain;

tree
build_lang_decl(n64_enum_tree_code code, tree name, tree type) asm("_build_lang_decl");
tree
build_lang_decl(n64_enum_tree_code code, tree name, tree type)
{
  register tree t = build_decl (code, name, type);
  struct n64_tag_obstack *obstack = current_obstack;
  register int i = sizeof (struct n64_tag_lang_decl) / sizeof (int);
  register int *pi;

  if (! ((t)->common.permanent_flag))
    obstack = saveable_obstack;
  else

    obstack = &permanent_obstack;

  if (free_lang_decl_chain && obstack == &permanent_obstack)
    {
      pi = (int *)free_lang_decl_chain;
      free_lang_decl_chain = ((free_lang_decl_chain)->common.chain);
    }
  else
    pi = (int *) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_lang_decl))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });

  while (i > 0)
    pi[--i] = 0;

  ((t)->decl.lang_specific) = (struct n64_tag_lang_decl *) pi;
  (((struct n64_tag_lang_decl *) pi)->decl_flags.permanent_attr)
    = obstack == &permanent_obstack;
  my_friendly_assert ((((struct n64_tag_lang_decl *) pi)->decl_flags.permanent_attr)
   == ((t)->common.permanent_flag), 234);
  (((t)->decl.lang_specific)->main_decl_variant) = t;
  if (current_lang_name == lang_name_cplusplus)
    {
      (((t)->decl.lang_specific)->decl_flags.language) = lang_cplusplus;
    }
  else if (current_lang_name == lang_name_c)
    (((t)->decl.lang_specific)->decl_flags.language) = lang_c;
  else my_friendly_abort (64);
  return t;
}

tree
build_lang_field_decl(n64_enum_tree_code code, tree name, tree type) asm("_build_lang_field_decl");
tree
build_lang_field_decl(n64_enum_tree_code code, tree name, tree type)
{
  extern struct n64_tag_obstack *current_obstack, *saveable_obstack;
  register tree t = build_decl (code, name, type);
  struct n64_tag_obstack *obstack = current_obstack;
  register int i = sizeof (struct n64_tag_lang_decl_flags) / sizeof (int);
  register int *pi;
  if (! ((t)->common.permanent_flag))
    obstack = saveable_obstack;
  else
    my_friendly_assert (obstack == &permanent_obstack, 235);

  pi = (int *) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_lang_decl_flags))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  while (i > 0)
    pi[--i] = 0;

  ((t)->decl.lang_specific) = (struct n64_tag_lang_decl *) pi;
  return t;
}

void
copy_lang_decl(tree node) asm("_copy_lang_decl");
void
copy_lang_decl(tree node)
{
  int size;
  int *pi;

  if (((n64_enum_tree_code) (node)->common.code) == FIELD_DECL)
    size = sizeof (struct n64_tag_lang_decl_flags);
  else
    size = sizeof (struct n64_tag_lang_decl);
  pi = (int *)__extension__ ({ struct n64_tag_obstack *__h = (&permanent_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((size)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  memcpy ((char *)pi,(char *)((node)->decl.lang_specific),size);
  ((node)->decl.lang_specific) = (struct n64_tag_lang_decl *)pi;
}

tree
make_lang_type(n64_enum_tree_code code) asm("_make_lang_type");
tree
make_lang_type(n64_enum_tree_code code)
{
  extern struct n64_tag_obstack *current_obstack, *saveable_obstack;
  register tree t = make_node (code);
  struct n64_tag_obstack *obstack = current_obstack;
  register int i = sizeof (struct n64_tag_lang_type) / sizeof (int);
  register int *pi;


  (((t)->type.lang_flag_5)) = 1;

  if (! ((t)->common.permanent_flag))
    obstack = saveable_obstack;
  else
    my_friendly_assert (obstack == &permanent_obstack, 236);

  pi = (int *) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_lang_type))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  while (i > 0)
    pi[--i] = 0;

  ((t)->type.lang_specific) = (struct n64_tag_lang_type *) pi;
  (((t)->type.lang_specific)->as_list) = build_tree_list ((tree) 
                                          ((void *)0)
                                                   , t);
  (((t)->type.lang_specific)->type_flags.interface_unknown = !!(interface_unknown));
  (((t)->type.lang_specific)->type_flags.interface_only) = interface_only;
  (((t)->type.lang_specific)->vbase_size) = integer_zero_node;
  ((t)->type.binfo) = make_binfo (integer_zero_node, t, (tree) 
                                                    ((void *)0)
                                                             , (tree) 
                                                               ((void *)0)
                                                                        ,
          (tree) 
         ((void *)0)
                  );
  (((t)->type.lang_specific)->binfo_as_list) = build_tree_list ((tree) 
                                                ((void *)0)
                                                         , ((t)->type.binfo));




  build_pointer_type (t);






  return t;
}

void
copy_decl_lang_specific(tree decl) asm("_copy_decl_lang_specific");
void
copy_decl_lang_specific(tree decl)
{
  extern struct n64_tag_obstack *current_obstack, *saveable_obstack;
  register int *old = (int *)((decl)->decl.lang_specific);
  struct n64_tag_obstack *obstack = current_obstack;
  register int i = sizeof (struct n64_tag_lang_decl) / sizeof (int);
  register int *pi;

  if (! ((decl)->common.permanent_flag))
    obstack = saveable_obstack;
  else
    my_friendly_assert (obstack == &permanent_obstack, 237);

  pi = (int *) __extension__ ({ struct n64_tag_obstack *__h = (obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((sizeof (struct n64_tag_lang_decl))); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
  while (i-- > 0)
    pi[i] = old[i];

  ((decl)->decl.lang_specific) = (struct n64_tag_lang_decl *) pi;





}

void
dump_time_statistics(void) asm("_dump_time_statistics");
void
dump_time_statistics(void)
{
  register tree prev = 0, decl, next;
  int this_time = my_get_run_time ();
  (((((struct n64_tag_lang_identifier *)(this_filename_time))->local_value))->int_cst.int_cst_low)
    += this_time - body_time;

  fprintf (
          (__acrt_iob_func(2))
                , "\n******\n");
  print_time ("header files (total)", header_time);
  print_time ("main file (total)", this_time - body_time);
  fprintf (
          (__acrt_iob_func(2))
                , "ratio = %g : 1\n",
    (double)header_time / (double)(this_time - body_time));
  fprintf (
          (__acrt_iob_func(2))
                , "\n******\n");

  for (decl = filename_times; decl; decl = next)
    {
      next = (((struct n64_tag_lang_identifier *)(decl))->global_value);
      (((struct n64_tag_lang_identifier *)(decl))->global_value) = prev;
      prev = decl;
    }

  for (decl = prev; decl; decl = (((struct n64_tag_lang_identifier *)(decl))->global_value))
    print_time (((decl)->identifier.pointer),
  (((((struct n64_tag_lang_identifier *)(decl))->local_value))->int_cst.int_cst_low));
}

void
compiler_error(char *s, int v, int v2) asm("_compiler_error");
void
compiler_error(char *s, int v, int v2)
{
  char buf[1024];
  sprintf (buf, s, v, v2);
  error_with_file_and_line (input_filename, lineno, "%s (compiler error)", buf);
}

void
compiler_error_with_decl(tree decl, char *s) asm("_compiler_error_with_decl");
void
compiler_error_with_decl(tree decl, char *s)
{
  char *name;
  count_error (0);

  report_error_function (0);

  if (((n64_enum_tree_code) (decl)->common.code) == PARM_DECL)
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ",
      ((((decl)->decl.context))->decl.filename),
      ((((decl)->decl.context))->decl.linenum));
  else
    fprintf (
            (__acrt_iob_func(2))
                  , "%s:%d: ",
      ((decl)->decl.filename), ((decl)->decl.linenum));

  name = lang_printable_name (decl);
  if (name)
    fprintf (
            (__acrt_iob_func(2))
                  , s, name);
  else
    fprintf (
            (__acrt_iob_func(2))
                  , s, "((anonymous))");
  fprintf (
          (__acrt_iob_func(2))
                , " (compiler error)\n");
}

void
yyerror(char *string) asm("_yyerror");
void
yyerror(char *string)
{
  extern int end_of_file;
  char buf[200];

  strcpy (buf, string);



  if (end_of_file)
    strcat (buf, input_redirected ()
     ? " at end of saved text"
     : " at end of input");
  else if (token_buffer[0] == 0)
    strcat (buf, " at null character");
  else if (token_buffer[0] == '"')
    strcat (buf, " before string constant");
  else if (token_buffer[0] == '\'')
    strcat (buf, " before character constant");
  else if (token_buffer[0] < 040 || (unsigned char) token_buffer[0] >= 0177)
    sprintf (buf + strlen (buf), " before character 0%o",
      (unsigned char) token_buffer[0]);
  else
    strcat (buf, " before `%s'");

  error (buf, token_buffer);
}
int handle_sysv_pragma(void) asm("_handle_sysv_pragma");
int handle_sysv_pragma(void)
{
  for (;;)
    {
      switch (yylex ())
 {
 case 258:
 case 259:
 case 264:
 case 263:
   handle_pragma_token ("ignored", yylval.ttype);
   break;
 case '(':
   handle_pragma_token ("(", (tree) 
                            ((void *)0)
                                     );
   break;
 case ')':
   handle_pragma_token (")", (tree) 
                            ((void *)0)
                                     );
   break;
 case ',':
   handle_pragma_token (",", (tree) 
                            ((void *)0)
                                     );
   break;
 case '=':
   handle_pragma_token ("=", (tree) 
                            ((void *)0)
                                     );
   break;
 case 300:
   handle_pragma_token ("(", (tree) 
                            ((void *)0)
                                     );
   handle_pragma_token (")", (tree) 
                            ((void *)0)
                                     );
   break;
 case 338:
   handle_pragma_token (((void *)0), (tree) 
                                 ((void *)0)
                                          );
   return;
 default:
   handle_pragma_token (((void *)0), (tree) 
                                 ((void *)0)
                                          );
   while (yylex () != 338)
                   ;
   return;
 }
    }
}

