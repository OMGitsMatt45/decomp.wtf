// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/reload1.c
/* Reload pseudo regs into hard regs for insns that require hard regs.
   Copyright (C) 1987, 88, 89, 92, 93, 94, 1995 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int gcc_obstack_init(...) asm("_gcc_obstack_init");
extern int init_recog(...) asm("_init_recog");
extern int get_max_uid(...) asm("_get_max_uid");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int max_label_num(...) asm("_max_label_num");
extern int get_first_label_num(...) asm("_get_first_label_num");
extern int note_stores(...) asm("_note_stores");
extern int reg_classes_intersect_p(...) asm("_reg_classes_intersect_p");
extern int mark_elimination(...) asm("_mark_elimination");
extern int reg_set_p(...) asm("_reg_set_p");
extern int error_for_asm(...) asm("_error_for_asm");
extern int fatal(...) asm("_fatal");
extern int push_obstacks(...) asm("_push_obstacks");
extern int pop_obstacks(...) asm("_pop_obstacks");
extern int retry_global_alloc(...) asm("_retry_global_alloc");
extern int constrain_operands(...) asm("_constrain_operands");
extern int true_regnum(...) asm("_true_regnum");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int delete_insns_since(...) asm("_delete_insns_since");
struct n64_tag__obstack_chunk;
struct n64_tag_elim_table;
struct n64_tag_hard_reg_n_uses;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_needs;
struct n64_tag_obstack;
struct n64_tag_optab;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

struct n64_tag__obstack_chunk
{
  char *limit;
  struct n64_tag__obstack_chunk *prev;
  char contents[4];
};

struct n64_tag_obstack
{
  long chunk_size;
  struct n64_tag__obstack_chunk* chunk;
  char *object_base;
  char *next_free;
  char *chunk_limit;
  ptrdiff_t temp;
  int alignment_mask;
  struct n64_tag__obstack_chunk *(*chunkfun)(...);
  void (*freefun)(...);
  char *extra_arg;
  unsigned use_extra_arg:1;
  unsigned maybe_empty_object:1;



  unsigned alloc_failed:1;
};




extern void _obstack_newchunk (struct n64_tag_obstack *, int) asm("__obstack_newchunk");
extern void _obstack_free (struct n64_tag_obstack *, void *) asm("__obstack_free");
extern int _obstack_begin (struct n64_tag_obstack *, int, int,
       void *(*)(...), void (*)(...)) asm("__obstack_begin");
extern int _obstack_begin_1 (struct n64_tag_obstack *, int, int,
         void *(*)(...), void (*)(...), void *) asm("__obstack_begin_1");
void obstack_init (struct n64_tag_obstack *obstack) asm("_obstack_init");

void * obstack_alloc (struct n64_tag_obstack *obstack, int size) asm("_obstack_alloc");

void * obstack_copy (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy");
void * obstack_copy0 (struct n64_tag_obstack *obstack, void *address, int size) asm("_obstack_copy0");

void obstack_free (struct n64_tag_obstack *obstack, void *block) asm("_obstack_free");

void obstack_blank (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank");

void obstack_grow (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow");
void obstack_grow0 (struct n64_tag_obstack *obstack, void *data, int size) asm("_obstack_grow0");

void obstack_1grow (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow");
void obstack_ptr_grow (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow");
void obstack_int_grow (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow");

void * obstack_finish (struct n64_tag_obstack *obstack) asm("_obstack_finish");

int obstack_object_size (struct n64_tag_obstack *obstack) asm("_obstack_object_size");

int obstack_room (struct n64_tag_obstack *obstack) asm("_obstack_room");
void obstack_1grow_fast (struct n64_tag_obstack *obstack, int data_char) asm("_obstack_1grow_fast");
void obstack_ptr_grow_fast (struct n64_tag_obstack *obstack, void *data) asm("_obstack_ptr_grow_fast");
void obstack_int_grow_fast (struct n64_tag_obstack *obstack, int data) asm("_obstack_int_grow_fast");
void obstack_blank_fast (struct n64_tag_obstack *obstack, int size) asm("_obstack_blank_fast");

void * obstack_base (struct n64_tag_obstack *obstack) asm("_obstack_base");
void * obstack_next_free (struct n64_tag_obstack *obstack) asm("_obstack_next_free");
int obstack_alignment_mask (struct n64_tag_obstack *obstack) asm("_obstack_alignment_mask");
int obstack_chunk_size (struct n64_tag_obstack *obstack) asm("_obstack_chunk_size");
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
enum n64_cpp_enum_expand_modifier{EXPAND_NORMAL, EXPAND_SUM,
        EXPAND_CONST_ADDRESS, EXPAND_INITIALIZER};
typedef __underlying_type(enum n64_cpp_enum_expand_modifier) n64_enum_expand_modifier;



extern rtx forced_labels;



extern rtx save_expr_regs;

extern int current_function_calls_alloca;
extern int current_function_outgoing_args_size;



extern rtx current_function_arg_offset_rtx;


extern int current_function_uses_const_pool;


extern int current_function_uses_pic_offset_table;


extern rtx current_function_internal_arg_pointer;





extern int inhibit_defer_pop;



extern int function_call_count;




extern rtx nonlocal_goto_handler_slot;





extern rtx nonlocal_goto_stack_level;
extern int pending_stack_adjust;
extern int target_temp_slot_level;
enum n64_cpp_enum_direction{none, upward, downward};
typedef __underlying_type(enum n64_cpp_enum_direction) n64_enum_direction;

typedef struct n64_tag_optab
{
  n64_enum_rtx_code code;
  struct {
    n64_enum_insn_code insn_code;
    rtx libfunc;
  } handlers [(int) MAX_MACHINE_MODE];
} * optab;
extern rtx (*const insn_gen_function[])(...);

extern optab add_optab;
extern optab sub_optab;
extern optab smul_optab;
extern optab smul_highpart_optab;
extern optab umul_highpart_optab;
extern optab smul_widen_optab;

extern optab umul_widen_optab;
extern optab sdiv_optab;
extern optab sdivmod_optab;
extern optab udiv_optab;
extern optab udivmod_optab;
extern optab smod_optab;
extern optab umod_optab;
extern optab flodiv_optab;
extern optab ftrunc_optab;
extern optab and_optab;
extern optab ior_optab;
extern optab xor_optab;
extern optab ashl_optab;
extern optab ashr_optab;
extern optab lshr_optab;
extern optab rotl_optab;
extern optab rotr_optab;
extern optab smin_optab;
extern optab smax_optab;
extern optab umin_optab;
extern optab umax_optab;

extern optab mov_optab;
extern optab movstrict_optab;

extern optab cmp_optab;
extern optab tst_optab;


extern optab neg_optab;
extern optab abs_optab;
extern optab one_cmpl_optab;
extern optab ffs_optab;
extern optab sqrt_optab;
extern optab sin_optab;
extern optab cos_optab;
extern optab strlen_optab;


extern n64_enum_insn_code extendtab[MAX_MACHINE_MODE][MAX_MACHINE_MODE][2];


extern n64_enum_insn_code fixtab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code fixtrunctab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];
extern n64_enum_insn_code floattab[(int) MAX_MACHINE_MODE][(int) MAX_MACHINE_MODE][2];


extern optab code_to_optab[((int)LAST_AND_UNUSED_RTX_CODE) + 1];







enum n64_cpp_enum_optab_methods{
  OPTAB_DIRECT,
  OPTAB_LIB,
  OPTAB_WIDEN,
  OPTAB_LIB_WIDEN,
  OPTAB_MUST_WIDEN
};
typedef __underlying_type(enum n64_cpp_enum_optab_methods) n64_enum_optab_methods;





extern rtx extendsfdf2_libfunc;
extern rtx extendsfxf2_libfunc;
extern rtx extendsftf2_libfunc;
extern rtx extenddfxf2_libfunc;
extern rtx extenddftf2_libfunc;

extern rtx truncdfsf2_libfunc;
extern rtx truncxfsf2_libfunc;
extern rtx trunctfsf2_libfunc;
extern rtx truncxfdf2_libfunc;
extern rtx trunctfdf2_libfunc;

extern rtx memcpy_libfunc;
extern rtx bcopy_libfunc;
extern rtx memcmp_libfunc;
extern rtx bcmp_libfunc;
extern rtx memset_libfunc;
extern rtx bzero_libfunc;

extern rtx eqhf2_libfunc;
extern rtx nehf2_libfunc;
extern rtx gthf2_libfunc;
extern rtx gehf2_libfunc;
extern rtx lthf2_libfunc;
extern rtx lehf2_libfunc;

extern rtx eqsf2_libfunc;
extern rtx nesf2_libfunc;
extern rtx gtsf2_libfunc;
extern rtx gesf2_libfunc;
extern rtx ltsf2_libfunc;
extern rtx lesf2_libfunc;

extern rtx eqdf2_libfunc;
extern rtx nedf2_libfunc;
extern rtx gtdf2_libfunc;
extern rtx gedf2_libfunc;
extern rtx ltdf2_libfunc;
extern rtx ledf2_libfunc;

extern rtx eqxf2_libfunc;
extern rtx nexf2_libfunc;
extern rtx gtxf2_libfunc;
extern rtx gexf2_libfunc;
extern rtx ltxf2_libfunc;
extern rtx lexf2_libfunc;

extern rtx eqtf2_libfunc;
extern rtx netf2_libfunc;
extern rtx gttf2_libfunc;
extern rtx getf2_libfunc;
extern rtx lttf2_libfunc;
extern rtx letf2_libfunc;

extern rtx floatsisf_libfunc;
extern rtx floatdisf_libfunc;
extern rtx floattisf_libfunc;

extern rtx floatsidf_libfunc;
extern rtx floatdidf_libfunc;
extern rtx floattidf_libfunc;

extern rtx floatsixf_libfunc;
extern rtx floatdixf_libfunc;
extern rtx floattixf_libfunc;

extern rtx floatsitf_libfunc;
extern rtx floatditf_libfunc;
extern rtx floattitf_libfunc;

extern rtx fixsfsi_libfunc;
extern rtx fixsfdi_libfunc;
extern rtx fixsfti_libfunc;

extern rtx fixdfsi_libfunc;
extern rtx fixdfdi_libfunc;
extern rtx fixdfti_libfunc;

extern rtx fixxfsi_libfunc;
extern rtx fixxfdi_libfunc;
extern rtx fixxfti_libfunc;

extern rtx fixtfsi_libfunc;
extern rtx fixtfdi_libfunc;
extern rtx fixtfti_libfunc;

extern rtx fixunssfsi_libfunc;
extern rtx fixunssfdi_libfunc;
extern rtx fixunssfti_libfunc;

extern rtx fixunsdfsi_libfunc;
extern rtx fixunsdfdi_libfunc;
extern rtx fixunsdfti_libfunc;

extern rtx fixunsxfsi_libfunc;
extern rtx fixunsxfdi_libfunc;
extern rtx fixunsxfti_libfunc;

extern rtx fixunstfsi_libfunc;
extern rtx fixunstfdi_libfunc;
extern rtx fixunstfti_libfunc;

typedef rtx (*rtxfun)(...);




extern rtxfun bcc_gen_fctn[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code setcc_gen_code[((int)LAST_AND_UNUSED_RTX_CODE)];





extern n64_enum_insn_code movcc_gen_code[(int) MAX_MACHINE_MODE];



extern n64_enum_insn_code movstr_optab[(int) MAX_MACHINE_MODE];




extern rtx expand_binop (n64_enum_machine_mode, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_expand_binop")
                                   ;


extern rtx sign_expand_binop (n64_enum_machine_mode, optab, optab, rtx, rtx, rtx, int, n64_enum_optab_methods) asm("_sign_expand_binop")
                                           ;


extern int expand_twoval_binop (optab, rtx, rtx, rtx, rtx, int) asm("_expand_twoval_binop");


extern rtx expand_unop (n64_enum_machine_mode, optab, rtx, rtx, int) asm("_expand_unop");


extern rtx expand_abs (n64_enum_machine_mode, rtx, rtx, int, int) asm("_expand_abs");


extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");



extern void emit_unop_insn (int, rtx, rtx, n64_enum_rtx_code) asm("_emit_unop_insn");



extern rtx emit_no_conflict_block (rtx, rtx, rtx, rtx, rtx) asm("_emit_no_conflict_block");


extern void emit_libcall_block (rtx, rtx, rtx, rtx) asm("_emit_libcall_block");


extern void emit_clr_insn (rtx) asm("_emit_clr_insn");


extern void emit_0_to_1_insn (rtx) asm("_emit_0_to_1_insn");


extern void emit_cmp_insn (rtx, rtx, n64_enum_rtx_code, rtx, n64_enum_machine_mode, int, int) asm("_emit_cmp_insn")
                                  ;



extern int can_compare_p (n64_enum_machine_mode) asm("_can_compare_p");



extern void emit_float_lib_cmp (rtx, rtx, n64_enum_rtx_code) asm("_emit_float_lib_cmp");


extern void emit_indirect_jump (rtx) asm("_emit_indirect_jump");



rtx emit_conditional_move (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, rtx, rtx, n64_enum_machine_mode, int) asm("_emit_conditional_move")

                             ;


int can_conditionally_move_p (n64_enum_machine_mode mode) asm("_can_conditionally_move_p");






extern rtx gen_add2_insn (rtx, rtx) asm("_gen_add2_insn");
extern rtx gen_sub2_insn (rtx, rtx) asm("_gen_sub2_insn");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern int have_add2_insn (n64_enum_machine_mode) asm("_have_add2_insn");
extern int have_sub2_insn (n64_enum_machine_mode) asm("_have_sub2_insn");


extern n64_enum_insn_code can_extend_p (n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_can_extend_p")
                               ;



extern rtx gen_extend_insn (rtx, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int) asm("_gen_extend_insn")
                              ;



extern void init_fixtab (void) asm("_init_fixtab");
extern void init_floattab (void) asm("_init_floattab");


extern void expand_float (rtx, rtx, int) asm("_expand_float");


extern void expand_fix (rtx, rtx, int) asm("_expand_fix");



extern void init_optabs (void) asm("_init_optabs");





extern rtx negate_rtx (n64_enum_machine_mode, rtx) asm("_negate_rtx");


extern rtx expand_and (rtx, rtx, rtx) asm("_expand_and");


extern rtx emit_store_flag (rtx, n64_enum_rtx_code, rtx, rtx, n64_enum_machine_mode, int, int) asm("_emit_store_flag")
                                   ;




extern rtx get_condition (rtx, rtx *) asm("_get_condition");





extern void init_expr_once (void) asm("_init_expr_once");


extern void init_expr (void) asm("_init_expr");



extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");


extern void emit_queue (void) asm("_emit_queue");



extern void convert_move (rtx, rtx, int) asm("_convert_move");


extern rtx convert_to_mode (n64_enum_machine_mode, rtx, int) asm("_convert_to_mode");


extern rtx convert_modes (n64_enum_machine_mode, n64_enum_machine_mode, rtx, int) asm("_convert_modes");


extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");



extern void move_block_to_reg (int, rtx, int, n64_enum_machine_mode) asm("_move_block_to_reg");



extern void move_block_from_reg (int, rtx, int, int) asm("_move_block_from_reg");


extern void use_reg (rtx*, rtx) asm("_use_reg");


extern void use_regs (rtx*, int, int) asm("_use_regs");



extern void clear_storage (rtx, rtx) asm("_clear_storage");


extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");


extern rtx emit_move_insn_1 (rtx, rtx) asm("_emit_move_insn_1");



extern rtx push_block (rtx, int, int) asm("_push_block");


extern rtx gen_push_operand (void) asm("_gen_push_operand");
extern rtx force_operand (rtx, rtx) asm("_force_operand");
extern void init_pending_stack_adjust (void) asm("_init_pending_stack_adjust");



extern void clear_pending_stack_adjust (void) asm("_clear_pending_stack_adjust");


extern void do_pending_stack_adjust (void) asm("_do_pending_stack_adjust");
extern rtx compare_from_rtx (rtx, rtx, n64_enum_rtx_code, int, n64_enum_machine_mode, rtx, int) asm("_compare_from_rtx")
                                    ;


extern void do_tablejump (rtx, n64_enum_machine_mode, rtx, rtx, rtx) asm("_do_tablejump");
extern rtx promoted_input_arg (int, n64_enum_machine_mode *, int *) asm("_promoted_input_arg");




extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");



extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");


extern rtx memory_address_noforce (n64_enum_machine_mode, rtx) asm("_memory_address_noforce");





extern rtx change_address (rtx, n64_enum_machine_mode, rtx) asm("_change_address");




extern rtx validize_mem (rtx) asm("_validize_mem");


extern rtx assemble_trampoline_template (void) asm("_assemble_trampoline_template");


extern int rtx_equal_p (rtx, rtx) asm("_rtx_equal_p");



extern rtx stabilize (rtx) asm("_stabilize");



extern rtx copy_all_regs (rtx) asm("_copy_all_regs");


extern rtx copy_to_reg (rtx) asm("_copy_to_reg");


extern rtx copy_addr_to_reg (rtx) asm("_copy_addr_to_reg");


extern rtx copy_to_mode_reg (n64_enum_machine_mode, rtx) asm("_copy_to_mode_reg");


extern rtx copy_to_suggested_reg (rtx, rtx, n64_enum_machine_mode) asm("_copy_to_suggested_reg");



extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");


extern rtx force_not_mem (rtx) asm("_force_not_mem");
extern void adjust_stack (rtx) asm("_adjust_stack");


extern void anti_adjust_stack (rtx) asm("_anti_adjust_stack");


enum n64_cpp_enum_save_level{SAVE_BLOCK, SAVE_FUNCTION, SAVE_NONLOCAL};
typedef __underlying_type(enum n64_cpp_enum_save_level) n64_enum_save_level;



extern void emit_stack_save (n64_enum_save_level, rtx *, rtx) asm("_emit_stack_save");


extern void emit_stack_restore (n64_enum_save_level, rtx, rtx) asm("_emit_stack_restore");



extern rtx allocate_dynamic_stack_space (rtx, rtx, int) asm("_allocate_dynamic_stack_space");


extern rtx function_value(...) asm("_function_value");



extern rtx hard_libcall_value (n64_enum_machine_mode) asm("_hard_libcall_value");



extern rtx round_push (rtx) asm("_round_push");

extern void emit_block_move (rtx, rtx, rtx, int) asm("_emit_block_move");

extern rtx store_bit_field (rtx, int, int, n64_enum_machine_mode, rtx, int, int) asm("_store_bit_field");
extern rtx extract_bit_field (rtx, int, int, int, rtx, n64_enum_machine_mode, n64_enum_machine_mode, int, int) asm("_extract_bit_field");
extern rtx expand_mult (n64_enum_machine_mode, rtx, rtx, rtx, int) asm("_expand_mult");
extern rtx expand_mult_add (rtx, rtx, rtx, rtx,n64_enum_machine_mode, int) asm("_expand_mult_add");

extern rtx assemble_static_space (int) asm("_assemble_static_space");




extern rtx (*lang_expand_expr)(...);
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern rtx reload_in[(2 * 10 * (1 + 1))];
extern rtx reload_out[(2 * 10 * (1 + 1))];
extern rtx reload_in_reg[(2 * 10 * (1 + 1))];
extern n64_enum_reg_class reload_reg_class[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_inmode[(2 * 10 * (1 + 1))];
extern n64_enum_machine_mode reload_outmode[(2 * 10 * (1 + 1))];
extern char reload_optional[(2 * 10 * (1 + 1))];
extern int reload_inc[(2 * 10 * (1 + 1))];
extern int reload_opnum[(2 * 10 * (1 + 1))];
extern int reload_secondary_p[(2 * 10 * (1 + 1))];
extern int reload_secondary_in_reload[(2 * 10 * (1 + 1))];
extern int reload_secondary_out_reload[(2 * 10 * (1 + 1))];

extern n64_enum_insn_code reload_secondary_in_icode[(2 * 10 * (1 + 1))];
extern n64_enum_insn_code reload_secondary_out_icode[(2 * 10 * (1 + 1))];

extern int n_reloads;

extern rtx reload_reg_rtx[(2 * 10 * (1 + 1))];
enum n64_cpp_enum_reload_type{
  RELOAD_FOR_INPUT, RELOAD_FOR_OUTPUT, RELOAD_FOR_INSN,
  RELOAD_FOR_INPUT_ADDRESS, RELOAD_FOR_OUTPUT_ADDRESS,
  RELOAD_FOR_OPERAND_ADDRESS, RELOAD_FOR_OPADDR_ADDR,
  RELOAD_OTHER, RELOAD_FOR_OTHER_ADDRESS
};
typedef __underlying_type(enum n64_cpp_enum_reload_type) n64_enum_reload_type;


extern n64_enum_reload_type reload_when_needed[(2 * 10 * (1 + 1))];

extern rtx *reg_equiv_constant;
extern rtx *reg_equiv_memory_loc;
extern rtx *reg_equiv_address;
extern rtx *reg_equiv_mem;



extern int n_earlyclobbers;
extern rtx reload_earlyclobbers[10];


extern int reload_n_operands;



extern int reload_first_uid;





extern char indirect_symref_ok;


extern char double_reg_address_ok;





extern n64_enum_insn_code reload_in_optab[];
extern n64_enum_insn_code reload_out_optab[];







extern rtx get_secondary_mem (rtx, n64_enum_machine_mode, int, n64_enum_reload_type) asm("_get_secondary_mem")
                               ;


extern void clear_secondary_mem (void) asm("_clear_secondary_mem");



extern void transfer_replacements (int, int) asm("_transfer_replacements");




extern int strict_memory_address_p (n64_enum_machine_mode, rtx) asm("_strict_memory_address_p");




extern int operands_match_p (rtx, rtx) asm("_operands_match_p");


extern int n_occurrences (int, char *) asm("_n_occurrences");


extern int safe_from_earlyclobber (rtx, rtx) asm("_safe_from_earlyclobber");




extern void find_reloads (rtx, int, int, int, short *) asm("_find_reloads");





extern rtx form_sum (rtx, rtx) asm("_form_sum");



extern void subst_reloads (void) asm("_subst_reloads");




extern void copy_replacements (rtx, rtx) asm("_copy_replacements");



extern rtx find_replacement (rtx *) asm("_find_replacement");




extern int refers_to_regno_for_reload_p (int, int, rtx, rtx *) asm("_refers_to_regno_for_reload_p");


extern int reg_overlap_mentioned_for_reload_p (rtx, rtx) asm("_reg_overlap_mentioned_for_reload_p");



extern int refers_to_mem_for_reload_p (rtx) asm("_refers_to_mem_for_reload_p");



extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg")
                             ;


extern int regno_clobbered_p (int, rtx) asm("_regno_clobbered_p");





extern void init_reload (void) asm("_init_reload");


extern int reload (rtx, int, FILE *) asm("_reload");



extern void mark_home_live (int) asm("_mark_home_live");



extern rtx eliminate_regs (rtx, n64_enum_machine_mode, rtx) asm("_eliminate_regs");




extern rtx gen_reload (rtx, rtx, int, n64_enum_reload_type) asm("_gen_reload");




extern void init_caller_save (void) asm("_init_caller_save");


extern void init_save_areas (void) asm("_init_save_areas");


extern int setup_save_areas (int *) asm("_setup_save_areas");


extern void save_call_clobbered_regs (n64_enum_machine_mode) asm("_save_call_clobbered_regs");
extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
typedef unsigned int *regset;




extern int regset_bytes;
extern int regset_size;



extern int n_basic_blocks;



extern rtx *basic_block_head;



extern rtx *basic_block_end;




extern regset *basic_block_live_at_start;
extern int *reg_basic_block;
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");
extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");
extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
static rtx *reg_last_reload_reg;



static char *reg_has_output_reload;



static HARD_REG_SET reg_is_output_reload;





rtx *reg_equiv_constant;





rtx *reg_equiv_memory_loc;




rtx *reg_equiv_address;



rtx *reg_equiv_mem;


static int *reg_max_ref_width;



static rtx *reg_equiv_init;






static int reg_reloaded_contents[68];





static rtx reg_reloaded_insn[68];


static int n_spills;





static rtx spill_reg_rtx[68];




static rtx spill_reg_store[68];





static short spill_reg_order[68];




HARD_REG_SET forbidden_regs;
static HARD_REG_SET bad_spill_regs;




static short spill_regs[68];




static int last_spill_reg;






static short potential_reload_regs[68];




static char regs_explicitly_used[68];



static HARD_REG_SET counted_for_groups;





static HARD_REG_SET counted_for_nongroups;





static char *cannot_omit_stores;
static char spill_indirect_levels;





char indirect_symref_ok;



char double_reg_address_ok;



static rtx spill_stack_slot[68];



static int spill_stack_slot_width[68];






char *basic_block_needs[(int) LIM_REG_CLASSES];



int reload_first_uid;




int caller_save_needed;




int reload_in_progress = 0;





n64_enum_insn_code reload_in_optab[(int) MAX_MACHINE_MODE];
n64_enum_insn_code reload_out_optab[(int) MAX_MACHINE_MODE];





struct n64_tag_obstack reload_obstack;
char *reload_firstobj;





extern rtx forced_labels;






static struct n64_tag_elim_table
{
  int from;
  int to;
  int initial_offset;
  int can_eliminate;
  int can_eliminate_previous;

  int offset;
  int max_offset;
  int previous_offset;
  int ref_outside_mem;
  rtx from_rtx;




  rtx to_rtx;
} reg_eliminate[] =






  {{ 0, (0 + 29)}, { 0, (0 + 30)}, { (0 + 30), (0 + 29)}};
static int num_not_at_initial_offset;


static int num_eliminable;
static char *offsets_known_at;
static int (*offsets_at)[(sizeof reg_eliminate / sizeof reg_eliminate[0])];



static int num_labels;

struct n64_tag_hard_reg_n_uses { int regno; int uses; };

static int possible_group_p (int, int *) asm("_possible_group_p");
static void count_possible_groups (int *, n64_enum_machine_mode *, int *, int) asm("_count_possible_groups")
                        ;
static int modes_equiv_for_class_p (n64_enum_machine_mode, n64_enum_machine_mode, n64_enum_reg_class) asm("_modes_equiv_for_class_p")

                            ;
static void spill_failure (rtx) asm("_spill_failure");
static int new_spill_reg (int, int, int *, int *, int, FILE *) asm("_new_spill_reg")
                    ;
static void delete_dead_insn (rtx) asm("_delete_dead_insn");
static void alter_reg (int, int) asm("_alter_reg");
static void mark_scratch_live (rtx) asm("_mark_scratch_live");
static void set_label_offsets (rtx, rtx, int) asm("_set_label_offsets");
static int eliminate_regs_in_insn (rtx, int) asm("_eliminate_regs_in_insn");
static void mark_not_eliminable (rtx, rtx) asm("_mark_not_eliminable");
static int spill_hard_reg (int, int, FILE *, int) asm("_spill_hard_reg");
static void scan_paradoxical_subregs (rtx) asm("_scan_paradoxical_subregs");
static int hard_reg_use_compare (struct n64_tag_hard_reg_n_uses *, struct n64_tag_hard_reg_n_uses *) asm("_hard_reg_use_compare")
                                      ;
static void order_regs_for_reload (void) asm("_order_regs_for_reload");
static int compare_spill_regs (short *, short *) asm("_compare_spill_regs");
static void reload_as_needed (rtx, int) asm("_reload_as_needed");
static void forget_old_reloads_1 (rtx, rtx) asm("_forget_old_reloads_1");
static int reload_reg_class_lower (short *, short *) asm("_reload_reg_class_lower");
static void mark_reload_reg_in_use (int, int, n64_enum_reload_type, n64_enum_machine_mode) asm("_mark_reload_reg_in_use")
                               ;
static void clear_reload_reg_in_use (int, int, n64_enum_reload_type, n64_enum_machine_mode) asm("_clear_reload_reg_in_use")
                               ;
static int reload_reg_free_p (int, int, n64_enum_reload_type) asm("_reload_reg_free_p");
static int reload_reg_free_before_p (int, int, n64_enum_reload_type) asm("_reload_reg_free_before_p");
static int reload_reg_reaches_end_p (int, int, n64_enum_reload_type) asm("_reload_reg_reaches_end_p");
static int reloads_conflict (int, int) asm("_reloads_conflict");
static int allocate_reload_reg (int, rtx, int, int) asm("_allocate_reload_reg");
static void choose_reload_regs (rtx, rtx) asm("_choose_reload_regs");
static void merge_assigned_reloads (rtx) asm("_merge_assigned_reloads");
static void emit_reload_insns (rtx) asm("_emit_reload_insns");
static void delete_output_reload (rtx, int, rtx) asm("_delete_output_reload");
static void inc_for_reload (rtx, rtx, int) asm("_inc_for_reload");
static int constraint_accepts_reg_p (char *, rtx) asm("_constraint_accepts_reg_p");
static int count_occurrences (rtx, rtx) asm("_count_occurrences");



void
init_reload(void) asm("_init_reload");
void
init_reload(void)
{
  register int i;





  register rtx tem
    = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode),
        gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode),
   gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (((68)) + 3) + 1),
   gen_rtx (CONST_INT, VOIDmode, (int) (4))));
  spill_indirect_levels = 0;

  while (memory_address_p (QImode, tem))
    {
      spill_indirect_levels++;
      tem = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), tem);
    }



  tem = gen_rtx (MEM, ((target_flags & 0x00000002) ? DImode : SImode), gen_rtx (SYMBOL_REF, ((target_flags & 0x00000002) ? DImode : SImode), "foo"));
  indirect_symref_ok = memory_address_p (QImode, tem);



  for (i = 0; i < 68; i++)
    {
      tem = gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode),
       gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), (0 + 30)),
       gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), i));

      tem = plus_constant_wide (tem, (int) (4));

      if (memory_address_p (QImode, tem))
 {
   double_reg_address_ok = 1;
   break;
 }
    }


  gcc_obstack_init (&reload_obstack);
  reload_firstobj = (char *) __extension__ ({ struct n64_tag_obstack *__h = (&reload_obstack); __extension__ ({ struct n64_tag_obstack *__o = (__h); int __len = ((0)); if (__o->chunk_limit - __o->next_free < __len) _obstack_newchunk (__o, __len); if (!__o->alloc_failed) __o->next_free += __len; (void) 0; }); __extension__ ({ struct n64_tag_obstack *__o1 = (__h); void *value; if (__o1->alloc_failed) value = 0; else { value = (void *) __o1->object_base; if (__o1->next_free == value) __o1->maybe_empty_object = 1; __o1->next_free = (((((__o1->next_free) - (char *)0)+__o1->alignment_mask) & ~ (__o1->alignment_mask)) + (char *)0); if (__o1->next_free - (char *)__o1->chunk > __o1->chunk_limit - (char *)__o1->chunk) __o1->next_free = __o1->chunk_limit; __o1->object_base = __o1->next_free; } value; }); });
}
int
reload(rtx first, int global, FILE *dumpfile) asm("_reload");
int
reload(rtx first, int global, FILE *dumpfile)
{
  register int cxx_class;
  register int i, j, k;
  register rtx insn;
  register struct n64_tag_elim_table *ep;

  int something_changed;
  int something_needs_reloads;
  int something_needs_elimination;
  int new_basic_block_needs;
  n64_enum_reg_class caller_save_spill_class = NO_REGS;
  int caller_save_group_size = 1;


  int failure = 0;


  int this_block;


  init_recog ();


  reload_first_uid = get_max_uid ();

  for (i = 0; i < (int) LIM_REG_CLASSES; i++)
    basic_block_needs[i] = 0;



  clear_secondary_mem ();





  memcpy (regs_explicitly_used,regs_ever_live,sizeof regs_ever_live);


  memset ((char *) spill_stack_slot,0,sizeof spill_stack_slot);
  memset ((char *) spill_stack_slot_width,0,sizeof spill_stack_slot_width);



  init_save_areas ();






  for (i = 68; i < max_regno; i++)
    mark_home_live (i);

  for (i = 0; i < scratch_list_length; i++)
    if (scratch_list[i])
      mark_scratch_live (scratch_list[i]);



  emit_note (((void *)0), -1);
  reg_equiv_constant = (rtx *) 
                              __builtin_alloca((
                              max_regno * sizeof (rtx)
                              ))
                                                               ;
  memset ((char *) reg_equiv_constant,0,max_regno * sizeof (rtx));
  reg_equiv_memory_loc = (rtx *) 
                                __builtin_alloca((
                                max_regno * sizeof (rtx)
                                ))
                                                                 ;
  memset ((char *) reg_equiv_memory_loc,0,max_regno * sizeof (rtx));
  reg_equiv_mem = (rtx *) 
                         __builtin_alloca((
                         max_regno * sizeof (rtx)
                         ))
                                                          ;
  memset ((char *) reg_equiv_mem,0,max_regno * sizeof (rtx));
  reg_equiv_init = (rtx *) 
                          __builtin_alloca((
                          max_regno * sizeof (rtx)
                          ))
                                                           ;
  memset ((char *) reg_equiv_init,0,max_regno * sizeof (rtx));
  reg_equiv_address = (rtx *) 
                             __builtin_alloca((
                             max_regno * sizeof (rtx)
                             ))
                                                              ;
  memset ((char *) reg_equiv_address,0,max_regno * sizeof (rtx));
  reg_max_ref_width = (int *) 
                             __builtin_alloca((
                             max_regno * sizeof (int)
                             ))
                                                              ;
  memset ((char *) reg_max_ref_width,0,max_regno * sizeof (int));
  cannot_omit_stores = (char *) 
                               __builtin_alloca((
                               max_regno
                               ))
                                                 ;
  memset (cannot_omit_stores,0,max_regno);
  for (insn = first; insn; insn = ((insn)->fld[2].rtx))
    {
      rtx set = single_set (insn);

      if (set != 0 && ((((set)->fld[0].rtx))->code) == REG)
 {
   rtx note = find_reg_note (insn, REG_EQUIV, (rtx) 0);
   if (note

       && (! (((((note)->fld[0].rtx))->code) == LABEL_REF || ((((note)->fld[0].rtx))->code) == SYMBOL_REF || ((((note)->fld[0].rtx))->code) == CONST_INT || ((((note)->fld[0].rtx))->code) == CONST_DOUBLE || ((((note)->fld[0].rtx))->code) == CONST || ((((note)->fld[0].rtx))->code) == HIGH) || ! flag_pic
    || (! pic_address_needs_scratch (((note)->fld[0].rtx))))

       )
     {
       rtx x = ((note)->fld[0].rtx);
       i = ((((set)->fld[0].rtx))->fld[0].rtint);
       if (i > (((68)) + 3))
  {
    if (((x)->code) == MEM)
      reg_equiv_memory_loc[i] = x;
    else if ((((x)->code) == LABEL_REF || ((x)->code) == SYMBOL_REF || ((x)->code) == CONST_INT || ((x)->code) == CONST_DOUBLE || ((x)->code) == CONST || ((x)->code) == HIGH))
      {
        if (((((x)->code) != CONST_DOUBLE || mips_const_double_ok (x, ((x)->mode))) && ! (((x)->code) == CONST && 0)))
   reg_equiv_constant[i] = x;
        else
   reg_equiv_memory_loc[i]
     = force_const_mem (((((set)->fld[0].rtx))->mode), x);
      }
    else
      continue;





    if (((x)->code) != MEM
        || rtx_equal_p (((set)->fld[1].rtx), x))
      reg_equiv_init[i] = insn;
  }
     }
 }



      else if (set && ((((set)->fld[0].rtx))->code) == MEM
        && ((((set)->fld[1].rtx))->code) == REG
        && reg_equiv_memory_loc[((((set)->fld[1].rtx))->fld[0].rtint)]
        && rtx_equal_p (((set)->fld[0].rtx),
          reg_equiv_memory_loc[((((set)->fld[1].rtx))->fld[0].rtint)]))
 reg_equiv_init[((((set)->fld[1].rtx))->fld[0].rtint)] = insn;

      if ((rtx_class[(int)(((insn)->code))]) == 'i')
 scan_paradoxical_subregs (((insn)->fld[3].rtx));
    }



  frame_pointer_needed = (! flag_omit_frame_pointer






     || (current_function_calls_alloca
         && 1)

     || (current_function_calls_alloca));

  num_eliminable = 0;




  for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
    {
      ep->can_eliminate = ep->can_eliminate_previous
 = ((!frame_pointer_needed || ((ep->from) == 0 && (ep->to) == (0 + 30)))
    && ! (ep->to == (0 + 29) && frame_pointer_needed));
    }
  for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
    {
      num_eliminable += ep->can_eliminate;
      ep->from_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), ep->from);
      ep->to_rtx = gen_rtx (REG, ((target_flags & 0x00000002) ? DImode : SImode), ep->to);
    }

  num_labels = max_label_num () - get_first_label_num ();


  offsets_known_at = (char *) 
                             __builtin_alloca((
                             num_labels
                             ))
                                                ;
  offsets_at
    = (int (*)[(sizeof reg_eliminate / sizeof reg_eliminate[0])])
      
     __builtin_alloca((
     num_labels * (sizeof reg_eliminate / sizeof reg_eliminate[0]) * sizeof (int)
     ))
                                                             ;

  offsets_known_at -= get_first_label_num ();
  offsets_at -= get_first_label_num ();





  for (i = (((68)) + 3) + 1; i < max_regno; i++)
    alter_reg (i, -1);




  assign_stack_local (BLKmode, 0, 0);







  for (insn = first; insn && num_eliminable; insn = ((insn)->fld[2].rtx))
    if (((insn)->code) == INSN || ((insn)->code) == JUMP_INSN
 || ((insn)->code) == CALL_INSN)
      note_stores (((insn)->fld[3].rtx), mark_not_eliminable);
  order_regs_for_reload ();


  n_spills = 0;
  for (i = 0; i < 68; i++)
    spill_reg_order[i] = -1;


  last_spill_reg = -1;






  do { register HARD_REG_ELT_TYPE *scan_tp_ = (forbidden_regs), *scan_fp_ = (bad_spill_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);



  for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
    if (! ep->can_eliminate)
      spill_hard_reg (ep->from, global, dumpfile, 1);






  if (global)
    for (i = 0; i < (int) LIM_REG_CLASSES; i++)
      {
 basic_block_needs[i] = (char *) 
                                __builtin_alloca((
                                n_basic_blocks
                                ))
                                                       ;
 memset (basic_block_needs[i],0,n_basic_blocks);
      }


  reload_in_progress = 1;
  something_changed = 1;

  something_needs_reloads = 0;


  something_needs_elimination = 0;
  while (something_changed)
    {
      rtx after_call = 0;




      int max_needs[(int) LIM_REG_CLASSES];


      int group_size[(int) LIM_REG_CLASSES];


      int max_groups[(int) LIM_REG_CLASSES];


      int max_nongroups[(int) LIM_REG_CLASSES];





      n64_enum_machine_mode group_mode[(int) LIM_REG_CLASSES];

      rtx max_needs_insn[(int) LIM_REG_CLASSES];
      rtx max_groups_insn[(int) LIM_REG_CLASSES];
      rtx max_nongroups_insn[(int) LIM_REG_CLASSES];
      rtx x;
      int starting_frame_size = get_frame_size ();
      int previous_frame_pointer_needed = frame_pointer_needed;
      static char *reg_class_names[] = { "NO_REGS", "GR_REGS", "FP_REGS", "HI_REG", "LO_REG", "HILO_REG", "MD_REGS", "ST_REGS", "ALL_REGS" };

      something_changed = 0;
      memset ((char *) max_needs,0,sizeof max_needs);
      memset ((char *) max_groups,0,sizeof max_groups);
      memset ((char *) max_nongroups,0,sizeof max_nongroups);
      memset ((char *) max_needs_insn,0,sizeof max_needs_insn);
      memset ((char *) max_groups_insn,0,sizeof max_groups_insn);
      memset ((char *) max_nongroups_insn,0,sizeof max_nongroups_insn);
      memset ((char *) group_size,0,sizeof group_size);
      for (i = 0; i < (int) LIM_REG_CLASSES; i++)
 group_mode[i] = VOIDmode;


      this_block = 0;



      new_basic_block_needs = 0;



      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 {
   { compute_frame_size (get_frame_size ()); if ((ep->from) == (0 + 30) && (ep->to) == (0 + 29)) (ep->initial_offset) = 0; else if ((ep->from) == 0 && ((ep->to) == (0 + 30) || (ep->to) == (0 + 29))) (ep->initial_offset) = (current_frame_info.total_size - (0 && mips_isa >= 3 ? current_function_pretend_args_size : 0)); else abort (); };
   ep->previous_offset = ep->offset
     = ep->max_offset = ep->initial_offset;
 }
      num_not_at_initial_offset = 0;

      memset ((char *) &offsets_known_at[get_first_label_num ()],0,num_labels);






      for (x = forced_labels; x; x = ((x)->fld[1].rtx))
 if (((x)->fld[0].rtx))
   set_label_offsets (((x)->fld[0].rtx), (rtx) 0, 1);
      for (i = 68; i < max_regno; i++)
 if (reg_renumber[i] < 0 && reg_equiv_memory_loc[i])
   {
     rtx x = eliminate_regs (reg_equiv_memory_loc[i], 0, (rtx) 0);

     if (strict_memory_address_p (((regno_reg_rtx[i])->mode),
      ((x)->fld[0].rtx)))
       reg_equiv_mem[i] = x, reg_equiv_address[i] = 0;
     else if ((((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH)
       || (((((x)->fld[0].rtx))->code) == REG
    && ((((x)->fld[0].rtx))->fld[0].rtint) < 68)
       || (((((x)->fld[0].rtx))->code) == PLUS
    && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
    && (((((((x)->fld[0].rtx))->fld[0].rtx))->fld[0].rtint)
        < 68)
    && (((((((x)->fld[0].rtx))->fld[1].rtx))->code) == LABEL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == SYMBOL_REF || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST_DOUBLE || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == CONST || ((((((x)->fld[0].rtx))->fld[1].rtx))->code) == HIGH)))
       reg_equiv_address[i] = ((x)->fld[0].rtx), reg_equiv_mem[i] = 0;
     else
       {






  reg_equiv_memory_loc[i] = 0;
  reg_equiv_init[i] = 0;
  alter_reg (i, -1);
  something_changed = 1;
       }
   }



      if (something_changed)
 continue;




      if (caller_save_group_size > 1)
 {
   group_mode[(int) caller_save_spill_class] = ((target_flags & 0x00000002) ? DImode : SImode);
   group_size[(int) caller_save_spill_class] = caller_save_group_size;
 }




      for (insn = first; insn; insn = ((insn)->fld[2].rtx))
 {
   if (global && this_block + 1 < n_basic_blocks
       && insn == basic_block_head[this_block+1])
     ++this_block;





   if (((insn)->code) == CODE_LABEL || ((insn)->code) == JUMP_INSN
       || ((rtx_class[(int)(((insn)->code))]) == 'i'
    && ((insn)->fld[6].rtx) != 0))
     set_label_offsets (insn, insn, 0);

   if ((rtx_class[(int)(((insn)->code))]) == 'i')
     {


       rtx avoid_return_reg = 0;

       rtx old_body = ((insn)->fld[3].rtx);
       int old_code = ((insn)->fld[4].rtint);
        rtx old_notes = ((insn)->fld[6].rtx);
       int did_elimination = 0;
       struct n64_tag_needs
  {

    int regs[2][(int) LIM_REG_CLASSES];
    int groups[(int) LIM_REG_CLASSES];
  };


       struct {
  struct n64_tag_needs other;
  struct n64_tag_needs input;
  struct n64_tag_needs output;
  struct n64_tag_needs insn;
  struct n64_tag_needs other_addr;
  struct n64_tag_needs op_addr;
  struct n64_tag_needs op_addr_reload;
  struct n64_tag_needs in_addr[10];
  struct n64_tag_needs out_addr[10];
       } insn_needs;


       if (num_eliminable)
  did_elimination = eliminate_regs_in_insn (insn, 0);
       find_reloads (insn, 0, spill_indirect_levels, global,
       spill_reg_order);
       ((insn)->mode = ((did_elimination ? QImode : n_reloads ? HImode : ((insn)->mode) == DImode ? DImode : VOIDmode)))


                      ;


       if (did_elimination)
  {
    __extension__ ({ struct n64_tag_obstack *__o = (&reload_obstack); void *__obj = (reload_firstobj); if (__obj > (void *)__o->chunk && __obj < (void *)__o->chunk_limit) __o->next_free = __o->object_base = __obj; else (obstack_free) (__o, __obj); });
    ((insn)->fld[3].rtx) = old_body;
    ((insn)->fld[4].rtint) = old_code;
     ((insn)->fld[6].rtx) = old_notes;
    something_needs_elimination = 1;
  }





       if (n_reloads == 0
    && ! (((insn)->code) == CALL_INSN
   && caller_save_spill_class != NO_REGS))
  continue;

       something_needs_reloads = 1;
       memset ((char *) &insn_needs,0,sizeof insn_needs);




       for (i = 0; i < n_reloads; i++)
  {
    register n64_enum_reg_class *p;
    n64_enum_reg_class cxx_class = reload_reg_class[i];
    int size;
    n64_enum_machine_mode mode;
    int nongroup_need;
    struct n64_tag_needs *this_needs;





    if (reload_reg_rtx[i] != 0
        || reload_optional[i] != 0
        || (reload_out[i] == 0 && reload_in[i] == 0
     && ! reload_secondary_p[i]))
        continue;





    if (global && ! basic_block_needs[(int) cxx_class][this_block])
      {
        basic_block_needs[(int) cxx_class][this_block] = 1;
        new_basic_block_needs = 1;
      }


    mode = reload_inmode[i];
    if ((mode_size[(int)(reload_outmode[i])]) > (mode_size[(int)(mode)]))
      mode = reload_outmode[i];
    size = ((cxx_class) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(mode)]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(mode)]) + (8) - 1) / (8))) : (((mode_size[(int)(mode)]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))));






    nongroup_need = 0;
    if (size == 1)
      for (j = 0; j < n_reloads; j++)
        if ((((reload_reg_class[j]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (8) - 1) / (8))) : (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))




      > 1)
     && (!reload_optional[j])
     && (reload_in[j] != 0 || reload_out[j] != 0
         || reload_secondary_p[j])
     && reloads_conflict (i, j)
     && reg_classes_intersect_p (cxx_class,
            reload_reg_class[j]))
   {
     nongroup_need = 1;
     break;
   }


    switch (reload_when_needed[i])
      {
      case RELOAD_OTHER:
        this_needs = &insn_needs.other;
        break;
      case RELOAD_FOR_INPUT:
        this_needs = &insn_needs.input;
        break;
      case RELOAD_FOR_OUTPUT:
        this_needs = &insn_needs.output;
        break;
      case RELOAD_FOR_INSN:
        this_needs = &insn_needs.insn;
        break;
      case RELOAD_FOR_OTHER_ADDRESS:
        this_needs = &insn_needs.other_addr;
        break;
      case RELOAD_FOR_INPUT_ADDRESS:
        this_needs = &insn_needs.in_addr[reload_opnum[i]];
        break;
      case RELOAD_FOR_OUTPUT_ADDRESS:
        this_needs = &insn_needs.out_addr[reload_opnum[i]];
        break;
      case RELOAD_FOR_OPERAND_ADDRESS:
        this_needs = &insn_needs.op_addr;
        break;
      case RELOAD_FOR_OPADDR_ADDR:
        this_needs = &insn_needs.op_addr_reload;
        break;
      }

    if (size > 1)
      {
        n64_enum_machine_mode other_mode, allocate_mode;



        this_needs->groups[(int) cxx_class]++;
        p = reg_class_superclasses[(int) cxx_class];
        while (*p != LIM_REG_CLASSES)
   this_needs->groups[(int) *p++]++;




        if (group_size[(int) cxx_class] < size)
   {
     other_mode = group_mode[(int) cxx_class];
     allocate_mode = mode;

     group_size[(int) cxx_class] = size;
     group_mode[(int) cxx_class] = mode;
   }
        else
   {
     other_mode = mode;
     allocate_mode = group_mode[(int) cxx_class];
   }




        if (other_mode != VOIDmode && other_mode != allocate_mode
     && ! modes_equiv_for_class_p (allocate_mode,
       other_mode, cxx_class))
   fatal_insn ("Two dissimilar machine modes both need groups of consecutive regs of the same class",
        insn);
      }
    else if (size == 1)
      {
        this_needs->regs[nongroup_need][(int) cxx_class] += 1;
        p = reg_class_superclasses[(int) cxx_class];
        while (*p != LIM_REG_CLASSES)
   this_needs->regs[nongroup_need][(int) *p++] += 1;
      }
    else
      abort ();
  }






       for (i = 0; i < (int) LIM_REG_CLASSES; i++)
  {
    int in_max, out_max;


    for (j = 0; j <= 1; j++)
      {
        for (in_max = 0, out_max = 0, k = 0;
      k < reload_n_operands; k++)
   {
     in_max
       = ((in_max) > (insn_needs.in_addr[k].regs[j][i]) ? (in_max) : (insn_needs.in_addr[k].regs[j][i]));
     out_max
       = ((out_max) > (insn_needs.out_addr[k].regs[j][i]) ? (out_max) : (insn_needs.out_addr[k].regs[j][i]));
   }







        in_max = ((((insn_needs.op_addr.regs[j][i]) > (insn_needs.op_addr_reload.regs[j][i]) ? (insn_needs.op_addr.regs[j][i]) : (insn_needs.op_addr_reload.regs[j][i]))) > (in_max) ? (((insn_needs.op_addr.regs[j][i]) > (insn_needs.op_addr_reload.regs[j][i]) ? (insn_needs.op_addr.regs[j][i]) : (insn_needs.op_addr_reload.regs[j][i]))) : (in_max))

               ;

        out_max = ((out_max) > (insn_needs.insn.regs[j][i]) ? (out_max) : (insn_needs.insn.regs[j][i]));

        insn_needs.input.regs[j][i]
   = ((insn_needs.input.regs[j][i] + insn_needs.op_addr.regs[j][i] + insn_needs.insn.regs[j][i]) > (in_max + insn_needs.input.regs[j][i]) ? (insn_needs.input.regs[j][i] + insn_needs.op_addr.regs[j][i] + insn_needs.insn.regs[j][i]) : (in_max + insn_needs.input.regs[j][i]))


                                               ;

        insn_needs.output.regs[j][i] += out_max;
        insn_needs.other.regs[j][i]
   += ((((insn_needs.input.regs[j][i]) > (insn_needs.output.regs[j][i]) ? (insn_needs.input.regs[j][i]) : (insn_needs.output.regs[j][i]))) > (insn_needs.other_addr.regs[j][i]) ? (((insn_needs.input.regs[j][i]) > (insn_needs.output.regs[j][i]) ? (insn_needs.input.regs[j][i]) : (insn_needs.output.regs[j][i]))) : (insn_needs.other_addr.regs[j][i]))

                                     ;

      }


    for (in_max = 0, out_max = 0, j = 0;
         j < reload_n_operands; j++)
      {
        in_max = ((in_max) > (insn_needs.in_addr[j].groups[i]) ? (in_max) : (insn_needs.in_addr[j].groups[i]));
        out_max
   = ((out_max) > (insn_needs.out_addr[j].groups[i]) ? (out_max) : (insn_needs.out_addr[j].groups[i]));
      }

    in_max = ((((insn_needs.op_addr.groups[i]) > (insn_needs.op_addr_reload.groups[i]) ? (insn_needs.op_addr.groups[i]) : (insn_needs.op_addr_reload.groups[i]))) > (in_max) ? (((insn_needs.op_addr.groups[i]) > (insn_needs.op_addr_reload.groups[i]) ? (insn_needs.op_addr.groups[i]) : (insn_needs.op_addr_reload.groups[i]))) : (in_max))

           ;
    out_max = ((out_max) > (insn_needs.insn.groups[i]) ? (out_max) : (insn_needs.insn.groups[i]));

    insn_needs.input.groups[i]
      = ((insn_needs.input.groups[i] + insn_needs.op_addr.groups[i] + insn_needs.insn.groups[i]) > (in_max + insn_needs.input.groups[i]) ? (insn_needs.input.groups[i] + insn_needs.op_addr.groups[i] + insn_needs.insn.groups[i]) : (in_max + insn_needs.input.groups[i]))


                                          ;

    insn_needs.output.groups[i] += out_max;
    insn_needs.other.groups[i]
      += ((((insn_needs.input.groups[i]) > (insn_needs.output.groups[i]) ? (insn_needs.input.groups[i]) : (insn_needs.output.groups[i]))) > (insn_needs.other_addr.groups[i]) ? (((insn_needs.input.groups[i]) > (insn_needs.output.groups[i]) ? (insn_needs.input.groups[i]) : (insn_needs.output.groups[i]))) : (insn_needs.other_addr.groups[i]))

                                       ;
  }
       if (((insn)->code) == CALL_INSN
    && caller_save_spill_class != NO_REGS)
  {


    int nongroup_need = 0;
    int *caller_save_needs;

    for (j = 0; j < n_reloads; j++)
      if ((((reload_reg_class[j]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (8) - 1) / (8))) : (((mode_size[(int)(((mode_size[(int)(reload_outmode[j])]) > (mode_size[(int)(reload_inmode[j])])) ? reload_outmode[j] : reload_inmode[j])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))))




    > 1)
   && reg_classes_intersect_p (caller_save_spill_class,
          reload_reg_class[j]))
        {
   nongroup_need = 1;
   break;
        }

    caller_save_needs
      = (caller_save_group_size > 1
         ? insn_needs.other.groups
         : insn_needs.other.regs[nongroup_need]);

    if (caller_save_needs[(int) caller_save_spill_class] == 0)
      {
        register n64_enum_reg_class *p
   = reg_class_superclasses[(int) caller_save_spill_class];

        caller_save_needs[(int) caller_save_spill_class]++;

        while (*p != LIM_REG_CLASSES)
   caller_save_needs[(int) *p++] += 1;
      }




    if (global
        && ! (basic_block_needs[(int) caller_save_spill_class]
       [this_block]))
      {
        basic_block_needs[(int) caller_save_spill_class]
   [this_block] = 1;
        new_basic_block_needs = 1;
      }
  }
       for (i = 0; i < (int) LIM_REG_CLASSES; i++)
  {
    if (max_needs[i] < insn_needs.other.regs[0][i])
      {
        max_needs[i] = insn_needs.other.regs[0][i];
        max_needs_insn[i] = insn;
      }
    if (max_groups[i] < insn_needs.other.groups[i])
      {
        max_groups[i] = insn_needs.other.groups[i];
        max_groups_insn[i] = insn;
      }
    if (max_nongroups[i] < insn_needs.other.regs[1][i])
      {
        max_nongroups[i] = insn_needs.other.regs[1][i];
        max_nongroups_insn[i] = insn;
      }
  }
     }

 }



      if (starting_frame_size != get_frame_size ())
 something_changed = 1;

      if (dumpfile)
 for (i = 0; i < (int) LIM_REG_CLASSES; i++)
   {
     if (max_needs[i] > 0)
       fprintf (dumpfile,
    ";; Need %d reg%s of class %s (for insn %d).\n",
         max_needs[i], max_needs[i] == 1 ? "" : "s",
         reg_class_names[i], ((max_needs_insn[i])->fld[0].rtint));
     if (max_nongroups[i] > 0)
       fprintf (dumpfile,
         ";; Need %d nongroup reg%s of class %s (for insn %d).\n",
         max_nongroups[i], max_nongroups[i] == 1 ? "" : "s",
         reg_class_names[i], ((max_nongroups_insn[i])->fld[0].rtint));
     if (max_groups[i] > 0)
       fprintf (dumpfile,
         ";; Need %d group%s (%smode) of class %s (for insn %d).\n",
         max_groups[i], max_groups[i] == 1 ? "" : "s",
         mode_name[(int) group_mode[i]],
         reg_class_names[i], ((max_groups_insn[i])->fld[0].rtint));
   }




      if (caller_save_needed
   && ! setup_save_areas (&something_changed)
   && caller_save_spill_class == NO_REGS)
 {




   caller_save_spill_class
     = double_reg_address_ok ? NO_REGS : GR_REGS;
   caller_save_group_size
     = ((caller_save_spill_class) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]) + (8) - 1) / (8))) : (((mode_size[(int)(((target_flags & 0x00000002) ? DImode : SImode))]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))));
   something_changed = 1;
 }







      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 if ((ep->from == (0 + 30) && (current_function_calls_alloca))

     || ! (!frame_pointer_needed || ((ep->from) == 0 && (ep->to) == (0 + 30)))

     )
   ep->can_eliminate = 0;
      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 {
   struct n64_tag_elim_table *op;
   register int new_to = -1;

   if (! ep->can_eliminate && ep->can_eliminate_previous)
     {


       for (op = reg_eliminate;
     op < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; op++)
  if (op->from == ep->from && op->can_eliminate)
    {
      new_to = op->to;
      break;
    }



       for (op = reg_eliminate;
     op < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; op++)
  if (op->from == new_to && op->to == ep->to)
    op->can_eliminate = 0;
     }
 }







      frame_pointer_needed = 1;
      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 {
   if (ep->can_eliminate && ep->from == (0 + 30)
       && ep->to != (0 + 30))
     frame_pointer_needed = 0;

   if (! ep->can_eliminate && ep->can_eliminate_previous)
     {
       ep->can_eliminate_previous = 0;
       spill_hard_reg (ep->from, global, dumpfile, 1);
       something_changed = 1;
       num_eliminable--;
     }
 }
      for (i = 0; i < (int) LIM_REG_CLASSES; i++)
 if (max_needs[i] > 0 || max_groups[i] > 0 || max_nongroups[i] > 0)
   break;
      if (i == (int) LIM_REG_CLASSES && !new_basic_block_needs && ! something_changed)
 break;
      if (n_spills)
 {
   for (i = j = 68 - 1; i >= 0; i--)
     if (potential_reload_regs[i] != -1)
       potential_reload_regs[j--] = potential_reload_regs[i];

   for (i = 0; i < n_spills; i++)
     {
       potential_reload_regs[i] = spill_regs[i];
       spill_reg_order[spill_regs[i]] = -1;
       ((forbidden_regs)[(spill_regs[i]) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))));
     }

   n_spills = 0;
 }
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (counted_for_groups); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (counted_for_nongroups); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

      for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
 {



   while (max_groups[cxx_class] > 0)
     {



       count_possible_groups (group_size, group_mode, max_groups,
         cxx_class);

       if (max_groups[cxx_class] <= 0)
  break;



       if (group_size[cxx_class] == 2)
  {

    for (i = 0; i < 68; i++)
      {
        int other;

        j = potential_reload_regs[i];
        if (j >= 0 && ! ((bad_spill_regs)[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
     &&
     ((j > 0 && (other = j - 1, spill_reg_order[other] >= 0)
       && ((reg_class_contents[cxx_class])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
       && ((reg_class_contents[cxx_class])[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(group_mode[cxx_class]) ][ (other) ]
       && ! ((counted_for_nongroups)[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32))))



       && ! ((counted_for_groups)[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32)))))
      ||
      (j < 68 - 1
       && (other = j + 1, spill_reg_order[other] >= 0)
       && ((reg_class_contents[cxx_class])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
       && ((reg_class_contents[cxx_class])[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(group_mode[cxx_class]) ][ (j) ]
       && ! ((counted_for_nongroups)[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32))))

       && ! ((counted_for_groups)[(other) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32))))
                )))
   {
     register n64_enum_reg_class *p;



     max_groups[cxx_class]--;
     p = reg_class_superclasses[cxx_class];
     while (*p != LIM_REG_CLASSES)
       {
         if (group_size [(int) *p] <= group_size [cxx_class])
    max_groups[(int) *p]--;
         p++;
       }


     ((counted_for_groups)[(j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32)));
     ((counted_for_groups)[(other) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((other) % ((unsigned) 32)));
     break;
   }
      }
    if (i == 68)
      for (i = 0; i < 68; i++)
        {
   int k;
   j = potential_reload_regs[i];

   for (k = 0; k < 68; k++)
     if (potential_reload_regs[k] == j + 1)
       break;
   if (j >= 0 && j + 1 < 68
       && k < 68
       && spill_reg_order[j] < 0 && spill_reg_order[j + 1] < 0
       && ((reg_class_contents[cxx_class])[(j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j) % ((unsigned) 32))))
       && ((reg_class_contents[cxx_class])[(j + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j + 1) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(group_mode[cxx_class]) ][ (j) ]
       && ! ((counted_for_nongroups)[(j + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j + 1) % ((unsigned) 32))))

       && ! ((bad_spill_regs)[(j + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j + 1) % ((unsigned) 32)))))
     break;
        }




    if (i >= 68)
      {

        spill_failure (max_groups_insn[cxx_class]);
        failure = 1;
        goto failed;
      }
    else
      something_changed
        |= new_spill_reg (i, cxx_class, max_needs, ((void *)0),
     global, dumpfile);
  }
       else
  {



    for (i = 0; i < 68; i++)
      {
        int k;

        j = potential_reload_regs[i];
        if (j >= 0
     && j + group_size[cxx_class] <= 68
     && mips_hard_regno_mode_ok[ (int)(group_mode[cxx_class]) ][ (j) ])
   {

     for (k = 0; k < group_size[cxx_class]; k++)
       if (! (spill_reg_order[j + k] < 0
       && ! ((bad_spill_regs)[(j + k) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j + k) % ((unsigned) 32))))
       && ((reg_class_contents[cxx_class])[(j + k) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((j + k) % ((unsigned) 32))))))
         break;

     if (k == group_size[cxx_class])
       {
         register n64_enum_reg_class *p;
         for (k = 0; k < group_size[cxx_class]; k++)
    {
      int idx;
      ((counted_for_groups)[(j + k) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((j + k) % ((unsigned) 32)));
      for (idx = 0; idx < 68; idx++)
        if (potential_reload_regs[idx] == j + k)
          break;
      something_changed
        |= new_spill_reg (idx, cxx_class,
            max_needs, ((void *)0),
            global, dumpfile);
    }



         max_groups[cxx_class]--;
         p = reg_class_superclasses[cxx_class];
         while (*p != LIM_REG_CLASSES)
    {
      if (group_size [(int) *p]
          <= group_size [cxx_class])
        max_groups[(int) *p]--;
      p++;
    }
         break;
       }
   }
      }


    if (i >= 68)
      {

        spill_failure (max_groups_insn[cxx_class]);
        failure = 1;
        goto failed;
      }
  }
     }



   while (max_needs[cxx_class] > 0 || max_nongroups[cxx_class] > 0)
     {
       for (i = 0; i < 68; i++)
  if (potential_reload_regs[i] >= 0
      && ((reg_class_contents[cxx_class])[(potential_reload_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((potential_reload_regs[i]) % ((unsigned) 32))))







      && (max_nongroups[cxx_class] == 0
   || possible_group_p (potential_reload_regs[i], max_groups)))
    break;







       if (i >= 68
    && (asm_noperands (max_needs[cxx_class] > 0
         ? max_needs_insn[cxx_class]
         : max_nongroups_insn[cxx_class])
        < 0))
  for (i = 0; i < 68; i++)
    if (potential_reload_regs[i] >= 0
        && ((reg_class_contents[cxx_class])[(potential_reload_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((potential_reload_regs[i]) % ((unsigned) 32))))
                                  )
      break;




       if (i >= 68)
  {

    spill_failure (max_needs[cxx_class] > 0 ? max_needs_insn[cxx_class]
     : max_nongroups_insn[cxx_class]);
    failure = 1;
    goto failed;
  }
       else
  something_changed
    |= new_spill_reg (i, cxx_class, max_needs, max_nongroups,
        global, dumpfile);
     }
 }
    }



  if (global)
    for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
      if (ep->can_eliminate)
 mark_elimination (ep->from, ep->to);





  if (caller_save_needed)
    save_call_clobbered_regs (num_eliminable ? QImode
         : caller_save_spill_class != NO_REGS ? HImode
         : VOIDmode);
  for (i = 68; i < max_regno; i++)
    if (reg_renumber[i] < 0 && reg_equiv_init[i] != 0
 && ((reg_equiv_init[i])->code) != NOTE)
      {
 if (reg_set_p (regno_reg_rtx[i], ((reg_equiv_init[i])->fld[3].rtx)))
   delete_dead_insn (reg_equiv_init[i]);
 else
   {
     ((reg_equiv_init[i])->code = (NOTE));
     ((reg_equiv_init[i])->fld[3].rtstr) = 0;
     ((reg_equiv_init[i])->fld[4].rtint) = -1;
   }
      }





  if (something_needs_reloads || something_needs_elimination
      || (caller_save_needed && num_eliminable)
      || caller_save_spill_class != NO_REGS)
    reload_as_needed (first, global);







  if (! frame_pointer_needed)
    for (i = 0; i < n_basic_blocks; i++)
      basic_block_live_at_start[i][(0 + 30) / 32]
 &= ~ ((unsigned int) 1 << ((0 + 30)
          % 32));



 failed:

  reload_in_progress = 0;
  for (i = 68; i < max_regno; i++)
    {
      rtx addr = 0;
      int in_struct = 0;
      if (reg_equiv_mem[i])
 {
   addr = ((reg_equiv_mem[i])->fld[0].rtx);
   in_struct = ((reg_equiv_mem[i])->in_struct);
 }
      if (reg_equiv_address[i])
 addr = reg_equiv_address[i];
      if (addr)
 {
   if (reg_renumber[i] < 0)
     {
       rtx reg = regno_reg_rtx[i];
       ((reg)->fld[0].rtx) = addr;
       ((reg)->volatil) = 0;
       ((reg)->in_struct) = in_struct;
       ((reg)->code = (MEM));
     }
   else if (reg_equiv_mem[i])
     ((reg_equiv_mem[i])->fld[0].rtx) = addr;
 }
    }
  reg_equiv_constant = 0;
  reg_equiv_memory_loc = 0;

  if (scratch_list)
    free (scratch_list);
  scratch_list = 0;
  if (scratch_block)
    free (scratch_block);
  scratch_block = 0;

  return failure;
}




static int
possible_group_p(int regno, int *max_groups) asm("_possible_group_p");
static int
possible_group_p(int regno, int *max_groups)
{
  int i;
  int cxx_class = (int) NO_REGS;

  for (i = 0; i < (int) (int) LIM_REG_CLASSES; i++)
    if (max_groups[i] > 0)
      {
 cxx_class = i;
 break;
      }

  if (cxx_class == (int) NO_REGS)
    return 1;


  for (i = 0; i < 68 - 1; i++)
    {

      if (i == regno || i + 1 == regno)
 continue;





      if (! (((reg_class_contents[cxx_class])[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
      && ((reg_class_contents[cxx_class])[(i + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + 1) % ((unsigned) 32))))))
 continue;


      if (spill_reg_order[i] < 0 && spill_reg_order[i + 1] < 0
   && ! ((bad_spill_regs)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
   && ! ((bad_spill_regs)[(i + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + 1) % ((unsigned) 32)))))
 return 1;



      if (spill_reg_order[i] < 0
   && ! ((bad_spill_regs)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
   && spill_reg_order[i + 1] >= 0
   && ! ((counted_for_groups)[(i + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + 1) % ((unsigned) 32))))
   && ! ((counted_for_nongroups)[(i + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + 1) % ((unsigned) 32)))))
 return 1;
      if (spill_reg_order[i + 1] < 0
   && ! ((bad_spill_regs)[(i + 1) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + 1) % ((unsigned) 32))))
   && spill_reg_order[i] >= 0
   && ! ((counted_for_groups)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
   && ! ((counted_for_nongroups)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)))))
 return 1;
    }

  return 0;
}




static void
count_possible_groups(int *group_size, n64_enum_machine_mode *group_mode, int *max_groups, int cxx_class) asm("_count_possible_groups");
static void
count_possible_groups(int *group_size, n64_enum_machine_mode *group_mode, int *max_groups, int cxx_class)
{
  HARD_REG_SET cxx_new;
  int i, j;





  if (group_size[cxx_class] == 0)
    return;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (cxx_new); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);


  for (i = 0; i < n_spills; i++)
    if (((reg_class_contents[cxx_class])[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))
 && ! ((counted_for_groups)[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))
 && ! ((counted_for_nongroups)[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32)))))
      ((cxx_new)[(spill_regs[i]) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32)));


  for (i = 0; i < 68 && max_groups[cxx_class] > 0; i++)
    if (((cxx_new)[(i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))))
 && i + group_size[cxx_class] <= 68
 && mips_hard_regno_mode_ok[ (int)(group_mode[cxx_class]) ][ (i) ])
      {
 for (j = 1; j < group_size[cxx_class]; j++)
   if (! ((cxx_new)[(i + j) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((i + j) % ((unsigned) 32)))))
     break;

 if (j == group_size[cxx_class])
   {


     register n64_enum_reg_class *p;

     max_groups[cxx_class]--;
     p = reg_class_superclasses[cxx_class];
     while (*p != LIM_REG_CLASSES)
       {
  if (group_size [(int) *p] <= group_size [cxx_class])
    max_groups[(int) *p]--;
  p++;
       }


     for (j = 0; j < group_size[cxx_class]; j++)
       ((counted_for_groups)[(i + j) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i + j) % ((unsigned) 32)));
   }



 i += j - 1;
      }
}
static int
modes_equiv_for_class_p(n64_enum_machine_mode allocate_mode, n64_enum_machine_mode other_mode, n64_enum_reg_class cxx_class) asm("_modes_equiv_for_class_p");
static int
modes_equiv_for_class_p(n64_enum_machine_mode allocate_mode, n64_enum_machine_mode other_mode, n64_enum_reg_class cxx_class)
{
  register int regno;
  for (regno = 0; regno < 68; regno++)
    {
      if (((reg_class_contents[(int) cxx_class])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
   && mips_hard_regno_mode_ok[ (int)(allocate_mode) ][ (regno) ]
   && ! mips_hard_regno_mode_ok[ (int)(other_mode) ][ (regno) ])
 return 0;
    }
  return 1;
}




static void
spill_failure(rtx insn) asm("_spill_failure");
static void
spill_failure(rtx insn)
{
  if (asm_noperands (((insn)->fld[3].rtx)) >= 0)
    error_for_asm (insn, "`asm' needs too many reloads");
  else
    fatal_insn ("Unable to find a register to spill.", insn);
}
static int
new_spill_reg(int i, int cxx_class, int *max_needs, int *max_nongroups, int global, FILE *dumpfile) asm("_new_spill_reg");
static int
new_spill_reg(int i, int cxx_class, int *max_needs, int *max_nongroups, int global, FILE *dumpfile)
{
  register n64_enum_reg_class *p;
  int val;
  int regno = potential_reload_regs[i];

  if (i >= 68)
    abort ();

  if (fixed_regs[regno] || ((forbidden_regs)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
    fatal ("fixed or forbidden register was spilled.\nThis may be due to a compiler bug or to impossible asm\nstatements or clauses.");





  potential_reload_regs[i] = -1;
  spill_regs[n_spills] = regno;
  spill_reg_order[regno] = n_spills;
  if (dumpfile)
    fprintf (dumpfile, "Spilling reg %d.\n", spill_regs[n_spills]);



  max_needs[cxx_class]--;
  p = reg_class_superclasses[cxx_class];
  while (*p != LIM_REG_CLASSES)
    max_needs[(int) *p++]--;

  if (max_nongroups && max_nongroups[cxx_class] > 0)
    {
      ((counted_for_nongroups)[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));
      max_nongroups[cxx_class]--;
      p = reg_class_superclasses[cxx_class];
      while (*p != LIM_REG_CLASSES)
 max_nongroups[(int) *p++]--;
    }




  val = spill_hard_reg (spill_regs[n_spills], global, dumpfile, 0);
  if (num_eliminable && ! regs_ever_live[spill_regs[n_spills]])
    val = 1;

  regs_ever_live[spill_regs[n_spills]] = 1;
  n_spills++;

  return val;
}




static void
delete_dead_insn(rtx insn) asm("_delete_dead_insn");
static void
delete_dead_insn(rtx insn)
{
  rtx prev = prev_real_insn (insn);
  rtx prev_dest;



  if (prev && ((((prev)->fld[3].rtx))->code) == SET
      && (prev_dest = ((((prev)->fld[3].rtx))->fld[0].rtx), ((prev_dest)->code) == REG)
      && reg_mentioned_p (prev_dest, ((insn)->fld[3].rtx))
      && find_regno_note (insn, REG_DEAD, ((prev_dest)->fld[0].rtint)))
    delete_dead_insn (prev);

  ((insn)->code = (NOTE));
  ((insn)->fld[4].rtint) = -1;
  ((insn)->fld[3].rtstr) = 0;
}
static void
alter_reg(register int i, int from_reg) asm("_alter_reg");
static void
alter_reg(register int i, int from_reg)
{


  if (regno_reg_rtx[i] == 0)
    return;



  if (((regno_reg_rtx[i])->code) != REG)
    return;



  ((regno_reg_rtx[i])->fld[0].rtint)
    = reg_renumber[i] >= 0 ? reg_renumber[i] : i;




  if (reg_renumber[i] < 0
      && reg_n_refs[i] > 0
      && reg_equiv_constant[i] == 0
      && reg_equiv_memory_loc[i] == 0)
    {
      register rtx x;
      int inherent_size = (mode_size[(int)(((regno_reg_rtx[i])->mode))]);
      int total_size = ((inherent_size) > (reg_max_ref_width[i]) ? (inherent_size) : (reg_max_ref_width[i]));
      int adjust = 0;
      if (from_reg == -1)
 {

   x = assign_stack_local (((regno_reg_rtx[i])->mode), total_size, -1);
   if (((target_flags & 0x00010000) != 0))




     adjust = inherent_size - total_size;

   ((x)->unchanging) = ((regno_reg_rtx[i])->unchanging);
 }

      else if (spill_stack_slot[from_reg] != 0
        && spill_stack_slot_width[from_reg] >= total_size
        && ((mode_size[(int)(((spill_stack_slot[from_reg])->mode))])
     >= inherent_size))
 x = spill_stack_slot[from_reg];

      else
 {


   n64_enum_machine_mode mode = ((regno_reg_rtx[i])->mode);
   rtx stack_slot;
   if (spill_stack_slot[from_reg])
     {
       if ((mode_size[(int)(((spill_stack_slot[from_reg])->mode))])
    > inherent_size)
  mode = ((spill_stack_slot[from_reg])->mode);
       if (spill_stack_slot_width[from_reg] > total_size)
  total_size = spill_stack_slot_width[from_reg];
     }

   x = assign_stack_local (mode, total_size, -1);
   stack_slot = x;
   if (((target_flags & 0x00010000) != 0))
     {




       adjust = (mode_size[(int)(mode)]) - total_size;
       if (adjust)
  stack_slot = gen_rtx (MEM, mode_for_size (total_size
         * 8,
         MODE_INT, 1),
          plus_constant_wide (((x)->fld[0].rtx), (int) (adjust)));
     }
   spill_stack_slot[from_reg] = stack_slot;
   spill_stack_slot_width[from_reg] = total_size;
 }



      if (((target_flags & 0x00010000) != 0) && inherent_size < total_size)
 adjust += (total_size - inherent_size);



      if (adjust != 0 || ((x)->mode) != ((regno_reg_rtx[i])->mode))
 {
   x = gen_rtx (MEM, ((regno_reg_rtx[i])->mode),
         plus_constant_wide (((x)->fld[0].rtx), (int) (adjust)));
   ((x)->unchanging) = ((regno_reg_rtx[i])->unchanging);
 }


      reg_equiv_memory_loc[i] = x;
    }
}




void
mark_home_live(int regno) asm("_mark_home_live");
void
mark_home_live(int regno)
{
  register int i, lim;
  i = reg_renumber[regno];
  if (i < 0)
    return;
  lim = i + (! ((unsigned) ((i) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[regno])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[regno])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  while (i < lim)
    regs_ever_live[i++] = 1;
}



static void
mark_scratch_live(rtx scratch) asm("_mark_scratch_live");
static void
mark_scratch_live(rtx scratch)
{
  register int i;
  int regno = ((scratch)->fld[0].rtint);
  int lim = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((scratch)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((scratch)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

  for (i = regno; i < lim; i++)
    regs_ever_live[i] = 1;
}
static void
set_label_offsets(rtx x, rtx insn, int initial_p) asm("_set_label_offsets");
static void
set_label_offsets(rtx x, rtx insn, int initial_p)
{
  n64_enum_rtx_code code = ((x)->code);
  rtx tem;
  int i;
  struct n64_tag_elim_table *p;

  switch (code)
    {
    case LABEL_REF:
      if (((x)->volatil))
 return;

      x = ((x)->fld[0].rtx);



    case CODE_LABEL:







      if (! offsets_known_at[((x)->fld[3].rtint)])
 {
   for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
     offsets_at[((x)->fld[3].rtint)][i]
       = (initial_p ? reg_eliminate[i].initial_offset
   : reg_eliminate[i].offset);
   offsets_known_at[((x)->fld[3].rtint)] = 1;
 }





      else if (x == insn
        && (tem = prev_nonnote_insn (insn)) != 0
        && ((tem)->code) == BARRIER)
 {
   num_not_at_initial_offset = 0;
   for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
     {
       reg_eliminate[i].offset = reg_eliminate[i].previous_offset
  = offsets_at[((x)->fld[3].rtint)][i];
       if (reg_eliminate[i].can_eliminate
    && (reg_eliminate[i].offset
        != reg_eliminate[i].initial_offset))
  num_not_at_initial_offset++;
     }
 }

      else




 for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
   if (offsets_at[((x)->fld[3].rtint)][i]
       != (initial_p ? reg_eliminate[i].initial_offset
    : reg_eliminate[i].offset))
     reg_eliminate[i].can_eliminate = 0;

      return;

    case JUMP_INSN:
      set_label_offsets (((insn)->fld[3].rtx), insn, initial_p);



    case INSN:
    case CALL_INSN:


      for (tem = ((x)->fld[6].rtx); tem; tem = ((tem)->fld[1].rtx))
 if (((n64_enum_reg_note) ((tem)->mode)) == REG_LABEL)
   set_label_offsets (((tem)->fld[0].rtx), insn, 1);
      return;

    case ADDR_VEC:
    case ADDR_DIFF_VEC:




      for (i = 0; i < ((x)->fld[code == ADDR_DIFF_VEC].rtvec->num_elem); i++)
 set_label_offsets (((x)->fld[code == ADDR_DIFF_VEC].rtvec->elem[i].rtx),
      insn, initial_p);
      return;

    case SET:
      if (((x)->fld[0].rtx) != pc_rtx)
 return;

      switch (((((x)->fld[1].rtx))->code))
 {
 case PC:
 case RETURN:
   return;

 case LABEL_REF:
   set_label_offsets (((((x)->fld[1].rtx))->fld[0].rtx), insn, initial_p);
   return;

 case IF_THEN_ELSE:
   tem = ((((x)->fld[1].rtx))->fld[1].rtx);
   if (((tem)->code) == LABEL_REF)
     set_label_offsets (((tem)->fld[0].rtx), insn, initial_p);
   else if (((tem)->code) != PC && ((tem)->code) != RETURN)
     break;

   tem = ((((x)->fld[1].rtx))->fld[2].rtx);
   if (((tem)->code) == LABEL_REF)
     set_label_offsets (((tem)->fld[0].rtx), insn, initial_p);
   else if (((tem)->code) != PC && ((tem)->code) != RETURN)
     break;
   return;
 }



      for (p = reg_eliminate; p < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; p++)
 if (p->offset != p->initial_offset)
   p->can_eliminate = 0;
    }
}




static struct n64_tag_rtvec_def *old_asm_operands_vec, *new_asm_operands_vec;
rtx
eliminate_regs(rtx x, n64_enum_machine_mode mem_mode, rtx insn) asm("_eliminate_regs");
rtx
eliminate_regs(rtx x, n64_enum_machine_mode mem_mode, rtx insn)
{
  n64_enum_rtx_code code = ((x)->code);
  struct n64_tag_elim_table *ep;
  int regno;
  rtx cxx_new;
  int i, j;
  char *fmt;
  int copied = 0;

  switch (code)
    {
    case CONST_INT:
    case CONST_DOUBLE:
    case CONST:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
    case ASM_INPUT:
    case ADDR_VEC:
    case ADDR_DIFF_VEC:
    case RETURN:
      return x;

    case REG:
      regno = ((x)->fld[0].rtint);



      if (regno < 68)
 {
   for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
        ep++)
     if (ep->from_rtx == x && ep->can_eliminate)
       {
  if (! mem_mode

      && ! (insn != 0 && (((insn)->code) == EXPR_LIST
     || ((insn)->code) == INSN_LIST)))
    ep->ref_outside_mem = 1;
  return plus_constant_wide (ep->to_rtx, (int) (ep->previous_offset));
       }

 }
      else if (reg_equiv_memory_loc && reg_equiv_memory_loc[regno]
        && (reg_equiv_address[regno] || num_not_at_initial_offset))
 {
   cxx_new = eliminate_regs (reg_equiv_memory_loc[regno],
    mem_mode, insn);
   if (cxx_new != reg_equiv_memory_loc[regno])
     {
       cannot_omit_stores[regno] = 1;
       return copy_rtx (cxx_new);
     }
 }
      return x;

    case PLUS:


      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68
   && (((((x)->fld[1].rtx))->code) == LABEL_REF || ((((x)->fld[1].rtx))->code) == SYMBOL_REF || ((((x)->fld[1].rtx))->code) == CONST_INT || ((((x)->fld[1].rtx))->code) == CONST_DOUBLE || ((((x)->fld[1].rtx))->code) == CONST || ((((x)->fld[1].rtx))->code) == HIGH))
 {
   for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
        ep++)
     if (ep->from_rtx == ((x)->fld[0].rtx) && ep->can_eliminate)
       {
  if (! mem_mode

      && ! (insn != 0 && (((insn)->code) == EXPR_LIST
     || ((insn)->code) == INSN_LIST)))
    ep->ref_outside_mem = 1;
  if (mem_mode != 0 && ((((x)->fld[1].rtx))->code) == CONST_INT
      && ((((x)->fld[1].rtx))->fld[0].rtwint) == - ep->previous_offset)
    return ep->to_rtx;
  else
    return gen_rtx (PLUS, ((target_flags & 0x00000002) ? DImode : SImode), ep->to_rtx,
      plus_constant_wide (((x)->fld[1].rtx), (int) (ep->previous_offset))
                           );
       }



   return x;
 }
      {
 rtx new0 = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);
 rtx new1 = eliminate_regs (((x)->fld[1].rtx), mem_mode, insn);

 if (new0 != ((x)->fld[0].rtx) || new1 != ((x)->fld[1].rtx))
   {




     if (((new0)->code) == PLUS && ((new1)->code) == REG
  && ((new1)->fld[0].rtint) >= 68
  && reg_renumber[((new1)->fld[0].rtint)] < 0
  && reg_equiv_constant != 0
  && reg_equiv_constant[((new1)->fld[0].rtint)] != 0)
       new1 = reg_equiv_constant[((new1)->fld[0].rtint)];
     else if (((new1)->code) == PLUS && ((new0)->code) == REG
       && ((new0)->fld[0].rtint) >= 68
       && reg_renumber[((new0)->fld[0].rtint)] < 0
       && reg_equiv_constant[((new0)->fld[0].rtint)] != 0)
       new0 = reg_equiv_constant[((new0)->fld[0].rtint)];

     cxx_new = form_sum (new0, new1);




     if (! mem_mode && ((cxx_new)->code) != PLUS)
       return gen_rtx (PLUS, ((x)->mode), cxx_new, const0_rtx);
     else
       return cxx_new;
   }
      }
      return x;

    case MULT:





      if (((((x)->fld[0].rtx))->code) == REG
   && ((((x)->fld[0].rtx))->fld[0].rtint) < 68
   && ((((x)->fld[1].rtx))->code) == CONST_INT)
 for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
      ep++)
   if (ep->from_rtx == ((x)->fld[0].rtx) && ep->can_eliminate)
     {
       if (! mem_mode

    && ! (insn != 0 && (((insn)->code) == EXPR_LIST
          || ((insn)->code) == INSN_LIST)))
  ep->ref_outside_mem = 1;

       return
  plus_constant_wide (gen_rtx (MULT, ((target_flags & 0x00000002) ? DImode : SImode), ep->to_rtx, ((x)->fld[1].rtx)), (int) (ep->previous_offset * ((((x)->fld[1].rtx))->fld[0].rtwint)))
                                                     ;
     }



    case CALL:
    case COMPARE:
    case MINUS:
    case DIV: case UDIV:
    case MOD: case UMOD:
    case AND: case IOR: case XOR:
    case ROTATERT: case ROTATE:
    case ASHIFTRT: case LSHIFTRT: case ASHIFT:
    case NE: case EQ:
    case GE: case GT: case GEU: case GTU:
    case LE: case LT: case LEU: case LTU:
      {
 rtx new0 = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);
 rtx new1
   = ((x)->fld[1].rtx) ? eliminate_regs (((x)->fld[1].rtx), mem_mode, insn) : 0;

 if (new0 != ((x)->fld[0].rtx) || new1 != ((x)->fld[1].rtx))
   return gen_rtx (code, ((x)->mode), new0, new1);
      }
      return x;

    case EXPR_LIST:

      if (((x)->fld[0].rtx))
 {
   cxx_new = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);
   if (cxx_new != ((x)->fld[0].rtx))
     x = gen_rtx (EXPR_LIST, ((n64_enum_reg_note) ((x)->mode)), cxx_new, ((x)->fld[1].rtx));
 }



    case INSN_LIST:



      if (((x)->fld[1].rtx))
 {
   cxx_new = eliminate_regs (((x)->fld[1].rtx), mem_mode, insn);
   if (cxx_new != ((x)->fld[1].rtx))
     return gen_rtx (((x)->code), ((x)->mode), ((x)->fld[0].rtx), cxx_new);
 }
      return x;

    case PRE_INC:
    case POST_INC:
    case PRE_DEC:
    case POST_DEC:
      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 if (ep->to_rtx == ((x)->fld[0].rtx))
   {
     int size = (mode_size[(int)(mem_mode)]);






     if (code == PRE_DEC || code == POST_DEC)
       ep->offset += size;
     else
       ep->offset -= size;
   }


    case USE:
    case STRICT_LOW_PART:
    case NEG: case NOT:
    case SIGN_EXTEND: case ZERO_EXTEND:
    case TRUNCATE: case FLOAT_EXTEND: case FLOAT_TRUNCATE:
    case FLOAT: case FIX:
    case UNSIGNED_FIX: case UNSIGNED_FLOAT:
    case ABS:
    case SQRT:
    case FFS:
      cxx_new = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);
      if (cxx_new != ((x)->fld[0].rtx))
 return gen_rtx (code, ((x)->mode), cxx_new);
      return x;

    case SUBREG:






      if (((((x)->fld[0].rtx))->code) == REG
   && ((mode_size[(int)(((x)->mode))])
       <= (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
   && reg_equiv_memory_loc != 0
   && reg_equiv_memory_loc[((((x)->fld[0].rtx))->fld[0].rtint)] != 0)
 {
   cxx_new = eliminate_regs (reg_equiv_memory_loc[((((x)->fld[0].rtx))->fld[0].rtint)],
    mem_mode, insn);


   if (cxx_new == reg_equiv_memory_loc[((((x)->fld[0].rtx))->fld[0].rtint)])
     cxx_new = ((x)->fld[0].rtx);
   else
     {


       cxx_new = copy_rtx (cxx_new);



       if (insn != 0 && ((insn)->code) != EXPR_LIST
    && ((insn)->code) != INSN_LIST)
  emit_insn_before (gen_rtx (USE, VOIDmode, ((x)->fld[0].rtx)),
      insn);
     }
 }
      else
 cxx_new = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);

      if (cxx_new != ((x)->fld[0].rtx))
 {
   if (((cxx_new)->code) == MEM
       && ((mode_size[(int)(((x)->mode))])
    <= (mode_size[(int)(((cxx_new)->mode))]))





       && ! (((((x)->fld[0].rtx))->code) == REG
      && (mode_size[(int)(((x)->mode))]) <= ((target_flags & 0x00002000) ? 8 : 4)
      && (mode_size[(int)(((cxx_new)->mode))]) <= ((target_flags & 0x00002000) ? 8 : 4)
      && ((mode_size[(int)(((x)->mode))])
   > (mode_size[(int)(((cxx_new)->mode))]))
      && ((mode_class[(int)(((cxx_new)->mode))]) == MODE_INT || (mode_class[(int)(((cxx_new)->mode))]) == MODE_PARTIAL_INT || (mode_class[(int)(((cxx_new)->mode))]) == MODE_COMPLEX_INT)
      && ZERO_EXTEND != NIL)

       )
     {
       int offset = ((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
       n64_enum_machine_mode mode = ((x)->mode);

       if (((target_flags & 0x00010000) != 0))
  offset += (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((cxx_new)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((cxx_new)->mode))])))

      - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)]))));

       ((cxx_new)->mode = (mode));
       ((cxx_new)->fld[0].rtx) = plus_constant_wide (((cxx_new)->fld[0].rtx), (int) (offset));
       return cxx_new;
     }
   else
     return gen_rtx (SUBREG, ((x)->mode), cxx_new, ((x)->fld[1].rtint));
 }

      return x;

    case CLOBBER:



      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 if (ep->to_rtx == ((x)->fld[0].rtx))
   ep->can_eliminate = 0;

      cxx_new = eliminate_regs (((x)->fld[0].rtx), mem_mode, insn);
      if (cxx_new != ((x)->fld[0].rtx))
 return gen_rtx (code, ((x)->mode), cxx_new);
      return x;

    case ASM_OPERANDS:
      {
 rtx *temp_vec;

 if ((((x))->fld[3].rtvec) != old_asm_operands_vec)
   {



     old_asm_operands_vec = (((x))->fld[3].rtvec);
     temp_vec = (rtx *) 
                       __builtin_alloca((
                       ((x)->fld[3].rtvec->num_elem) * sizeof (rtx)
                       ))
                                                             ;
     for (i = 0; i < (((x))->fld[3].rtvec->num_elem); i++)
       temp_vec[i] = eliminate_regs ((((x))->fld[3].rtvec->elem[(i)].rtx),
         mem_mode, insn);

     for (i = 0; i < (((x))->fld[3].rtvec->num_elem); i++)
       if (temp_vec[i] != (((x))->fld[3].rtvec->elem[(i)].rtx))
  break;

     if (i == (((x))->fld[3].rtvec->num_elem))
       new_asm_operands_vec = old_asm_operands_vec;
     else
       new_asm_operands_vec
  = gen_rtvec_v ((((x))->fld[3].rtvec->num_elem), temp_vec);
   }


 if (new_asm_operands_vec == old_asm_operands_vec)
   return x;

 cxx_new = gen_rtx (ASM_OPERANDS, VOIDmode, (((x))->fld[0].rtstr),
         (((x))->fld[1].rtstr),
         (((x))->fld[2].rtint), new_asm_operands_vec,
         (((x))->fld[4].rtvec),
         (((x))->fld[5].rtstr),
         (((x))->fld[6].rtint));
 cxx_new->volatil = x->volatil;
 return cxx_new;
      }

    case SET:

      if (((((x)->fld[0].rtx))->code) == REG)
 {
   for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
        ep++)
     if (ep->to_rtx == ((x)->fld[0].rtx)
  && ((x)->fld[0].rtx) != hard_frame_pointer_rtx)
       {


  rtx src = ((x)->fld[1].rtx);

  if (((src)->code) == PLUS
      && ((src)->fld[0].rtx) == ((x)->fld[0].rtx)
      && ((((src)->fld[1].rtx))->code) == CONST_INT)
    ep->offset -= ((((src)->fld[1].rtx))->fld[0].rtwint);
  else
    ep->can_eliminate = 0;
       }





   for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
        ep++)
     if (ep->from_rtx == ((x)->fld[0].rtx) && ep->can_eliminate)
       ep->can_eliminate = 0;
 }


      {
 rtx new0 = eliminate_regs (((x)->fld[0].rtx), 0, insn);
 rtx new1 = eliminate_regs (((x)->fld[1].rtx), 0, insn);



 if (((((x)->fld[0].rtx))->code) == REG && ((new0)->code) == MEM
     && insn != 0 && ((insn)->code) != EXPR_LIST
     && ((insn)->code) != INSN_LIST)
   emit_insn_after (gen_rtx (CLOBBER, VOIDmode, ((x)->fld[0].rtx)), insn);

 if (new0 != ((x)->fld[0].rtx) || new1 != ((x)->fld[1].rtx))
   return gen_rtx (SET, VOIDmode, new0, new1);
      }

      return x;

    case MEM:



      cxx_new = eliminate_regs (((x)->fld[0].rtx), ((x)->mode), insn);
      if (cxx_new != ((x)->fld[0].rtx))
 {
   cxx_new = gen_rtx (MEM, ((x)->mode), cxx_new);
   cxx_new->volatil = x->volatil;
   cxx_new->unchanging = x->unchanging;
   cxx_new->in_struct = x->in_struct;
   return cxx_new;
 }
      else
 return x;
    }



  fmt = (rtx_format[(int)(code)]);
  for (i = 0; i < (rtx_length[(int)(code)]); i++, fmt++)
    {
      if (*fmt == 'e')
 {
   cxx_new = eliminate_regs (((x)->fld[i].rtx), mem_mode, insn);
   if (cxx_new != ((x)->fld[i].rtx) && ! copied)
     {
       rtx new_x = rtx_alloc (code);
       memcpy ((char *) new_x,(char *) x,(sizeof (*new_x) - sizeof (new_x->fld) + sizeof (new_x->fld[0]) * (rtx_length[(int)(code)])))

                                                          ;
       x = new_x;
       copied = 1;
     }
   ((x)->fld[i].rtx) = cxx_new;
 }
      else if (*fmt == 'E')
 {
   int copied_vec = 0;
   for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
     {
       cxx_new = eliminate_regs (((x)->fld[i].rtvec->elem[j].rtx), mem_mode, insn);
       if (cxx_new != ((x)->fld[i].rtvec->elem[j].rtx) && ! copied_vec)
  {
    rtvec new_v = gen_rtvec_v (((x)->fld[i].rtvec->num_elem),
          &((x)->fld[i].rtvec->elem[0].rtx));
    if (! copied)
      {
        rtx new_x = rtx_alloc (code);
        memcpy ((char *) new_x,(char *) x,(sizeof (*new_x) - sizeof (new_x->fld) + (sizeof (new_x->fld[0]) * (rtx_length[(int)(code)]))))


                               ;
        x = new_x;
        copied = 1;
      }
    ((x)->fld[i].rtvec) = new_v;
    copied_vec = 1;
  }
       ((x)->fld[i].rtvec->elem[j].rtx) = cxx_new;
     }
 }
    }

  return x;
}
static int
eliminate_regs_in_insn(rtx insn, int replace) asm("_eliminate_regs_in_insn");
static int
eliminate_regs_in_insn(rtx insn, int replace)
{
  rtx old_body = ((insn)->fld[3].rtx);
  rtx old_set = single_set (insn);
  rtx new_body;
  int val = 0;
  struct n64_tag_elim_table *ep;

  if (! replace)
    push_obstacks (&reload_obstack, &reload_obstack);

  if (old_set != 0 && ((((old_set)->fld[0].rtx))->code) == REG
      && ((((old_set)->fld[0].rtx))->fld[0].rtint) < 68)
    {

      for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
 if (ep->from_rtx == ((old_set)->fld[0].rtx) && ep->can_eliminate)
   {
     if (replace)
       delete_dead_insn (insn);
     val = 1;
     goto done;
   }
      if (((((old_set)->fld[1].rtx))->code) == PLUS
   && ((((((old_set)->fld[1].rtx))->fld[0].rtx))->code) == REG
   && ((((((old_set)->fld[1].rtx))->fld[1].rtx))->code) == CONST_INT)
 for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])];
      ep++)
   if (ep->from_rtx == ((((old_set)->fld[1].rtx))->fld[0].rtx)
       && ep->can_eliminate)
     {




       if (ep->offset == - ((((((old_set)->fld[1].rtx))->fld[1].rtx))->fld[0].rtwint))
  {



    ((insn)->fld[3].rtx) = gen_rtx (SET, VOIDmode,
         ((old_set)->fld[0].rtx), ep->to_rtx);
    ((insn)->fld[4].rtint) = -1;
    val = 1;
    goto done;
  }

       break;
     }
    }

  old_asm_operands_vec = 0;
  new_body = eliminate_regs (old_body, 0, replace ? insn : (rtx) 0);
  if (new_body != old_body)
    {







      if (! replace && asm_noperands (old_body) < 0)
 new_body = copy_rtx (new_body);






      if (old_set != 0
   && ((((((old_set)->fld[1].rtx))->code) == REG
        && (((new_body)->code) != SET
     || ((((new_body)->fld[1].rtx))->code) != REG))



       || (old_set != 0
    && ((((((old_set)->fld[1].rtx))->code) == MEM
         && ((old_set)->fld[1].rtx) != recog_operand[1])
        || (((((old_set)->fld[0].rtx))->code) == MEM
     && ((old_set)->fld[0].rtx) != recog_operand[0])))

       || ((((old_set)->fld[1].rtx))->code) == PLUS))
 {
   if (! validate_change (insn, &((insn)->fld[3].rtx), new_body, 0))



     ((insn)->fld[3].rtx) = new_body;
 }
      else
 ((insn)->fld[3].rtx) = new_body;

      val = 1;
    }
  num_not_at_initial_offset = 0;
  for (ep = reg_eliminate; ep < &reg_eliminate[(sizeof reg_eliminate / sizeof reg_eliminate[0])]; ep++)
    {
      if (ep->previous_offset != ep->offset && ep->ref_outside_mem)
 ep->can_eliminate = 0;

      ep->ref_outside_mem = 0;

      if (ep->previous_offset != ep->offset)
 val = 1;

      ep->previous_offset = ep->offset;
      if (ep->can_eliminate && ep->offset != ep->initial_offset)
 num_not_at_initial_offset++;


      ep->max_offset = ((ep->max_offset) > (ep->offset) ? (ep->max_offset) : (ep->offset));



    }

 done:





  if (val && ((insn)->fld[6].rtx) != 0)
    ((insn)->fld[6].rtx) = eliminate_regs (((insn)->fld[6].rtx), 0, ((insn)->fld[6].rtx));

  if (! replace)
    pop_obstacks ();

  return val;
}
static void
mark_not_eliminable(rtx dest, rtx x) asm("_mark_not_eliminable");
static void
mark_not_eliminable(rtx dest, rtx x)
{
  register int i;




  if (((dest)->code) == SUBREG)
    dest = ((dest)->fld[0].rtx);

  if (dest == hard_frame_pointer_rtx)
    return;

  for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
    if (reg_eliminate[i].can_eliminate && dest == reg_eliminate[i].to_rtx
 && (((x)->code) != SET
     || ((((x)->fld[1].rtx))->code) != PLUS
     || ((((x)->fld[1].rtx))->fld[0].rtx) != dest
     || ((((((x)->fld[1].rtx))->fld[1].rtx))->code) != CONST_INT))
      {
 reg_eliminate[i].can_eliminate_previous
   = reg_eliminate[i].can_eliminate = 0;
 num_eliminable--;
      }
}
static int
spill_hard_reg(register int regno, int global, FILE *dumpfile, int cant_eliminate) asm("_spill_hard_reg");
static int
spill_hard_reg(register int regno, int global, FILE *dumpfile, int cant_eliminate)
{
  n64_enum_reg_class cxx_class = mips_regno_to_class[ (regno) ];
  int something_changed = 0;
  register int i;

  ((forbidden_regs)[(regno) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)));

  if (cant_eliminate)
    regs_ever_live[regno] = 1;




  for (i = 68; i < max_regno; i++)
    if (reg_renumber[i] >= 0
 && reg_renumber[i] <= regno
 && (reg_renumber[i]
     + (! ((unsigned) ((reg_renumber[i]) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))

     > regno))
      {





 if (! cant_eliminate
     && basic_block_needs[0]
     && reg_basic_block[i] >= 0
     && basic_block_needs[(int) cxx_class][reg_basic_block[i]] == 0)
   {
     n64_enum_reg_class *p;

     for (p = reg_class_superclasses[(int) cxx_class];
   *p != LIM_REG_CLASSES; p++)
       if (basic_block_needs[(int) *p][reg_basic_block[i]] > 0)
  break;

     if (*p == LIM_REG_CLASSES)
       continue;
   }


 reg_renumber[i] = -1;

 something_changed = 1;
 if (global)
     retry_global_alloc (i, forbidden_regs);

 alter_reg (i, regno);
 if (dumpfile)
   {
     if (reg_renumber[i] == -1)
       fprintf (dumpfile, " Register %d now on stack.\n\n", i);
     else
       fprintf (dumpfile, " Register %d now in %d.\n\n",
         i, reg_renumber[i]);
   }
      }
  for (i = 0; i < scratch_list_length; i++)
    {
      if (scratch_list[i] && ((scratch_list[i])->fld[0].rtint) == regno)
 {
   if (! cant_eliminate && basic_block_needs[0]
       && ! basic_block_needs[(int) cxx_class][scratch_block[i]])
     {
       n64_enum_reg_class *p;

       for (p = reg_class_superclasses[(int) cxx_class];
     *p != LIM_REG_CLASSES; p++)
  if (basic_block_needs[(int) *p][scratch_block[i]] > 0)
    break;

       if (*p == LIM_REG_CLASSES)
  continue;
     }
   ((scratch_list[i])->code = (SCRATCH));
   scratch_list[i] = 0;
   something_changed = 1;
   continue;
 }
    }

  return something_changed;
}





static void
scan_paradoxical_subregs(register rtx x) asm("_scan_paradoxical_subregs");
static void
scan_paradoxical_subregs(register rtx x)
{
  register int i;
  register char *fmt;
  register n64_enum_rtx_code code = ((x)->code);

  switch (code)
    {
    case REG:




      return;

    case CONST_INT:
    case CONST:
    case SYMBOL_REF:
    case LABEL_REF:
    case CONST_DOUBLE:
    case CC0:
    case PC:
    case USE:
    case CLOBBER:
      return;

    case SUBREG:
      if (((((x)->fld[0].rtx))->code) == REG
   && (mode_size[(int)(((x)->mode))]) > (mode_size[(int)(((((x)->fld[0].rtx))->mode))]))
 reg_max_ref_width[((((x)->fld[0].rtx))->fld[0].rtint)]
   = (mode_size[(int)(((x)->mode))]);
      return;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 scan_paradoxical_subregs (((x)->fld[i].rtx));
      else if (fmt[i] == 'E')
 {
   register int j;
   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >=0; j--)
     scan_paradoxical_subregs (((x)->fld[i].rtvec->elem[j].rtx));
 }
    }
}

static int
hard_reg_use_compare(struct n64_tag_hard_reg_n_uses *p1, struct n64_tag_hard_reg_n_uses *p2) asm("_hard_reg_use_compare");
static int
hard_reg_use_compare(struct n64_tag_hard_reg_n_uses *p1, struct n64_tag_hard_reg_n_uses *p2)
{
  int tem = p1->uses - p2->uses;
  if (tem != 0) return tem;


  return p1->regno - p2->regno;
}





static void
order_regs_for_reload(void) asm("_order_regs_for_reload");
static void
order_regs_for_reload(void)
{
  register int i;
  register int o = 0;
  int large = 0;

  struct n64_tag_hard_reg_n_uses hard_reg_n_uses[68];

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (bad_spill_regs); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

  for (i = 0; i < 68; i++)
    potential_reload_regs[i] = -1;




  for (i = 0; i < 68; i++)
    {
      hard_reg_n_uses[i].uses = 0;
      hard_reg_n_uses[i].regno = i;
    }

  for (i = 68; i < max_regno; i++)
    {
      int regno = reg_renumber[i];
      if (regno >= 0)
 {
   int lim = regno + (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((regno_reg_rtx[i])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   while (regno < lim)
     hard_reg_n_uses[regno++].uses += reg_n_refs[i];
 }
      large += reg_n_refs[i];
    }





  for (i = 0; i < 68; i++)
    {
      if (fixed_regs[i])
 {
   hard_reg_n_uses[i].uses += 2 * large + 2;
   ((bad_spill_regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
 }
      else if (regs_explicitly_used[i])
 {
   hard_reg_n_uses[i].uses += large + 1;






   ((bad_spill_regs)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));

 }
    }
  hard_reg_n_uses[(0 + 30)].uses += 2 * large + 2;
  ((bad_spill_regs)[((0 + 30)) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << (((0 + 30)) % ((unsigned) 32)));




  for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
    {
      hard_reg_n_uses[reg_eliminate[i].from].uses += 2 * large + 2;
      ((bad_spill_regs)[(reg_eliminate[i].from) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((reg_eliminate[i].from) % ((unsigned) 32)));
    }
  for (i = 0; i < 68; i++)
    {
      if (hard_reg_n_uses[i].uses == 0 && call_used_regs[i])
 potential_reload_regs[o++] = i;
    }
  for (i = 0; i < 68; i++)
    {
      if (hard_reg_n_uses[i].uses == 0 && ! call_used_regs[i])
 potential_reload_regs[o++] = i;
    }


  qsort (hard_reg_n_uses, 68,
  sizeof hard_reg_n_uses[0], hard_reg_use_compare);





  for (i = 0; i < 68; i++)
    if (hard_reg_n_uses[i].uses != 0)
      potential_reload_regs[o++] = hard_reg_n_uses[i].regno;
}



static int
compare_spill_regs(short int *r1, short int *r2) asm("_compare_spill_regs");
static int
compare_spill_regs(short int *r1, short int *r2)
{
  return *r1 - *r2;
}
static void
reload_as_needed(rtx first, int live_known) asm("_reload_as_needed");
static void
reload_as_needed(rtx first, int live_known)
{
  register rtx insn;
  register int i;
  int this_block = 0;
  rtx x;
  rtx after_call = 0;

  memset ((char *) spill_reg_rtx,0,sizeof spill_reg_rtx);
  memset ((char *) spill_reg_store,0,sizeof spill_reg_store);
  reg_last_reload_reg = (rtx *) 
                               __builtin_alloca((
                               max_regno * sizeof (rtx)
                               ))
                                                                ;
  memset ((char *) reg_last_reload_reg,0,max_regno * sizeof (rtx));
  reg_has_output_reload = (char *) 
                                  __builtin_alloca((
                                  max_regno
                                  ))
                                                    ;
  for (i = 0; i < n_spills; i++)
    {
      reg_reloaded_contents[i] = -1;
      reg_reloaded_insn[i] = 0;
    }



  for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
    {
      { compute_frame_size (get_frame_size ()); if ((reg_eliminate[i].from) == (0 + 30) && (reg_eliminate[i].to) == (0 + 29)) (reg_eliminate[i].initial_offset) = 0; else if ((reg_eliminate[i].from) == 0 && ((reg_eliminate[i].to) == (0 + 30) || (reg_eliminate[i].to) == (0 + 29))) (reg_eliminate[i].initial_offset) = (current_frame_info.total_size - (0 && mips_isa >= 3 ? current_function_pretend_args_size : 0)); else abort (); }
                                      ;
      reg_eliminate[i].previous_offset
 = reg_eliminate[i].offset = reg_eliminate[i].initial_offset;
    }






  num_not_at_initial_offset = 0;



  if (n_spills > 1)
    {
      qsort (spill_regs, n_spills, sizeof (short), compare_spill_regs);
      for (i = 0; i < n_spills; i++)
 spill_reg_order[spill_regs[i]] = i;
    }

  for (insn = first; insn;)
    {
      register rtx next = ((insn)->fld[2].rtx);


      if (live_known && this_block + 1 < n_basic_blocks
   && insn == basic_block_head[this_block+1])
 ++this_block;



      if (((insn)->code) == CODE_LABEL)
 {
   num_not_at_initial_offset = 0;
   for (i = 0; i < (sizeof reg_eliminate / sizeof reg_eliminate[0]); i++)
     {
       reg_eliminate[i].offset = reg_eliminate[i].previous_offset
  = offsets_at[((insn)->fld[3].rtint)][i];
       if (reg_eliminate[i].can_eliminate
    && (reg_eliminate[i].offset
        != reg_eliminate[i].initial_offset))
  num_not_at_initial_offset++;
     }
 }

      else if ((rtx_class[(int)(((insn)->code))]) == 'i')
 {
   rtx avoid_return_reg = 0;
   rtx oldpat = ((insn)->fld[3].rtx);
   if ((((((insn)->fld[3].rtx))->code) == USE
        || ((((insn)->fld[3].rtx))->code) == CLOBBER)
       && ((((((insn)->fld[3].rtx))->fld[0].rtx))->code) == MEM)
     ((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtx)
       = eliminate_regs (((((((insn)->fld[3].rtx))->fld[0].rtx))->fld[0].rtx),
    ((((((insn)->fld[3].rtx))->fld[0].rtx))->mode), (rtx) 0);



   if (num_eliminable && ((insn)->mode) == QImode)
     {
       eliminate_regs_in_insn (insn, 1);
       if (((insn)->code) == NOTE)
  {
    insn = next;
    continue;
  }
     }

   if (((insn)->mode) == VOIDmode)
     n_reloads = 0;




   else
     {
       memset (reg_has_output_reload,0,max_regno);
       do { register HARD_REG_ELT_TYPE *scan_tp_ = (reg_is_output_reload); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

       find_reloads (insn, 1, spill_indirect_levels, live_known,
       spill_reg_order);
     }

   if (n_reloads > 0)
     {
       rtx prev = ((insn)->fld[1].rtx), next = ((insn)->fld[2].rtx);
       rtx p;
       int cxx_class;





       for (cxx_class = 0; cxx_class < (int) LIM_REG_CLASSES; cxx_class++)
  if (basic_block_needs[cxx_class] != 0
      && basic_block_needs[cxx_class][this_block] == 0)
    for (i = 0; i < n_reloads; i++)
      if (cxx_class == (int) reload_reg_class[i]
   && reload_reg_rtx[i] == 0
   && ! reload_optional[i]
   && (reload_in[i] != 0 || reload_out[i] != 0
       || reload_secondary_p[i] != 0))
        fatal_insn ("Non-optional registers need a spill register", insn);





       choose_reload_regs (insn, avoid_return_reg);
       emit_reload_insns (insn);





       subst_reloads ();





       if (asm_noperands (((insn)->fld[3].rtx)) >= 0)
  for (p = ((prev)->fld[2].rtx); p != next; p = ((p)->fld[2].rtx))
    if (p != insn && (rtx_class[(int)(((p)->code))]) == 'i'
        && (recog_memoized (p) < 0
     || (insn_extract (p),
         ! constrain_operands (((p)->fld[4].rtint), 1))))
      {
        error_for_asm (insn,
         "`asm' operand requires impossible reload");
        ((p)->code = (NOTE));
        ((p)->fld[3].rtstr) = 0;
        ((p)->fld[4].rtint) = -1;
      }
     }






   note_stores (oldpat, forget_old_reloads_1);



   for (x = ((insn)->fld[2].rtx); x != next; x = ((x)->fld[2].rtx))
     if (((x)->code) == INSN && ((((x)->fld[3].rtx))->code) == CLOBBER)
       note_stores (((x)->fld[3].rtx), forget_old_reloads_1);
 }

      if (((insn)->code) == CODE_LABEL)
 for (i = 0; i < n_spills; i++)
   {
     reg_reloaded_contents[i] = -1;
     reg_reloaded_insn[i] = 0;
   }



      else if (((insn)->code) == CALL_INSN)
 for (i = 0; i < n_spills; i++)
   if (call_used_regs[spill_regs[i]])
     {
       reg_reloaded_contents[i] = -1;
       reg_reloaded_insn[i] = 0;
     }
      insn = next;




    }
}
static void
forget_old_reloads_1(rtx x, rtx ignored) asm("_forget_old_reloads_1");
static void
forget_old_reloads_1(rtx x, rtx ignored)
{
  register int regno;
  int nr;
  int offset = 0;


  while (((x)->code) == SUBREG)
    {
      offset += ((x)->fld[1].rtint);
      x = ((x)->fld[0].rtx);
    }

  if (((x)->code) != REG)
    return;

  regno = ((x)->fld[0].rtint) + offset;

  if (regno >= 68)
    nr = 1;
  else
    {
      int i;
      nr = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((x)->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));




      for (i = 0; i < nr; i++)
 if (spill_reg_order[regno + i] >= 0


     && (n_reloads == 0
  || ! ((reg_is_output_reload)[(regno + i) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + i) % ((unsigned) 32))))))
   {
     reg_reloaded_contents[spill_reg_order[regno + i]] = -1;
     reg_reloaded_insn[spill_reg_order[regno + i]] = 0;
   }
    }




  while (nr-- > 0)


    if (n_reloads == 0 || reg_has_output_reload[regno + nr] == 0)
      reg_last_reload_reg[regno + nr] = 0;
}


static n64_enum_machine_mode reload_mode[(2 * 10 * (1 + 1))];


static int reload_nregs[(2 * 10 * (1 + 1))];




static int
reload_reg_class_lower(short int *p1, short int *p2) asm("_reload_reg_class_lower");
static int
reload_reg_class_lower(short int *p1, short int *p2)
{
  register int r1 = *p1, r2 = *p2;
  register int t;


  t = reload_optional[r1] - reload_optional[r2];
  if (t != 0)
    return t;


  t = ((reg_class_size[(int) reload_reg_class[r2]] == 1)
       - (reg_class_size[(int) reload_reg_class[r1]] == 1));
  if (t != 0)
    return t;


  t = reload_nregs[r2] - reload_nregs[r1];
  if (t != 0)
    return t;


  t = (int) reload_reg_class[r1] - (int) reload_reg_class[r2];
  if (t != 0)
    return t;



  return r1 - r2;
}





static HARD_REG_SET reload_reg_used;

static HARD_REG_SET reload_reg_used_in_input_addr[10];

static HARD_REG_SET reload_reg_used_in_output_addr[10];

static HARD_REG_SET reload_reg_used_in_input[10];

static HARD_REG_SET reload_reg_used_in_output[10];

static HARD_REG_SET reload_reg_used_in_op_addr;

static HARD_REG_SET reload_reg_used_in_op_addr_reload;

static HARD_REG_SET reload_reg_used_in_insn;

static HARD_REG_SET reload_reg_used_in_other_addr;


static HARD_REG_SET reload_reg_used_at_all;



static HARD_REG_SET reload_reg_used_for_inherit;





static void
mark_reload_reg_in_use(int regno, int opnum, n64_enum_reload_type type, n64_enum_machine_mode mode) asm("_mark_reload_reg_in_use");
static void
mark_reload_reg_in_use(int regno, int opnum, n64_enum_reload_type type, n64_enum_machine_mode mode)
{
  int nregs = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  int i;

  for (i = regno; i < nregs + regno; i++)
    {
      switch (type)
 {
 case RELOAD_OTHER:
   ((reload_reg_used)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_INPUT_ADDRESS:
   ((reload_reg_used_in_input_addr[opnum])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_OUTPUT_ADDRESS:
   ((reload_reg_used_in_output_addr[opnum])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_OPERAND_ADDRESS:
   ((reload_reg_used_in_op_addr)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_OPADDR_ADDR:
   ((reload_reg_used_in_op_addr_reload)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_OTHER_ADDRESS:
   ((reload_reg_used_in_other_addr)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_INPUT:
   ((reload_reg_used_in_input[opnum])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_OUTPUT:
   ((reload_reg_used_in_output[opnum])[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;

 case RELOAD_FOR_INSN:
   ((reload_reg_used_in_insn)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
   break;
 }

      ((reload_reg_used_at_all)[(i) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32)));
    }
}



static void
clear_reload_reg_in_use(int regno, int opnum, n64_enum_reload_type type, n64_enum_machine_mode mode) asm("_clear_reload_reg_in_use");
static void
clear_reload_reg_in_use(int regno, int opnum, n64_enum_reload_type type, n64_enum_machine_mode mode)
{
  int nregs = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
  int i;

  for (i = regno; i < nregs + regno; i++)
    {
      switch (type)
 {
 case RELOAD_OTHER:
   ((reload_reg_used)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_INPUT_ADDRESS:
   ((reload_reg_used_in_input_addr[opnum])[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_OUTPUT_ADDRESS:
   ((reload_reg_used_in_output_addr[opnum])[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_OPERAND_ADDRESS:
   ((reload_reg_used_in_op_addr)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_OPADDR_ADDR:
   ((reload_reg_used_in_op_addr_reload)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_OTHER_ADDRESS:
   ((reload_reg_used_in_other_addr)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_INPUT:
   ((reload_reg_used_in_input[opnum])[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_OUTPUT:
   ((reload_reg_used_in_output[opnum])[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;

 case RELOAD_FOR_INSN:
   ((reload_reg_used_in_insn)[(i) / ((unsigned) 32)] &= ~(((HARD_REG_ELT_TYPE) (1)) << ((i) % ((unsigned) 32))));
   break;
 }
    }
}




static int
reload_reg_free_p(int regno, int opnum, n64_enum_reload_type type) asm("_reload_reg_free_p");
static int
reload_reg_free_p(int regno, int opnum, n64_enum_reload_type type)
{
  int i;





  if (type != RELOAD_FOR_OTHER_ADDRESS
      && ((reload_reg_used)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
    return 0;

  switch (type)
    {
    case RELOAD_OTHER:


      if (((reload_reg_used)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
   || ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
   || ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_INPUT:
      if (((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
   || ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      if (((reload_reg_used_in_op_addr_reload)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;


      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;


      for (i = opnum + 1; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_INPUT_ADDRESS:


      if (((reload_reg_used_in_input_addr[opnum])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = 0; i < opnum; i++)
 if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_OUTPUT_ADDRESS:


      if (((reload_reg_used_in_output_addr[opnum])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = opnum; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_OPERAND_ADDRESS:
      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return (! ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_OPADDR_ADDR:
      for (i = 0; i < reload_n_operands; i++)
        if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
          return 0;

      return (!((reload_reg_used_in_op_addr_reload)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_OUTPUT:


      if (((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      for (i = 0; i <= opnum; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_INSN:
      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return (! ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_OTHER_ADDRESS:
      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));
    }
  abort ();
}
static int
reload_reg_free_before_p(int regno, int opnum, n64_enum_reload_type type) asm("_reload_reg_free_before_p");
static int
reload_reg_free_before_p(int regno, int opnum, n64_enum_reload_type type)
{
  int i;

  switch (type)
    {
    case RELOAD_FOR_OTHER_ADDRESS:

      return 1;

    case RELOAD_OTHER:
      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));
    case RELOAD_FOR_OUTPUT_ADDRESS:




      for (i = 0; i < opnum; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      if (((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return (! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_OUTPUT:




      if (((reload_reg_used_in_output_addr[opnum])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      for (i = 0; i < opnum; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));

    case RELOAD_FOR_OPERAND_ADDRESS:
    case RELOAD_FOR_OPADDR_ADDR:
    case RELOAD_FOR_INSN:



      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));

    case RELOAD_FOR_INPUT:




      for (i = 0; i <= opnum; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));

    case RELOAD_FOR_INPUT_ADDRESS:


      for (i = 0; i < opnum; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return ! ((reload_reg_used_in_other_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))));
    }
  abort ();
}
static int
reload_reg_reaches_end_p(int regno, int opnum, n64_enum_reload_type type) asm("_reload_reg_reaches_end_p");
static int
reload_reg_reaches_end_p(int regno, int opnum, n64_enum_reload_type type)
{
  int i;

  switch (type)
    {
    case RELOAD_OTHER:


      return 1;






    case RELOAD_FOR_OTHER_ADDRESS:



      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return (! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_INPUT_ADDRESS:





      for (i = opnum; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      for (i = opnum + 1; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      if (((reload_reg_used_in_op_addr_reload)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
 return 0;

      return (! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && ! ((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_INPUT:





      for (i = opnum + 1; i < reload_n_operands; i++)
 if (((reload_reg_used_in_input_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_input[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;



    case RELOAD_FOR_OPERAND_ADDRESS:


      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;

    case RELOAD_FOR_OPADDR_ADDR:
      for (i = 0; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     || ((reload_reg_used_in_output[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return (! ((reload_reg_used_in_op_addr)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
       && !((reload_reg_used_in_insn)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))));

    case RELOAD_FOR_INSN:



      opnum = -1;



    case RELOAD_FOR_OUTPUT:
    case RELOAD_FOR_OUTPUT_ADDRESS:


      for (i = opnum + 1; i < reload_n_operands; i++)
 if (((reload_reg_used_in_output_addr[i])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   return 0;

      return 1;
    }

  abort ();
}






static int
reloads_conflict(int r1, int r2) asm("_reloads_conflict");
static int
reloads_conflict(int r1, int r2)
{
  n64_enum_reload_type r1_type = reload_when_needed[r1];
  n64_enum_reload_type r2_type = reload_when_needed[r2];
  int r1_opnum = reload_opnum[r1];
  int r2_opnum = reload_opnum[r2];



  if (r2_type == RELOAD_OTHER && r1_type != RELOAD_FOR_OTHER_ADDRESS)
    return 1;



  switch (r1_type)
    {
    case RELOAD_FOR_INPUT:
      return (r2_type == RELOAD_FOR_INSN
       || r2_type == RELOAD_FOR_OPERAND_ADDRESS
       || r2_type == RELOAD_FOR_OPADDR_ADDR
       || r2_type == RELOAD_FOR_INPUT
       || (r2_type == RELOAD_FOR_INPUT_ADDRESS && r2_opnum > r1_opnum));

    case RELOAD_FOR_INPUT_ADDRESS:
      return ((r2_type == RELOAD_FOR_INPUT_ADDRESS && r1_opnum == r2_opnum)
       || (r2_type == RELOAD_FOR_INPUT && r2_opnum < r1_opnum));

    case RELOAD_FOR_OUTPUT_ADDRESS:
      return ((r2_type == RELOAD_FOR_OUTPUT_ADDRESS && r2_opnum == r1_opnum)
       || (r2_type == RELOAD_FOR_OUTPUT && r2_opnum >= r1_opnum));

    case RELOAD_FOR_OPERAND_ADDRESS:
      return (r2_type == RELOAD_FOR_INPUT || r2_type == RELOAD_FOR_INSN
       || r2_type == RELOAD_FOR_OPERAND_ADDRESS);

    case RELOAD_FOR_OPADDR_ADDR:
      return (r2_type == RELOAD_FOR_INPUT
       || r2_type == RELOAD_FOR_OPADDR_ADDR);

    case RELOAD_FOR_OUTPUT:
      return (r2_type == RELOAD_FOR_INSN || r2_type == RELOAD_FOR_OUTPUT
       || (r2_type == RELOAD_FOR_OUTPUT_ADDRESS
    && r2_opnum >= r1_opnum));

    case RELOAD_FOR_INSN:
      return (r2_type == RELOAD_FOR_INPUT || r2_type == RELOAD_FOR_OUTPUT
       || r2_type == RELOAD_FOR_INSN
       || r2_type == RELOAD_FOR_OPERAND_ADDRESS);

    case RELOAD_FOR_OTHER_ADDRESS:
      return r2_type == RELOAD_FOR_OTHER_ADDRESS;

    case RELOAD_OTHER:
      return r2_type != RELOAD_FOR_OTHER_ADDRESS;

    default:
      abort ();
    }
}



short reload_order[(2 * 10 * (1 + 1))];



char reload_inherited[(2 * 10 * (1 + 1))];



rtx reload_inheritance_insn[(2 * 10 * (1 + 1))];



rtx reload_override_in[(2 * 10 * (1 + 1))];



int reload_spill_index[(2 * 10 * (1 + 1))];
static int
allocate_reload_reg(int r, rtx insn, int last_reload, int noerror) asm("_allocate_reload_reg");
static int
allocate_reload_reg(int r, rtx insn, int last_reload, int noerror)
{
  int i;
  int pass;
  int count;
  rtx cxx_new;
  int regno;
  int force_group = reload_nregs[r] > 1 && ! last_reload;
  for (pass = 0; pass < 2; pass++)
    {
      if (noerror || ! force_group)
 i = last_spill_reg;
      else
 i = -1;

      for (count = 0; count < n_spills; count++)
 {
   int cxx_class = (int) reload_reg_class[r];

   i = (i + 1) % n_spills;

   if (reload_reg_free_p (spill_regs[i], reload_opnum[r],
     reload_when_needed[r])
       && ((reg_class_contents[cxx_class])[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))
       && mips_hard_regno_mode_ok[ (int)(reload_mode[r]) ][ (spill_regs[i]) ]



       && (pass
    || (((reload_reg_used_at_all)[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))

        && ! ((reload_reg_used_for_inherit)[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))
                         )))
     {
       int nr = (! ((unsigned) ((spill_regs[i]) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));



       if (force_group)
  nr = ((reload_reg_class[r]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(reload_mode[r])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(reload_mode[r])]) + (8) - 1) / (8))) : (((mode_size[(int)(reload_mode[r])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))));

       if (nr == 1)
  {

    if (force_group)
      continue;
    break;
  }




       if (! ((counted_for_nongroups)[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32)))))
  while (nr > 1)
    {
      regno = spill_regs[i] + nr - 1;
      if (!(((reg_class_contents[cxx_class])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
     && spill_reg_order[regno] >= 0
     && reload_reg_free_p (regno, reload_opnum[r],
      reload_when_needed[r])
     && ! ((counted_for_nongroups)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
              ))
        break;
      nr--;
    }
       if (nr == 1)
  break;
     }
 }


      if (count < n_spills)
 break;
    }


  if (count == n_spills)
    {
      if (noerror)
 return 0;
      goto failure;
    }




  cxx_new = spill_reg_rtx[i];

  if (cxx_new == 0 || ((cxx_new)->mode) != reload_mode[r])
    spill_reg_rtx[i] = cxx_new
      = gen_rtx (REG, reload_mode[r], spill_regs[i]);

  regno = true_regnum (cxx_new);



  if (mips_hard_regno_mode_ok[ (int)(reload_mode[r]) ][ (regno) ])
    {
      n64_enum_machine_mode test_mode = VOIDmode;
      if (reload_in[r])
 test_mode = ((reload_in[r])->mode);






      if (! (reload_in[r] != 0 && test_mode != VOIDmode
      && ! mips_hard_regno_mode_ok[ (int)(test_mode) ][ (regno) ]))
 if (! (reload_out[r] != 0
        && ! mips_hard_regno_mode_ok[ (int)(((reload_out[r])->mode)) ][ (regno) ]))
   {

     last_spill_reg = i;



     mark_reload_reg_in_use (spill_regs[i], reload_opnum[r],
        reload_when_needed[r], reload_mode[r]);

     reload_reg_rtx[r] = cxx_new;
     reload_spill_index[r] = i;
     return 1;
   }
    }


  if (noerror)
    return 0;

 failure:
  if (asm_noperands (((insn)->fld[3].rtx)) < 0)

    fatal_insn ("Could not find a spill register", insn);



  error_for_asm (insn,
   "`asm' operand constraint incompatible with operand size");
  reload_in[r] = 0;
  reload_out[r] = 0;
  reload_reg_rtx[r] = 0;
  reload_optional[r] = 1;
  reload_secondary_p[r] = 1;

  return 1;
}
static void
choose_reload_regs(rtx insn, rtx avoid_return_reg) asm("_choose_reload_regs");
static void
choose_reload_regs(rtx insn, rtx avoid_return_reg)
{
  register int i, j;
  int max_group_size = 1;
  n64_enum_reg_class group_class = NO_REGS;
  int inheritance;

  rtx save_reload_reg_rtx[(2 * 10 * (1 + 1))];
  char save_reload_inherited[(2 * 10 * (1 + 1))];
  rtx save_reload_inheritance_insn[(2 * 10 * (1 + 1))];
  rtx save_reload_override_in[(2 * 10 * (1 + 1))];
  int save_reload_spill_index[(2 * 10 * (1 + 1))];
  HARD_REG_SET save_reload_reg_used;
  HARD_REG_SET save_reload_reg_used_in_input_addr[10];
  HARD_REG_SET save_reload_reg_used_in_output_addr[10];
  HARD_REG_SET save_reload_reg_used_in_input[10];
  HARD_REG_SET save_reload_reg_used_in_output[10];
  HARD_REG_SET save_reload_reg_used_in_op_addr;
  HARD_REG_SET save_reload_reg_used_in_op_addr_reload;
  HARD_REG_SET save_reload_reg_used_in_insn;
  HARD_REG_SET save_reload_reg_used_in_other_addr;
  HARD_REG_SET save_reload_reg_used_at_all;

  memset (reload_inherited,0,(2 * 10 * (1 + 1)));
  memset ((char *) reload_inheritance_insn,0,(2 * 10 * (1 + 1)) * sizeof (rtx));
  memset ((char *) reload_override_in,0,(2 * 10 * (1 + 1)) * sizeof (rtx));

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_at_all); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_op_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_op_addr_reload); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_insn); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_other_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

  for (i = 0; i < reload_n_operands; i++)
    {
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_output[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_input[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_input_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_output_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);
    }
  for (j = 0; j < n_reloads; j++)
    {
      reload_order[j] = j;
      reload_spill_index[j] = -1;

      reload_mode[j]
 = (reload_inmode[j] == VOIDmode
    || ((mode_size[(int)(reload_outmode[j])])
        > (mode_size[(int)(reload_inmode[j])])))
   ? reload_outmode[j] : reload_inmode[j];

      reload_nregs[j] = ((reload_reg_class[j]) == FP_REGS ? ((target_flags & 0x00000200) ? (((mode_size[(int)(reload_mode[j])]) + (8) - 1) / (8)) : 2 * (((mode_size[(int)(reload_mode[j])]) + (8) - 1) / (8))) : (((mode_size[(int)(reload_mode[j])]) + (((target_flags & 0x00002000) ? 8 : 4)) - 1) / (((target_flags & 0x00002000) ? 8 : 4))));

      if (reload_nregs[j] > 1)
 {
   max_group_size = ((reload_nregs[j]) > (max_group_size) ? (reload_nregs[j]) : (max_group_size));
   group_class = reg_class_superunion[(int)reload_reg_class[j]][(int)group_class];
 }



      if (reload_reg_rtx[j])
 mark_reload_reg_in_use (((reload_reg_rtx[j])->fld[0].rtint), reload_opnum[j],
    reload_when_needed[j], reload_mode[j]);
    }

  if (n_reloads > 1)
    qsort (reload_order, n_reloads, sizeof (short), reload_reg_class_lower);

  memcpy ((char *) save_reload_reg_rtx,(char *) reload_reg_rtx,sizeof reload_reg_rtx)
                        ;
  memcpy (save_reload_inherited,reload_inherited,sizeof reload_inherited);
  memcpy ((char *) save_reload_inheritance_insn,(char *) reload_inheritance_insn,sizeof reload_inheritance_insn)

                                 ;
  memcpy ((char *) save_reload_override_in,(char *) reload_override_in,sizeof reload_override_in)
                            ;
  memcpy ((char *) save_reload_spill_index,(char *) reload_spill_index,sizeof reload_spill_index)
                            ;
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used), *scan_fp_ = (reload_reg_used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_at_all), *scan_fp_ = (reload_reg_used_at_all); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_op_addr), *scan_fp_ = (reload_reg_used_in_op_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                  ;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_op_addr_reload), *scan_fp_ = (reload_reg_used_in_op_addr_reload); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                         ;

  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_insn), *scan_fp_ = (reload_reg_used_in_insn); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                               ;
  do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_other_addr), *scan_fp_ = (reload_reg_used_in_other_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                     ;

  for (i = 0; i < reload_n_operands; i++)
    {
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_output[i]), *scan_fp_ = (reload_reg_used_in_output[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                 ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_input[i]), *scan_fp_ = (reload_reg_used_in_input[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_input_addr[i]), *scan_fp_ = (reload_reg_used_in_input_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                     ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (save_reload_reg_used_in_output_addr[i]), *scan_fp_ = (reload_reg_used_in_output_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                      ;
    }







  for (inheritance = optimize > 0; inheritance >= 0; inheritance--)
    {
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_for_inherit); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = 0; } while (0);

      for (j = 0; j < n_reloads; j++)
 {
   register int r = reload_order[j];


   if (reload_out[r] == 0 && reload_in[r] == 0 && ! reload_secondary_p[r])
     continue;




   if (reload_in[r] != 0 && reload_reg_rtx[r] != 0
       && (rtx_equal_p (reload_in[r], reload_reg_rtx[r])
    || rtx_equal_p (reload_out[r], reload_reg_rtx[r])))
     continue;
   if (inheritance)
     {
       register int regno = -1;
       n64_enum_machine_mode mode;

       if (reload_in[r] == 0)
  ;
       else if (((reload_in[r])->code) == REG)
  {
    regno = ((reload_in[r])->fld[0].rtint);
    mode = ((reload_in[r])->mode);
  }
       else if (((reload_in_reg[r])->code) == REG)
  {
    regno = ((reload_in_reg[r])->fld[0].rtint);
    mode = ((reload_in_reg[r])->mode);
  }
       if (regno >= 0 && reg_last_reload_reg[regno] != 0)
  {
    i = spill_reg_order[((reg_last_reload_reg[regno])->fld[0].rtint)];

    if (reg_reloaded_contents[i] == regno
        && ((mode_size[(int)(((reg_last_reload_reg[regno])->mode))])
     >= (mode_size[(int)(mode)]))
        && mips_hard_regno_mode_ok[ (int)(reload_mode[r]) ][ (spill_regs[i]) ]
        && ((reg_class_contents[(int) reload_reg_class[r]])[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))

        && (reload_nregs[r] == max_group_size
     || ! ((reg_class_contents[(int) group_class])[(spill_regs[i]) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i]) % ((unsigned) 32))))
                      )
        && reload_reg_free_p (spill_regs[i], reload_opnum[r],
         reload_when_needed[r])
        && reload_reg_free_before_p (spill_regs[i],
         reload_opnum[r],
         reload_when_needed[r]))
      {


        int nr
   = (! ((unsigned) ((spill_regs[i]) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
        int k;

        for (k = 1; k < nr; k++)
   if (reg_reloaded_contents[spill_reg_order[spill_regs[i] + k]]
       != regno)
     break;

        if (k == nr)
   {
     int i1;
     for (i1 = 0; i1 < n_earlyclobbers; i1++)
       if (reg_overlap_mentioned_for_reload_p
    (reg_last_reload_reg[regno],
     reload_earlyclobbers[i1]))
         break;

     if (i1 != n_earlyclobbers


         || ((mode_size[(int)(reload_mode[r])])
      > (mode_size[(int)(mode)])))
       reload_override_in[r] = reg_last_reload_reg[regno];
     else
       {
         int k;



         mark_reload_reg_in_use (spill_regs[i],
            reload_opnum[r],
            reload_when_needed[r],
            reload_mode[r]);
         reload_reg_rtx[r] = reg_last_reload_reg[regno];
         reload_inherited[r] = 1;
         reload_inheritance_insn[r]
    = reg_reloaded_insn[i];
         reload_spill_index[r] = i;
         for (k = 0; k < nr; k++)
    ((reload_reg_used_for_inherit)[(spill_regs[i + k]) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i + k]) % ((unsigned) 32)))
                          ;
       }
   }
      }
  }
     }


   if (inheritance
       && reload_in[r] != 0
       && ! reload_inherited[r]
       && reload_out[r] == 0
       && ((((reload_in[r])->code) == LABEL_REF || ((reload_in[r])->code) == SYMBOL_REF || ((reload_in[r])->code) == CONST_INT || ((reload_in[r])->code) == CONST_DOUBLE || ((reload_in[r])->code) == CONST || ((reload_in[r])->code) == HIGH)
    || ((reload_in[r])->code) == PLUS
    || ((reload_in[r])->code) == REG
    || ((reload_in[r])->code) == MEM)
       && (reload_nregs[r] == max_group_size
    || ! reg_classes_intersect_p (reload_reg_class[r], group_class)))
     {
       register rtx equiv
  = find_equiv_reg (reload_in[r], insn, reload_reg_class[r],
      -1, ((void *)0), 0, reload_mode[r]);
       int regno;

       if (equiv != 0)
  {
    if (((equiv)->code) == REG)
      regno = ((equiv)->fld[0].rtint);
    else if (((equiv)->code) == SUBREG)
      {




        regno = ((((equiv)->fld[0].rtx))->fld[0].rtint) + ((equiv)->fld[1].rtint);
        equiv = gen_rtx (REG, reload_mode[r], regno);
      }
    else
      abort ();
  }



       if (equiv != 0
    && ((spill_reg_order[regno] >= 0
         && ! reload_reg_free_before_p (regno, reload_opnum[r],
            reload_when_needed[r]))
        || ! ((reg_class_contents[(int) reload_reg_class[r]])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32))))
                 ))
  equiv = 0;

       if (equiv != 0 && ((reload_reg_used_at_all)[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
  equiv = 0;

       if (equiv != 0 && ! mips_hard_regno_mode_ok[ (int)(reload_mode[r]) ][ (regno) ])
  equiv = 0;






       if (equiv != 0)
  for (i = 0; i < n_earlyclobbers; i++)
    if (reg_overlap_mentioned_for_reload_p (equiv,
         reload_earlyclobbers[i]))
      {
        reload_override_in[r] = equiv;
        equiv = 0;
        break;
      }




       if (equiv != 0 && regno_clobbered_p (regno, insn))
  {
    reload_override_in[r] = equiv;
    equiv = 0;
  }



       if (equiv != 0 && regno != (0 + 30))
  {
    reload_reg_rtx[r] = equiv;
    reload_inherited[r] = 1;


    i = spill_reg_order[regno];
    if (i >= 0)
      {
        int nr = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
        int k;
        mark_reload_reg_in_use (regno, reload_opnum[r],
           reload_when_needed[r],
           reload_mode[r]);
        for (k = 0; k < nr; k++)
   ((reload_reg_used_for_inherit)[(regno + k) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((regno + k) % ((unsigned) 32)));
      }
  }
     }



   if (reload_reg_rtx[r] != 0 || reload_optional[r] != 0)
     continue;
 }



      for (j = 0; j < n_reloads; j++)
 {
   register int r = reload_order[j];


   if (reload_out[r] == 0 && reload_in[r] == 0 && ! reload_secondary_p[r])
     continue;



   if (reload_reg_rtx[r] != 0 || reload_optional[r])
     continue;

   if (! allocate_reload_reg (r, insn, j == n_reloads - 1, inheritance))
     break;
 }


      if (j == n_reloads)
 break;

    fail:



      memcpy ((char *) reload_reg_rtx,(char *) save_reload_reg_rtx,sizeof reload_reg_rtx)
                            ;
      memcpy ((char *) reload_inherited,(char *) save_reload_inherited,sizeof reload_inherited)
                              ;
      memcpy ((char *) reload_inheritance_insn,(char *) save_reload_inheritance_insn,sizeof reload_inheritance_insn)

                                     ;
      memcpy ((char *) reload_override_in,(char *) save_reload_override_in,sizeof reload_override_in)
                                ;
      memcpy ((char *) reload_spill_index,(char *) save_reload_spill_index,sizeof reload_spill_index)
                                ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used), *scan_fp_ = (save_reload_reg_used); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_at_all), *scan_fp_ = (save_reload_reg_used_at_all); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0);
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_op_addr), *scan_fp_ = (save_reload_reg_used_in_op_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                    ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_op_addr_reload), *scan_fp_ = (save_reload_reg_used_in_op_addr_reload); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                           ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_insn), *scan_fp_ = (save_reload_reg_used_in_insn); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                 ;
      do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_other_addr), *scan_fp_ = (save_reload_reg_used_in_other_addr); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                       ;

      for (i = 0; i < reload_n_operands; i++)
 {
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_input[i]), *scan_fp_ = (save_reload_reg_used_in_input[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                         ;
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_output[i]), *scan_fp_ = (save_reload_reg_used_in_output[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                          ;
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_input_addr[i]), *scan_fp_ = (save_reload_reg_used_in_input_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                              ;
   do { register HARD_REG_ELT_TYPE *scan_tp_ = (reload_reg_used_in_output_addr[i]), *scan_fp_ = (save_reload_reg_used_in_output_addr[i]); register int i; for (i = 0; i < ((68 + 32 - 1) / 32); i++) *scan_tp_++ = *scan_fp_++; } while (0)
                                               ;
 }
    }





  for (j = 0; j < n_reloads; j++)
    {
      register int r = reload_order[j];

      if (reload_inherited[r] && reload_reg_rtx[r] != 0
   && ! reload_reg_free_before_p (true_regnum (reload_reg_rtx[r]),
      reload_opnum[r],
      reload_when_needed[r]))
 reload_inherited[r] = 0;



      if (reload_override_in[r]
   && (((reload_override_in[r])->code) == REG
       || ((reload_override_in[r])->code) == SUBREG))
 {
   int regno = true_regnum (reload_override_in[r]);
   if (spill_reg_order[regno] >= 0
       && ! reload_reg_free_before_p (regno, reload_opnum[r],
          reload_when_needed[r]))
     reload_override_in[r] = 0;
 }
    }



  for (j = 0; j < n_reloads; j++)
    if (reload_override_in[j])
      reload_in[j] = reload_override_in[j];




  for (j = 0; j < n_reloads; j++)
    if (reload_reg_rtx[j] != 0
 && ((reload_optional[j] && ! reload_inherited[j])
     || (reload_in[j] == 0 && reload_out[j] == 0
  && ! reload_secondary_p[j])))
      {
 int regno = true_regnum (reload_reg_rtx[j]);

 if (spill_reg_order[regno] >= 0)
   clear_reload_reg_in_use (regno, reload_opnum[j],
       reload_when_needed[j], reload_mode[j]);
 reload_reg_rtx[j] = 0;
      }


  for (j = 0; j < n_reloads; j++)
    {
      register int r = reload_order[j];

      i = reload_spill_index[r];




      if (reload_out[r] != 0 && ((reload_out[r])->code) == REG
   && reload_reg_rtx[r] != 0)
 {
   register int nregno = ((reload_out[r])->fld[0].rtint);
   int nr = 1;

   if (nregno < 68)
     nr = (! ((unsigned) ((nregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

   while (--nr >= 0)
     reg_has_output_reload[nregno + nr] = 1;

   if (i >= 0)
     {
       nr = (! ((unsigned) ((spill_regs[i]) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(reload_mode[r])]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
       while (--nr >= 0)
  ((reg_is_output_reload)[(spill_regs[i] + nr) / ((unsigned) 32)] |= ((HARD_REG_ELT_TYPE) (1)) << ((spill_regs[i] + nr) % ((unsigned) 32)));
     }

   if (reload_when_needed[r] != RELOAD_OTHER
       && reload_when_needed[r] != RELOAD_FOR_OUTPUT
       && reload_when_needed[r] != RELOAD_FOR_INSN)
     abort ();
 }
    }
}
static void
emit_reload_insns(rtx insn) asm("_emit_reload_insns");
static void
emit_reload_insns(rtx insn)
{
  register int j;
  rtx input_reload_insns[10];
  rtx other_input_address_reload_insns = 0;
  rtx other_input_reload_insns = 0;
  rtx input_address_reload_insns[10];
  rtx output_reload_insns[10];
  rtx output_address_reload_insns[10];
  rtx operand_reload_insns = 0;
  rtx other_operand_reload_insns = 0;
  rtx other_output_reload_insns = 0;
  rtx following_insn = ((insn)->fld[2].rtx);
  rtx before_insn = insn;
  int special;

  rtx new_spill_reg_store[68];

  for (j = 0; j < reload_n_operands; j++)
    input_reload_insns[j] = input_address_reload_insns[j]
      = output_reload_insns[j] = output_address_reload_insns[j] = 0;






  for (j = 0; j < n_reloads; j++)
    {
      register rtx old;
      rtx oldequiv_reg = 0;

      if (reload_spill_index[j] >= 0)
 new_spill_reg_store[reload_spill_index[j]] = 0;

      old = reload_in[j];
      if (old != 0 && ! reload_inherited[j]
   && ! rtx_equal_p (reload_reg_rtx[j], old)
   && reload_reg_rtx[j] != 0)
 {
   register rtx reloadreg = reload_reg_rtx[j];
   rtx oldequiv = 0;
   n64_enum_machine_mode mode;
   rtx *where;
   mode = ((old)->mode);
   if (mode == VOIDmode)
     mode = reload_inmode[j];







   if (reload_secondary_in_reload[j] >= 0
       && reload_secondary_in_icode[j] == CODE_FOR_nothing
       && optimize)
     oldequiv
       = find_equiv_reg (old, insn,
    reload_reg_class[reload_secondary_in_reload[j]],
    -1, ((void *)0), 0, mode);
   if (oldequiv == 0 && optimize
       && (((old)->code) == MEM
    || (((old)->code) == REG
        && ((old)->fld[0].rtint) >= 68
        && reg_renumber[((old)->fld[0].rtint)] < 0)))
     oldequiv = find_equiv_reg (old, insn, ALL_REGS,
           -1, ((void *)0), 0, mode);

   if (oldequiv)
     {
       int regno = true_regnum (oldequiv);




       if (spill_reg_order[regno] >= 0
    && (! reload_reg_free_p (regno, reload_opnum[j],
        reload_when_needed[j])
        || ! reload_reg_free_before_p (regno, reload_opnum[j],
           reload_when_needed[j])))
  oldequiv = 0;



       if (spill_reg_order[regno] < 0)
  {
    int k;
    for (k = 0; k < n_reloads; k++)
      if (reload_reg_rtx[k] != 0 && k != j
   && reg_overlap_mentioned_for_reload_p (reload_reg_rtx[k],
              oldequiv))
        {
   oldequiv = 0;
   break;
        }
  }






       if (oldequiv != 0
    && ((mips_regno_to_class[ (regno) ] != reload_reg_class[j]
         && (((mips_regno_to_class[ (regno) ]) == GR_REGS && (reload_reg_class[j]) == GR_REGS ? 2 : (mips_regno_to_class[ (regno) ]) == FP_REGS && (reload_reg_class[j]) == FP_REGS ? 2 : (mips_regno_to_class[ (regno) ]) == GR_REGS && (reload_reg_class[j]) == FP_REGS ? 4 : (mips_regno_to_class[ (regno) ]) == FP_REGS && (reload_reg_class[j]) == GR_REGS ? 4 : (((mips_regno_to_class[ (regno) ]) == HI_REG || (mips_regno_to_class[ (regno) ]) == LO_REG || (mips_regno_to_class[ (regno) ]) == MD_REGS || (mips_regno_to_class[ (regno) ]) == HILO_REG) && (reload_reg_class[j]) == GR_REGS) ? 6 : (((reload_reg_class[j]) == HI_REG || (reload_reg_class[j]) == LO_REG || (reload_reg_class[j]) == MD_REGS || (mips_regno_to_class[ (regno) ]) == HILO_REG) && (mips_regno_to_class[ (regno) ]) == GR_REGS) ? 6 : 12)

      >= ((mips_cpu == PROCESSOR_R4000 || mips_cpu == PROCESSOR_R6000) ? 6 : 4)))

        || (mips_secondary_reload_class (reload_reg_class[j], mode, oldequiv, 1)

     != NO_REGS)


        || ((!(target_flags & 0x00400000) && (mode_class[(int)(mode)]) == MODE_INT && ((reload_reg_class[j] == FP_REGS && mips_regno_to_class[ (regno) ] == GR_REGS) || (reload_reg_class[j] == GR_REGS && mips_regno_to_class[ (regno) ] == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (mode) == DFmode && ((reload_reg_class[j] == GR_REGS && mips_regno_to_class[ (regno) ] == FP_REGS) || (mips_regno_to_class[ (regno) ] == GR_REGS && reload_reg_class[j] == FP_REGS))))



        ))
  oldequiv = 0;
     }

   if (oldequiv == 0)
     oldequiv = old;
   else if (((oldequiv)->code) == REG)
     oldequiv_reg = oldequiv;
   else if (((oldequiv)->code) == SUBREG)
     oldequiv_reg = ((oldequiv)->fld[0].rtx);





   if (optimize && ((oldequiv)->code) == REG
       && ((oldequiv)->fld[0].rtint) < 68
       && spill_reg_order[((oldequiv)->fld[0].rtint)] >= 0
       && spill_reg_store[spill_reg_order[((oldequiv)->fld[0].rtint)]] != 0
       && find_reg_note (insn, REG_DEAD, reload_in[j])


       && count_occurrences (((insn)->fld[3].rtx), reload_in[j]) == 1)
     delete_output_reload
       (insn, j, spill_reg_store[spill_reg_order[((oldequiv)->fld[0].rtint)]]);







   if (((reloadreg)->mode) != mode)
     reloadreg = gen_rtx (REG, mode, ((reloadreg)->fld[0].rtint));
   while (((oldequiv)->code) == SUBREG && ((oldequiv)->mode) != mode)
     oldequiv = ((oldequiv)->fld[0].rtx);
   if (((oldequiv)->mode) != VOIDmode
       && mode != ((oldequiv)->mode))
     oldequiv = gen_rtx (SUBREG, mode, oldequiv, 0);


   switch (reload_when_needed[j])
     {
     case RELOAD_OTHER:
       where = &other_input_reload_insns;
       break;
     case RELOAD_FOR_INPUT:
       where = &input_reload_insns[reload_opnum[j]];
       break;
     case RELOAD_FOR_INPUT_ADDRESS:
       where = &input_address_reload_insns[reload_opnum[j]];
       break;
     case RELOAD_FOR_OUTPUT_ADDRESS:
       where = &output_address_reload_insns[reload_opnum[j]];
       break;
     case RELOAD_FOR_OPERAND_ADDRESS:
       where = &operand_reload_insns;
       break;
     case RELOAD_FOR_OPADDR_ADDR:
       where = &other_operand_reload_insns;
       break;
     case RELOAD_FOR_OTHER_ADDRESS:
       where = &other_input_address_reload_insns;
       break;
     default:
       abort ();
     }

   push_to_sequence (*where);
   special = 0;


   if (((oldequiv)->code) == POST_INC
       || ((oldequiv)->code) == POST_DEC
       || ((oldequiv)->code) == PRE_INC
       || ((oldequiv)->code) == PRE_DEC)
     {



       if (reload_secondary_in_reload[j] >= 0)
  abort ();

       special = 1;

       inc_for_reload (reloadreg, oldequiv, reload_inc[j]);
     }





   else if (optimize && ((old)->code) == REG
     && ((old)->fld[0].rtint) >= 68
     && dead_or_set_p (insn, old)


     && reload_reg_free_before_p (((reloadreg)->fld[0].rtint),
      reload_opnum[j],
      reload_when_needed[j]))
     {
       rtx temp = ((insn)->fld[1].rtx);
       while (temp && ((temp)->code) == NOTE)
  temp = ((temp)->fld[1].rtx);
       if (temp
    && ((temp)->code) == INSN
    && ((((temp)->fld[3].rtx))->code) == SET
    && ((((temp)->fld[3].rtx))->fld[0].rtx) == old

    && asm_noperands (((temp)->fld[3].rtx)) < 0

    && constraint_accepts_reg_p (insn_operand_constraint[recog_memoized (temp)][0],
            reloadreg)


    && count_occurrences (((insn)->fld[3].rtx), old) == 1

    && ! reg_mentioned_p (old, ((((temp)->fld[3].rtx))->fld[1].rtx)))
  {

    ((((temp)->fld[3].rtx))->fld[0].rtx) = reloadreg;


    if (reg_n_deaths[((old)->fld[0].rtint)] == 1
        && reg_n_sets[((old)->fld[0].rtint)] == 1)
      {
        reg_renumber[((old)->fld[0].rtint)] = ((reload_reg_rtx[j])->fld[0].rtint);
        alter_reg (((old)->fld[0].rtint), -1);
      }
    special = 1;
  }
     }



   if (! special)
     {

       rtx second_reload_reg = 0;
       n64_enum_insn_code icode;
       if (reload_secondary_in_reload[j] >= 0)
  {
    int secondary_reload = reload_secondary_in_reload[j];
    rtx real_oldequiv = oldequiv;
    rtx real_old = old;




    if (((oldequiv)->code) == REG
        && ((oldequiv)->fld[0].rtint) >= 68
        && reg_equiv_mem[((oldequiv)->fld[0].rtint)] != 0)
      real_oldequiv = reg_equiv_mem[((oldequiv)->fld[0].rtint)];

    if (((old)->code) == REG
        && ((old)->fld[0].rtint) >= 68
        && reg_equiv_mem[((old)->fld[0].rtint)] != 0)
      real_old = reg_equiv_mem[((old)->fld[0].rtint)];

    second_reload_reg = reload_reg_rtx[secondary_reload];
    icode = reload_secondary_in_icode[j];

    if ((old != oldequiv && ! rtx_equal_p (old, oldequiv))
        || (reload_in[j] != 0 && reload_out[j] != 0))
      {
        n64_enum_reg_class new_class
   = mips_secondary_reload_class (reload_reg_class[j], mode, real_oldequiv, 1)
                           ;

        if (new_class == NO_REGS)
   second_reload_reg = 0;
        else
   {
     n64_enum_insn_code new_icode;
     n64_enum_machine_mode new_mode;

     if (! ((reg_class_contents[(int) new_class])[(((second_reload_reg)->fld[0].rtint)) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((((second_reload_reg)->fld[0].rtint)) % ((unsigned) 32))))
                                   )
       oldequiv = old, real_oldequiv = real_old;
     else
       {
         new_icode = reload_in_optab[(int) mode];
         if (new_icode != CODE_FOR_nothing
      && ((insn_operand_predicate[(int) new_icode][0]
           && ! ((*insn_operand_predicate[(int) new_icode][0])
          (reloadreg, mode)))
          || (insn_operand_predicate[(int) new_icode][1]
       && ! ((*insn_operand_predicate[(int) new_icode][1])
      (real_oldequiv, mode)))))
    new_icode = CODE_FOR_nothing;

         if (new_icode == CODE_FOR_nothing)
    new_mode = mode;
         else
    new_mode = insn_operand_mode[(int) new_icode][2];

         if (((second_reload_reg)->mode) != new_mode)
    {
      if (!mips_hard_regno_mode_ok[ (int)(new_mode) ][ (((second_reload_reg)->fld[0].rtint)) ]
                   )
        oldequiv = old, real_oldequiv = real_old;
      else
        second_reload_reg
          = gen_rtx (REG, new_mode,
       ((second_reload_reg)->fld[0].rtint));
    }
       }
   }
      }
    if (second_reload_reg)
      {
        if (icode != CODE_FOR_nothing)
   {
     emit_insn ((*insn_gen_function[(int) (icode)]) (reloadreg, real_oldequiv,
            second_reload_reg));
     special = 1;
   }
        else
   {


     n64_enum_insn_code tertiary_icode
       = reload_secondary_in_icode[secondary_reload];

     if (tertiary_icode != CODE_FOR_nothing)
       {
         rtx third_reload_reg
           = reload_reg_rtx[reload_secondary_in_reload[secondary_reload]];

         emit_insn (((*insn_gen_function[(int) (tertiary_icode)])
       (second_reload_reg, real_oldequiv,
        third_reload_reg)));
       }
     else
       gen_reload (second_reload_reg, oldequiv,
     reload_opnum[j],
     reload_when_needed[j]);

     oldequiv = second_reload_reg;
   }
      }
  }


       if (! special && ! rtx_equal_p (reloadreg, oldequiv))
  gen_reload (reloadreg, oldequiv, reload_opnum[j],
       reload_when_needed[j]);
     }


   *where = get_insns ();
   end_sequence ();
 }
      if (optimize && reload_inherited[j] && reload_spill_index[j] >= 0
   && reload_in[j] != 0
   && ((reload_in[j])->code) == REG






   && spill_reg_store[reload_spill_index[j]] != 0

   && reload_reg_free_before_p (spill_regs[reload_spill_index[j]],
           reload_opnum[j], reload_when_needed[j])
   && dead_or_set_p (insn, reload_in[j])


   && count_occurrences (((insn)->fld[3].rtx), reload_in[j]) == 1)
 delete_output_reload (insn, j,
         spill_reg_store[reload_spill_index[j]]);







      old = reload_out[j];
      if (old != 0
   && reload_reg_rtx[j] != old
   && reload_reg_rtx[j] != 0)
 {
   register rtx reloadreg = reload_reg_rtx[j];
   register rtx second_reloadreg = 0;
   rtx note, p;
   n64_enum_machine_mode mode;
   int special = 0;




   if ((((old)->code) == REG || ((old)->code) == SCRATCH)
       && (note = find_reg_note (insn, REG_UNUSED, old)) != 0)
     {
       ((note)->fld[0].rtx) = reload_reg_rtx[j];
       continue;
     }

   else if (((old)->code) == SUBREG
     && ((((old)->fld[0].rtx))->code) == REG
     && 0 != (note = find_reg_note (insn, REG_UNUSED,
        ((old)->fld[0].rtx))))
     {
       ((note)->fld[0].rtx) = gen_lowpart_common (((old)->mode),
         reload_reg_rtx[j]);
       continue;
     }
   else if (((old)->code) == SCRATCH)


     continue;
   if (((insn)->code) == JUMP_INSN)
     abort ();

   if (reload_when_needed[j] == RELOAD_OTHER)
     start_sequence ();
   else
     push_to_sequence (output_reload_insns[reload_opnum[j]]);




   mode = ((old)->mode);
   if (mode == VOIDmode)
     {

       if (asm_noperands (((insn)->fld[3].rtx)) < 0)

  fatal_insn ("VOIDmode on an output", insn);
       error_for_asm (insn, "output operand is constant in `asm'");

       mode = word_mode;
       old = gen_rtx (REG, mode, ((reloadreg)->fld[0].rtint));
     }

   if (((reloadreg)->mode) != mode)
     reloadreg = gen_rtx (REG, mode, ((reloadreg)->fld[0].rtint));







   if (reload_secondary_out_reload[j] >= 0)
     {
       rtx real_old = old;

       if (((old)->code) == REG && ((old)->fld[0].rtint) >= 68
    && reg_equiv_mem[((old)->fld[0].rtint)] != 0)
  real_old = reg_equiv_mem[((old)->fld[0].rtint)];

       if((mips_secondary_reload_class (reload_reg_class[j], mode, real_old, 0)

    != NO_REGS))
  {
    second_reloadreg = reloadreg;
    reloadreg = reload_reg_rtx[reload_secondary_out_reload[j]];



    if (reload_secondary_out_icode[j] != CODE_FOR_nothing)
      {
        emit_insn (((*insn_gen_function[(int) (reload_secondary_out_icode[j])])
      (real_old, second_reloadreg, reloadreg)));
        special = 1;
      }
    else
      {



        int secondary_reload = reload_secondary_out_reload[j];
        n64_enum_insn_code tertiary_icode
   = reload_secondary_out_icode[secondary_reload];

        if (((reloadreg)->mode) != mode)
   reloadreg = gen_rtx (REG, mode, ((reloadreg)->fld[0].rtint));

        if (tertiary_icode != CODE_FOR_nothing)
   {
     rtx third_reloadreg
       = reload_reg_rtx[reload_secondary_out_reload[secondary_reload]];
     rtx tem;
     if (((real_old)->code) == SUBREG
         && ((mode_size[(int)(((real_old)->mode))])
      > (mode_size[(int)(((((real_old)->fld[0].rtx))->mode))]))
         && 0 != (tem = gen_lowpart_common
           (((((real_old)->fld[0].rtx))->mode),
     reloadreg)))
       real_old = ((real_old)->fld[0].rtx), reloadreg = tem;

     gen_reload (reloadreg, second_reloadreg,
          reload_opnum[j], reload_when_needed[j]);
     emit_insn (((*insn_gen_function[(int) (tertiary_icode)])
          (real_old, reloadreg, third_reloadreg)));
     special = 1;
   }

        else



   gen_reload (reloadreg, second_reloadreg,
        reload_opnum[j], reload_when_needed[j]);
      }
  }
     }



   if (! special)
     gen_reload (old, reloadreg, reload_opnum[j],
   reload_when_needed[j]);
   for (p = get_insns (); p; p = ((p)->fld[2].rtx))
     if ((rtx_class[(int)(((p)->code))]) == 'i')
       {




  note_stores (((p)->fld[3].rtx), forget_old_reloads_1);

  if (reg_mentioned_p (reload_reg_rtx[j], ((p)->fld[3].rtx))
      && reload_spill_index[j] >= 0)
    new_spill_reg_store[reload_spill_index[j]] = p;
       }

   if (reload_when_needed[j] == RELOAD_OTHER)
     {
       if (other_output_reload_insns)
  emit_insns (other_output_reload_insns);
       other_output_reload_insns = get_insns ();
     }
   else
     output_reload_insns[reload_opnum[j]] = get_insns ();

   end_sequence ();
 }
    }
  emit_insns_before (other_input_address_reload_insns, before_insn);
  emit_insns_before (other_input_reload_insns, before_insn);

  for (j = 0; j < reload_n_operands; j++)
    {
      emit_insns_before (input_address_reload_insns[j], before_insn);
      emit_insns_before (input_reload_insns[j], before_insn);
    }

  emit_insns_before (other_operand_reload_insns, before_insn);
  emit_insns_before (operand_reload_insns, before_insn);

  for (j = 0; j < reload_n_operands; j++)
    {
      emit_insns_before (output_address_reload_insns[j], following_insn);
      emit_insns_before (output_reload_insns[j], following_insn);
    }

  emit_insns_before (other_output_reload_insns, following_insn);
  for (j = 0; j < n_reloads; j++)
    {
      register int r = reload_order[j];
      register int i = reload_spill_index[r];
      if (i >= 0 && reload_reg_rtx[r] != 0
   && reload_reg_reaches_end_p (spill_regs[i], reload_opnum[r],
           reload_when_needed[r]))
 {


   int nr
     = (! ((unsigned) ((spill_regs[i]) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));
   int k;

   for (k = 0; k < nr; k++)
     {
       reg_reloaded_contents[spill_reg_order[spill_regs[i] + k]] = -1;
       reg_reloaded_insn[spill_reg_order[spill_regs[i] + k]] = 0;
     }


   if (reload_out[r] != 0 && ((reload_out[r])->code) == REG)
     {
       register int nregno = ((reload_out[r])->fld[0].rtint);
       int nnr = (nregno >= 68 ? 1
    : (! ((unsigned) ((nregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                       );

       spill_reg_store[i] = new_spill_reg_store[i];
       reg_last_reload_reg[nregno] = reload_reg_rtx[r];







       if (nregno < 68)
  for (k = 1; k < nnr; k++)
    reg_last_reload_reg[nregno + k]
      = (nr == nnr ? gen_rtx (REG,
         reg_raw_mode[((reload_reg_rtx[r])->fld[0].rtint) + k],
         ((reload_reg_rtx[r])->fld[0].rtint) + k)
         : 0);


       for (k = 0; k < nr; k++)
  {
    reg_reloaded_contents[spill_reg_order[spill_regs[i] + k]]
      = (nregno >= 68 || nr != nnr ? nregno
         : nregno + k);
    reg_reloaded_insn[spill_reg_order[spill_regs[i] + k]] = insn;
  }
     }




   else if (reload_out[r] == 0
     && reload_in[r] != 0
     && ((((reload_in[r])->code) == REG
   && ! reg_has_output_reload[((reload_in[r])->fld[0].rtint)]
         || (((reload_in_reg[r])->code) == REG
      && ! reg_has_output_reload[((reload_in_reg[r])->fld[0].rtint)]))))
     {
       register int nregno;
       int nnr;

       if (((reload_in[r])->code) == REG)
  nregno = ((reload_in[r])->fld[0].rtint);
       else
  nregno = ((reload_in_reg[r])->fld[0].rtint);

       nnr = (nregno >= 68 ? 1
       : (! ((unsigned) ((nregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reload_reg_rtx[r])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)))
                                   );

       reg_last_reload_reg[nregno] = reload_reg_rtx[r];

       if (nregno < 68)
  for (k = 1; k < nnr; k++)
    reg_last_reload_reg[nregno + k]
      = (nr == nnr ? gen_rtx (REG,
         reg_raw_mode[((reload_reg_rtx[r])->fld[0].rtint) + k],
         ((reload_reg_rtx[r])->fld[0].rtint) + k)
         : 0);



       if (! reload_inherited[r])
  spill_reg_store[i] = 0;

       for (k = 0; k < nr; k++)
  {
    reg_reloaded_contents[spill_reg_order[spill_regs[i] + k]]
      = (nregno >= 68 || nr != nnr ? nregno
         : nregno + k);
    reg_reloaded_insn[spill_reg_order[spill_regs[i] + k]]
      = insn;
  }
     }
 }
      if (i < 0 && reload_out[r] != 0 && ((reload_out[r])->code) == REG)
 {
   register int nregno = ((reload_out[r])->fld[0].rtint);
   if (nregno >= 68)
     reg_last_reload_reg[nregno] = 0;
   else
     {
       int num_regs = (! ((unsigned) ((nregno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(((reload_out[r])->mode))]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(((reload_out[r])->mode))]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4)));

       while (num_regs-- > 0)
  reg_last_reload_reg[nregno + num_regs] = 0;
     }
 }
    }
}







rtx
gen_reload(rtx out, rtx in, int opnum, n64_enum_reload_type type) asm("_gen_reload");
rtx
gen_reload(rtx out, rtx in, int opnum, n64_enum_reload_type type)
{
  rtx last = get_last_insn ();
  rtx tem;



  if (((in)->code) == SUBREG
      && ((mode_size[(int)(((in)->mode))])
   > (mode_size[(int)(((((in)->fld[0].rtx))->mode))]))
      && (tem = gen_lowpart_common (((((in)->fld[0].rtx))->mode), out)) != 0)
    in = ((in)->fld[0].rtx), out = tem;
  else if (((out)->code) == SUBREG
      && ((mode_size[(int)(((out)->mode))])
   > (mode_size[(int)(((((out)->fld[0].rtx))->mode))]))
      && (tem = gen_lowpart_common (((((out)->fld[0].rtx))->mode), in)) != 0)
    out = ((out)->fld[0].rtx), in = tem;
  if (((in)->code) == PLUS
      && (((((in)->fld[0].rtx))->code) == REG
   || ((((in)->fld[0].rtx))->code) == MEM)
      && (((((in)->fld[1].rtx))->code) == REG
   || (((((in)->fld[1].rtx))->code) == LABEL_REF || ((((in)->fld[1].rtx))->code) == SYMBOL_REF || ((((in)->fld[1].rtx))->code) == CONST_INT || ((((in)->fld[1].rtx))->code) == CONST_DOUBLE || ((((in)->fld[1].rtx))->code) == CONST || ((((in)->fld[1].rtx))->code) == HIGH)
   || ((((in)->fld[1].rtx))->code) == MEM))
    {
      rtx op0, op1, tem, insn;
      int code;

      op0 = find_replacement (&((in)->fld[0].rtx));
      op1 = find_replacement (&((in)->fld[1].rtx));
      if (((((in)->fld[1].rtx))->code) == REG
   && ((out)->fld[0].rtint) == ((((in)->fld[1].rtx))->fld[0].rtint))
 tem = op0, op0 = op1, op1 = tem;

      if (op0 != ((in)->fld[0].rtx) || op1 != ((in)->fld[1].rtx))
 in = gen_rtx (PLUS, ((in)->mode), op0, op1);

      insn = emit_insn (gen_rtx (SET, VOIDmode, out, in));
      code = recog_memoized (insn);

      if (code >= 0)
 {
   insn_extract (insn);



   if (constrain_operands (code, 1))
     return insn;
 }

      delete_insns_since (last);
      if ((((op1)->code) == LABEL_REF || ((op1)->code) == SYMBOL_REF || ((op1)->code) == CONST_INT || ((op1)->code) == CONST_DOUBLE || ((op1)->code) == CONST || ((op1)->code) == HIGH) || ((op1)->code) == MEM
   || (((op1)->code) == REG
       && ((op1)->fld[0].rtint) >= 68))
 tem = op0, op0 = op1, op1 = tem;

      emit_insn (gen_move_insn (out, op0));





      if (rtx_equal_p (op0, op1))
 op1 = out;

      insn = emit_insn (gen_add2_insn (out, op1));




      code = recog_memoized (insn);

      if (code >= 0)
 {
   insn_extract (insn);



   if (constrain_operands (code, 1))
     return insn;
 }

      delete_insns_since (last);

      emit_insn (gen_move_insn (out, op1));
      emit_insn (gen_add2_insn (out, op0));
    }



  else if (((in)->code) == REG && ((in)->fld[0].rtint) < 68
    && ((out)->code) == REG && ((out)->fld[0].rtint) < 68
    && ((!(target_flags & 0x00400000) && (mode_class[(int)(((out)->mode))]) == MODE_INT && ((mips_regno_to_class[ (((in)->fld[0].rtint)) ] == FP_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == GR_REGS) || (mips_regno_to_class[ (((in)->fld[0].rtint)) ] == GR_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == FP_REGS))) || ((target_flags & 0x00000200) && !(target_flags & 0x00002000) && (((out)->mode)) == DFmode && ((mips_regno_to_class[ (((in)->fld[0].rtint)) ] == GR_REGS && mips_regno_to_class[ (((out)->fld[0].rtint)) ] == FP_REGS) || (mips_regno_to_class[ (((out)->fld[0].rtint)) ] == GR_REGS && mips_regno_to_class[ (((in)->fld[0].rtint)) ] == FP_REGS))))

                          )
    {

      rtx loc = get_secondary_mem (in, ((out)->mode), opnum, type);

      if (((loc)->mode) != ((out)->mode))
 out = gen_rtx (REG, ((loc)->mode), ((out)->fld[0].rtint));

      if (((loc)->mode) != ((in)->mode))
 in = gen_rtx (REG, ((loc)->mode), ((in)->fld[0].rtint));

      emit_insn (gen_move_insn (loc, in));
      emit_insn (gen_move_insn (out, loc));
    }



  else if ((rtx_class[(int)(((in)->code))]) == 'o' || ((in)->code) == SUBREG)
    emit_insn (gen_move_insn (out, in));







  else
    emit_insn (gen_rtx (SET, VOIDmode, out, in));







  return last ? ((last)->fld[2].rtx) : get_insns ();
}
static void
delete_output_reload(rtx insn, int j, rtx output_reload_insn) asm("_delete_output_reload");
static void
delete_output_reload(rtx insn, int j, rtx output_reload_insn)
{
  register rtx i1;



  rtx reg = reload_in[j];
  while (((reg)->code) == SUBREG)
    reg = ((reg)->fld[0].rtx);






  for (i1 = ((output_reload_insn)->fld[2].rtx);
       i1 != insn; i1 = ((i1)->fld[2].rtx))
    {
      if (((i1)->code) == CODE_LABEL || ((i1)->code) == JUMP_INSN)
 return;
      if ((((i1)->code) == INSN || ((i1)->code) == CALL_INSN)
   && reg_mentioned_p (reg, ((i1)->fld[3].rtx)))
 return;
    }

  if (cannot_omit_stores[((reg)->fld[0].rtint)])
    return;



  if (reload_out[j] == reload_in[j])
    delete_insn (output_reload_insn);




  else if (reg_n_deaths[((reg)->fld[0].rtint)] == 1
    && reg_basic_block[((reg)->fld[0].rtint)] >= 0
    && find_regno_note (insn, REG_DEAD, ((reg)->fld[0].rtint)))
    {
      rtx i2;






      for (i2 = ((insn)->fld[1].rtx); i2; i2 = ((i2)->fld[1].rtx))
 {
   rtx set = single_set (i2);



   if (set != 0 && ((set)->fld[0].rtx) == reg)
     continue;
   if (((i2)->code) == CODE_LABEL
       || ((i2)->code) == JUMP_INSN)
     break;
   if ((((i2)->code) == INSN || ((i2)->code) == CALL_INSN)
       && reg_mentioned_p (reg, ((i2)->fld[3].rtx)))


     return;
 }


      for (i2 = ((insn)->fld[1].rtx); i2; i2 = ((i2)->fld[1].rtx))
 {
   rtx set = single_set (i2);

   if (set != 0 && ((set)->fld[0].rtx) == reg)
     delete_insn (i2);
   if (((i2)->code) == CODE_LABEL
       || ((i2)->code) == JUMP_INSN)
     break;
 }



      reg_renumber[((reg)->fld[0].rtint)] = ((reload_reg_rtx[j])->fld[0].rtint);
      alter_reg (((reg)->fld[0].rtint), -1);
    }
}
static void
inc_for_reload(rtx reloadreg, rtx value, int inc_amount) asm("_inc_for_reload");
static void
inc_for_reload(rtx reloadreg, rtx value, int inc_amount)
{

  rtx incloc = ((value)->fld[0].rtx);

  int post = (((value)->code) == POST_DEC || ((value)->code) == POST_INC);
  rtx last;
  rtx inc;
  rtx add_insn;
  int code;





  if (((incloc)->code) == REG)
    reg_last_reload_reg[((incloc)->fld[0].rtint)] = 0;

  if (((value)->code) == PRE_DEC || ((value)->code) == POST_DEC)
    inc_amount = - inc_amount;

  inc = gen_rtx (CONST_INT, VOIDmode, (int) (inc_amount));


  if (post)
    emit_insn (gen_move_insn (reloadreg, incloc));




  last = get_last_insn ();
  add_insn = emit_insn (gen_rtx (SET, VOIDmode, incloc,
     gen_rtx (PLUS, ((incloc)->mode),
       incloc, inc)));

  code = recog_memoized (add_insn);
  if (code >= 0)
    {
      insn_extract (add_insn);
      if (constrain_operands (code, 1))
 {




   if (! post)
     emit_insn (gen_move_insn (reloadreg, incloc));

   return;
 }
    }

  delete_insns_since (last);






  if (! post)
    {
      emit_insn (gen_move_insn (reloadreg, incloc));
      emit_insn (gen_add2_insn (reloadreg, inc));
      emit_insn (gen_move_insn (incloc, reloadreg));
    }
  else
    {
      emit_insn (gen_add2_insn (reloadreg, inc));
      emit_insn (gen_move_insn (incloc, reloadreg));
      emit_insn (gen_add2_insn (reloadreg, gen_rtx (CONST_INT, VOIDmode, (int) (-inc_amount))));
    }

  return;
}




static int
constraint_accepts_reg_p(char *string, rtx reg) asm("_constraint_accepts_reg_p");
static int
constraint_accepts_reg_p(char *string, rtx reg)
{
  int value = 0;
  int regno = true_regnum (reg);
  int c;


  value = 0;

  while (1)
    switch (c = *string++)
      {
      case 0:

 return value;
      case ',':

 if (value == 0)
   return 0;

 value = 0;
 break;
      case 'g':
      case 'r':

 if (((reg_class_contents[(int) GR_REGS])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
   value = 1;
 break;
      default:

 {
   n64_enum_reg_class cxx_class = mips_char_to_class[ (c) ];

   if (((reg_class_contents[(int) cxx_class])[(regno) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno) % ((unsigned) 32)))))
     value = 1;
 }
      }
}




static int
count_occurrences(register rtx x, register rtx find) asm("_count_occurrences");
static int
count_occurrences(register rtx x, register rtx find)
{
  register int i, j;
  register n64_enum_rtx_code code;
  register char *format_ptr;
  int count;

  if (x == find)
    return 1;
  if (x == 0)
    return 0;

  code = ((x)->code);

  switch (code)
    {
    case REG:
    case QUEUED:
    case CONST_INT:
    case CONST_DOUBLE:
    case SYMBOL_REF:
    case CODE_LABEL:
    case PC:
    case CC0:
      return 0;

    case SET:
      if (((x)->fld[0].rtx) == find)
 return count_occurrences (((x)->fld[1].rtx), find);
      break;
    }

  format_ptr = (rtx_format[(int)(code)]);
  count = 0;

  for (i = 0; i < (rtx_length[(int)(code)]); i++)
    {
      switch (*format_ptr++)
 {
 case 'e':
   count += count_occurrences (((x)->fld[i].rtx), find);
   break;

 case 'E':
   if (((x)->fld[i].rtvec) != 
                     ((void *)0)
                         )
     {
       for (j = 0; j < ((x)->fld[i].rtvec->num_elem); j++)
  count += count_occurrences (((x)->fld[i].rtvec->elem[j].rtx), find);
     }
   break;
 }
    }
  return count;
}

