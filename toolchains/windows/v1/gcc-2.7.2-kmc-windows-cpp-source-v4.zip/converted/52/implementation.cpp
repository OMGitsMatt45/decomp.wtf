// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/recog.c
/* Subroutines used by or related to instruction recognition.
   Copyright (C) 1987, 88, 91, 92, 93, 1994 Free Software Foundation, Inc.

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int recog(...) asm("_recog");
extern int rtx_equal_p(...) asm("_rtx_equal_p");
extern int constrain_operands(...) asm("_constrain_operands");
extern int mode_dependent_address_p(...) asm("_mode_dependent_address_p");
extern int dead_or_set_p(...) asm("_dead_or_set_p");
extern int pic_address_needs_scratch(...) asm("_pic_address_needs_scratch");
extern int operands_match_p(...) asm("_operands_match_p");
extern int reg_fits_class_p(...) asm("_reg_fits_class_p");
extern int exact_log2_wide(...) asm("_exact_log2_wide");
extern int safe_from_earlyclobber(...) asm("_safe_from_earlyclobber");
struct n64_tag_function_unit_desc;
struct n64_tag_funny_match;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");
enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;







union tree_node;





enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx(...) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union tree_node *) asm("_immed_real_const");
extern union tree_node *make_tree (union tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");

enum n64_cpp_enum_attr_type{TYPE_UNKNOWN, TYPE_BRANCH, TYPE_JUMP, TYPE_CALL, TYPE_LOAD, TYPE_STORE, TYPE_MOVE, TYPE_XFER, TYPE_HILO, TYPE_ARITH, TYPE_DARITH, TYPE_IMUL, TYPE_IDIV, TYPE_ICMP, TYPE_FADD, TYPE_FMUL, TYPE_FMADD, TYPE_FDIV, TYPE_FABS, TYPE_FNEG, TYPE_FCMP, TYPE_FCVT, TYPE_FSQRT, TYPE_MULTI, TYPE_NOP};
typedef __underlying_type(enum n64_cpp_enum_attr_type) n64_enum_attr_type;

extern n64_enum_attr_type get_attr_type(...) asm("_get_attr_type");


enum n64_cpp_enum_attr_mode{MODE_UNKNOWN, MODE_NONE, MODE_QI, MODE_HI, MODE_SI, MODE_DI, MODE_SF, MODE_DF, MODE_FPSW};
typedef __underlying_type(enum n64_cpp_enum_attr_mode) n64_enum_attr_mode;

extern n64_enum_attr_mode get_attr_mode(...) asm("_get_attr_mode");


extern int get_attr_length(...) asm("_get_attr_length");
extern void init_lengths(...) asm("_init_lengths");
extern void shorten_branches (rtx) asm("_shorten_branches");
extern int insn_default_length (rtx) asm("_insn_default_length");
extern int insn_variable_length_p (rtx) asm("_insn_variable_length_p");
extern int insn_current_length (rtx) asm("_insn_current_length");

extern int *insn_addresses;
extern int insn_current_address;


enum n64_cpp_enum_attr_dslot{DSLOT_NO, DSLOT_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_dslot) n64_enum_attr_dslot;

extern n64_enum_attr_dslot get_attr_dslot(...) asm("_get_attr_dslot");


enum n64_cpp_enum_attr_cpu{CPU_DEFAULT, CPU_R3000, CPU_R6000, CPU_R4000, CPU_R4600, CPU_R4650, CPU_R8000};
typedef __underlying_type(enum n64_cpp_enum_attr_cpu) n64_enum_attr_cpu;

extern n64_enum_attr_cpu get_attr_cpu(void) asm("_get_attr_cpu");


enum n64_cpp_enum_attr_branch_likely{BRANCH_LIKELY_NO, BRANCH_LIKELY_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_branch_likely) n64_enum_attr_branch_likely;

extern n64_enum_attr_branch_likely get_attr_branch_likely(void) asm("_get_attr_branch_likely");


enum n64_cpp_enum_attr_abicalls{ABICALLS_NO, ABICALLS_YES};
typedef __underlying_type(enum n64_cpp_enum_attr_abicalls) n64_enum_attr_abicalls;

extern n64_enum_attr_abicalls get_attr_abicalls(void) asm("_get_attr_abicalls");


extern int num_delay_slots (rtx) asm("_num_delay_slots");
extern int eligible_for_delay (rtx, int, rtx, int) asm("_eligible_for_delay");

extern int const_num_delay_slots (rtx) asm("_const_num_delay_slots");


extern int eligible_for_annul_false(...) asm("_eligible_for_annul_false");


extern int result_ready_cost (rtx) asm("_result_ready_cost");
extern int function_units_used (rtx) asm("_function_units_used");

extern struct n64_tag_function_unit_desc
{
  char *name;
  int bitmask;
  int multiplicity;
  int simultaneity;
  int default_cost;
  int max_issue_delay;
  int (*ready_cost_function)(...);
  int (*conflict_cost_function)(...);
  int max_blockage;
  unsigned int (*blockage_range_function)(...);
  int (*blockage_function)(...);
} function_units[];
extern rtx gen_adddf3 (rtx, rtx, rtx) asm("_gen_adddf3");
extern rtx gen_addsf3 (rtx, rtx, rtx) asm("_gen_addsf3");
extern rtx gen_addsi3 (rtx, rtx, rtx) asm("_gen_addsi3");
extern rtx gen_addsi3_internal (rtx, rtx, rtx) asm("_gen_addsi3_internal");
extern rtx gen_adddi3 (rtx, rtx, rtx) asm("_gen_adddi3");
extern rtx gen_adddi3_internal_1 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_1");
extern rtx gen_adddi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_adddi3_internal_2");
extern rtx gen_adddi3_internal_3 (rtx, rtx, rtx) asm("_gen_adddi3_internal_3");
extern rtx gen_addsi3_internal_2 (rtx, rtx, rtx) asm("_gen_addsi3_internal_2");
extern rtx gen_subdf3 (rtx, rtx, rtx) asm("_gen_subdf3");
extern rtx gen_subsf3 (rtx, rtx, rtx) asm("_gen_subsf3");
extern rtx gen_subsi3 (rtx, rtx, rtx) asm("_gen_subsi3");
extern rtx gen_subsi3_internal (rtx, rtx, rtx) asm("_gen_subsi3_internal");
extern rtx gen_subdi3 (rtx, rtx, rtx) asm("_gen_subdi3");
extern rtx gen_subdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal");
extern rtx gen_subdi3_internal_2 (rtx, rtx, rtx, rtx) asm("_gen_subdi3_internal_2");
extern rtx gen_subdi3_internal_3 (rtx, rtx, rtx) asm("_gen_subdi3_internal_3");
extern rtx gen_subsi3_internal_2 (rtx, rtx, rtx) asm("_gen_subsi3_internal_2");
extern rtx gen_muldf3 (rtx, rtx, rtx) asm("_gen_muldf3");
extern rtx gen_mulsf3 (rtx, rtx, rtx) asm("_gen_mulsf3");
extern rtx gen_mulsi3 (rtx, rtx, rtx) asm("_gen_mulsi3");
extern rtx gen_mulsi3_internal (rtx, rtx, rtx) asm("_gen_mulsi3_internal");
extern rtx gen_mulsi3_r4000 (rtx, rtx, rtx) asm("_gen_mulsi3_r4000");
extern rtx gen_mulsi3_r4650 (rtx, rtx, rtx) asm("_gen_mulsi3_r4650");
extern rtx gen_muldi3 (rtx, rtx, rtx) asm("_gen_muldi3");
extern rtx gen_muldi3_internal (rtx, rtx, rtx) asm("_gen_muldi3_internal");
extern rtx gen_muldi3_r4000 (rtx, rtx, rtx) asm("_gen_muldi3_r4000");
extern rtx gen_mulsidi3 (rtx, rtx, rtx) asm("_gen_mulsidi3");
extern rtx gen_mulsidi3_internal (rtx, rtx, rtx) asm("_gen_mulsidi3_internal");
extern rtx gen_mulsidi3_64bit (rtx, rtx, rtx) asm("_gen_mulsidi3_64bit");
extern rtx gen_smulsi3_highpart (rtx, rtx, rtx) asm("_gen_smulsi3_highpart");
extern rtx gen_umulsidi3 (rtx, rtx, rtx) asm("_gen_umulsidi3");
extern rtx gen_umulsidi3_internal (rtx, rtx, rtx) asm("_gen_umulsidi3_internal");
extern rtx gen_umulsidi3_64bit (rtx, rtx, rtx) asm("_gen_umulsidi3_64bit");
extern rtx gen_umulsi3_highpart (rtx, rtx, rtx) asm("_gen_umulsi3_highpart");
extern rtx gen_smuldi3_highpart (rtx, rtx, rtx) asm("_gen_smuldi3_highpart");
extern rtx gen_umuldi3_highpart (rtx, rtx, rtx) asm("_gen_umuldi3_highpart");
extern rtx gen_madsi (rtx, rtx, rtx) asm("_gen_madsi");
extern rtx gen_maddi (rtx, rtx, rtx) asm("_gen_maddi");
extern rtx gen_maddi_64bit (rtx, rtx, rtx) asm("_gen_maddi_64bit");
extern rtx gen_umaddi (rtx, rtx, rtx) asm("_gen_umaddi");
extern rtx gen_umaddi_64bit (rtx, rtx, rtx) asm("_gen_umaddi_64bit");
extern rtx gen_divdf3 (rtx, rtx, rtx) asm("_gen_divdf3");
extern rtx gen_divsf3 (rtx, rtx, rtx) asm("_gen_divsf3");
extern rtx gen_divmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_divmodsi4");
extern rtx gen_divmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_divmoddi4");
extern rtx gen_udivmodsi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmodsi4");
extern rtx gen_udivmoddi4 (rtx, rtx, rtx, rtx) asm("_gen_udivmoddi4");
extern rtx gen_divsi3 (rtx, rtx, rtx) asm("_gen_divsi3");
extern rtx gen_divdi3 (rtx, rtx, rtx) asm("_gen_divdi3");
extern rtx gen_modsi3 (rtx, rtx, rtx) asm("_gen_modsi3");
extern rtx gen_moddi3 (rtx, rtx, rtx) asm("_gen_moddi3");
extern rtx gen_udivsi3 (rtx, rtx, rtx) asm("_gen_udivsi3");
extern rtx gen_udivdi3 (rtx, rtx, rtx) asm("_gen_udivdi3");
extern rtx gen_umodsi3 (rtx, rtx, rtx) asm("_gen_umodsi3");
extern rtx gen_umoddi3 (rtx, rtx, rtx) asm("_gen_umoddi3");
extern rtx gen_sqrtdf2 (rtx, rtx) asm("_gen_sqrtdf2");
extern rtx gen_sqrtsf2 (rtx, rtx) asm("_gen_sqrtsf2");
extern rtx gen_abssi2 (rtx, rtx) asm("_gen_abssi2");
extern rtx gen_absdi2 (rtx, rtx) asm("_gen_absdi2");
extern rtx gen_absdf2 (rtx, rtx) asm("_gen_absdf2");
extern rtx gen_abssf2 (rtx, rtx) asm("_gen_abssf2");
extern rtx gen_ffssi2 (rtx, rtx) asm("_gen_ffssi2");
extern rtx gen_ffsdi2 (rtx, rtx) asm("_gen_ffsdi2");
extern rtx gen_negsi2 (rtx, rtx) asm("_gen_negsi2");
extern rtx gen_negdi2 (rtx, rtx) asm("_gen_negdi2");
extern rtx gen_negdi2_internal (rtx, rtx, rtx) asm("_gen_negdi2_internal");
extern rtx gen_negdi2_internal_2 (rtx, rtx) asm("_gen_negdi2_internal_2");
extern rtx gen_negdf2 (rtx, rtx) asm("_gen_negdf2");
extern rtx gen_negsf2 (rtx, rtx) asm("_gen_negsf2");
extern rtx gen_one_cmplsi2 (rtx, rtx) asm("_gen_one_cmplsi2");
extern rtx gen_one_cmpldi2 (rtx, rtx) asm("_gen_one_cmpldi2");
extern rtx gen_norsi3 (rtx, rtx, rtx) asm("_gen_norsi3");
extern rtx gen_nordi3 (rtx, rtx, rtx) asm("_gen_nordi3");
extern rtx gen_andsi3 (rtx, rtx, rtx) asm("_gen_andsi3");
extern rtx gen_anddi3 (rtx, rtx, rtx) asm("_gen_anddi3");
extern rtx gen_anddi3_internal1 (rtx, rtx, rtx) asm("_gen_anddi3_internal1");
extern rtx gen_iorsi3 (rtx, rtx, rtx) asm("_gen_iorsi3");
extern rtx gen_iordi3 (rtx, rtx, rtx) asm("_gen_iordi3");
extern rtx gen_xorsi3 (rtx, rtx, rtx) asm("_gen_xorsi3");
extern rtx gen_xordi3 (rtx, rtx, rtx) asm("_gen_xordi3");
extern rtx gen_xordi3_immed (rtx, rtx, rtx) asm("_gen_xordi3_immed");
extern rtx gen_truncdfsf2 (rtx, rtx) asm("_gen_truncdfsf2");
extern rtx gen_truncdisi2 (rtx, rtx) asm("_gen_truncdisi2");
extern rtx gen_truncdihi2 (rtx, rtx) asm("_gen_truncdihi2");
extern rtx gen_truncdiqi2 (rtx, rtx) asm("_gen_truncdiqi2");
extern rtx gen_zero_extendsidi2 (rtx, rtx) asm("_gen_zero_extendsidi2");
extern rtx gen_zero_extendsidi2_internal (rtx, rtx) asm("_gen_zero_extendsidi2_internal");
extern rtx gen_zero_extendhisi2 (rtx, rtx) asm("_gen_zero_extendhisi2");
extern rtx gen_zero_extendhidi2 (rtx, rtx) asm("_gen_zero_extendhidi2");
extern rtx gen_zero_extendqihi2 (rtx, rtx) asm("_gen_zero_extendqihi2");
extern rtx gen_zero_extendqisi2 (rtx, rtx) asm("_gen_zero_extendqisi2");
extern rtx gen_zero_extendqidi2 (rtx, rtx) asm("_gen_zero_extendqidi2");
extern rtx gen_extendsidi2 (rtx, rtx) asm("_gen_extendsidi2");
extern rtx gen_extendsidi2_internal (rtx, rtx) asm("_gen_extendsidi2_internal");
extern rtx gen_extendhidi2 (rtx, rtx) asm("_gen_extendhidi2");
extern rtx gen_extendhidi2_internal (rtx, rtx) asm("_gen_extendhidi2_internal");
extern rtx gen_extendhisi2 (rtx, rtx) asm("_gen_extendhisi2");
extern rtx gen_extendhisi2_internal (rtx, rtx) asm("_gen_extendhisi2_internal");
extern rtx gen_extendqihi2 (rtx, rtx) asm("_gen_extendqihi2");
extern rtx gen_extendqihi2_internal (rtx, rtx) asm("_gen_extendqihi2_internal");
extern rtx gen_extendqisi2 (rtx, rtx) asm("_gen_extendqisi2");
extern rtx gen_extendqisi2_insn (rtx, rtx) asm("_gen_extendqisi2_insn");
extern rtx gen_extendqidi2 (rtx, rtx) asm("_gen_extendqidi2");
extern rtx gen_extendqidi2_insn (rtx, rtx) asm("_gen_extendqidi2_insn");
extern rtx gen_extendsfdf2 (rtx, rtx) asm("_gen_extendsfdf2");
extern rtx gen_fix_truncdfsi2 (rtx, rtx) asm("_gen_fix_truncdfsi2");
extern rtx gen_fix_truncsfsi2 (rtx, rtx) asm("_gen_fix_truncsfsi2");
extern rtx gen_fix_truncdfdi2 (rtx, rtx) asm("_gen_fix_truncdfdi2");
extern rtx gen_fix_truncsfdi2 (rtx, rtx) asm("_gen_fix_truncsfdi2");
extern rtx gen_floatsidf2 (rtx, rtx) asm("_gen_floatsidf2");
extern rtx gen_floatdidf2 (rtx, rtx) asm("_gen_floatdidf2");
extern rtx gen_floatsisf2 (rtx, rtx) asm("_gen_floatsisf2");
extern rtx gen_floatdisf2 (rtx, rtx) asm("_gen_floatdisf2");
extern rtx gen_fixuns_truncdfsi2 (rtx, rtx) asm("_gen_fixuns_truncdfsi2");
extern rtx gen_fixuns_truncdfdi2 (rtx, rtx) asm("_gen_fixuns_truncdfdi2");
extern rtx gen_fixuns_truncsfsi2 (rtx, rtx) asm("_gen_fixuns_truncsfsi2");
extern rtx gen_fixuns_truncsfdi2 (rtx, rtx) asm("_gen_fixuns_truncsfdi2");
extern rtx gen_extv (rtx, rtx, rtx, rtx) asm("_gen_extv");
extern rtx gen_extzv (rtx, rtx, rtx, rtx) asm("_gen_extzv");
extern rtx gen_insv (rtx, rtx, rtx, rtx) asm("_gen_insv");
extern rtx gen_movsi_ulw (rtx, rtx) asm("_gen_movsi_ulw");
extern rtx gen_movsi_usw (rtx, rtx) asm("_gen_movsi_usw");
extern rtx gen_movdi (rtx, rtx) asm("_gen_movdi");
extern rtx gen_movdi_internal (rtx, rtx) asm("_gen_movdi_internal");
extern rtx gen_movdi_internal2 (rtx, rtx) asm("_gen_movdi_internal2");
extern rtx gen_reload_indi (rtx, rtx, rtx) asm("_gen_reload_indi");
extern rtx gen_reload_outdi (rtx, rtx, rtx) asm("_gen_reload_outdi");
extern rtx gen_movsi (rtx, rtx) asm("_gen_movsi");
extern rtx gen_movsi_internal1 (rtx, rtx) asm("_gen_movsi_internal1");
extern rtx gen_movsi_internal2 (rtx, rtx) asm("_gen_movsi_internal2");
extern rtx gen_reload_outsi (rtx, rtx, rtx) asm("_gen_reload_outsi");
extern rtx gen_movhi (rtx, rtx) asm("_gen_movhi");
extern rtx gen_movhi_internal1 (rtx, rtx) asm("_gen_movhi_internal1");
extern rtx gen_movhi_internal2 (rtx, rtx) asm("_gen_movhi_internal2");
extern rtx gen_movqi (rtx, rtx) asm("_gen_movqi");
extern rtx gen_movqi_internal1 (rtx, rtx) asm("_gen_movqi_internal1");
extern rtx gen_movqi_internal2 (rtx, rtx) asm("_gen_movqi_internal2");
extern rtx gen_movsf (rtx, rtx) asm("_gen_movsf");
extern rtx gen_movsf_internal1 (rtx, rtx) asm("_gen_movsf_internal1");
extern rtx gen_movsf_internal2 (rtx, rtx) asm("_gen_movsf_internal2");
extern rtx gen_movdf (rtx, rtx) asm("_gen_movdf");
extern rtx gen_movdf_internal1 (rtx, rtx) asm("_gen_movdf_internal1");
extern rtx gen_movdf_internal1a (rtx, rtx) asm("_gen_movdf_internal1a");
extern rtx gen_movdf_internal2 (rtx, rtx) asm("_gen_movdf_internal2");
extern rtx gen_loadgp (rtx) asm("_gen_loadgp");
extern rtx gen_movstrsi (rtx, rtx, rtx, rtx) asm("_gen_movstrsi");
extern rtx gen_movstrsi_internal (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal");
extern rtx gen_movstrsi_internal2 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal2");
extern rtx gen_movstrsi_internal3 (rtx, rtx, rtx, rtx) asm("_gen_movstrsi_internal3");
extern rtx gen_ashlsi3 (rtx, rtx, rtx) asm("_gen_ashlsi3");
extern rtx gen_ashldi3 (rtx, rtx, rtx) asm("_gen_ashldi3");
extern rtx gen_ashldi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal");
extern rtx gen_ashldi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal2");
extern rtx gen_ashldi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashldi3_internal3");
extern rtx gen_ashldi3_internal4 (rtx, rtx, rtx) asm("_gen_ashldi3_internal4");
extern rtx gen_ashrsi3 (rtx, rtx, rtx) asm("_gen_ashrsi3");
extern rtx gen_ashrdi3 (rtx, rtx, rtx) asm("_gen_ashrdi3");
extern rtx gen_ashrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal");
extern rtx gen_ashrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal2");
extern rtx gen_ashrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_ashrdi3_internal3");
extern rtx gen_ashrdi3_internal4 (rtx, rtx, rtx) asm("_gen_ashrdi3_internal4");
extern rtx gen_lshrsi3 (rtx, rtx, rtx) asm("_gen_lshrsi3");
extern rtx gen_lshrdi3 (rtx, rtx, rtx) asm("_gen_lshrdi3");
extern rtx gen_lshrdi3_internal (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal");
extern rtx gen_lshrdi3_internal2 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal2");
extern rtx gen_lshrdi3_internal3 (rtx, rtx, rtx, rtx) asm("_gen_lshrdi3_internal3");
extern rtx gen_lshrdi3_internal4 (rtx, rtx, rtx) asm("_gen_lshrdi3_internal4");
extern rtx gen_cmpsi (rtx, rtx) asm("_gen_cmpsi");
extern rtx gen_tstsi (rtx) asm("_gen_tstsi");
extern rtx gen_cmpdi (rtx, rtx) asm("_gen_cmpdi");
extern rtx gen_tstdi (rtx) asm("_gen_tstdi");
extern rtx gen_cmpdf (rtx, rtx) asm("_gen_cmpdf");
extern rtx gen_cmpsf (rtx, rtx) asm("_gen_cmpsf");
extern rtx gen_branch_fp_ne (rtx, rtx) asm("_gen_branch_fp_ne");
extern rtx gen_branch_fp_ne_rev (rtx, rtx) asm("_gen_branch_fp_ne_rev");
extern rtx gen_branch_fp_eq (rtx, rtx) asm("_gen_branch_fp_eq");
extern rtx gen_branch_fp_eq_rev (rtx, rtx) asm("_gen_branch_fp_eq_rev");
extern rtx gen_branch_zero (rtx, rtx, rtx, rtx) asm("_gen_branch_zero");
extern rtx gen_branch_zero_di (rtx, rtx, rtx, rtx) asm("_gen_branch_zero_di");
extern rtx gen_branch_equality (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality");
extern rtx gen_branch_equality_di (rtx, rtx, rtx, rtx, rtx) asm("_gen_branch_equality_di");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bne (rtx) asm("_gen_bne");
extern rtx gen_bgt (rtx) asm("_gen_bgt");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_blt (rtx) asm("_gen_blt");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx gen_bgtu (rtx) asm("_gen_bgtu");
extern rtx gen_bgeu (rtx) asm("_gen_bgeu");
extern rtx gen_bltu (rtx) asm("_gen_bltu");
extern rtx gen_bleu (rtx) asm("_gen_bleu");
extern rtx gen_seq (rtx) asm("_gen_seq");
extern rtx gen_seq_si_zero (rtx, rtx) asm("_gen_seq_si_zero");
extern rtx gen_seq_di_zero (rtx, rtx) asm("_gen_seq_di_zero");
extern rtx gen_seq_si (rtx, rtx, rtx) asm("_gen_seq_si");
extern rtx gen_seq_di (rtx, rtx, rtx) asm("_gen_seq_di");
extern rtx gen_sne (rtx) asm("_gen_sne");
extern rtx gen_sne_si_zero (rtx, rtx) asm("_gen_sne_si_zero");
extern rtx gen_sne_di_zero (rtx, rtx) asm("_gen_sne_di_zero");
extern rtx gen_sne_si (rtx, rtx, rtx) asm("_gen_sne_si");
extern rtx gen_sne_di (rtx, rtx, rtx) asm("_gen_sne_di");
extern rtx gen_sgt (rtx) asm("_gen_sgt");
extern rtx gen_sgt_si (rtx, rtx, rtx) asm("_gen_sgt_si");
extern rtx gen_sgt_di (rtx, rtx, rtx) asm("_gen_sgt_di");
extern rtx gen_sge (rtx) asm("_gen_sge");
extern rtx gen_sge_si (rtx, rtx, rtx) asm("_gen_sge_si");
extern rtx gen_sge_di (rtx, rtx, rtx) asm("_gen_sge_di");
extern rtx gen_slt (rtx) asm("_gen_slt");
extern rtx gen_slt_si (rtx, rtx, rtx) asm("_gen_slt_si");
extern rtx gen_slt_di (rtx, rtx, rtx) asm("_gen_slt_di");
extern rtx gen_sle (rtx) asm("_gen_sle");
extern rtx gen_sle_si_const (rtx, rtx, rtx) asm("_gen_sle_si_const");
extern rtx gen_sle_di_const (rtx, rtx, rtx) asm("_gen_sle_di_const");
extern rtx gen_sle_si_reg (rtx, rtx, rtx) asm("_gen_sle_si_reg");
extern rtx gen_sle_di_reg (rtx, rtx, rtx) asm("_gen_sle_di_reg");
extern rtx gen_sgtu (rtx) asm("_gen_sgtu");
extern rtx gen_sgtu_si (rtx, rtx, rtx) asm("_gen_sgtu_si");
extern rtx gen_sgtu_di (rtx, rtx, rtx) asm("_gen_sgtu_di");
extern rtx gen_sgeu (rtx) asm("_gen_sgeu");
extern rtx gen_sgeu_si (rtx, rtx, rtx) asm("_gen_sgeu_si");
extern rtx gen_sgeu_di (rtx, rtx, rtx) asm("_gen_sgeu_di");
extern rtx gen_sltu (rtx) asm("_gen_sltu");
extern rtx gen_sltu_si (rtx, rtx, rtx) asm("_gen_sltu_si");
extern rtx gen_sltu_di (rtx, rtx, rtx) asm("_gen_sltu_di");
extern rtx gen_sleu (rtx) asm("_gen_sleu");
extern rtx gen_sleu_si_const (rtx, rtx, rtx) asm("_gen_sleu_si_const");
extern rtx gen_sleu_di_const (rtx, rtx, rtx) asm("_gen_sleu_di_const");
extern rtx gen_sleu_si_reg (rtx, rtx, rtx) asm("_gen_sleu_si_reg");
extern rtx gen_sleu_di_reg (rtx, rtx, rtx) asm("_gen_sleu_di_reg");
extern rtx gen_seq_df (rtx, rtx) asm("_gen_seq_df");
extern rtx gen_sne_df (rtx, rtx) asm("_gen_sne_df");
extern rtx gen_slt_df (rtx, rtx) asm("_gen_slt_df");
extern rtx gen_sle_df (rtx, rtx) asm("_gen_sle_df");
extern rtx gen_sgt_df (rtx, rtx) asm("_gen_sgt_df");
extern rtx gen_sge_df (rtx, rtx) asm("_gen_sge_df");
extern rtx gen_seq_sf (rtx, rtx) asm("_gen_seq_sf");
extern rtx gen_sne_sf (rtx, rtx) asm("_gen_sne_sf");
extern rtx gen_slt_sf (rtx, rtx) asm("_gen_slt_sf");
extern rtx gen_sle_sf (rtx, rtx) asm("_gen_sle_sf");
extern rtx gen_sgt_sf (rtx, rtx) asm("_gen_sgt_sf");
extern rtx gen_sge_sf (rtx, rtx) asm("_gen_sge_sf");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_indirect_jump (rtx) asm("_gen_indirect_jump");
extern rtx gen_indirect_jump_internal1 (rtx) asm("_gen_indirect_jump_internal1");
extern rtx gen_indirect_jump_internal2 (rtx) asm("_gen_indirect_jump_internal2");
extern rtx gen_tablejump (rtx, rtx) asm("_gen_tablejump");
extern rtx gen_tablejump_internal1 (rtx, rtx) asm("_gen_tablejump_internal1");
extern rtx gen_tablejump_internal2 (rtx, rtx) asm("_gen_tablejump_internal2");
extern rtx gen_return (void) asm("_gen_return");
extern rtx gen_return_internal (rtx) asm("_gen_return_internal");
extern rtx gen_casesi (rtx, rtx, rtx, rtx, rtx) asm("_gen_casesi");
extern rtx gen_casesi_internal (rtx, rtx, rtx) asm("_gen_casesi_internal");
extern rtx gen_prologue (void) asm("_gen_prologue");
extern rtx gen_blockage (void) asm("_gen_blockage");
extern rtx gen_get_fnaddr (rtx, rtx) asm("_gen_get_fnaddr");
extern rtx gen_call_internal1 (rtx, rtx, rtx) asm("_gen_call_internal1");
extern rtx gen_call_internal2 (rtx, rtx, rtx) asm("_gen_call_internal2");
extern rtx gen_call_internal3a (rtx, rtx, rtx) asm("_gen_call_internal3a");
extern rtx gen_call_internal3b (rtx, rtx, rtx) asm("_gen_call_internal3b");
extern rtx gen_call_internal4a (rtx, rtx, rtx) asm("_gen_call_internal4a");
extern rtx gen_call_internal4b (rtx, rtx, rtx) asm("_gen_call_internal4b");
extern rtx gen_call_value_internal1 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal1");
extern rtx gen_call_value_internal2 (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal2");
extern rtx gen_call_value_internal3a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3a");
extern rtx gen_call_value_internal3b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal3b");
extern rtx gen_call_value_internal4a (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4a");
extern rtx gen_call_value_internal4b (rtx, rtx, rtx, rtx) asm("_gen_call_value_internal4b");
extern rtx gen_untyped_call (rtx, rtx, rtx) asm("_gen_untyped_call");
extern rtx gen_nop (void) asm("_gen_nop");
extern rtx gen_probe (void) asm("_gen_probe");
extern rtx gen_movsicc (rtx, rtx, rtx, rtx) asm("_gen_movsicc");






extern rtx gen_call(...) asm("_gen_call");
extern rtx gen_call_value(...) asm("_gen_call_value");





enum n64_cpp_enum_insn_code{
  CODE_FOR_adddf3 = 0,
  CODE_FOR_addsf3 = 1,
  CODE_FOR_addsi3 = 2,
  CODE_FOR_addsi3_internal = 3,
  CODE_FOR_adddi3 = 4,
  CODE_FOR_adddi3_internal_1 = 5,
  CODE_FOR_adddi3_internal_2 = 8,
  CODE_FOR_adddi3_internal_3 = 11,
  CODE_FOR_addsi3_internal_2 = 12,
  CODE_FOR_subdf3 = 13,
  CODE_FOR_subsf3 = 14,
  CODE_FOR_subsi3 = 15,
  CODE_FOR_subsi3_internal = 16,
  CODE_FOR_subdi3 = 17,
  CODE_FOR_subdi3_internal = 18,
  CODE_FOR_subdi3_internal_2 = 21,
  CODE_FOR_subdi3_internal_3 = 24,
  CODE_FOR_subsi3_internal_2 = 25,
  CODE_FOR_muldf3 = 26,
  CODE_FOR_mulsf3 = 27,
  CODE_FOR_mulsi3 = 28,
  CODE_FOR_mulsi3_internal = 29,
  CODE_FOR_mulsi3_r4000 = 30,
  CODE_FOR_mulsi3_r4650 = 31,
  CODE_FOR_muldi3 = 32,
  CODE_FOR_muldi3_internal = 33,
  CODE_FOR_muldi3_r4000 = 34,
  CODE_FOR_mulsidi3 = 35,
  CODE_FOR_mulsidi3_internal = 36,
  CODE_FOR_mulsidi3_64bit = 37,
  CODE_FOR_smulsi3_highpart = 38,
  CODE_FOR_umulsidi3 = 39,
  CODE_FOR_umulsidi3_internal = 40,
  CODE_FOR_umulsidi3_64bit = 41,
  CODE_FOR_umulsi3_highpart = 42,
  CODE_FOR_smuldi3_highpart = 43,
  CODE_FOR_umuldi3_highpart = 44,
  CODE_FOR_madsi = 45,
  CODE_FOR_maddi = 46,
  CODE_FOR_maddi_64bit = 47,
  CODE_FOR_umaddi = 48,
  CODE_FOR_umaddi_64bit = 49,
  CODE_FOR_divdf3 = 58,
  CODE_FOR_divsf3 = 59,
  CODE_FOR_divmodsi4 = 60,
  CODE_FOR_divmoddi4 = 61,
  CODE_FOR_udivmodsi4 = 62,
  CODE_FOR_udivmoddi4 = 63,
  CODE_FOR_divsi3 = 64,
  CODE_FOR_divdi3 = 65,
  CODE_FOR_modsi3 = 66,
  CODE_FOR_moddi3 = 67,
  CODE_FOR_udivsi3 = 68,
  CODE_FOR_udivdi3 = 69,
  CODE_FOR_umodsi3 = 70,
  CODE_FOR_umoddi3 = 71,
  CODE_FOR_sqrtdf2 = 72,
  CODE_FOR_sqrtsf2 = 73,
  CODE_FOR_abssi2 = 74,
  CODE_FOR_absdi2 = 75,
  CODE_FOR_absdf2 = 76,
  CODE_FOR_abssf2 = 77,
  CODE_FOR_ffssi2 = 78,
  CODE_FOR_ffsdi2 = 79,
  CODE_FOR_negsi2 = 80,
  CODE_FOR_negdi2 = 81,
  CODE_FOR_negdi2_internal = 82,
  CODE_FOR_negdi2_internal_2 = 83,
  CODE_FOR_negdf2 = 84,
  CODE_FOR_negsf2 = 85,
  CODE_FOR_one_cmplsi2 = 86,
  CODE_FOR_one_cmpldi2 = 87,
  CODE_FOR_norsi3 = 89,
  CODE_FOR_nordi3 = 90,
  CODE_FOR_andsi3 = 92,
  CODE_FOR_anddi3 = 93,
  CODE_FOR_anddi3_internal1 = 95,
  CODE_FOR_iorsi3 = 96,
  CODE_FOR_iordi3 = 97,
  CODE_FOR_xorsi3 = 99,
  CODE_FOR_xordi3 = 100,
  CODE_FOR_xordi3_immed = 102,
  CODE_FOR_truncdfsf2 = 103,
  CODE_FOR_truncdisi2 = 104,
  CODE_FOR_truncdihi2 = 105,
  CODE_FOR_truncdiqi2 = 106,
  CODE_FOR_zero_extendsidi2 = 113,
  CODE_FOR_zero_extendsidi2_internal = 114,
  CODE_FOR_zero_extendhisi2 = 115,
  CODE_FOR_zero_extendhidi2 = 116,
  CODE_FOR_zero_extendqihi2 = 117,
  CODE_FOR_zero_extendqisi2 = 118,
  CODE_FOR_zero_extendqidi2 = 119,
  CODE_FOR_extendsidi2 = 120,
  CODE_FOR_extendsidi2_internal = 121,
  CODE_FOR_extendhidi2 = 122,
  CODE_FOR_extendhidi2_internal = 123,
  CODE_FOR_extendhisi2 = 124,
  CODE_FOR_extendhisi2_internal = 125,
  CODE_FOR_extendqihi2 = 126,
  CODE_FOR_extendqihi2_internal = 127,
  CODE_FOR_extendqisi2 = 128,
  CODE_FOR_extendqisi2_insn = 129,
  CODE_FOR_extendqidi2 = 130,
  CODE_FOR_extendqidi2_insn = 131,
  CODE_FOR_extendsfdf2 = 132,
  CODE_FOR_fix_truncdfsi2 = 133,
  CODE_FOR_fix_truncsfsi2 = 134,
  CODE_FOR_fix_truncdfdi2 = 135,
  CODE_FOR_fix_truncsfdi2 = 136,
  CODE_FOR_floatsidf2 = 137,
  CODE_FOR_floatdidf2 = 138,
  CODE_FOR_floatsisf2 = 139,
  CODE_FOR_floatdisf2 = 140,
  CODE_FOR_fixuns_truncdfsi2 = 141,
  CODE_FOR_fixuns_truncdfdi2 = 142,
  CODE_FOR_fixuns_truncsfsi2 = 143,
  CODE_FOR_fixuns_truncsfdi2 = 144,
  CODE_FOR_extv = 145,
  CODE_FOR_extzv = 146,
  CODE_FOR_insv = 147,
  CODE_FOR_movsi_ulw = 148,
  CODE_FOR_movsi_usw = 149,
  CODE_FOR_movdi = 150,
  CODE_FOR_movdi_internal = 151,
  CODE_FOR_movdi_internal2 = 153,
  CODE_FOR_reload_indi = 154,
  CODE_FOR_reload_outdi = 155,
  CODE_FOR_movsi = 157,
  CODE_FOR_movsi_internal1 = 158,
  CODE_FOR_movsi_internal2 = 159,
  CODE_FOR_reload_outsi = 160,
  CODE_FOR_movhi = 161,
  CODE_FOR_movhi_internal1 = 162,
  CODE_FOR_movhi_internal2 = 163,
  CODE_FOR_movqi = 164,
  CODE_FOR_movqi_internal1 = 165,
  CODE_FOR_movqi_internal2 = 166,
  CODE_FOR_movsf = 167,
  CODE_FOR_movsf_internal1 = 168,
  CODE_FOR_movsf_internal2 = 169,
  CODE_FOR_movdf = 170,
  CODE_FOR_movdf_internal1 = 171,
  CODE_FOR_movdf_internal1a = 172,
  CODE_FOR_movdf_internal2 = 173,
  CODE_FOR_loadgp = 175,
  CODE_FOR_movstrsi = 176,
  CODE_FOR_movstrsi_internal = 177,
  CODE_FOR_movstrsi_internal2 = 179,
  CODE_FOR_movstrsi_internal3 = 180,
  CODE_FOR_ashlsi3 = 181,
  CODE_FOR_ashldi3 = 182,
  CODE_FOR_ashldi3_internal = 183,
  CODE_FOR_ashldi3_internal2 = 184,
  CODE_FOR_ashldi3_internal3 = 187,
  CODE_FOR_ashldi3_internal4 = 190,
  CODE_FOR_ashrsi3 = 191,
  CODE_FOR_ashrdi3 = 192,
  CODE_FOR_ashrdi3_internal = 193,
  CODE_FOR_ashrdi3_internal2 = 194,
  CODE_FOR_ashrdi3_internal3 = 197,
  CODE_FOR_ashrdi3_internal4 = 200,
  CODE_FOR_lshrsi3 = 201,
  CODE_FOR_lshrdi3 = 202,
  CODE_FOR_lshrdi3_internal = 203,
  CODE_FOR_lshrdi3_internal2 = 204,
  CODE_FOR_lshrdi3_internal3 = 207,
  CODE_FOR_lshrdi3_internal4 = 210,
  CODE_FOR_cmpsi = 211,
  CODE_FOR_tstsi = 212,
  CODE_FOR_cmpdi = 213,
  CODE_FOR_tstdi = 214,
  CODE_FOR_cmpdf = 215,
  CODE_FOR_cmpsf = 216,
  CODE_FOR_branch_fp_ne = 217,
  CODE_FOR_branch_fp_ne_rev = 218,
  CODE_FOR_branch_fp_eq = 219,
  CODE_FOR_branch_fp_eq_rev = 220,
  CODE_FOR_branch_zero = 221,
  CODE_FOR_branch_zero_di = 222,
  CODE_FOR_branch_equality = 223,
  CODE_FOR_branch_equality_di = 224,
  CODE_FOR_beq = 225,
  CODE_FOR_bne = 226,
  CODE_FOR_bgt = 227,
  CODE_FOR_bge = 228,
  CODE_FOR_blt = 229,
  CODE_FOR_ble = 230,
  CODE_FOR_bgtu = 231,
  CODE_FOR_bgeu = 232,
  CODE_FOR_bltu = 233,
  CODE_FOR_bleu = 234,
  CODE_FOR_seq = 235,
  CODE_FOR_seq_si_zero = 236,
  CODE_FOR_seq_di_zero = 237,
  CODE_FOR_seq_si = 238,
  CODE_FOR_seq_di = 240,
  CODE_FOR_sne = 242,
  CODE_FOR_sne_si_zero = 243,
  CODE_FOR_sne_di_zero = 244,
  CODE_FOR_sne_si = 245,
  CODE_FOR_sne_di = 247,
  CODE_FOR_sgt = 249,
  CODE_FOR_sgt_si = 250,
  CODE_FOR_sgt_di = 251,
  CODE_FOR_sge = 252,
  CODE_FOR_sge_si = 253,
  CODE_FOR_sge_di = 255,
  CODE_FOR_slt = 257,
  CODE_FOR_slt_si = 258,
  CODE_FOR_slt_di = 259,
  CODE_FOR_sle = 260,
  CODE_FOR_sle_si_const = 261,
  CODE_FOR_sle_di_const = 262,
  CODE_FOR_sle_si_reg = 263,
  CODE_FOR_sle_di_reg = 265,
  CODE_FOR_sgtu = 267,
  CODE_FOR_sgtu_si = 268,
  CODE_FOR_sgtu_di = 269,
  CODE_FOR_sgeu = 270,
  CODE_FOR_sgeu_si = 271,
  CODE_FOR_sgeu_di = 273,
  CODE_FOR_sltu = 275,
  CODE_FOR_sltu_si = 276,
  CODE_FOR_sltu_di = 277,
  CODE_FOR_sleu = 278,
  CODE_FOR_sleu_si_const = 279,
  CODE_FOR_sleu_di_const = 280,
  CODE_FOR_sleu_si_reg = 281,
  CODE_FOR_sleu_di_reg = 283,
  CODE_FOR_seq_df = 285,
  CODE_FOR_sne_df = 286,
  CODE_FOR_slt_df = 287,
  CODE_FOR_sle_df = 288,
  CODE_FOR_sgt_df = 289,
  CODE_FOR_sge_df = 290,
  CODE_FOR_seq_sf = 291,
  CODE_FOR_sne_sf = 292,
  CODE_FOR_slt_sf = 293,
  CODE_FOR_sle_sf = 294,
  CODE_FOR_sgt_sf = 295,
  CODE_FOR_sge_sf = 296,
  CODE_FOR_jump = 297,
  CODE_FOR_indirect_jump = 298,
  CODE_FOR_indirect_jump_internal1 = 299,
  CODE_FOR_indirect_jump_internal2 = 300,
  CODE_FOR_tablejump = 301,
  CODE_FOR_tablejump_internal1 = 302,
  CODE_FOR_tablejump_internal2 = 303,
  CODE_FOR_return = 304,
  CODE_FOR_return_internal = 305,
  CODE_FOR_casesi = 306,
  CODE_FOR_casesi_internal = 307,
  CODE_FOR_prologue = 308,
  CODE_FOR_blockage = 309,
  CODE_FOR_get_fnaddr = 310,
  CODE_FOR_call = 311,
  CODE_FOR_call_internal1 = 312,
  CODE_FOR_call_internal2 = 313,
  CODE_FOR_call_internal3a = 314,
  CODE_FOR_call_internal3b = 315,
  CODE_FOR_call_internal4a = 316,
  CODE_FOR_call_internal4b = 317,
  CODE_FOR_call_value = 318,
  CODE_FOR_call_value_internal1 = 319,
  CODE_FOR_call_value_internal2 = 320,
  CODE_FOR_call_value_internal3a = 321,
  CODE_FOR_call_value_internal3b = 322,
  CODE_FOR_call_value_internal4a = 323,
  CODE_FOR_call_value_internal4b = 324,
  CODE_FOR_untyped_call = 325,
  CODE_FOR_nop = 326,
  CODE_FOR_probe = 327,
  CODE_FOR_movsicc = 336,
  CODE_FOR_nothing };
typedef __underlying_type(enum n64_cpp_enum_insn_code) n64_enum_insn_code;

extern int recog_memoized (rtx) asm("_recog_memoized");




extern int validate_change (rtx, rtx *, rtx, int) asm("_validate_change");



extern int apply_change_group (void) asm("_apply_change_group");



extern int num_validated_changes (void) asm("_num_validated_changes");



extern void cancel_changes (int) asm("_cancel_changes");



extern int volatile_ok;



extern void insn_extract (rtx) asm("_insn_extract");




extern rtx recog_operand[];


extern rtx *recog_operand_loc[];



extern rtx *recog_dup_loc[];



extern char recog_dup_num[];
extern char *const insn_template[];

extern char *(*const insn_outfun[])(...);

extern const int insn_n_operands[];

extern const int insn_n_dups[];



extern const int insn_n_alternatives[];





extern char *const insn_operand_constraint[][10];






extern const n64_enum_machine_mode insn_operand_mode[][10];

extern const char insn_operand_strict_low[][10];

extern int (*const insn_operand_predicate[][10])(...);

extern char * insn_name[];
extern int max_regno;



extern int max_scratch;




extern int *reg_n_refs;



extern short *reg_n_sets;







extern short *reg_n_deaths;





extern char *reg_changes_size;
extern int *reg_n_calls_crossed;
extern int *reg_live_length;




extern short *reg_renumber;




extern char regs_ever_live[68];



extern char *reg_names[68];






extern n64_enum_machine_mode reg_raw_mode[68];






extern int *regno_first_uid;







extern int *regno_last_uid;



extern int *regno_last_note_uid;





extern char *regno_pointer_flag;




extern rtx regs_may_share;




extern rtx *regno_reg_rtx;




extern int caller_save_needed;
extern rtx *scratch_list;

extern int *scratch_block;

extern int scratch_list_length;
typedef unsigned int HARD_REG_ELT_TYPE;
typedef HARD_REG_ELT_TYPE HARD_REG_SET[((68 + 32 - 1) / 32)];
extern char fixed_regs[68];



extern HARD_REG_SET fixed_reg_set;






extern char call_used_regs[68];



extern HARD_REG_SET call_used_reg_set;







extern char call_fixed_regs[68];



extern HARD_REG_SET call_fixed_reg_set;






extern char global_regs[68];
extern HARD_REG_SET reg_class_contents[];



extern int reg_class_size[(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_superclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern n64_enum_reg_class reg_class_subclasses[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_subunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];




extern n64_enum_reg_class reg_class_superunion[(int) LIM_REG_CLASSES][(int) LIM_REG_CLASSES];



extern int n_non_fixed_regs;



extern char *reg_names[68];
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;
extern rtx alter_subreg(...) asm("_alter_subreg");

int strict_memory_address_p(...) asm("_strict_memory_address_p");
int memory_address_p(...) asm("_memory_address_p");
int volatile_ok;




int which_alternative;





int reload_completed;





void
init_recog_no_volatile(void) asm("_init_recog_no_volatile");
void
init_recog_no_volatile(void)
{
  volatile_ok = 0;
}

void
init_recog(void) asm("_init_recog");
void
init_recog(void)
{
  volatile_ok = 1;
}
int
recog_memoized(rtx insn) asm("_recog_memoized");
int
recog_memoized(rtx insn)
{
  if (((insn)->fld[4].rtint) < 0)
    ((insn)->fld[4].rtint) = recog (((insn)->fld[3].rtx), insn, ((void *)0));
  return ((insn)->fld[4].rtint);
}




int
check_asm_operands(rtx x) asm("_check_asm_operands");
int
check_asm_operands(rtx x)
{
  int noperands = asm_noperands (x);
  rtx *operands;
  int i;

  if (noperands < 0)
    return 0;
  if (noperands == 0)
    return 1;

  operands = (rtx *) 
                    __builtin_alloca((
                    noperands * sizeof (rtx)
                    ))
                                                     ;
  decode_asm_operands (x, operands, ((void *)0), ((void *)0), ((void *)0));

  for (i = 0; i < noperands; i++)
    if (!general_operand (operands[i], VOIDmode))
      return 0;

  return 1;
}
static rtx change_objects[(10 * 5)];
static int change_old_codes[(10 * 5)];
static rtx *change_locs[(10 * 5)];
static rtx change_olds[(10 * 5)];

static int num_changes = 0;
int
validate_change(rtx object, rtx *loc, rtx cxx_new, int in_group) asm("_validate_change");
int
validate_change(rtx object, rtx *loc, rtx cxx_new, int in_group)
{
  rtx old = *loc;

  if (old == cxx_new || rtx_equal_p (old, cxx_new))
    return 1;

  if (num_changes >= (10 * 5)
      || (in_group == 0 && num_changes != 0))
    abort ();

  *loc = cxx_new;


  change_objects[num_changes] = object;
  change_locs[num_changes] = loc;
  change_olds[num_changes] = old;

  if (object && ((object)->code) != MEM)
    {


      change_old_codes[num_changes] = ((object)->fld[4].rtint);
      ((object)->fld[4].rtint) = -1;
    }

  num_changes++;




  if (in_group)
    return 1;
  else
    return apply_change_group ();
}




int
apply_change_group(void) asm("_apply_change_group");
int
apply_change_group(void)
{
  int i;
  for (i = 0; i < num_changes; i++)
    {
      rtx object = change_objects[i];

      if (object == 0)
 continue;

      if (((object)->code) == MEM)
 {
   if (! memory_address_p (((object)->mode), ((object)->fld[0].rtx)))
     break;
 }
      else if ((recog_memoized (object) < 0
  && (asm_noperands (((object)->fld[3].rtx)) < 0
      || ! check_asm_operands (((object)->fld[3].rtx))
      || reload_completed))
        || (reload_completed
     && (insn_extract (object),
         ! constrain_operands (((object)->fld[4].rtint), 1))))
 {
   rtx pat = ((object)->fld[3].rtx);






   if (((pat)->code) == PARALLEL
       && ((((pat)->fld[0].rtvec->elem[((pat)->fld[0].rtvec->num_elem) - 1].rtx))->code) == CLOBBER
       && asm_noperands (((object)->fld[3].rtx)) < 0)
     {
        rtx newpat;

        if (((pat)->fld[0].rtvec->num_elem) == 2)
   newpat = ((pat)->fld[0].rtvec->elem[0].rtx);
        else
   {
     int j;

     newpat = gen_rtx (PARALLEL, VOIDmode,
         gen_rtvec (((pat)->fld[0].rtvec->num_elem) - 1));
     for (j = 0; j < ((newpat)->fld[0].rtvec->num_elem); j++)
       ((newpat)->fld[0].rtvec->elem[j].rtx) = ((pat)->fld[0].rtvec->elem[j].rtx);
   }
        validate_change (object, &((object)->fld[3].rtx), newpat, 1);
      }
   else if (((pat)->code) == USE || ((pat)->code) == CLOBBER)


     continue;
   else
     break;
 }
    }

  if (i == num_changes)
    {
      num_changes = 0;
      return 1;
    }
  else
    {
      cancel_changes (0);
      return 0;
    }
}



int
num_validated_changes(void) asm("_num_validated_changes");
int
num_validated_changes(void)
{
  return num_changes;
}



void
cancel_changes(int num) asm("_cancel_changes");
void
cancel_changes(int num)
{
  int i;



  for (i = num_changes - 1; i >= num; i--)
    {
      *change_locs[i] = change_olds[i];
      if (change_objects[i] && ((change_objects[i])->code) != MEM)
 ((change_objects[i])->fld[4].rtint) = change_old_codes[i];
    }
  num_changes = num;
}




static void
validate_replace_rtx_1(rtx *loc, rtx from, rtx to, rtx object) asm("_validate_replace_rtx_1");
static void
validate_replace_rtx_1(rtx *loc, rtx from, rtx to, rtx object)
{
  register int i, j;
  register char *fmt;
  register rtx x = *loc;
  n64_enum_rtx_code code = ((x)->code);





  if (x == from
      || (((x)->code) == REG && ((from)->code) == REG
   && ((x)->mode) == ((from)->mode)
   && ((x)->fld[0].rtint) == ((from)->fld[0].rtint))
      || (((x)->code) == ((from)->code) && ((x)->mode) == ((from)->mode)
   && rtx_equal_p (x, from)))
    {
      validate_change (object, loc, to, 1);
      return;
    }




  if ((rtx_class[(int)(code)]) == '<' || (rtx_class[(int)(code)]) == 'c')
    {
      int prev_changes = num_changes;

      validate_replace_rtx_1 (&((x)->fld[0].rtx), from, to, object);
      validate_replace_rtx_1 (&((x)->fld[1].rtx), from, to, object);
      if (prev_changes != num_changes && (((((x)->fld[0].rtx))->code) == LABEL_REF || ((((x)->fld[0].rtx))->code) == SYMBOL_REF || ((((x)->fld[0].rtx))->code) == CONST_INT || ((((x)->fld[0].rtx))->code) == CONST_DOUBLE || ((((x)->fld[0].rtx))->code) == CONST || ((((x)->fld[0].rtx))->code) == HIGH))
 {
   validate_change (object, loc,
      gen_rtx ((rtx_class[(int)(code)]) == 'c' ? code
        : swap_condition (code),
        ((x)->mode), ((x)->fld[1].rtx), ((x)->fld[0].rtx)),
      1);
   x = *loc;
   code = ((x)->code);
 }
    }

  switch (code)
    {
    case PLUS:


      if (((((x)->fld[1].rtx))->code) == CONST_INT && ((x)->fld[1].rtx) == to)
 validate_change (object, loc,
    plus_constant_wide (((x)->fld[0].rtx), (int) (((((x)->fld[1].rtx))->fld[0].rtwint))), 1);
      return;

    case ZERO_EXTEND:
    case SIGN_EXTEND:





      if (((to)->mode) == VOIDmode
   && (((x)->fld[0].rtx) == from
       || (((((x)->fld[0].rtx))->code) == REG && ((from)->code) == REG
    && ((((x)->fld[0].rtx))->mode) == ((from)->mode)
    && ((((x)->fld[0].rtx))->fld[0].rtint) == ((from)->fld[0].rtint))))
 {
   rtx cxx_new = simplify_unary_operation (code, ((x)->mode), to,
           ((from)->mode));
   if (cxx_new == 0)
     cxx_new = gen_rtx (CLOBBER, ((x)->mode), const0_rtx);

   validate_change (object, loc, cxx_new, 1);
   return;
 }
      break;

    case SUBREG:





      if (((x)->fld[0].rtx) == from
   && ((from)->code) == REG
   && ((to)->code) == MEM
   && ! mode_dependent_address_p (((to)->fld[0].rtx))
   && ! ((to)->volatil)
   && (mode_size[(int)(((x)->mode))]) <= (mode_size[(int)(((to)->mode))]))
 {
   int offset = ((x)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
   n64_enum_machine_mode mode = ((x)->mode);
   rtx cxx_new;

   if (((target_flags & 0x00010000) != 0))
     offset += (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((((x)->fld[0].rtx))->mode))])))

         - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(mode)])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(mode)]))));

   cxx_new = gen_rtx (MEM, mode, plus_constant_wide (((to)->fld[0].rtx), (int) (offset)));
   ((cxx_new)->volatil) = ((to)->volatil);
   ((cxx_new)->unchanging) = ((to)->unchanging);
   ((cxx_new)->in_struct) = ((to)->in_struct);
   validate_change (object, loc, cxx_new, 1);
   return;
 }
      break;

    case ZERO_EXTRACT:
    case SIGN_EXTRACT:





      if (((x)->fld[0].rtx) == from && ((from)->code) == REG && ((to)->code) == MEM
   && ((((x)->fld[1].rtx))->code) == CONST_INT
   && ((((x)->fld[2].rtx))->code) == CONST_INT
   && ! mode_dependent_address_p (((to)->fld[0].rtx))
   && ! ((to)->volatil))
 {
   n64_enum_machine_mode wanted_mode = VOIDmode;
   n64_enum_machine_mode is_mode = ((to)->mode);
   int width = ((((x)->fld[1].rtx))->fld[0].rtwint);
   int pos = ((((x)->fld[2].rtx))->fld[0].rtwint);


   if (code == ZERO_EXTRACT)
     wanted_mode = insn_operand_mode[(int) CODE_FOR_extzv][1];


   if (code == SIGN_EXTRACT)
     wanted_mode = insn_operand_mode[(int) CODE_FOR_extv][1];



   if (wanted_mode != VOIDmode
       && (mode_size[(int)(wanted_mode)]) < (mode_size[(int)(is_mode)]))
     {
       int offset = pos / 8;
       rtx newmem;



       if (((target_flags & 0x00010000) != 0) != 0)
  offset = ((mode_size[(int)(is_mode)]) - (mode_size[(int)(wanted_mode)])
     - offset);

       pos %= (8 * mode_size[(int)(wanted_mode)]);

       newmem = gen_rtx (MEM, wanted_mode,
    plus_constant_wide (((to)->fld[0].rtx), (int) (offset)));
       ((newmem)->unchanging) = ((to)->unchanging);
       ((newmem)->volatil) = ((to)->volatil);
       ((newmem)->in_struct) = ((to)->in_struct);

       validate_change (object, &((x)->fld[2].rtx), gen_rtx (CONST_INT, VOIDmode, (int) (pos)), 1);
       validate_change (object, &((x)->fld[0].rtx), newmem, 1);
     }
 }

      break;
    }

  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 validate_replace_rtx_1 (&((x)->fld[i].rtx), from, to, object);
      else if (fmt[i] == 'E')
 for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
   validate_replace_rtx_1 (&((x)->fld[i].rtvec->elem[j].rtx), from, to, object);
    }
}




int
validate_replace_rtx(rtx from, rtx to, rtx insn) asm("_validate_replace_rtx");
int
validate_replace_rtx(rtx from, rtx to, rtx insn)
{
  validate_replace_rtx_1 (&((insn)->fld[3].rtx), from, to, insn);
  return apply_change_group ();
}
static rtx *
find_single_use_1(rtx dest, rtx *loc) asm("_find_single_use_1");
static rtx *
find_single_use_1(rtx dest, rtx *loc)
{
  rtx x = *loc;
  n64_enum_rtx_code code = ((x)->code);
  rtx *result = 0;
  rtx *this_result;
  int i;
  char *fmt;

  switch (code)
    {
    case CONST_INT:
    case CONST:
    case LABEL_REF:
    case SYMBOL_REF:
    case CONST_DOUBLE:
    case CLOBBER:
      return 0;

    case SET:




      if (((((x)->fld[0].rtx))->code) != CC0
   && ((((x)->fld[0].rtx))->code) != PC
   && ((((x)->fld[0].rtx))->code) != REG
   && ! (((((x)->fld[0].rtx))->code) == SUBREG
  && ((((((x)->fld[0].rtx))->fld[0].rtx))->code) == REG
  && ((((mode_size[(int)(((((((x)->fld[0].rtx))->fld[0].rtx))->mode))])
        + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4))
      == (((mode_size[(int)(((((x)->fld[0].rtx))->mode))])
    + (((target_flags & 0x00002000) ? 8 : 4) - 1)) / ((target_flags & 0x00002000) ? 8 : 4)))))
 break;

      return find_single_use_1 (dest, &((x)->fld[1].rtx));

    case MEM:
    case SUBREG:
      return find_single_use_1 (dest, &((x)->fld[0].rtx));
    }




  fmt = (rtx_format[(int)(code)]);
  for (i = (rtx_length[(int)(code)]) - 1; i >= 0; i--)
    {
      if (fmt[i] == 'e')
 {
   if (dest == ((x)->fld[i].rtx)
       || (((dest)->code) == REG && ((((x)->fld[i].rtx))->code) == REG
    && ((dest)->fld[0].rtint) == ((((x)->fld[i].rtx))->fld[0].rtint)))
     this_result = loc;
   else
     this_result = find_single_use_1 (dest, &((x)->fld[i].rtx));

   if (result == 0)
     result = this_result;
   else if (this_result)

     return 0;
 }
      else if (fmt[i] == 'E')
 {
   int j;

   for (j = ((x)->fld[i].rtvec->num_elem) - 1; j >= 0; j--)
     {
       if (((x)->fld[i].rtvec->elem[j].rtx) == dest
    || (((dest)->code) == REG
        && ((((x)->fld[i].rtvec->elem[j].rtx))->code) == REG
        && ((((x)->fld[i].rtvec->elem[j].rtx))->fld[0].rtint) == ((dest)->fld[0].rtint)))
  this_result = loc;
       else
  this_result = find_single_use_1 (dest, &((x)->fld[i].rtvec->elem[j].rtx));

       if (result == 0)
  result = this_result;
       else if (this_result)
  return 0;
     }
 }
    }

  return result;
}
rtx *
find_single_use(rtx dest, rtx insn, rtx *ploc) asm("_find_single_use");
rtx *
find_single_use(rtx dest, rtx insn, rtx *ploc)
{
  rtx next;
  rtx *result;
  rtx link;
  if (reload_completed || reload_in_progress || ((dest)->code) != REG)
    return 0;

  for (next = next_nonnote_insn (insn);
       next != 0 && ((next)->code) != CODE_LABEL;
       next = next_nonnote_insn (next))
    if ((rtx_class[(int)(((next)->code))]) == 'i' && dead_or_set_p (next, dest))
      {
 for (link = ((next)->fld[5].rtx); link; link = ((link)->fld[1].rtx))
   if (((link)->fld[0].rtx) == insn)
     break;

 if (link)
   {
     result = find_single_use_1 (dest, &((next)->fld[3].rtx));
     if (ploc)
       *ploc = next;
     return result;
   }
      }

  return 0;
}
int
general_operand(register rtx op, n64_enum_machine_mode mode) asm("_general_operand");
int
general_operand(register rtx op, n64_enum_machine_mode mode)
{
  register n64_enum_rtx_code code = ((op)->code);
  int mode_altering_drug = 0;

  if (mode == VOIDmode)
    mode = ((op)->mode);



  if (((op)->mode) == VOIDmode && mode != VOIDmode
      && (mode_class[(int)(mode)]) != MODE_INT
      && (mode_class[(int)(mode)]) != MODE_PARTIAL_INT)
    return 0;

  if ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH))
    return ((((op)->mode) == VOIDmode || ((op)->mode) == mode)

     && (! flag_pic || (! pic_address_needs_scratch (op)))

     && ((((op)->code) != CONST_DOUBLE || mips_const_double_ok (op, ((op)->mode))) && ! (((op)->code) == CONST && 0)));




  if (((op)->mode) != mode)
    return 0;

  if (code == SUBREG)
    {



      if (((((op)->fld[0].rtx))->code) == MEM
   && (mode_size[(int)(mode)]) > (mode_size[(int)(((((op)->fld[0].rtx))->mode))]))
 return 0;


      op = ((op)->fld[0].rtx);
      code = ((op)->code);





    }

  if (code == REG)

    return (((op)->fld[0].rtint) >= 68
     || mips_regno_to_class[ (((op)->fld[0].rtint)) ] != NO_REGS);

  if (code == MEM)
    {
      register rtx y = ((op)->fld[0].rtx);
      if (! volatile_ok && ((op)->volatil))
 return 0;

      mode = ((op)->mode);
      { register rtx xinsn = (y); if ((target_flags & 0x10000000)) { trace("\n========== GO_IF_LEGITIMATE_ADDRESS, %sstrict\n",(0) ? "" : "not "); debug_rtx(xinsn); } if (((xinsn)->code) == REG && (((((xinsn)->fld[0].rtint)) >= 68) || (((unsigned) ((((xinsn)->fld[0].rtint)) - 0) < (31 - 0 + 1))))) goto win; if (((((xinsn)->code) == LABEL_REF || ((xinsn)->code) == SYMBOL_REF || ((xinsn)->code) == CONST_INT || ((xinsn)->code) == HIGH || (((xinsn)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xinsn)) && ! 0)) && (!0 || !0))) goto win; if (((xinsn)->code) == PLUS) { register rtx xplus0 = ((xinsn)->fld[0].rtx); register rtx xplus1 = ((xinsn)->fld[1].rtx); register n64_enum_rtx_code code0 = ((xplus0)->code); register n64_enum_rtx_code code1 = ((xplus1)->code); if (code0 != REG && code1 == REG) { xplus0 = ((xinsn)->fld[1].rtx); xplus1 = ((xinsn)->fld[0].rtx); code0 = ((xplus0)->code); code1 = ((xplus1)->code); } if (code0 == REG && (((((xplus0)->fld[0].rtint)) >= 68) || (((unsigned) ((((xplus0)->fld[0].rtint)) - 0) < (31 - 0 + 1))))) { if (code1 == CONST_INT && ((xplus1)->fld[0].rtwint) >= -32768 && ((xplus1)->fld[0].rtwint) + (mode_size[(int)(mode)]) - 1 <= 32767) goto win; if (!(target_flags & 0x20000000) && ! 0 && ((((xplus1)->code) == LABEL_REF || ((xplus1)->code) == SYMBOL_REF || ((xplus1)->code) == CONST_INT || ((xplus1)->code) == HIGH || (((xplus1)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xplus1)) && ! 0)) && (!0 || !0)) && (!(target_flags & 0x00004000) || code1 != CONST || ((((xplus1)->fld[0].rtx))->code) != MINUS)) goto win; } } if ((target_flags & 0x10000000)) trace("Not a legitimate address\n"); };
    }
  return 0;

 win:
  if (mode_altering_drug)
    return ! mode_dependent_address_p (((op)->fld[0].rtx));
  return 1;
}







int
address_operand(register rtx op, n64_enum_machine_mode mode) asm("_address_operand");
int
address_operand(register rtx op, n64_enum_machine_mode mode)
{
  return memory_address_p (mode, op);
}
int
register_operand(register rtx op, n64_enum_machine_mode mode) asm("_register_operand");
int
register_operand(register rtx op, n64_enum_machine_mode mode)
{
  if (((op)->mode) != mode && mode != VOIDmode)
    return 0;

  if (((op)->code) == SUBREG)
    {






      if (! reload_completed && ((((op)->fld[0].rtx))->code) == MEM)
 return general_operand (op, mode);
      op = ((op)->fld[0].rtx);
    }



  return (((op)->code) == REG
   && (((op)->fld[0].rtint) >= 68
       || mips_regno_to_class[ (((op)->fld[0].rtint)) ] != NO_REGS));
}




int
scratch_operand(register rtx op, n64_enum_machine_mode mode) asm("_scratch_operand");
int
scratch_operand(register rtx op, n64_enum_machine_mode mode)
{
  return (((op)->mode) == mode
   && (((op)->code) == SCRATCH
       || (((op)->code) == REG
    && ((op)->fld[0].rtint) < 68)));
}






int
immediate_operand(register rtx op, n64_enum_machine_mode mode) asm("_immediate_operand");
int
immediate_operand(register rtx op, n64_enum_machine_mode mode)
{


  if (((op)->mode) == VOIDmode && mode != VOIDmode
      && (mode_class[(int)(mode)]) != MODE_INT
      && (mode_class[(int)(mode)]) != MODE_PARTIAL_INT)
    return 0;

  return ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH)
   && (((op)->mode) == mode || mode == VOIDmode
       || ((op)->mode) == VOIDmode)

   && (! flag_pic || (! pic_address_needs_scratch (op)))

   && ((((op)->code) != CONST_DOUBLE || mips_const_double_ok (op, ((op)->mode))) && ! (((op)->code) == CONST && 0)));
}



int
const_int_operand(register rtx op, n64_enum_machine_mode mode) asm("_const_int_operand");
int
const_int_operand(register rtx op, n64_enum_machine_mode mode)
{
  return ((op)->code) == CONST_INT;
}




int
const_double_operand(register rtx op, n64_enum_machine_mode mode) asm("_const_double_operand");
int
const_double_operand(register rtx op, n64_enum_machine_mode mode)
{


  if (((op)->mode) == VOIDmode && mode != VOIDmode
      && (mode_class[(int)(mode)]) != MODE_INT
      && (mode_class[(int)(mode)]) != MODE_PARTIAL_INT)
    return 0;

  return ((((op)->code) == CONST_DOUBLE || ((op)->code) == CONST_INT)
   && (mode == VOIDmode || ((op)->mode) == mode
       || ((op)->mode) == VOIDmode));
}



int
nonimmediate_operand(register rtx op, n64_enum_machine_mode mode) asm("_nonimmediate_operand");
int
nonimmediate_operand(register rtx op, n64_enum_machine_mode mode)
{
  return (general_operand (op, mode) && ! (((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH));
}



int
nonmemory_operand(register rtx op, n64_enum_machine_mode mode) asm("_nonmemory_operand");
int
nonmemory_operand(register rtx op, n64_enum_machine_mode mode)
{
  if ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH))
    {


      if (((op)->mode) == VOIDmode && mode != VOIDmode
   && (mode_class[(int)(mode)]) != MODE_INT
   && (mode_class[(int)(mode)]) != MODE_PARTIAL_INT)
 return 0;

      return ((((op)->mode) == VOIDmode || ((op)->mode) == mode)

       && (! flag_pic || (! pic_address_needs_scratch (op)))

       && ((((op)->code) != CONST_DOUBLE || mips_const_double_ok (op, ((op)->mode))) && ! (((op)->code) == CONST && 0)));
    }

  if (((op)->mode) != mode && mode != VOIDmode)
    return 0;

  if (((op)->code) == SUBREG)
    {






      if (! reload_completed && ((((op)->fld[0].rtx))->code) == MEM)
 return general_operand (op, mode);
      op = ((op)->fld[0].rtx);
    }



  return (((op)->code) == REG
   && (((op)->fld[0].rtint) >= 68
       || mips_regno_to_class[ (((op)->fld[0].rtint)) ] != NO_REGS));
}







int
push_operand(rtx op, n64_enum_machine_mode mode) asm("_push_operand");
int
push_operand(rtx op, n64_enum_machine_mode mode)
{
  if (((op)->code) != MEM)
    return 0;

  if (((op)->mode) != mode)
    return 0;

  op = ((op)->fld[0].rtx);

  if (((op)->code) != PRE_DEC)
    return 0;

  return ((op)->fld[0].rtx) == stack_pointer_rtx;
}



int
memory_address_p(n64_enum_machine_mode mode, register rtx addr) asm("_memory_address_p");
int
memory_address_p(n64_enum_machine_mode mode, register rtx addr)
{
  { register rtx xinsn = (addr); if ((target_flags & 0x10000000)) { trace("\n========== GO_IF_LEGITIMATE_ADDRESS, %sstrict\n",(0) ? "" : "not "); debug_rtx(xinsn); } if (((xinsn)->code) == REG && (((((xinsn)->fld[0].rtint)) >= 68) || (((unsigned) ((((xinsn)->fld[0].rtint)) - 0) < (31 - 0 + 1))))) goto win; if (((((xinsn)->code) == LABEL_REF || ((xinsn)->code) == SYMBOL_REF || ((xinsn)->code) == CONST_INT || ((xinsn)->code) == HIGH || (((xinsn)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xinsn)) && ! 0)) && (!0 || !0))) goto win; if (((xinsn)->code) == PLUS) { register rtx xplus0 = ((xinsn)->fld[0].rtx); register rtx xplus1 = ((xinsn)->fld[1].rtx); register n64_enum_rtx_code code0 = ((xplus0)->code); register n64_enum_rtx_code code1 = ((xplus1)->code); if (code0 != REG && code1 == REG) { xplus0 = ((xinsn)->fld[1].rtx); xplus1 = ((xinsn)->fld[0].rtx); code0 = ((xplus0)->code); code1 = ((xplus1)->code); } if (code0 == REG && (((((xplus0)->fld[0].rtint)) >= 68) || (((unsigned) ((((xplus0)->fld[0].rtint)) - 0) < (31 - 0 + 1))))) { if (code1 == CONST_INT && ((xplus1)->fld[0].rtwint) >= -32768 && ((xplus1)->fld[0].rtwint) + (mode_size[(int)(mode)]) - 1 <= 32767) goto win; if (!(target_flags & 0x20000000) && ! 0 && ((((xplus1)->code) == LABEL_REF || ((xplus1)->code) == SYMBOL_REF || ((xplus1)->code) == CONST_INT || ((xplus1)->code) == HIGH || (((xplus1)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (xplus1)) && ! 0)) && (!0 || !0)) && (!(target_flags & 0x00004000) || code1 != CONST || ((((xplus1)->fld[0].rtx))->code) != MINUS)) goto win; } } if ((target_flags & 0x10000000)) trace("Not a legitimate address\n"); };
  return 0;

 win:
  return 1;
}







int
memory_operand(register rtx op, n64_enum_machine_mode mode) asm("_memory_operand");
int
memory_operand(register rtx op, n64_enum_machine_mode mode)
{
  rtx inner;

  if (! reload_completed)


    return ((op)->code) == MEM && general_operand (op, mode);

  if (mode != VOIDmode && ((op)->mode) != mode)
    return 0;

  inner = op;
  if (((inner)->code) == SUBREG)
    inner = ((inner)->fld[0].rtx);

  return (((inner)->code) == MEM && general_operand (op, mode));
}




int
indirect_operand(register rtx op, n64_enum_machine_mode mode) asm("_indirect_operand");
int
indirect_operand(register rtx op, n64_enum_machine_mode mode)
{

  if (! reload_completed
      && ((op)->code) == SUBREG && ((((op)->fld[0].rtx))->code) == MEM)
    {
      register int offset = ((op)->fld[1].rtint) * ((target_flags & 0x00002000) ? 8 : 4);
      rtx inner = ((op)->fld[0].rtx);

      if (((target_flags & 0x00010000) != 0))
 offset -= (((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((op)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((op)->mode))])))
     - ((((target_flags & 0x00002000) ? 8 : 4)) < ((mode_size[(int)(((inner)->mode))])) ? (((target_flags & 0x00002000) ? 8 : 4)) : ((mode_size[(int)(((inner)->mode))]))));

      if (mode != VOIDmode && ((op)->mode) != mode)
 return 0;






      return ((offset == 0 && general_operand (((inner)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode)))
       || (((((inner)->fld[0].rtx))->code) == PLUS
    && ((((((inner)->fld[0].rtx))->fld[1].rtx))->code) == CONST_INT
    && ((((((inner)->fld[0].rtx))->fld[1].rtx))->fld[0].rtwint) == -offset
    && general_operand (((((inner)->fld[0].rtx))->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode))));
    }

  return (((op)->code) == MEM
   && memory_operand (op, mode)
   && general_operand (((op)->fld[0].rtx), ((target_flags & 0x00000002) ? DImode : SImode)));
}




int
comparison_operator(register rtx op, n64_enum_machine_mode mode) asm("_comparison_operator");
int
comparison_operator(register rtx op, n64_enum_machine_mode mode)
{
  return ((mode == VOIDmode || ((op)->mode) == mode)
   && (rtx_class[(int)(((op)->code))]) == '<');
}





int
asm_noperands(rtx body) asm("_asm_noperands");
int
asm_noperands(rtx body)
{
  if (((body)->code) == ASM_OPERANDS)

    return (((body))->fld[3].rtvec->num_elem);
  if (((body)->code) == SET && ((((body)->fld[1].rtx))->code) == ASM_OPERANDS)

    return (((((body)->fld[1].rtx)))->fld[3].rtvec->num_elem) + 1;
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == SET
    && ((((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx))->code) == ASM_OPERANDS)
    {


      int i;
      int n_sets;


      for (i = ((body)->fld[0].rtvec->num_elem); i > 0; i--)
 {
   if (((((body)->fld[0].rtvec->elem[i - 1].rtx))->code) == SET)
     break;
   if (((((body)->fld[0].rtvec->elem[i - 1].rtx))->code) != CLOBBER)
     return -1;
 }


      n_sets = i;




      for (i = 0; i < n_sets; i++)
 {
   rtx elt = ((body)->fld[0].rtvec->elem[i].rtx);
   if (((elt)->code) != SET)
     return -1;
   if (((((elt)->fld[1].rtx))->code) != ASM_OPERANDS)
     return -1;


   if ((((((elt)->fld[1].rtx)))->fld[3].rtvec)
       != (((((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx)))->fld[3].rtvec))
     return -1;
 }
      return ((((((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx)))->fld[3].rtvec->num_elem)
       + n_sets);
    }
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == ASM_OPERANDS)
    {


      int i;


      for (i = ((body)->fld[0].rtvec->num_elem) - 1; i > 0; i--)
 if (((((body)->fld[0].rtvec->elem[i].rtx))->code) != CLOBBER)
   return -1;

      return (((((body)->fld[0].rtvec->elem[0].rtx)))->fld[3].rtvec->num_elem);
    }
  else
    return -1;
}
char *
decode_asm_operands(rtx body, rtx *operands, rtx **operand_locs, char **constraints, n64_enum_machine_mode *modes) asm("_decode_asm_operands");
char *
decode_asm_operands(rtx body, rtx *operands, rtx **operand_locs, char **constraints, n64_enum_machine_mode *modes)
{
  register int i;
  int noperands;
  char *cxx_template = 0;

  if (((body)->code) == SET && ((((body)->fld[1].rtx))->code) == ASM_OPERANDS)
    {
      rtx asmop = ((body)->fld[1].rtx);


      noperands = (((asmop))->fld[3].rtvec->num_elem) + 1;

      for (i = 1; i < noperands; i++)
 {
   if (operand_locs)
     operand_locs[i] = &(((asmop))->fld[3].rtvec->elem[(i - 1)].rtx);
   if (operands)
     operands[i] = (((asmop))->fld[3].rtvec->elem[(i - 1)].rtx);
   if (constraints)
     constraints[i] = (((((asmop))->fld[4].rtvec->elem[(i - 1)].rtx))->fld[0].rtstr);
   if (modes)
     modes[i] = (((((asmop))->fld[4].rtvec->elem[(i - 1)].rtx))->mode);
 }



      if (operands)
 operands[0] = ((body)->fld[0].rtx);
      if (operand_locs)
 operand_locs[0] = &((body)->fld[0].rtx);
      if (constraints)
 constraints[0] = (((asmop))->fld[1].rtstr);
      if (modes)
 modes[0] = ((((body)->fld[0].rtx))->mode);
      cxx_template = (((asmop))->fld[0].rtstr);
    }
  else if (((body)->code) == ASM_OPERANDS)
    {
      rtx asmop = body;


      noperands = (((asmop))->fld[3].rtvec->num_elem);



      for (i = 0; i < noperands; i++)
 {
   if (operand_locs)
     operand_locs[i] = &(((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (operands)
     operands[i] = (((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (constraints)
     constraints[i] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->fld[0].rtstr);
   if (modes)
     modes[i] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->mode);
 }
      cxx_template = (((asmop))->fld[0].rtstr);
    }
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == SET)
    {
      rtx asmop = ((((body)->fld[0].rtvec->elem[0].rtx))->fld[1].rtx);
      int nparallel = ((body)->fld[0].rtvec->num_elem);
      int nin = (((asmop))->fld[3].rtvec->num_elem);
      int nout = 0;





      for (i = 0; i < nparallel; i++)
 {
   if (((((body)->fld[0].rtvec->elem[i].rtx))->code) == CLOBBER)
     break;

   if (operands)
     operands[i] = ((((body)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx);
   if (operand_locs)
     operand_locs[i] = &((((body)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx);
   if (constraints)
     constraints[i] = ((((((body)->fld[0].rtvec->elem[i].rtx))->fld[1].rtx))->fld[1].rtstr);
   if (modes)
     modes[i] = ((((((body)->fld[0].rtvec->elem[i].rtx))->fld[0].rtx))->mode);
   nout++;
 }

      for (i = 0; i < nin; i++)
 {
   if (operand_locs)
     operand_locs[i + nout] = &(((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (operands)
     operands[i + nout] = (((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (constraints)
     constraints[i + nout] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->fld[0].rtstr);
   if (modes)
     modes[i + nout] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->mode);
 }

      cxx_template = (((asmop))->fld[0].rtstr);
    }
  else if (((body)->code) == PARALLEL
    && ((((body)->fld[0].rtvec->elem[0].rtx))->code) == ASM_OPERANDS)
    {


      rtx asmop = ((body)->fld[0].rtvec->elem[0].rtx);
      int nin = (((asmop))->fld[3].rtvec->num_elem);

      for (i = 0; i < nin; i++)
 {
   if (operand_locs)
     operand_locs[i] = &(((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (operands)
     operands[i] = (((asmop))->fld[3].rtvec->elem[(i)].rtx);
   if (constraints)
     constraints[i] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->fld[0].rtstr);
   if (modes)
     modes[i] = (((((asmop))->fld[4].rtvec->elem[(i)].rtx))->mode);
 }

      cxx_template = (((asmop))->fld[0].rtstr);
    }

  return cxx_template;
}





static rtx *
find_constant_term_loc(rtx *p) asm("_find_constant_term_loc");
static rtx *
find_constant_term_loc(rtx *p)
{
  register rtx *tem;
  register n64_enum_rtx_code code = ((*p)->code);



  if (code == CONST_INT || code == SYMBOL_REF || code == LABEL_REF
      || code == CONST)
    return p;



  if (((*p)->code) != PLUS)
    return 0;



  if (((*p)->fld[0].rtx) && (((((*p)->fld[0].rtx))->code) == LABEL_REF || ((((*p)->fld[0].rtx))->code) == SYMBOL_REF || ((((*p)->fld[0].rtx))->code) == CONST_INT || ((((*p)->fld[0].rtx))->code) == CONST_DOUBLE || ((((*p)->fld[0].rtx))->code) == CONST || ((((*p)->fld[0].rtx))->code) == HIGH)
      && ((*p)->fld[1].rtx) && (((((*p)->fld[1].rtx))->code) == LABEL_REF || ((((*p)->fld[1].rtx))->code) == SYMBOL_REF || ((((*p)->fld[1].rtx))->code) == CONST_INT || ((((*p)->fld[1].rtx))->code) == CONST_DOUBLE || ((((*p)->fld[1].rtx))->code) == CONST || ((((*p)->fld[1].rtx))->code) == HIGH))
    return p;



  if (((*p)->fld[0].rtx) != 0)
    {
      tem = find_constant_term_loc (&((*p)->fld[0].rtx));
      if (tem != 0)
 return tem;
    }

  if (((*p)->fld[1].rtx) != 0)
    {
      tem = find_constant_term_loc (&((*p)->fld[1].rtx));
      if (tem != 0)
 return tem;
    }

  return 0;
}
int
offsettable_memref_p(rtx op) asm("_offsettable_memref_p");
int
offsettable_memref_p(rtx op)
{
  return ((((op)->code) == MEM)
   && offsettable_address_p (1, ((op)->mode), ((op)->fld[0].rtx)));
}




int
offsettable_nonstrict_memref_p(rtx op) asm("_offsettable_nonstrict_memref_p");
int
offsettable_nonstrict_memref_p(rtx op)
{
  return ((((op)->code) == MEM)
   && offsettable_address_p (0, ((op)->mode), ((op)->fld[0].rtx)));
}
int
offsettable_address_p(int strictp, n64_enum_machine_mode mode, register rtx y) asm("_offsettable_address_p");
int
offsettable_address_p(int strictp, n64_enum_machine_mode mode, register rtx y)
{
  register n64_enum_rtx_code ycode = ((y)->code);
  register rtx z;
  rtx y1 = y;
  rtx *y2;
  int (*addressp)(...) = (strictp  ? (int (*)(...))strict_memory_address_p : (int (*)(...))memory_address_p);

  if (((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == HIGH || (((y)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (y)) && ! 0)) && (!0 || !0)))
    return 1;




  if (mode_dependent_address_p (y))
    return 0;




  if ((ycode == PLUS) && (y2 = find_constant_term_loc (&y1)))
    {
      int good;

      y1 = *y2;
      *y2 = plus_constant_wide (*y2, (int) ((mode_size[(int)(mode)]) - 1));


      good = (*addressp) (QImode, y);


      *y2 = y1;
      return good;
    }

  if (ycode == PRE_DEC || ycode == PRE_INC
      || ycode == POST_DEC || ycode == POST_INC)
    return 0;






  z = plus_constant_for_output_wide (y, (int) ((mode_size[(int)(mode)]) - 1));



  return (*addressp) (QImode, z);
}







int
mode_dependent_address_p(rtx addr) asm("_mode_dependent_address_p");
int
mode_dependent_address_p(rtx addr)
{
  {};
  return 0;
 win:
  return 1;
}




int
mode_independent_operand(rtx op, n64_enum_machine_mode mode) asm("_mode_independent_operand");
int
mode_independent_operand(rtx op, n64_enum_machine_mode mode)
{
  rtx addr;

  if (! general_operand (op, mode))
    return 0;

  if (((op)->code) != MEM)
    return 1;

  addr = ((op)->fld[0].rtx);
  {};
  return 1;
 lose:
  return 0;
}







rtx
adj_offsettable_operand(rtx op, int offset) asm("_adj_offsettable_operand");
rtx
adj_offsettable_operand(rtx op, int offset)
{
  register n64_enum_rtx_code code = ((op)->code);

  if (code == MEM)
    {
      register rtx y = ((op)->fld[0].rtx);
      register rtx cxx_new;

      if (((((y)->code) == LABEL_REF || ((y)->code) == SYMBOL_REF || ((y)->code) == CONST_INT || ((y)->code) == HIGH || (((y)->code) == CONST && ! (flag_pic && pic_address_needs_scratch (y)) && ! 0)) && (!0 || !0)))
 {
   cxx_new = gen_rtx (MEM, ((op)->mode), plus_constant_for_output_wide (y, (int) (offset)));
   ((cxx_new)->unchanging) = ((op)->unchanging);
   return cxx_new;
 }

      if (((y)->code) == PLUS)
 {
   rtx z = y;
   register rtx *const_loc;

   op = copy_rtx (op);
   z = ((op)->fld[0].rtx);
   const_loc = find_constant_term_loc (&z);
   if (const_loc)
     {
       *const_loc = plus_constant_for_output_wide (*const_loc, (int) (offset));
       return op;
     }
 }

      cxx_new = gen_rtx (MEM, ((op)->mode), plus_constant_for_output_wide (y, (int) (offset)));
      ((cxx_new)->unchanging) = ((op)->unchanging);
      return cxx_new;
    }
  abort ();
}
struct n64_tag_funny_match
{
  int cxx_this, other;
};

int
constrain_operands(int insn_code_num, int strict) asm("_constrain_operands");
int
constrain_operands(int insn_code_num, int strict)
{
  char *constraints[10];
  int matching_operands[10];
  enum n64_cpp_enum_op_type{OP_IN, OP_OUT, OP_INOUT};
typedef __underlying_type(enum n64_cpp_enum_op_type) n64_enum_op_type;
n64_enum_op_type op_types[10];
  int earlyclobber[10];
  register int c;
  int noperands = insn_n_operands[insn_code_num];

  struct n64_tag_funny_match funny_match[10];
  int funny_match_index;
  int nalternatives = insn_n_alternatives[insn_code_num];

  if (noperands == 0 || nalternatives == 0)
    return 1;

  for (c = 0; c < noperands; c++)
    {
      constraints[c] = insn_operand_constraint[insn_code_num][c];
      matching_operands[c] = -1;
      op_types[c] = OP_IN;
    }

  which_alternative = 0;

  while (which_alternative < nalternatives)
    {
      register int opno;
      int lose = 0;
      funny_match_index = 0;

      for (opno = 0; opno < noperands; opno++)
 {
   register rtx op = recog_operand[opno];
   n64_enum_machine_mode mode = ((op)->mode);
   register char *p = constraints[opno];
   int offset = 0;
   int win = 0;
   int val;

   earlyclobber[opno] = 0;

   if (((op)->code) == SUBREG)
     {
       if (((((op)->fld[0].rtx))->code) == REG
    && ((((op)->fld[0].rtx))->fld[0].rtint) < 68)
  offset = ((op)->fld[1].rtint);
       op = ((op)->fld[0].rtx);
     }



   if (*p == 0 || *p == ',')
     win = 1;

   while (*p && (c = *p++) != ',')
     switch (c)
       {
       case '?':
       case '!':
       case '*':
       case '%':
  break;

       case '#':


  while (*p && *p != ',')
    p++;
  break;

       case '=':
  op_types[opno] = OP_OUT;
  break;

       case '+':
  op_types[opno] = OP_INOUT;
  break;

       case '&':
  earlyclobber[opno] = 1;
  break;

       case '0':
       case '1':
       case '2':
       case '3':
       case '4':
  if (strict < 0)
    val = 1;
  else
    val = operands_match_p (recog_operand[c - '0'],
       recog_operand[opno]);

  matching_operands[opno] = c - '0';
  matching_operands[c - '0'] = opno;

  if (val != 0)
    win = 1;



  if (val == 2 && strict > 0)
    {
      funny_match[funny_match_index].cxx_this = opno;
      funny_match[funny_match_index++].other = c - '0';
    }
  break;

       case 'p':




  if (strict <= 0
      || (strict_memory_address_p
   (insn_operand_mode[insn_code_num][opno], op)))
    win = 1;
  break;



       case 'g':


  if (strict < 0
      || GR_REGS == ALL_REGS
      || ((op)->code) != REG
      || (reload_in_progress
   && ((op)->fld[0].rtint) >= 68)
      || reg_fits_class_p (op, GR_REGS, offset, mode))
    win = 1;
  break;

       case 'r':
  if (strict < 0
      || (strict == 0
   && ((op)->code) == REG
   && ((op)->fld[0].rtint) >= 68)
      || (strict == 0 && ((op)->code) == SCRATCH)
      || (((op)->code) == REG
   && ((GR_REGS == ALL_REGS
        && ((op)->fld[0].rtint) < 68)
       || reg_fits_class_p (op, GR_REGS,
       offset, mode))))
    win = 1;
  break;

       case 'X':


  win = 1;
  break;

       case 'm':
  if (((op)->code) == MEM

      || (strict < 0 && (((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH))

      || (reload_in_progress && ((op)->code) == REG
   && ((op)->fld[0].rtint) >= 68))
    win = 1;
  break;

       case '<':
  if (((op)->code) == MEM
      && (((((op)->fld[0].rtx))->code) == PRE_DEC
   || ((((op)->fld[0].rtx))->code) == POST_DEC))
    win = 1;
  break;

       case '>':
  if (((op)->code) == MEM
      && (((((op)->fld[0].rtx))->code) == PRE_INC
   || ((((op)->fld[0].rtx))->code) == POST_INC))
    win = 1;
  break;

       case 'E':
  if (((op)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'F':
  if (((op)->code) == CONST_DOUBLE)
    win = 1;
  break;

       case 'G':
       case 'H':
  if (((op)->code) == CONST_DOUBLE
      && ((c) == 'G' && (op) == (const_tiny_rtx[0][(int) (((op)->mode))])))
    win = 1;
  break;

       case 's':
  if (((op)->code) == CONST_INT
      || (((op)->code) == CONST_DOUBLE
   && ((op)->mode) == VOIDmode))
    break;
       case 'i':
  if ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH))
    win = 1;
  break;

       case 'n':
  if (((op)->code) == CONST_INT
      || (((op)->code) == CONST_DOUBLE
   && ((op)->mode) == VOIDmode))
    win = 1;
  break;

       case 'I':
       case 'J':
       case 'K':
       case 'L':
       case 'M':
       case 'N':
       case 'O':
       case 'P':
  if (((op)->code) == CONST_INT
      && ((c) == 'I' ? ((unsigned int) ((((op)->fld[0].rtwint)) + 0x8000) < 0x10000) : (c) == 'J' ? ((((op)->fld[0].rtwint)) == 0) : (c) == 'K' ? ((unsigned int) (((op)->fld[0].rtwint)) < 0x10000) : (c) == 'L' ? (((((op)->fld[0].rtwint)) & 0x0000ffff) == 0 && (((((op)->fld[0].rtwint)) & ~2147483647) == 0 || ((((op)->fld[0].rtwint)) & ~2147483647) == ~2147483647)) : (c) == 'M' ? ((((((op)->fld[0].rtwint)) & ~0x0000ffff) != 0) && (((((op)->fld[0].rtwint)) & ~0x0000ffff) != ~0x0000ffff) && (((((op)->fld[0].rtwint)) & 0x0000ffff) != 0 || (((((op)->fld[0].rtwint)) & ~2147483647) != 0 && ((((op)->fld[0].rtwint)) & ~2147483647) != ~2147483647))) : (c) == 'N' ? (((((op)->fld[0].rtwint)) & ~0x0000ffff) == ~0x0000ffff) : (c) == 'O' ? (exact_log2_wide ((int) (((op)->fld[0].rtwint))) >= 0) : (c) == 'P' ? ((((op)->fld[0].rtwint)) != 0 && (((((op)->fld[0].rtwint)) & ~0x0000ffff) == 0)) : 0))
    win = 1;
  break;


              case 'Q':
              case 'R':
              case 'S':
              case 'T':
              case 'U':
  if (((((op)->code) != MEM) ? 0 : ((c) == 'Q') ? !simple_memory_operand (op, ((op)->mode)) : ((c) == 'R') ? simple_memory_operand (op, ((op)->mode)) : ((c) == 'S') ? (0 && (((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH) && 0) : 0))
    win = 1;
  break;


       case 'V':
  if (((op)->code) == MEM
      && ! offsettable_memref_p (op))
    win = 1;
  break;

       case 'o':
  if ((strict > 0 && offsettable_memref_p (op))
      || (strict == 0 && offsettable_nonstrict_memref_p (op))

      || (strict < 0
   && ((((op)->code) == LABEL_REF || ((op)->code) == SYMBOL_REF || ((op)->code) == CONST_INT || ((op)->code) == CONST_DOUBLE || ((op)->code) == CONST || ((op)->code) == HIGH) || ((op)->code) == MEM))

      || (reload_in_progress && ((op)->code) == REG
   && ((op)->fld[0].rtint) >= 68))
    win = 1;
  break;

       default:
  if (strict < 0
      || (strict == 0
   && ((op)->code) == REG
   && ((op)->fld[0].rtint) >= 68)
      || (strict == 0 && ((op)->code) == SCRATCH)
      || (((op)->code) == REG
   && reg_fits_class_p (op, mips_char_to_class[ (c) ],
          offset, mode)))
    win = 1;
       }

   constraints[opno] = p;


   if (! win)
     lose = 1;
 }


      if (! lose)
 {
   int opno, eopno;




   if (strict > 0)
     for (eopno = 0; eopno < noperands; eopno++)



       if (earlyclobber[eopno]
    && ((recog_operand[eopno])->code) == REG)
  for (opno = 0; opno < noperands; opno++)
    if ((((recog_operand[opno])->code) == MEM
         || op_types[opno] != OP_OUT)
        && opno != eopno

        && *constraints[opno] != 0
        && ! (matching_operands[opno] == eopno
       && rtx_equal_p (recog_operand[opno],
         recog_operand[eopno]))
        && ! safe_from_earlyclobber (recog_operand[opno],
         recog_operand[eopno]))
      lose = 1;

   if (! lose)
     {
       while (--funny_match_index >= 0)
  {
    recog_operand[funny_match[funny_match_index].other]
      = recog_operand[funny_match[funny_match_index].cxx_this];
  }

       return 1;
     }
 }

      which_alternative++;
    }



  if (strict == 0)
    return constrain_operands (insn_code_num, -1);
  else
    return 0;
}






int
reg_fits_class_p(rtx operand, register n64_enum_reg_class cxx_class, int offset, n64_enum_machine_mode mode) asm("_reg_fits_class_p");
int
reg_fits_class_p(rtx operand, register n64_enum_reg_class cxx_class, int offset, n64_enum_machine_mode mode)
{
  register int regno = ((operand)->fld[0].rtint);
  if (regno < 68
      && ((reg_class_contents[(int) cxx_class])[(regno + offset) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + offset) % ((unsigned) 32))))
                      )
    {
      register int sr;
      regno += offset;
      for (sr = (! ((unsigned) ((regno) - 32) < (63 - 32 + 1)) ? (((mode_size[(int)(mode)]) + ((target_flags & 0x00002000) ? 8 : 4) - 1) / ((target_flags & 0x00002000) ? 8 : 4)) : (((mode_size[(int)(mode)]) + ((target_flags & 0x00000200) ? 8 : 4) - 1) / ((target_flags & 0x00000200) ? 8 : 4))) - 1;
    sr > 0; sr--)
 if (! ((reg_class_contents[(int) cxx_class])[(regno + sr) / ((unsigned) 32)] & (((HARD_REG_ELT_TYPE) (1)) << ((regno + sr) % ((unsigned) 32))))
                )
   break;
      return sr == 0;
    }

  return 0;
}

