// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From binutils/gas/gasp.c
/* gasp.c - Gnu assembler preprocessor main program.
   Copyright (C) 1994, 1995 Free Software Foundation, Inc.

   Written by Steve and Judy Chamberlain of Cygnus Support,
      sac@cygnus.com

   This file is part of GASP, the GNU Assembler Preprocessor.

   GASP is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   GASP is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with GASP; see the file COPYING.  If not, write to the Free
   Software Foundation, 59 Temple Place - Suite 330, Boston, MA
   02111-1307, USA. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
struct n64_tag_formal_struct;
struct n64_tag_hs;
struct n64_tag_include_path;
struct n64_tag_include_stack;
struct n64_tag_keyword;
struct n64_tag_le;
struct n64_tag_macro_struct;
struct n64_tag_option;
struct n64_tag_sb;


extern char *optarg;
extern int optind;




extern int opterr;



extern int optopt;
struct n64_tag_option
{

  const char *name;





  int has_arg;
  int *flag;
  int val;
};
extern int getopt(...) asm("_getopt");

extern int getopt_long (int argc, char *const *argv, const char *shortopts,
          const struct n64_tag_option *longopts, int *longind) asm("_getopt_long");
extern int getopt_long_only (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind) asm("_getopt_long_only");


extern int _getopt_internal (int argc, char *const *argv,
        const char *shortopts,
               const struct n64_tag_option *longopts, int *longind,
        int long_only) asm("__getopt_internal");













extern char **buildargv (char *) asm("_buildargv");



extern void freeargv (char **) asm("_freeargv");



extern char *basename(...) asm("_basename");




extern char *concat (const char *, ...) asm("_concat");



extern int fdmatch (int fd1, int fd2) asm("_fdmatch");



extern long get_run_time (void) asm("_get_run_time");



extern const char *spaces (int count) asm("_spaces");




extern int errno_max (void) asm("_errno_max");




extern const char *strerrno (int) asm("_strerrno");



extern int strtoerrno (const char *) asm("_strtoerrno");



extern char *xstrerror (int) asm("_xstrerror");




extern int signo_max (void) asm("_signo_max");
extern const char *strsigno (int) asm("_strsigno");



extern int strtosigno (const char *) asm("_strtosigno");



extern int xatexit (void (*fn) (void)) asm("_xatexit");






typedef void libiberty_voidfn (int status);
__volatile__ libiberty_voidfn xexit asm("_xexit");




extern void xmalloc_set_program_name (const char *) asm("_xmalloc_set_program_name");
extern void * xmalloc(...) asm("_xmalloc");






extern void * xrealloc(...) asm("_xrealloc");





extern char _hex_value[256];
extern void hex_init (void) asm("_hex_init");
typedef struct n64_tag_sb
  {
    char *ptr;
    int len;
    int pot;
    struct n64_tag_le *item;
  }
sb;


typedef struct n64_tag_le
  {
    struct n64_tag_le *next;
    int size;
    char data[1];
  }
sb_element;


typedef struct
  {
    sb_element *size[30];
  } sb_list_vector;

extern int string_count[30];

extern void sb_build (sb *, int) asm("_sb_build");
extern void sb_new (sb *) asm("_sb_new");
extern void sb_kill (sb *) asm("_sb_kill");
extern void sb_add_sb (sb *, sb *) asm("_sb_add_sb");
extern void sb_reset (sb *) asm("_sb_reset");
extern void sb_add_char (sb *, int) asm("_sb_add_char");
extern void sb_add_string (sb *, const char *) asm("_sb_add_string");
extern void sb_add_buffer (sb *, const char *, int) asm("_sb_add_buffer");
extern void sb_print (FILE *, sb *) asm("_sb_print");
extern void sb_print_at (FILE *, int, sb *) asm("_sb_print_at");
extern char *sb_name (sb *) asm("_sb_name");
extern char *sb_terminate (sb *) asm("_sb_terminate");
extern int sb_skip_white (int, sb *) asm("_sb_skip_white");
extern int sb_skip_comma (int, sb *) asm("_sb_skip_comma");


extern void input_scrub_include_sb (sb *, char *) asm("_input_scrub_include_sb");
extern int macro_defined;

extern int buffer_and_nest
  (const char *, const char *, sb *, int (*) (sb *)) asm("_buffer_and_nest");
extern void macro_init
  (int alternate, int mri, int strip_at, int (*) (const char *, int, sb *, int *)) asm("_macro_init")
                                                       ;
extern const char *define_macro
  (int idx, sb *in, sb *label, int (*get_line) (sb *)) asm("_define_macro");
extern int check_macro (const char *, sb *, int, const char **) asm("_check_macro");
extern void delete_macro (const char *) asm("_delete_macro");
extern const char *expand_irp
  (int, int, sb *, sb *, int (*) (sb *), int) asm("_expand_irp");

char *program_version = "1.2";




int unreasonable;
int stats;
int print_line_number;
int copysource;
int warnings;
int errors;
int fatals;
int alternate = 0;
int mri = 0;
char comment_char = '!';
int radix = 10;

int had_end;


FILE *outfile;
static char chartype[256];
struct
  {
    int on;
    int hadelse;
  }
ifstack[100];
int ifi;





typedef struct
  {
    char *name;
    int len;
  }
symbol;

typedef struct
  {
    int value;
    symbol add_symbol;
    symbol sub_symbol;
  }
exp_t;
enum n64_cpp_enum_anonymous_0{
    hash_integer,
    hash_string,
    hash_macro,
    hash_formal
  };
typedef __underlying_type(enum n64_cpp_enum_anonymous_0) n64_enum_anonymous_0;
typedef n64_enum_anonymous_0 hash_type;

typedef struct n64_tag_hs
  {
    sb key;
    hash_type type;
    union
      {
 sb s;
 int i;
 struct n64_tag_macro_struct *m;
 struct n64_tag_formal_struct *f;
      } value;
    struct n64_tag_hs *next;
  } hash_entry;

typedef struct
  {
    hash_entry **table;
    int size;
  } hash_table;
typedef struct n64_tag_formal_struct
  {
    struct n64_tag_formal_struct *next;
    sb name;
    sb def;
    sb actual;
    int index;
  }
formal_entry;



typedef struct n64_tag_macro_struct
  {
    sb sub;
    int formal_count;
    formal_entry *formals;
    hash_table formal_hash;
  }
macro_entry;
enum n64_cpp_enum_anonymous_1{
    include_file, include_repeat, include_while, include_macro
  };
typedef __underlying_type(enum n64_cpp_enum_anonymous_1) n64_enum_anonymous_1;
typedef n64_enum_anonymous_1 include_type;

struct n64_tag_include_stack
  {
    sb pushback;
    int pushback_index;
    FILE *handle;
    sb name;
    int linecount;
    include_type type;
    int index;
  }
include_stack[30];

struct n64_tag_include_stack *sp;




typedef struct n64_tag_include_path
{
  struct n64_tag_include_path *next;
  sb path;
} include_path;

include_path *paths_head;
include_path *paths_tail;


static void quit (void) asm("_quit");
static void hash_new_table (int, hash_table *) asm("_hash_new_table");
static int hash (sb *) asm("_hash");
static hash_entry *hash_create (hash_table *, sb *) asm("_hash_create");
static void hash_add_to_string_table (hash_table *, sb *, sb *, int) asm("_hash_add_to_string_table");
static void hash_add_to_int_table (hash_table *, sb *, int) asm("_hash_add_to_int_table");
static hash_entry *hash_lookup (hash_table *, sb *) asm("_hash_lookup");
static void checkconst (int, exp_t *) asm("_checkconst");
static int sb_strtol (int, sb *, int, int *) asm("_sb_strtol");
static int level_0 (int, sb *, exp_t *) asm("_level_0");
static int level_1 (int, sb *, exp_t *) asm("_level_1");
static int level_2 (int, sb *, exp_t *) asm("_level_2");
static int level_3 (int, sb *, exp_t *) asm("_level_3");
static int level_4 (int, sb *, exp_t *) asm("_level_4");
static int level_5 (int, sb *, exp_t *) asm("_level_5");
static int exp_parse (int, sb *, exp_t *) asm("_exp_parse");
static void exp_string (exp_t *, sb *) asm("_exp_string");
static int exp_get_abs (const char *, int, sb *, int *) asm("_exp_get_abs");



static void unget (int) asm("_unget");
static void include_buf (sb *, sb *, include_type, int) asm("_include_buf");
static void include_print_where_line (FILE *) asm("_include_print_where_line");
static void include_print_line (FILE *) asm("_include_print_line");
static int get_line (sb *) asm("_get_line");
static int grab_label (sb *, sb *) asm("_grab_label");
static void change_base (int, sb *, sb *) asm("_change_base");
static void do_end (sb *) asm("_do_end");
static void do_assign (int, int, sb *) asm("_do_assign");
static void do_radix (sb *) asm("_do_radix");
static int get_opsize (int, sb *, int *) asm("_get_opsize");
static int eol (int, sb *) asm("_eol");
static void do_data (int, sb *, int) asm("_do_data");
static void do_datab (int, sb *) asm("_do_datab");
static void do_align (int, sb *) asm("_do_align");
static void do_res (int, sb *, int) asm("_do_res");
static void do_export (sb *) asm("_do_export");
static void do_print (int, sb *) asm("_do_print");
static void do_heading (int, sb *) asm("_do_heading");
static void do_page (void) asm("_do_page");
static void do_form (int, sb *) asm("_do_form");
static int get_any_string (int, sb *, sb *, int, int) asm("_get_any_string");
static int skip_openp (int, sb *) asm("_skip_openp");
static int skip_closep (int, sb *) asm("_skip_closep");
static int dolen (int, sb *, sb *) asm("_dolen");
static int doinstr (int, sb *, sb *) asm("_doinstr");
static int dosubstr (int, sb *, sb *) asm("_dosubstr");
static void process_assigns (int, sb *, sb *) asm("_process_assigns");
static int get_and_process (int, sb *, sb *) asm("_get_and_process");
static void process_file (void) asm("_process_file");
static void free_old_entry (hash_entry *) asm("_free_old_entry");
static void do_assigna (int, sb *) asm("_do_assigna");
static void do_assignc (int, sb *) asm("_do_assignc");
static void do_reg (int, sb *) asm("_do_reg");
static int condass_lookup_name (sb *, int, sb *, int) asm("_condass_lookup_name");
static int whatcond (int, sb *, int *) asm("_whatcond");
static int istrue (int, sb *) asm("_istrue");
static void do_aif (int, sb *) asm("_do_aif");
static void do_aelse (void) asm("_do_aelse");
static void do_aendi (void) asm("_do_aendi");
static int condass_on (void) asm("_condass_on");
static void do_if (int, sb *, int) asm("_do_if");
static int get_mri_string (int, sb *, sb *, int) asm("_get_mri_string");
static void do_ifc (int, sb *, int) asm("_do_ifc");
static void do_aendr (void) asm("_do_aendr");
static void do_awhile (int, sb *) asm("_do_awhile");
static void do_aendw (void) asm("_do_aendw");
static void do_exitm (void) asm("_do_exitm");
static void do_arepeat (int, sb *) asm("_do_arepeat");
static void do_endm (void) asm("_do_endm");
static void do_irp (int, sb *, int) asm("_do_irp");
static void do_local (int, sb *) asm("_do_local");
static void do_macro (int, sb *) asm("_do_macro");
static int macro_op (int, sb *) asm("_macro_op");
static int getstring (int, sb *, sb *) asm("_getstring");
static void do_sdata (int, sb *, int) asm("_do_sdata");
static void do_sdatab (int, sb *) asm("_do_sdatab");
static int new_file (const char *) asm("_new_file");
static void do_include (int, sb *) asm("_do_include");
static void include_pop (void) asm("_include_pop");
static int get (void) asm("_get");
static int linecount (void) asm("_linecount");
static int include_next_index (void) asm("_include_next_index");
static void chartype_init (void) asm("_chartype_init");
static int process_pseudo_op (int, sb *, sb *) asm("_process_pseudo_op");
static void add_keyword (const char *, int) asm("_add_keyword");
static void process_init (void) asm("_process_init");
static void do_define (const char *) asm("_do_define");
static void show_usage (FILE *, int) asm("_show_usage");
static void show_help (void) asm("_show_help");
static void
quit(void) asm("_quit");
static void
quit(void)
{
  int exitcode;
  if (fatals + errors)
    exitcode = 1;
  else
    exitcode = 0;

  if (stats)
    {
      int i;
      for (i = 0; i < 30; i++)
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "strings size %8d : %d\n", 1<<i, string_count[i]);
 }
    }
  exit (exitcode);
}





static void
hash_new_table(int size, hash_table *ptr) asm("_hash_new_table");
static void
hash_new_table(int size, hash_table *ptr)
{
  int i;
  ptr->size = size;
  ptr->table = (hash_entry **) xmalloc (size * (sizeof (hash_entry *)));

  for (i = 0; i < size; i++)
    ptr->table[i] = 0;
}



static int
hash(sb *key) asm("_hash");
static int
hash(sb *key)
{
  int k = 0x1234;
  int i;
  char *p = key->ptr;
  for (i = 0; i < key->len; i++)
    {
      k ^= (k << 2) ^ *p;
      p++;
    }
  return k & 0xf0fff;
}




static
hash_entry *
hash_create(hash_table *tab, sb *key) asm("_hash_create");
hash_entry *
hash_create(hash_table *tab, sb *key)
{
  int k = hash (key) % tab->size;
  hash_entry *p;
  hash_entry **table = tab->table;

  p = table[k];

  while (1)
    {
      if (!p)
 {
   hash_entry *n = (hash_entry *) xmalloc (sizeof (hash_entry));
   n->next = table[k];
   sb_new (&n->key);
   sb_add_sb (&n->key, key);
   table[k] = n;
   n->type = hash_integer;
   return n;
 }
      if (strncmp (table[k]->key.ptr, key->ptr, key->len) == 0)
 {
   return p;
 }
      p = p->next;
    }
}




static
void
hash_add_to_string_table(hash_table *tab, sb *key, sb *name, int again) asm("_hash_add_to_string_table");
void
hash_add_to_string_table(hash_table *tab, sb *key, sb *name, int again)
{
  hash_entry *ptr = hash_create (tab, key);
  if (ptr->type == hash_integer)
    {
      sb_new (&ptr->value.s);
    }
  if (ptr->value.s.len)
    {
      if (!again)
 do { include_print_where_line (
(__acrt_iob_func(2))
); fprintf (
(__acrt_iob_func(2))
, "redefintion not allowed"); errors++; } while(0);
    }

  ptr->type = hash_string;
  sb_reset (&ptr->value.s);

  sb_add_sb (&ptr->value.s, name);
}



static
void
hash_add_to_int_table(hash_table *tab, sb *key, int name) asm("_hash_add_to_int_table");
void
hash_add_to_int_table(hash_table *tab, sb *key, int name)
{
  hash_entry *ptr = hash_create (tab, key);
  ptr->value.i = name;
}




static
hash_entry *
hash_lookup(hash_table *tab, sb *key) asm("_hash_lookup");
hash_entry *
hash_lookup(hash_table *tab, sb *key)
{
  int k = hash (key) % tab->size;
  hash_entry **table = tab->table;
  hash_entry *p = table[k];
  while (p)
    {
      if (p->key.len == key->len
   && strncmp (p->key.ptr, key->ptr, key->len) == 0)
 return p;
      p = p->next;
    }
  return 0;
}
static
void
checkconst(int op, exp_t *term) asm("_checkconst");
void
checkconst(int op, exp_t *term)
{
  if (term->add_symbol.len
      || term->sub_symbol.len)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "the %c operator cannot take non-absolute arguments.\n", op); errors++; } while(0);
    }
}





static
int
sb_strtol(int idx, sb *string, int base, int *ptr) asm("_sb_strtol");
int
sb_strtol(int idx, sb *string, int base, int *ptr)
{
  int value = 0;
  idx = sb_skip_white (idx, string);

  while (idx < string->len)
    {
      int ch = string->ptr[idx];
      int dig = 0;
      if (isdigit (ch))
 dig = ch - '0';
      else if (ch >= 'a' && ch <= 'f')
 dig = ch - 'a' + 10;
      else if (ch >= 'A' && ch <= 'F')
 dig = ch - 'A' + 10;
      else
 break;

      if (dig >= base)
 break;

      value = value * base + dig;
      idx++;
    }
  *ptr = value;
  return idx;
}

static int
level_0(int idx, sb *string, exp_t *lhs) asm("_level_0");
static int
level_0(int idx, sb *string, exp_t *lhs)
{
  lhs->add_symbol.len = 0;
  lhs->add_symbol.name = 0;

  lhs->sub_symbol.len = 0;
  lhs->sub_symbol.name = 0;

  idx = sb_skip_white (idx, string);

  lhs->value = 0;

  if (isdigit (string->ptr[idx]))
    {
      idx = sb_strtol (idx, string, 10, &lhs->value);
    }
  else if ((chartype[(unsigned)(string->ptr[idx])] & 1))
    {
      int len = 0;
      lhs->add_symbol.name = string->ptr + idx;
      while (idx < string->len && (chartype[(unsigned)(string->ptr[idx])] & 2))
 {
   idx++;
   len++;
 }
      lhs->add_symbol.len = len;
    }
  else if (string->ptr[idx] == '"')
    {
      sb acc;
      sb_new (&acc);
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "string where expression expected.\n"); errors++; } while(0);
      idx = getstring (idx, string, &acc);
      sb_kill (&acc);
    }
  else
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "can't find primary in expression.\n"); errors++; } while(0);
      idx++;
    }
  return sb_skip_white (idx, string);
}



static int
level_1(int idx, sb *string, exp_t *lhs) asm("_level_1");
static int
level_1(int idx, sb *string, exp_t *lhs)
{
  idx = sb_skip_white (idx, string);

  switch (string->ptr[idx])
    {
    case '+':
      idx = level_1 (idx + 1, string, lhs);
      break;
    case '~':
      idx = level_1 (idx + 1, string, lhs);
      checkconst ('~', lhs);
      lhs->value = ~lhs->value;
      break;
    case '-':
      {
 symbol t;
 idx = level_1 (idx + 1, string, lhs);
 lhs->value = -lhs->value;
 t = lhs->add_symbol;
 lhs->add_symbol = lhs->sub_symbol;
 lhs->sub_symbol = t;
 break;
      }
    case '(':
      idx++;
      idx = level_5 (sb_skip_white (idx, string), string, lhs);
      if (string->ptr[idx] != ')')
 do { include_print_where_line (
(__acrt_iob_func(2))
); fprintf (
(__acrt_iob_func(2))
, "misplaced closing parens.\n"); errors++; } while(0);
      else
 idx++;
      break;
    default:
      idx = level_0 (idx, string, lhs);
      break;
    }
  return sb_skip_white (idx, string);
}

static int
level_2(int idx, sb *string, exp_t *lhs) asm("_level_2");
static int
level_2(int idx, sb *string, exp_t *lhs)
{
  exp_t rhs;

  idx = level_1 (idx, string, lhs);

  while (idx < string->len && (string->ptr[idx] == '*'
          || string->ptr[idx] == '/'))
    {
      char op = string->ptr[idx++];
      idx = level_1 (idx, string, &rhs);
      switch (op)
 {
 case '*':
   checkconst ('*', lhs);
   checkconst ('*', &rhs);
   lhs->value *= rhs.value;
   break;
 case '/':
   checkconst ('/', lhs);
   checkconst ('/', &rhs);
   if (rhs.value == 0)
     do { include_print_where_line (
    (__acrt_iob_func(2))
    ); fprintf (
    (__acrt_iob_func(2))
    , "attempt to divide by zero.\n"); errors++; } while(0);
   else
     lhs->value /= rhs.value;
   break;
 }
    }
  return sb_skip_white (idx, string);
}


static int
level_3(int idx, sb *string, exp_t *lhs) asm("_level_3");
static int
level_3(int idx, sb *string, exp_t *lhs)
{
  exp_t rhs;

  idx = level_2 (idx, string, lhs);

  while (idx < string->len
  && (string->ptr[idx] == '+'
      || string->ptr[idx] == '-'))
    {
      char op = string->ptr[idx++];
      idx = level_2 (idx, string, &rhs);
      switch (op)
 {
 case '+':
   lhs->value += rhs.value;
   if (lhs->add_symbol.name && rhs.add_symbol.name)
     {
       do { include_print_where_line (
      (__acrt_iob_func(2))
      ); fprintf (
      (__acrt_iob_func(2))
      , "can't add two relocatable expressions\n"); errors++; } while(0);
     }

   if (rhs.add_symbol.name)
     {
       lhs->add_symbol = rhs.add_symbol;
     }
   break;
 case '-':
   lhs->value -= rhs.value;
   lhs->sub_symbol = rhs.add_symbol;
   break;
 }
    }
  return sb_skip_white (idx, string);
}

static int
level_4(int idx, sb *string, exp_t *lhs) asm("_level_4");
static int
level_4(int idx, sb *string, exp_t *lhs)
{
  exp_t rhs;

  idx = level_3 (idx, string, lhs);

  while (idx < string->len &&
  string->ptr[idx] == '&')
    {
      char op = string->ptr[idx++];
      idx = level_3 (idx, string, &rhs);
      switch (op)
 {
 case '&':
   checkconst ('&', lhs);
   checkconst ('&', &rhs);
   lhs->value &= rhs.value;
   break;
 }
    }
  return sb_skip_white (idx, string);
}

static int
level_5(int idx, sb *string, exp_t *lhs) asm("_level_5");
static int
level_5(int idx, sb *string, exp_t *lhs)
{
  exp_t rhs;

  idx = level_4 (idx, string, lhs);

  while (idx < string->len
  && (string->ptr[idx] == '|' || string->ptr[idx] == '~'))
    {
      char op = string->ptr[idx++];
      idx = level_4 (idx, string, &rhs);
      switch (op)
 {
 case '|':
   checkconst ('|', lhs);
   checkconst ('|', &rhs);
   lhs->value |= rhs.value;
   break;
 case '~':
   checkconst ('~', lhs);
   checkconst ('~', &rhs);
   lhs->value ^= rhs.value;
   break;
 }
    }
  return sb_skip_white (idx, string);
}






static int
exp_parse(int idx, sb *string, exp_t *res) asm("_exp_parse");
static int
exp_parse(int idx, sb *string, exp_t *res)
{
  return level_5 (sb_skip_white (idx, string), string, res);
}





static void
exp_string(exp_t *exp, sb *string) asm("_exp_string");
static void
exp_string(exp_t *exp, sb *string)
{
  int np = 0;
  int ad = 0;
  sb_reset (string);

  if (exp->add_symbol.len)
    {
      sb_add_buffer (string, exp->add_symbol.name, exp->add_symbol.len);
      np = 1;
      ad = 1;
    }
  if (exp->value)
    {
      char buf[20];
      if (np)
 sb_add_char (string, '+');
      sprintf (buf, "%d", exp->value);
      sb_add_string (string, buf);
      np = 1;
      ad = 1;
    }
  if (exp->sub_symbol.len)
    {
      sb_add_char (string, '-');
      sb_add_buffer (string, exp->add_symbol.name, exp->add_symbol.len);
      np = 0;
      ad = 1;
    }

  if (!ad)
    sb_add_char (string, '0');
}






static int
exp_get_abs(const char *emsg, int idx, sb *in, int *val) asm("_exp_get_abs");
static int
exp_get_abs(const char *emsg, int idx, sb *in, int *val)
{
  exp_t res;
  idx = exp_parse (idx, in, &res);
  if (res.add_symbol.len || res.sub_symbol.len)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , emsg); errors++; } while(0);
  *val = res.value;
  return idx;
}


sb label;
hash_table assign_hash_table;
hash_table keyword_hash_table;
hash_table vars;
static void
unget(int ch) asm("_unget");
static void
unget(int ch)
{
  if (ch == '\n')
    {
      sp->linecount--;
    }
  if (sp->pushback_index)
    sp->pushback_index--;
  else
    sb_add_char (&sp->pushback, ch);
}



static
void
include_buf(sb *name, sb *ptr, include_type type, int index) asm("_include_buf");
void
include_buf(sb *name, sb *ptr, include_type type, int index)
{
  sp++;
  if (sp - include_stack >= 30)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "unreasonable nesting.\n") ; fatals++; quit(); } while(0);
  sb_new (&sp->name);
  sb_add_sb (&sp->name, name);
  sp->handle = 0;
  sp->linecount = 1;
  sp->pushback_index = 0;
  sp->type = type;
  sp->index = index;
  sb_new (&sp->pushback);
  sb_add_sb (&sp->pushback, ptr);
}



static
void
include_print_where_line(FILE *file) asm("_include_print_where_line");
void
include_print_where_line(FILE *file)
{
  struct n64_tag_include_stack *p = include_stack + 1;

  while (p <= sp)
    {
      fprintf (file, "%s:%d ", sb_name (&p->name), p->linecount - 1);
      p++;
    }
}


static void
include_print_line(FILE *file) asm("_include_print_line");
static void
include_print_line(FILE *file)
{
  int n;
  struct n64_tag_include_stack *p = include_stack + 1;

  n = fprintf (file, "%4d", p->linecount);
  p++;
  while (p <= sp)
    {
      n += fprintf (file, ".%d", p->linecount);
      p++;
    }
  while (n < 8 * 3)
    {
      fprintf (file, " ");
      n++;
    }
}




static int
get_line(sb *in) asm("_get_line");
static int
get_line(sb *in)
{
  int online = 0;
  int more = 1;

  if (copysource)
    {
      putc (comment_char, outfile);
      if (print_line_number)
 include_print_line (outfile);
    }

  while (1)
    {
      int ch = get ();

      while (ch == '\r')
 ch = get ();

      if (ch == 
               (-1)
                  )
 {
   if (online)
     {
       do { include_print_where_line (
      (__acrt_iob_func(2))
      ); fprintf (
      (__acrt_iob_func(2))
      , "End of file not at start of line.\n"); warnings++;} while(0);
       if (copysource)
  putc ('\n', outfile);
       ch = '\n';
     }
   else
     more = 0;
   break;
 }

      if (copysource)
 {
   putc (ch, outfile);
 }

      if (ch == '\n')
 {
   ch = get ();
   online = 0;
   if (ch == '+')
     {

       if (copysource)
  {
    putc (comment_char, outfile);
    putc ('+', outfile);
  }
       ch = get ();
     }
   else
     {
       if (ch != 
                (-1)
                   )
  unget (ch);
       break;
     }
 }
      else
 {
   sb_add_char (in, ch);
 }
      online++;
    }

  return more;
}



static int
grab_label(sb *in, sb *out) asm("_grab_label");
static int
grab_label(sb *in, sb *out)
{
  int i = 0;
  sb_reset (out);
  if ((chartype[(unsigned)(in->ptr[i])] & 1))
    {
      sb_add_char (out, in->ptr[i]);
      i++;
      while (((chartype[(unsigned)(in->ptr[i])] & 2)
       || in->ptr[i] == '\\'
       || in->ptr[i] == '&')
      && i < in->len)
 {
   sb_add_char (out, in->ptr[i]);
   i++;
 }
    }
  return i;
}




static void
change_base(int idx, sb *in, sb *out) asm("_change_base");
static void
change_base(int idx, sb *in, sb *out)
{
  char buffer[20];

  while (idx < in->len)
    {
      if (idx < in->len - 1 && in->ptr[idx + 1] == '\'' && ! mri)
 {
   int base;
   int value;
   switch (in->ptr[idx])
     {
     case 'b':
     case 'B':
       base = 2;
       break;
     case 'q':
     case 'Q':
       base = 8;
       break;
     case 'h':
     case 'H':
       base = 16;
       break;
     case 'd':
     case 'D':
       base = 10;
       break;
     default:
       do { include_print_where_line (
      (__acrt_iob_func(2))
      ); fprintf (
      (__acrt_iob_func(2))
      , "Illegal base character %c.\n", in->ptr[idx]); errors++; } while(0);
       base = 10;
       break;
     }

   idx = sb_strtol (idx + 2, in, base, &value);
   sprintf (buffer, "%d", value);
   sb_add_string (out, buffer);
 }
      else if ((chartype[(unsigned)(in->ptr[idx])] & 1))
 {

   sb_add_char (out, in->ptr[idx]);
   idx++;
   while (idx < in->len && (chartype[(unsigned)(in->ptr[idx])] & 2))
     {
       sb_add_char (out, in->ptr[idx]);
       idx++;
     }
 }
      else if (isdigit (in->ptr[idx]))
 {
   int value;


   idx = sb_strtol (idx, in, radix, &value);
   sprintf (buffer, "%d", value);
   sb_add_string (out, buffer);


   while (idx < in->len && (chartype[(unsigned)(in->ptr[idx])] & 2))
     {
       sb_add_char (out, in->ptr[idx]);
       idx++;
     }
 }
      else if (in->ptr[idx] == '"' || in->ptr[idx] == '\'')
 {
   char tchar = in->ptr[idx];

   sb_add_char (out, in->ptr[idx]);
   idx++;
   while (idx < in->len && in->ptr[idx] != tchar)
     {
       sb_add_char (out, in->ptr[idx]);
       idx++;
     }
 }
      else
 {

   sb_add_char (out, in->ptr[idx]);
   idx++;
 }
    }

}


static void
do_end(sb *in) asm("_do_end");
static void
do_end(sb *in)
{
  had_end = 1;
  if (mri)
    fprintf (outfile, "%s\n", sb_name (in));
}



static void
do_assign(int again, int idx, sb *in) asm("_do_assign");
static void
do_assign(int again, int idx, sb *in)
{

  exp_t e;
  sb acc;

  sb_new (&acc);
  idx = exp_parse (idx, in, &e);
  exp_string (&e, &acc);
  hash_add_to_string_table (&assign_hash_table, &label, &acc, again);
  sb_kill (&acc);
}




static
void
do_radix(sb *ptr) asm("_do_radix");
void
do_radix(sb *ptr)
{
  int idx = sb_skip_white (0, ptr);
  switch (ptr->ptr[idx])
    {
    case 'B':
    case 'b':
      radix = 2;
      break;
    case 'q':
    case 'Q':
      radix = 8;
      break;
    case 'd':
    case 'D':
      radix = 10;
      break;
    case 'h':
    case 'H':
      radix = 16;
      break;
    default:
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "radix is %c must be one of b, q, d or h", radix); errors++; } while(0);
    }
}




static int
get_opsize(int idx, sb *in, int *size) asm("_get_opsize");
static int
get_opsize(int idx, sb *in, int *size)
{
  *size = 4;
  if (in->ptr[idx] == '.')
    {
      idx++;
    }
  switch (in->ptr[idx])
    {
    case 'b':
    case 'B':
      *size = 1;
      break;
    case 'w':
    case 'W':
      *size = 2;
      break;
    case 'l':
    case 'L':
      *size = 4;
      break;
    case ' ':
    case '\t':
      break;
    default:
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "size must be one of b, w or l, is %c.\n", in->ptr[idx]); errors++; } while(0);
      break;
    }
  idx++;

  return idx;
}

static
int eol(int idx, sb *line) asm("_eol");
int eol(int idx, sb *line)
{
  idx = sb_skip_white (idx, line);
  if (idx < line->len
      && (chartype[(unsigned)(line->ptr[idx])] & 16))
    return 1;
  if (idx >= line->len)
    return 1;
  return 0;
}




static void
do_data(int idx, sb *in, int size) asm("_do_data");
static void
do_data(int idx, sb *in, int size)
{
  int opsize = 4;
  char *opname = ".yikes!";
  sb acc;
  sb_new (&acc);

  if (!size)
    {
      idx = get_opsize (idx, in, &opsize);
    }
  else {
    opsize = size;
  }
  switch (opsize)
    {
    case 4:
      opname = ".long";
      break;
    case 2:
      opname = ".short";
      break;
    case 1:
      opname = ".byte";
      break;
    }


  fprintf (outfile, "%s\t", opname);

  idx = sb_skip_white (idx, in);

  if (alternate
      && idx < in->len
      && in->ptr[idx] == '"')
    {
      int i;
      idx = getstring (idx, in, &acc);
      for (i = 0; i < acc.len; i++)
 {
   if (i)
     fprintf(outfile,",");
   fprintf (outfile, "%d", acc.ptr[i]);
 }
    }
  else
    {
      while (!eol (idx, in))
 {
   exp_t e;
   idx = exp_parse (idx, in, &e);
   exp_string (&e, &acc);
   sb_add_char (&acc, 0);
   fprintf (outfile, acc.ptr);
   if (idx < in->len && in->ptr[idx] == ',')
     {
       fprintf (outfile, ",");
       idx++;
     }
 }
    }
  sb_kill (&acc);
  sb_print_at (outfile, idx, in);
  fprintf (outfile, "\n");
}



static void
do_datab(int idx, sb *in) asm("_do_datab");
static void
do_datab(int idx, sb *in)
{
  int opsize;
  int repeat;
  int fill;

  idx = get_opsize (idx, in, &opsize);

  idx = exp_get_abs ("datab repeat must be constant.\n", idx, in, &repeat);
  idx = sb_skip_comma (idx, in);
  idx = exp_get_abs ("datab data must be absolute.\n", idx, in, &fill);

  fprintf (outfile, ".fill\t%d,%d,%d\n", repeat, opsize, fill);
}



static void
do_align(int idx, sb *in) asm("_do_align");
static void
do_align(int idx, sb *in)
{
  int al;
  idx = exp_get_abs ("align needs absolute expression.\n", idx, in, &al);

  if (al != 1
      && al != 2
      && al != 4)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "alignment must be one of 1, 2 or 4.\n"); warnings++;} while(0);

  fprintf (outfile, ".align	%d\n", al);
}



static void
do_res(int idx, sb *in, int type) asm("_do_res");
static void
do_res(int idx, sb *in, int type)
{
  int size = 4;
  int count = 0;

  idx = get_opsize (idx, in, &size);
  while (!eol(idx, in))
    {
      idx = sb_skip_white (idx, in);
      if (in->ptr[idx] == ',')
 idx++;
      idx = exp_get_abs ("res needs absolute expression for fill count.\n", idx, in, &count);

      if (type == 'c' || type == 'z')
 count++;

      fprintf (outfile, ".space	%d\n", count * size);
    }
}




static void
do_export(sb *in) asm("_do_export");
static void
do_export(sb *in)
{
  fprintf (outfile, ".global	%s\n", sb_name (in));
}



static void
do_print(int idx, sb *in) asm("_do_print");
static void
do_print(int idx, sb *in)
{
  idx = sb_skip_white (idx, in);
  while (idx < in->len)
    {
      if (strncasecmp (in->ptr + idx, "LIST", 4) == 0)
 {
   fprintf (outfile, ".list\n");
   idx += 4;
 }
      else if (strncasecmp (in->ptr + idx, "NOLIST", 6) == 0)
 {
   fprintf (outfile, ".nolist\n");
   idx += 6;
 }
      idx++;
    }
}


static void
do_heading(int idx, sb *in) asm("_do_heading");
static void
do_heading(int idx, sb *in)
{
  sb head;
  sb_new (&head);
  idx = getstring (idx, in, &head);
  fprintf (outfile, ".title	\"%s\"\n", sb_name (&head));
  sb_kill (&head);
}



static void
do_page(void) asm("_do_page");
static void
do_page(void)
{
  fprintf (outfile, ".eject\n");
}


static void
do_form(int idx, sb *in) asm("_do_form");
static void
do_form(int idx, sb *in)
{
  int lines = 60;
  int columns = 132;
  idx = sb_skip_white (idx, in);

  while (idx < in->len)
    {

      if (strncasecmp (in->ptr + idx, "LIN=", 4) == 0)
 {
   idx += 4;
   idx = exp_get_abs ("form LIN= needs absolute expresssion.\n", idx, in, &lines);
 }

      if (strncasecmp (in->ptr + idx, "COL=", 4) == 0)
 {
   idx += 4;
   idx = exp_get_abs ("form COL= needs absolute expresssion.\n", idx, in, &columns);
 }

      idx++;
    }
  fprintf (outfile, ".psize %d,%d\n", lines, columns);

}
static int
get_any_string(int idx, sb *in, sb *out, int expand, int pretend_quoted) asm("_get_any_string");
static int
get_any_string(int idx, sb *in, sb *out, int expand, int pretend_quoted)
{
  sb_reset (out);
  idx = sb_skip_white (idx, in);

  if (idx < in->len)
    {
      if (in->len > 2 && in->ptr[idx+1] == '\'' && (chartype[(unsigned)(in->ptr[idx])] & 32))
 {
   while (!(chartype[(unsigned)(in->ptr[idx])] & 4))
     sb_add_char (out, in->ptr[idx++]);
 }
      else if (in->ptr[idx] == '%'
        && alternate
        && expand)
 {
   int val;
   char buf[20];

   idx = exp_get_abs ("% operator needs absolute expression",
        idx + 1,
        in,
        &val);
   sprintf(buf, "%d", val);
   sb_add_string (out, buf);
 }
      else if (in->ptr[idx] == '"'
        || in->ptr[idx] == '<'
        || (alternate && in->ptr[idx] == '\''))
 {
   if (alternate && expand)
     {

       sb_add_char (out, '\"');

       idx = getstring (idx, in, out);
       sb_add_char (out, '\"');

     }
   else {
     idx = getstring (idx, in, out);
   }
 }
      else
 {
   while (idx < in->len
   && (in->ptr[idx] == '"'
       || in->ptr[idx] == '\''
       || pretend_quoted
       || !(chartype[(unsigned)(in->ptr[idx])] & 4)))
     {
       if (in->ptr[idx] == '"'
    || in->ptr[idx] == '\'')
  {
    char tchar = in->ptr[idx];
    sb_add_char (out, in->ptr[idx++]);
    while (idx < in->len
    && in->ptr[idx] != tchar)
      sb_add_char (out, in->ptr[idx++]);
    if (idx == in->len)
      return idx;
  }
       sb_add_char (out, in->ptr[idx++]);
     }
 }
    }

  return idx;
}





static int
skip_openp(int idx, sb *in) asm("_skip_openp");
static int
skip_openp(int idx, sb *in)
{
  idx = sb_skip_white (idx, in);
  if (in->ptr[idx] != '(')
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "misplaced ( .\n"); errors++; } while(0);
  idx = sb_skip_white (idx + 1, in);
  return idx;
}




static int
skip_closep(int idx, sb *in) asm("_skip_closep");
static int
skip_closep(int idx, sb *in)
{
  idx = sb_skip_white (idx, in);
  if (in->ptr[idx] != ')')
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "misplaced ).\n"); errors++; } while(0);
  idx = sb_skip_white (idx + 1, in);
  return idx;
}



static int
dolen(int idx, sb *in, sb *out) asm("_dolen");
static int
dolen(int idx, sb *in, sb *out)
{

  sb stringout;
  char buffer[10];

  sb_new (&stringout);
  idx = skip_openp (idx, in);
  idx = get_and_process (idx, in, &stringout);
  idx = skip_closep (idx, in);
  sprintf (buffer, "%d", stringout.len);
  sb_add_string (out, buffer);

  sb_kill (&stringout);
  return idx;
}




static
int
doinstr(int idx, sb *in, sb *out) asm("_doinstr");
int
doinstr(int idx, sb *in, sb *out)
{
  sb string;
  sb search;
  int i;
  int start;
  int res;
  char buffer[10];

  sb_new (&string);
  sb_new (&search);
  idx = skip_openp (idx, in);
  idx = get_and_process (idx, in, &string);
  idx = sb_skip_comma (idx, in);
  idx = get_and_process (idx, in, &search);
  idx = sb_skip_comma (idx, in);
  if (isdigit (in->ptr[idx]))
    {
      idx = exp_get_abs (".instr needs absolute expresson.\n", idx, in, &start);
    }
  else
    {
      start = 0;
    }
  idx = skip_closep (idx, in);
  res = -1;
  for (i = start; i < string.len; i++)
    {
      if (strncmp (string.ptr + i, search.ptr, search.len) == 0)
 {
   res = i;
   break;
 }
    }
  sprintf (buffer, "%d", res);
  sb_add_string (out, buffer);
  sb_kill (&string);
  sb_kill (&search);
  return idx;
}


static int
dosubstr(int idx, sb *in, sb *out) asm("_dosubstr");
static int
dosubstr(int idx, sb *in, sb *out)
{
  sb string;
  int pos;
  int len;
  sb_new (&string);

  idx = skip_openp (idx, in);
  idx = get_and_process (idx, in, &string);
  idx = sb_skip_comma (idx, in);
  idx = exp_get_abs ("need absolute position.\n", idx, in, &pos);
  idx = sb_skip_comma (idx, in);
  idx = exp_get_abs ("need absolute length.\n", idx, in, &len);
  idx = skip_closep (idx, in);


  if (len < 0 || pos < 0 ||
      pos > string.len
      || pos + len > string.len)
    {
      sb_add_string (out, " ");
    }
  else
    {
      sb_add_char (out, '"');
      while (len > 0)
 {
   sb_add_char (out, string.ptr[pos++]);
   len--;
 }
      sb_add_char (out, '"');
    }
  sb_kill(&string);
  return idx;
}


static void
process_assigns(int idx, sb *in, sb *buf) asm("_process_assigns");
static void
process_assigns(int idx, sb *in, sb *buf)
{
  while (idx < in->len)
    {
      hash_entry *ptr;
      if (in->ptr[idx] == '\\'
   && in->ptr[idx + 1] == '&')
 {
   idx = condass_lookup_name (in, idx + 2, buf, 1);
 }
      else if (in->ptr[idx] == '\\'
        && in->ptr[idx + 1] == '$')
 {
   idx = condass_lookup_name (in, idx + 2, buf, 0);
 }
      else if (idx + 3 < in->len
        && in->ptr[idx] == '.'
        && toupper ((unsigned char) in->ptr[idx + 1]) == 'L'
        && toupper ((unsigned char) in->ptr[idx + 2]) == 'E'
        && toupper ((unsigned char) in->ptr[idx + 3]) == 'N')
 idx = dolen (idx + 4, in, buf);
      else if (idx + 6 < in->len
        && in->ptr[idx] == '.'
        && toupper ((unsigned char) in->ptr[idx + 1]) == 'I'
        && toupper ((unsigned char) in->ptr[idx + 2]) == 'N'
        && toupper ((unsigned char) in->ptr[idx + 3]) == 'S'
        && toupper ((unsigned char) in->ptr[idx + 4]) == 'T'
        && toupper ((unsigned char) in->ptr[idx + 5]) == 'R')
 idx = doinstr (idx + 6, in, buf);
      else if (idx + 7 < in->len
        && in->ptr[idx] == '.'
        && toupper ((unsigned char) in->ptr[idx + 1]) == 'S'
        && toupper ((unsigned char) in->ptr[idx + 2]) == 'U'
        && toupper ((unsigned char) in->ptr[idx + 3]) == 'B'
        && toupper ((unsigned char) in->ptr[idx + 4]) == 'S'
        && toupper ((unsigned char) in->ptr[idx + 5]) == 'T'
        && toupper ((unsigned char) in->ptr[idx + 6]) == 'R')
 idx = dosubstr (idx + 7, in, buf);
      else if ((chartype[(unsigned)(in->ptr[idx])] & 1))
 {

   sb acc;
   int cur = idx + 1;
   while (cur < in->len
   && ((chartype[(unsigned)(in->ptr[cur])] & 2)))
     cur++;

   sb_new (&acc);
   sb_add_buffer (&acc, in->ptr + idx, cur - idx);
   ptr = hash_lookup (&assign_hash_table, &acc);
   if (ptr)
     {

       sb_add_sb (buf, &ptr->value.s);
     }
   else
     {

       sb_add_sb (buf, &acc);
     }
   sb_kill (&acc);
   idx = cur;
 }
      else
 {
   sb_add_char (buf, in->ptr[idx++]);
 }
    }
}

static int
get_and_process(int idx, sb *in, sb *out) asm("_get_and_process");
static int
get_and_process(int idx, sb *in, sb *out)
{
  sb t;
  sb_new (&t);
  idx = get_any_string (idx, in, &t, 1, 0);
  process_assigns (0, &t, out);
  sb_kill (&t);
  return idx;
}

static
void
process_file(void) asm("_process_file");
void
process_file(void)
{
  sb line;
  sb t1, t2;
  sb acc;
  sb label_in;
  int more;

  sb_new (&line);
  sb_new (&t1);
  sb_new (&t2);
  sb_new(&acc);
  sb_new (&label_in);
  sb_reset (&line);
  more = get_line (&line);
  while (more)
    {

      int l;
      if (line.len == 0)
 {
   if (condass_on ())
     fprintf (outfile, "\n");
 }
      else if (mri
        && (line.ptr[0] == '*'
     || line.ptr[0] == '!'))
 {

   fprintf (outfile, sb_name (&line));
 }
      else
 {
   l = grab_label (&line, &label_in);
   sb_reset (&label);
   if (label_in.len)
     {



       process_assigns (0, &label_in, &label);
     }

   if (line.ptr[l] == ':')
     l++;
   while ((chartype[(unsigned)(line.ptr[l])] & 8) && l < line.len)
     l++;

   if (l < line.len)
     {
       if (process_pseudo_op (l, &line, &acc))
  {



  }
       else if (condass_on ())
  {
    if (macro_op (l, &line))
      {


      }
    else
      {
        {
   if (label.len)
     {
       fprintf (outfile, "%s:\t", sb_name (&label));
     }
   else
     fprintf (outfile, "\t");
   sb_reset(&t1);
   process_assigns (l, &line, &t1);
   sb_reset (&t2);
   change_base (0, &t1, &t2);
   fprintf (outfile, "%s\n", sb_name (&t2));
        }
      }
  }
     }
   else {

     if (label.len && condass_on())
       {
  fprintf (outfile, "%s:\n", sb_name (&label));
       }
   }
 }

      if (had_end)
 break;
      sb_reset (&line);
      more = get_line (&line);
    }

  if (!had_end && !mri)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "END missing from end of file.\n"); warnings++;} while(0);
}





static void
free_old_entry(hash_entry *ptr) asm("_free_old_entry");
static void
free_old_entry(hash_entry *ptr)
{
  if (ptr)
    {
      if (ptr->type == hash_string)
 sb_kill(&ptr->value.s);
    }
}



static void
do_assigna(int idx, sb *in) asm("_do_assigna");
static void
do_assigna(int idx, sb *in)
{
  sb tmp;
  int val;
  sb_new (&tmp);

  process_assigns (idx, in, &tmp);
  idx = exp_get_abs (".ASSIGNA needs constant expression argument.\n", 0, &tmp, &val);

  if (!label.len)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , ".ASSIGNA without label.\n"); errors++; } while(0);
    }
  else
    {
      hash_entry *ptr = hash_create (&vars, &label);
      free_old_entry (ptr);
      ptr->type = hash_integer;
      ptr->value.i = val;
    }
  sb_kill (&tmp);
}



static void
do_assignc(int idx, sb *in) asm("_do_assignc");
static void
do_assignc(int idx, sb *in)
{
  sb acc;
  sb_new (&acc);
  idx = getstring (idx, in, &acc);

  if (!label.len)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , ".ASSIGNS without label.\n"); errors++; } while(0);
    }
  else
    {
      hash_entry *ptr = hash_create (&vars, &label);
      free_old_entry (ptr);
      ptr->type = hash_string;
      sb_new (&ptr->value.s);
      sb_add_sb (&ptr->value.s, &acc);
    }
  sb_kill (&acc);
}




static void
do_reg(int idx, sb *in) asm("_do_reg");
static void
do_reg(int idx, sb *in)
{

  sb what;
  if (!mri)
    idx = skip_openp (idx, in);
  else
    idx = sb_skip_white (idx, in);
  sb_new (&what);
  while (idx < in->len
  && (mri
      ? ! eol (idx, in)
      : in->ptr[idx] != ')'))
    {
      sb_add_char (&what, in->ptr[idx]);
      idx++;
    }
  hash_add_to_string_table (&assign_hash_table, &label, &what, 1);
  sb_kill (&what);
}


static int
condass_lookup_name(sb *inbuf, int idx, sb *out, int warn) asm("_condass_lookup_name");
static int
condass_lookup_name(sb *inbuf, int idx, sb *out, int warn)
{
  hash_entry *ptr;
  sb condass_acc;
  sb_new (&condass_acc);

  while (idx < inbuf->len
  && (chartype[(unsigned)(inbuf->ptr[idx])] & 2))
    {
      sb_add_char (&condass_acc, inbuf->ptr[idx++]);
    }

  if (inbuf->ptr[idx] == '\'')
    idx++;
  ptr = hash_lookup (&vars, &condass_acc);


  if (!ptr)
    {
      if (warn)
 {
   do { include_print_where_line (
  (__acrt_iob_func(2))
  ); fprintf (
  (__acrt_iob_func(2))
  , "Can't find preprocessor variable %s.\n", sb_name (&condass_acc)); warnings++;} while(0);
 }
      else
 {
   sb_add_string (out, "0");
 }
    }
  else
    {
      if (ptr->type == hash_integer)
 {
   char buffer[30];
   sprintf (buffer, "%d", ptr->value.i);
   sb_add_string (out, buffer);
 }
      else
 {
   sb_add_sb (out, &ptr->value.s);
 }
    }
  sb_kill (&condass_acc);
  return idx;
}
static int
whatcond(int idx, sb *in, int *val) asm("_whatcond");
static int
whatcond(int idx, sb *in, int *val)
{
  int cond;

  idx = sb_skip_white (idx, in);
  cond = 7;
  if (idx + 1 < in->len)
    {
      char *p;
      char a, b;

      p = in->ptr + idx;
      a = toupper ((unsigned char) p[0]);
      b = toupper ((unsigned char) p[1]);
      if (a == 'E' && b == 'Q')
 cond = 1;
      else if (a == 'N' && b == 'E')
 cond = 2;
      else if (a == 'L' && b == 'T')
 cond = 4;
      else if (a == 'L' && b == 'E')
 cond = 5;
      else if (a == 'G' && b == 'T')
 cond = 6;
      else if (a == 'G' && b == 'E')
 cond = 3;
    }
  if (cond == 7)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "Comparison operator must be one of EQ, NE, LT, LE, GT or GE.\n"); errors++; } while(0);
      cond = 7;
    }
  idx = sb_skip_white (idx + 2, in);
  *val = cond;
  return idx;
}

static int
istrue(int idx, sb *in) asm("_istrue");
static int
istrue(int idx, sb *in)
{
  int res;
  sb acc_a;
  sb cond;
  sb acc_b;
  sb_new (&acc_a);
  sb_new (&cond);
  sb_new (&acc_b);
  idx = sb_skip_white (idx, in);

  if (in->ptr[idx] == '"')
    {
      int cond;
      int same;

      idx = getstring (idx, in, &acc_a);
      idx = whatcond (idx, in, &cond);
      idx = getstring (idx, in, &acc_b);
      same = acc_a.len == acc_b.len && (strncmp (acc_a.ptr, acc_b.ptr, acc_a.len) == 0);

      if (cond != 1 && cond != 2)
 {
   do { include_print_where_line (
  (__acrt_iob_func(2))
  ); fprintf (
  (__acrt_iob_func(2))
  , "Comparison operator for strings must be EQ or NE\n"); errors++; } while(0);
   res = 0;
 }
      else
 res = (cond != 1) ^ same;
    }
  else

    {
      int vala;
      int valb;
      int cond;
      idx = exp_get_abs ("Conditional operator must have absolute operands.\n", idx, in, &vala);
      idx = whatcond (idx, in, &cond);
      idx = sb_skip_white (idx, in);
      if (in->ptr[idx] == '"')
 {
   do { include_print_where_line (
  (__acrt_iob_func(2))
  ); fprintf (
  (__acrt_iob_func(2))
  , "String compared against expression.\n"); warnings++;} while(0);
   res = 0;
 }
      else
 {
   idx = exp_get_abs ("Conditional operator must have absolute operands.\n", idx, in, &valb);
   switch (cond)
     {
     default:
       res = 42;
       break;
     case 1:
       res = vala == valb;
       break;
     case 2:
       res = vala != valb;
       break;
     case 4:
       res = vala < valb;
       break;
     case 5:
       res = vala <= valb;
       break;
     case 6:
       res = vala > valb;
       break;
     case 3:
       res = vala >= valb;
       break;
     case 7:
       res = 0;
       break;
     }
 }
    }

  sb_kill (&acc_a);
  sb_kill (&cond);
  sb_kill (&acc_b);
  return res;
}


static void
do_aif(int idx, sb *in) asm("_do_aif");
static void
do_aif(int idx, sb *in)
{
  if (ifi >= 100)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "AIF nesting unreasonable.\n") ; fatals++; quit(); } while(0);
    }
  ifi++;
  ifstack[ifi].on = ifstack[ifi-1].on ? istrue (idx, in) : 0;
  ifstack[ifi].hadelse = 0;
}



static void
do_aelse(void) asm("_do_aelse");
static void
do_aelse(void)
{
  ifstack[ifi].on = ifstack[ifi-1].on ? !ifstack[ifi].on : 0;
  if (ifstack[ifi].hadelse)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "Multiple AELSEs in AIF.\n"); errors++; } while(0);
    }
  ifstack[ifi].hadelse = 1;
}



static void
do_aendi(void) asm("_do_aendi");
static void
do_aendi(void)
{
  if (ifi != 0)
    {
      ifi--;
    }
  else
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "AENDI without AIF.\n"); errors++; } while(0);
    }
}

static int
condass_on(void) asm("_condass_on");
static int
condass_on(void)
{
  return ifstack[ifi].on;
}



static void
do_if(int idx, sb *in, int cond) asm("_do_if");
static void
do_if(int idx, sb *in, int cond)
{
  int val;
  int res;

  if (ifi >= 100)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "IF nesting unreasonable.\n") ; fatals++; quit(); } while(0);
    }

  idx = exp_get_abs ("Conditional operator must have absolute operands.\n",
       idx, in, &val);
  switch (cond)
    {
    default:
    case 1: res = val == 0; break;
    case 2: res = val != 0; break;
    case 4: res = val < 0; break;
    case 5: res = val <= 0; break;
    case 3: res = val >= 0; break;
    case 6: res = val > 0; break;
    }

  ifi++;
  ifstack[ifi].on = ifstack[ifi-1].on ? res: 0;
  ifstack[ifi].hadelse = 0;
}



static int
get_mri_string(int idx, sb *in, sb *val, int terminator) asm("_get_mri_string");
static int
get_mri_string(int idx, sb *in, sb *val, int terminator)
{
  idx = sb_skip_white (idx, in);

  if (idx < in->len
      && in->ptr[idx] == '\'')
    {
      sb_add_char (val, '\'');
      for (++idx; idx < in->len; ++idx)
 {
   sb_add_char (val, in->ptr[idx]);
   if (in->ptr[idx] == '\'')
     {
       ++idx;
       if (idx >= in->len
    || in->ptr[idx] != '\'')
  break;
     }
 }
      idx = sb_skip_white (idx, in);
    }
  else
    {
      int i;

      while (idx < in->len
      && in->ptr[idx] != terminator)
 {
   sb_add_char (val, in->ptr[idx]);
   ++idx;
 }
      i = val->len - 1;
      while (i >= 0 && (chartype[(unsigned)(val->ptr[i])] & 8))
 --i;
      val->len = i + 1;
    }

  return idx;
}



static void
do_ifc(int idx, sb *in, int ifnc) asm("_do_ifc");
static void
do_ifc(int idx, sb *in, int ifnc)
{
  sb first;
  sb second;
  int res;

  if (ifi >= 100)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "IF nesting unreasonable.\n") ; fatals++; quit(); } while(0);
    }

  sb_new (&first);
  sb_new (&second);

  idx = get_mri_string (idx, in, &first, ',');

  if (idx >= in->len || in->ptr[idx] != ',')
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "Bad format for IF or IFNC.\n"); errors++; } while(0);
      return;
    }

  idx = get_mri_string (idx + 1, in, &second, ';');

  res = (first.len == second.len
  && strncmp (first.ptr, second.ptr, first.len) == 0);
  res ^= ifnc;

  ifi++;
  ifstack[ifi].on = ifstack[ifi-1].on ? res : 0;
  ifstack[ifi].hadelse = 0;
}


static void
do_aendr(void) asm("_do_aendr");
static void
do_aendr(void)
{
  if (!mri)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "AENDR without a AREPEAT.\n"); errors++; } while(0);
  else
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "ENDR without a REPT.\n"); errors++; } while(0);
}



static
void
do_awhile(int idx, sb *in) asm("_do_awhile");
void
do_awhile(int idx, sb *in)
{
  int line = linecount ();
  sb exp;
  sb sub;
  int doit;

  sb_new (&sub);
  sb_new (&exp);

  process_assigns (idx, in, &exp);
  doit = istrue (0, &exp);

  if (! buffer_and_nest ("AWHILE", "AENDW", &sub, get_line))
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "AWHILE without a AENDW at %d.\n", line - 1) ; fatals++; quit(); } while(0);
  if (doit)
    {
      int index = include_next_index ();

      sb copy;
      sb_new (&copy);
      sb_add_sb (&copy, &sub);
      sb_add_sb (&copy, in);
      sb_add_string (&copy, "\n");
      sb_add_sb (&copy, &sub);
      sb_add_string (&copy, "\t.AENDW\n");

      include_buf (&exp, &copy, include_while, index);
      sb_kill (&copy);
    }
  sb_kill (&exp);
  sb_kill (&sub);
}




static void
do_aendw(void) asm("_do_aendw");
static void
do_aendw(void)
{
  do { include_print_where_line (
 (__acrt_iob_func(2))
 ); fprintf (
 (__acrt_iob_func(2))
 , "AENDW without a AENDW.\n"); errors++; } while(0);
}






static void
do_exitm(void) asm("_do_exitm");
static void
do_exitm(void)
{
  include_type type = sp->type;
  if (type == include_repeat
      || type == include_while
      || type == include_macro)
    {
      int index = sp->index;
      include_pop ();
      while (sp->index == index
      && sp->type == type)
 {
   include_pop ();
 }
    }
}



static void
do_arepeat(int idx, sb *in) asm("_do_arepeat");
static void
do_arepeat(int idx, sb *in)
{
  int line = linecount ();
  sb exp;
  sb copy;
  sb sub;
  int rc;
  int ret;
  char buffer[30];

  sb_new (&exp);
  sb_new (&copy);
  sb_new (&sub);
  process_assigns (idx, in, &exp);
  idx = exp_get_abs ("AREPEAT must have absolute operand.\n", 0, &exp, &rc);
  if (!mri)
    ret = buffer_and_nest ("AREPEAT", "AENDR", &sub, get_line);
  else
    ret = buffer_and_nest ("REPT", "ENDR", &sub, get_line);
  if (! ret)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "AREPEAT without a AENDR at %d.\n", line - 1) ; fatals++; quit(); } while(0);
  if (rc > 0)
    {
      int index = include_next_index ();
      sb_add_sb (&copy, &sub);
      if (rc > 1)
 {
   if (!mri)
     sprintf (buffer, "\t.AREPEAT	%d\n", rc - 1);
   else
     sprintf (buffer, "\tREPT	%d\n", rc - 1);
   sb_add_string (&copy, buffer);
   sb_add_sb (&copy, &sub);
   if (!mri)
     sb_add_string (&copy, "	.AENDR\n");
   else
     sb_add_string (&copy, "	ENDR\n");
 }

      include_buf (&exp, &copy, include_repeat, index);
    }
  sb_kill (&exp);
  sb_kill (&sub);
  sb_kill (&copy);
}



static void
do_endm(void) asm("_do_endm");
static void
do_endm(void)
{
  do { include_print_where_line (
 (__acrt_iob_func(2))
 ); fprintf (
 (__acrt_iob_func(2))
 , ".ENDM without a matching .MACRO.\n"); errors++; } while(0);
}



static void
do_irp(int idx, sb *in, int irpc) asm("_do_irp");
static void
do_irp(int idx, sb *in, int irpc)
{
  const char *err;
  sb out;

  sb_new (&out);

  err = expand_irp (irpc, idx, in, &out, get_line, comment_char);
  if (err != 
            ((void *)0)
                )
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "%s\n", err); errors++; } while(0);

  fprintf (outfile, "%s", sb_terminate (&out));

  sb_kill (&out);
}




static
void
do_local(int idx, sb *line) asm("_do_local");
void
do_local(int idx, sb *line)
{
  do { include_print_where_line (
 (__acrt_iob_func(2))
 ); fprintf (
 (__acrt_iob_func(2))
 , "LOCAL outside of MACRO"); errors++; } while(0);
}

static void
do_macro(int idx, sb *in) asm("_do_macro");
static void
do_macro(int idx, sb *in)
{
  const char *err;
  int line = linecount ();

  err = define_macro (idx, in, &label, get_line);
  if (err != 
            ((void *)0)
                )
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "macro at line %d: %s\n", line - 1, err); errors++; } while(0);
}

static int
macro_op(int idx, sb *in) asm("_macro_op");
static int
macro_op(int idx, sb *in)
{
  const char *err;
  sb out;
  sb name;

  if (! macro_defined)
    return 0;

  sb_terminate (in);
  if (! check_macro (in->ptr + idx, &out, comment_char, &err))
    return 0;

  if (err != 
            ((void *)0)
                )
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "%s\n", err); errors++; } while(0);

  sb_new (&name);
  sb_add_string (&name, "macro expansion");

  include_buf (&name, &out, include_macro, include_next_index ());

  sb_kill (&name);
  sb_kill (&out);

  return 1;
}



static int
getstring(int idx, sb *in, sb *acc) asm("_getstring");
static int
getstring(int idx, sb *in, sb *acc)
{
  idx = sb_skip_white (idx, in);

  while (idx < in->len
  && (in->ptr[idx] == '"'
      || in->ptr[idx] == '<'
      || (in->ptr[idx] == '\'' && alternate)))
    {
      if (in->ptr[idx] == '<')
 {
   if (alternate || mri)
     {
       int nest = 0;
       idx++;
       while ((in->ptr[idx] != '>' || nest)
       && idx < in->len)
  {
    if (in->ptr[idx] == '!')
      {
        idx++ ;
        sb_add_char (acc, in->ptr[idx++]);
      }
    else {
      if (in->ptr[idx] == '>')
        nest--;
      if (in->ptr[idx] == '<')
        nest++;
      sb_add_char (acc, in->ptr[idx++]);
    }
  }
       idx++;
     }
   else {
     int code;
     idx++;
     idx = exp_get_abs ("Character code in string must be absolute expression.\n",
          idx, in, &code);
     sb_add_char (acc, code);

     if (in->ptr[idx] != '>')
       do { include_print_where_line (
      (__acrt_iob_func(2))
      ); fprintf (
      (__acrt_iob_func(2))
      , "Missing > for character code.\n"); errors++; } while(0);
     idx++;
   }
 }
      else if (in->ptr[idx] == '"' || in->ptr[idx] == '\'')
 {
   char tchar = in->ptr[idx];
   idx++;
   while (idx < in->len)
     {
       if (alternate && in->ptr[idx] == '!')
  {
    idx++ ;
    sb_add_char (acc, in->ptr[idx++]);
  }
       else {
  if (in->ptr[idx] == tchar)
    {
      idx++;
      if (idx >= in->len || in->ptr[idx] != tchar)
        break;
    }
  sb_add_char (acc, in->ptr[idx]);
  idx++;
       }
     }
 }
    }

  return idx;
}



static
void
do_sdata(int idx, sb *in, int type) asm("_do_sdata");
void
do_sdata(int idx, sb *in, int type)
{
  int nc = 0;
  int pidx = -1;
  sb acc;
  sb_new (&acc);
  fprintf (outfile, ".byte\t");

  while (!eol (idx, in))
    {
      int i;
      sb_reset (&acc);
      idx = sb_skip_white (idx, in);
      while (!eol (idx, in))
 {
   pidx = idx = get_any_string (idx, in, &acc, 0, 1);
   if (type == 'c')
     {
       if (acc.len > 255)
  {
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "string for SDATAC longer than 255 characters (%d).\n", acc.len); errors++; } while(0);
  }
       fprintf (outfile, "%d", acc.len);
       nc = 1;
     }

   for (i = 0; i < acc.len; i++)
     {
       if (nc)
  {
    fprintf (outfile, ",");
  }
       fprintf (outfile, "%d", acc.ptr[i]);
       nc = 1;
     }

   if (type == 'z')
     {
       if (nc)
  fprintf (outfile, ",");
       fprintf (outfile, "0");
     }
   idx = sb_skip_comma (idx, in);
   if (idx == pidx) break;
 }
      if (!alternate && in->ptr[idx] != ',' && idx != in->len)
 {
   fprintf (outfile, "\n");
   do { include_print_where_line (
  (__acrt_iob_func(2))
  ); fprintf (
  (__acrt_iob_func(2))
  , "illegal character in SDATA line (0x%x).\n", in->ptr[idx]); errors++; } while(0);
   break;
 }
      idx++;
    }
  sb_kill (&acc);
  fprintf (outfile, "\n");
}



static void
do_sdatab(int idx, sb *in) asm("_do_sdatab");
static void
do_sdatab(int idx, sb *in)
{
  int repeat;
  int i;
  sb acc;
  sb_new (&acc);

  idx = exp_get_abs ("Must have absolute SDATAB repeat count.\n", idx, in, &repeat);
  if (repeat <= 0)
    {
      do { include_print_where_line (
     (__acrt_iob_func(2))
     ); fprintf (
     (__acrt_iob_func(2))
     , "Must have positive SDATAB repeat count (%d).\n", repeat); errors++; } while(0);
      repeat = 1;
    }

  idx = sb_skip_comma (idx, in);
  idx = getstring (idx, in, &acc);

  for (i = 0; i < repeat; i++)
    {
      if (i)
 fprintf (outfile, "\t");
      fprintf (outfile, ".byte\t");
      sb_print (outfile, &acc);
      fprintf (outfile, "\n");
    }
  sb_kill (&acc);

}

static int
new_file(const char *name) asm("_new_file");
static int
new_file(const char *name)
{
  FILE *newone = fopen (name, "r");
  if (!newone)
    return 0;

  if ((sp - include_stack) == 30)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "Unreasonable include depth (%ld).\n", (long) (sp - include_stack)) ; fatals++; quit(); } while(0);

  sp++;
  sp->handle = newone;

  sb_new (&sp->name);
  sb_add_string (&sp->name, name);

  sp->linecount = 1;
  sp->pushback_index = 0;
  sp->type = include_file;
  sp->index = 0;
  sb_new (&sp->pushback);
  return 1;
}

static void
do_include(int idx, sb *in) asm("_do_include");
static void
do_include(int idx, sb *in)
{
  sb t;
  sb cat;
  include_path *includes;

  sb_new (&t);
  sb_new (&cat);

  if (! mri)
    idx = getstring (idx, in, &t);
  else
    {
      idx = sb_skip_white (idx, in);
      while (idx < in->len && ! (chartype[(unsigned)(in->ptr[idx])] & 8))
 {
   sb_add_char (&t, in->ptr[idx]);
   ++idx;
 }
    }

  for (includes = paths_head; includes; includes = includes->next)
    {
      sb_reset (&cat);
      sb_add_sb (&cat, &includes->path);
      sb_add_char (&cat, '/');
      sb_add_sb (&cat, &t);
      if (new_file (sb_name (&cat)))
 {
   break;
 }
    }
  if (!includes)
    {
      if (! new_file (sb_name (&t)))
 do { include_print_where_line (
(__acrt_iob_func(2))
); fprintf (
(__acrt_iob_func(2))
, "Can't open include file `%s'.\n", sb_name (&t)) ; fatals++; quit(); } while(0);
    }
  sb_kill (&cat);
  sb_kill (&t);
}

static void
include_pop(void) asm("_include_pop");
static void
include_pop(void)
{
  if (sp != include_stack)
    {
      if (sp->handle)
 fclose (sp->handle);
      sp--;
    }
}





static int
get(void) asm("_get");
static int
get(void)
{
  int r;

  if (sp->pushback.len != sp->pushback_index)
    {
      r = (char) (sp->pushback.ptr[sp->pushback_index++]);

      if (sp->pushback_index == sp->pushback.len)
 {
   sp->pushback.len = 0;
   sp->pushback_index = 0;
 }
    }
  else if (sp->handle)
    {
      r = getc (sp->handle);
    }
  else
    r = 
       (-1)
          ;

  if (r == 
          (-1) 
              && (sp - include_stack))
    {
      include_pop ();
      r = get ();
      while (r == 
                 (-1) 
                     && (sp - include_stack))
 {
   include_pop ();
   r = get ();
 }
      return r;
    }
  if (r == '\n')
    {
      sp->linecount++;
    }

  return r;
}

static int
linecount(void) asm("_linecount");
static int
linecount(void)
{
  return sp->linecount;
}

static int
include_next_index(void) asm("_include_next_index");
static int
include_next_index(void)
{
  static int index;
  if (!unreasonable
      && index > 1000)
    do { include_print_where_line (
   (__acrt_iob_func(2))
   ); fprintf (
   (__acrt_iob_func(2))
   , "Unreasonable expansion (-u turns off check).\n") ; fatals++; quit(); } while(0);
  return ++index;
}




static void
chartype_init(void) asm("_chartype_init");
static void
chartype_init(void)
{
  int x;
  for (x = 0; x < 256; x++)
    {
      if (isalpha (x) || x == '_' || x == '$')
 chartype[x] |= 1;

      if (mri && x == '.')
 chartype[x] |= 1;

      if (isdigit (x) || isalpha (x) || x == '_' || x == '$')
 chartype[x] |= 2;

      if (x == ' ' || x == '\t' || x == ',' || x == '"' || x == ';'
   || x == '"' || x == '<' || x == '>' || x == ')' || x == '(')
 chartype[x] |= 4;

      if (x == 'b' || x == 'B'
   || x == 'q' || x == 'Q'
   || x == 'h' || x == 'H'
   || x == 'd' || x == 'D')
 chartype [x] |= 32;

      if (x == ' ' || x == '\t')
 chartype[x] |= 8;

      if (x == comment_char)
 chartype[x] |= 16;
    }
}
struct n64_tag_keyword
{
  char *name;
  int code;
  int extra;
};

static struct n64_tag_keyword kinfo[] =
{
  { "EQU", (0x1000|1), 0 },
  { "ALTERNATE", (41), 0 },
  { "ASSIGN", (0x1000|2), 0 },
  { "REG", (0x1000|3), 0 },
  { "ORG", (0x1000|4), 0 },
  { "RADIX", (0x1000|5), 0 },
  { "DATA", (0x2000|0x1000|6), 0 },
  { "DB", (0x2000|0x1000|42), 0 },
  { "DW", (0x2000|0x1000|43), 0 },
  { "DL", (0x2000|0x1000|44), 0 },
  { "DATAB", (0x2000|0x1000|7), 0 },
  { "SDATA", (0x2000|0x1000|8), 0 },
  { "SDATAB", (0x2000|0x1000|9), 0 },
  { "SDATAZ", (0x2000|0x1000|11), 0 },
  { "SDATAC", (0x2000|0x1000|10), 0 },
  { "RES", (0x2000|0x1000|12), 0 },
  { "SRES", (0x2000|0x1000|13), 0 },
  { "SRESC", (0x2000|0x1000|14), 0 },
  { "SRESZ", (0x2000|0x1000|15), 0 },
  { "EXPORT", (0x2000|0x1000|16), 0 },
  { "GLOBAL", (0x2000|0x1000|17), 0 },
  { "PRINT", (0x2000|0x1000|19), 0 },
  { "FORM", (0x2000|0x1000|20), 0 },
  { "HEADING", (0x2000|0x1000|21), 0 },
  { "PAGE", (0x2000|0x1000|22), 0 },
  { "PROGRAM", (0x1000|27), 0 },
  { "END", (0x1000|25), 0 },
  { "INCLUDE", (0x1000|26), 0 },
  { "ASSIGNA", (0x1000|28), 0 },
  { "ASSIGNC", (29), 0 },
  { "AIF", (0x1000|30), 0 },
  { "AELSE", (0x1000|31), 0 },
  { "AENDI", (0x1000|32), 0 },
  { "AREPEAT", (0x1000|33), 0 },
  { "AENDR", (0x1000|34), 0 },
  { "EXITM", (37), 0 },
  { "MACRO", (0x1000|38), 0 },
  { "ENDM", (39), 0 },
  { "AWHILE", (35), 0 },
  { "ALIGN", (0x1000|0x2000|40), 0 },
  { "AENDW", (0x1000|36), 0 },
  { "ALTERNATE", (41), 0 },
  { "LOCAL", (45), 0 },
  { 
   ((void *)0)
       , 0, 0 }
};





static struct n64_tag_keyword mrikinfo[] =
{
  { "IFEQ", (0x1000|46), 0 },
  { "IFNE", (0x1000|47), 0 },
  { "IFLT", (0x1000|48), 0 },
  { "IFLE", (0x1000|49), 0 },
  { "IFGE", (0x1000|50), 0 },
  { "IFGT", (0x1000|51), 0 },
  { "IFC", (0x1000|52), 0 },
  { "IFNC", (0x1000|53), 0 },
  { "ELSEC", (0x1000|31), 0 },
  { "ENDC", (0x1000|32), 0 },
  { "MEXIT", (37), 0 },
  { "REPT", (0x1000|33), 0 },
  { "IRP", (0x1000|54), 0 },
  { "IRPC", (0x1000|55), 0 },
  { "ENDR", (0x1000|34), 0 },
  { 
   ((void *)0)
       , 0, 0 }
};




static int
process_pseudo_op(int idx, sb *line, sb *acc) asm("_process_pseudo_op");
static int
process_pseudo_op(int idx, sb *line, sb *acc)
{
  int oidx = idx;

  if (line->ptr[idx] == '.' || alternate || mri)
    {

      char *in;
      hash_entry *ptr;

      char *s;
      char *e;
      if (line->ptr[idx] == '.')
 idx++;
      in = line->ptr + idx;
      s = in;
      e = s;
      sb_reset (acc);

      while (idx < line->len && *e && (chartype[(unsigned)(*e)] & 1))
 {
   sb_add_char (acc, *e);
   e++;
   idx++;
 }

      ptr = hash_lookup (&keyword_hash_table, acc);

      if (!ptr)
 {





   return 0;
 }
      if (ptr->value.i & 0x2000)
 {
   if (label.len)
     {
       fprintf (outfile, "%s:\t", sb_name (&label));
     }
   else
     fprintf (outfile, "\t");
 }

      if (mri && ptr->value.i == (0x1000|25))
 {
   sb t;

   sb_new (&t);
   sb_add_buffer (&t, line->ptr + oidx, idx - oidx);
   fprintf (outfile, "\t%s", sb_name (&t));
   sb_kill (&t);
 }

      if (ptr->value.i & 0x1000)
 {




   sb_reset (acc);
   process_assigns (idx, line, acc);
   sb_reset(line);
   change_base (0, acc, line);
   idx = 0;
 }
      if (!condass_on ())
 {
   switch (ptr->value.i)
     {
     case (0x1000|30):
       do_aif (idx, line);
       break;
     case (0x1000|31):
       do_aelse ();
       break;
     case (0x1000|32):
       do_aendi ();
       break;
     }
   return 1;
 }
      else
 {
   switch (ptr->value.i)
     {
     case (41):
       alternate = 1;
       macro_init (1, mri, 0, exp_get_abs);
       return 1;
     case (0x1000|31):
       do_aelse ();
       return 1;
     case (0x1000|32):
       do_aendi ();
       return 1;
     case (0x1000|4):
       do { include_print_where_line (
      (__acrt_iob_func(2))
      ); fprintf (
      (__acrt_iob_func(2))
      , "ORG command not allowed.\n"); errors++; } while(0);
       break;
     case (0x1000|5):
       do_radix (line);
       return 1;
     case (0x2000|0x1000|42):
       do_data (idx, line, 1);
       return 1;
     case (0x2000|0x1000|43):
       do_data (idx, line, 2);
       return 1;
     case (0x2000|0x1000|44):
       do_data (idx, line, 4);
       return 1;
     case (0x2000|0x1000|6):
       do_data (idx, line, 0);
       return 1;
     case (0x2000|0x1000|7):
       do_datab (idx, line);
       return 1;
     case (0x2000|0x1000|8):
       do_sdata (idx, line, 0);
       return 1;
     case (0x2000|0x1000|9):
       do_sdatab (idx, line);
       return 1;
     case (0x2000|0x1000|10):
       do_sdata (idx, line, 'c');
       return 1;
     case (0x2000|0x1000|11):
       do_sdata (idx, line, 'z');
       return 1;
     case (0x1000|2):
       do_assign (1, 0, line);
       return 1;
     case (0x1000|30):
       do_aif (idx, line);
       return 1;
     case (0x1000|33):
       do_arepeat (idx, line);
       return 1;
     case (0x1000|36):
       do_aendw ();
       return 1;
     case (35):
       do_awhile (idx, line);
       return 1;
     case (0x1000|34):
       do_aendr ();
       return 1;
     case (0x1000|1):
       do_assign (0, idx, line);
       return 1;
     case (0x1000|0x2000|40):
       do_align (idx, line);
       return 1;
     case (0x2000|0x1000|12):
       do_res (idx, line, 0);
       return 1;
     case (0x2000|0x1000|13):
       do_res (idx, line, 's');
       return 1;
     case (0x1000|26):
       do_include (idx, line);
       return 1;
     case (45):
       do_local (idx, line);
       return 1;
     case (0x1000|38):
       do_macro (idx, line);
       return 1;
     case (39):
       do_endm ();
       return 1;
     case (0x2000|0x1000|14):
       do_res (idx, line, 'c');
       return 1;
     case (0x2000|0x1000|19):
       do_print (idx, line);
       return 1;
     case (0x2000|0x1000|20):
       do_form (idx, line);
       return 1;
     case (0x2000|0x1000|21):
       do_heading (idx, line);
       return 1;
     case (0x2000|0x1000|22):
       do_page ();
       return 1;
     case (0x2000|0x1000|17):
     case (0x2000|0x1000|16):
       do_export (line);
       return 1;
     case (0x2000|0x1000|23):
       return 1;
     case (0x2000|0x1000|15):
       do_res (idx, line, 'z');
       return 1;
     case (0x1000|27):
       return 1;
     case (0x1000|25):
       do_end (line);
       return 1;
     case (0x1000|28):
       do_assigna (idx, line);
       return 1;
     case (29):
       do_assignc (idx, line);
       return 1;
     case (37):
       do_exitm ();
       return 1;
     case (0x1000|3):
       do_reg (idx, line);
       return 1;
     case (0x1000|46):
       do_if (idx, line, 1);
       return 1;
     case (0x1000|47):
       do_if (idx, line, 2);
       return 1;
     case (0x1000|48):
       do_if (idx, line, 4);
       return 1;
     case (0x1000|49):
       do_if (idx, line, 5);
       return 1;
     case (0x1000|50):
       do_if (idx, line, 3);
       return 1;
     case (0x1000|51):
       do_if (idx, line, 6);
       return 1;
     case (0x1000|52):
       do_ifc (idx, line, 0);
       return 1;
     case (0x1000|53):
       do_ifc (idx, line, 1);
       return 1;
     case (0x1000|54):
       do_irp (idx, line, 0);
       return 1;
     case (0x1000|55):
       do_irp (idx, line, 1);
       return 1;
     }
 }
    }
  return 0;
}





static void
add_keyword(const char *name, int code) asm("_add_keyword");
static void
add_keyword(const char *name, int code)
{
  sb label;
  int j;

  sb_new (&label);
  sb_add_string (&label, name);

  hash_add_to_int_table (&keyword_hash_table, &label, code);

  sb_reset (&label);
  for (j = 0; name[j]; j++)
    sb_add_char (&label, name[j] - 'A' + 'a');
  hash_add_to_int_table (&keyword_hash_table, &label, code);

  sb_kill (&label);
}




static void
process_init(void) asm("_process_init");
static void
process_init(void)
{
  int i;

  for (i = 0; kinfo[i].name; i++)
    add_keyword (kinfo[i].name, kinfo[i].code);

  if (mri)
    {
      for (i = 0; mrikinfo[i].name; i++)
 add_keyword (mrikinfo[i].name, mrikinfo[i].code);
    }
}


static void
do_define(const char *string) asm("_do_define");
static void
do_define(const char *string)
{
  sb label;
  int res = 1;
  hash_entry *ptr;
  sb_new (&label);


  while (*string)
    {
      if (*string == '=')
 {
   sb value;
   sb_new (&value);
   string++;
   while (*string)
     {
       sb_add_char (&value, *string);
       string++;
     }
   exp_get_abs ("Invalid expression on command line.\n", 0, &value, &res);
   sb_kill (&value);
   break;
 }
      sb_add_char (&label, *string);

      string ++;
    }

  ptr = hash_create (&vars, &label);
  free_old_entry (ptr);
  ptr->type = hash_integer;
  ptr->value.i = res;
  sb_kill (&label);
}
char *program_name;


static struct n64_tag_option long_options[] =
{
  { "alternate", 0, 0, 'a' },
  { "include", 1, 0, 'I' },
  { "commentchar", 1, 0, 'c' },
  { "copysource", 0, 0, 's' },
  { "debug", 0, 0, 'd' },
  { "help", 0, 0, 'h' },
  { "mri", 0, 0, 'M' },
  { "output", 1, 0, 'o' },
  { "print", 0, 0, 'p' },
  { "unreasonable", 0, 0, 'u' },
  { "version", 0, 0, 'v' },
  { "define", 1, 0, 'd' },
  { 
   ((void *)0)
       , 0, 0, 0 }
};


static void
show_usage(FILE *file, int status) asm("_show_usage");
static void
show_usage(FILE *file, int status)
{
  fprintf (file, "Usage: %s \n  [-a]      [--alternate]         enter alternate macro mode\n  [-c char] [--commentchar char]  change the comment character from !\n  [-d]      [--debug]             print some debugging info\n  [-h]      [--help]              print this message\n  [-M]      [--mri]               enter MRI compatibility mode\n  [-o out]  [--output out]        set the output file\n  [-p]      [--print]             print line numbers\n",







                                                         program_name);
  fprintf (file, "  [-s]      [--copysource]        copy source through as comments \n  [-u]      [--unreasonable]      allow unreasonable nesting\n  [-v]      [--version]           print the program version\n  [-Dname=value]                  create preprocessor variable called name, with value\n  [-Ipath]                        add to include path list\n  [in-file]\n");






  exit (status);
}


static void
show_help(void) asm("_show_help");
static void
show_help(void)
{
  printf ("%s: Gnu Assembler Macro Preprocessor\n",
   program_name);
  show_usage (
             (__acrt_iob_func(1))
                   , 0);
}

int
main(int argc, char **argv) asm("_main");
int
main(int argc, char **argv)
{
  int opt;
  char *out_name = 0;
  sp = include_stack;

  ifstack[0].on = 1;
  ifi = 0;



  program_name = argv[0];
  xmalloc_set_program_name (program_name);

  hash_new_table (101, &keyword_hash_table);
  hash_new_table (101, &assign_hash_table);
  hash_new_table (101, &vars);

  sb_new (&label);

  while ((opt = getopt_long (argc, argv, "I:sdhavc:upo:D:M", long_options,
        (int *) 
               ((void *)0)
                   ))
  != 
    (-1)
       )
    {
      switch (opt)
 {
 case 'o':
   out_name = optarg;
   break;
 case 'u':
   unreasonable = 1;
   break;
 case 'I':
   {
     include_path *p = (include_path *) xmalloc (sizeof (include_path));
     sb_new (&p->path);
     sb_add_string (&p->path, optarg);
     if (paths_tail)
       paths_tail->next = p;
     else
       paths_head = p;
     paths_tail = p;
   }
   break;
 case 'p':
   print_line_number = 1;
   break;
 case 'c':
   comment_char = optarg[0];
   break;
 case 'a':
   alternate = 1;
   break;
 case 's':
   copysource = 1;
   break;
 case 'd':
   stats = 1;
   break;
 case 'D':
   do_define (optarg);
   break;
 case 'M':
   mri = 1;
   comment_char = ';';
   break;
 case 'h':
   show_help ();

 case 'v':
   printf ("GNU %s version %s\n", program_name, program_version);
   exit (0);

 case 0:
   break;
 default:
   show_usage (
              (__acrt_iob_func(2))
                    , 1);

 }
    }

  process_init ();

  macro_init (alternate, mri, 0, exp_get_abs);

  if (out_name) {
    outfile = fopen (out_name, "w");
    if (!outfile)
      {
 fprintf (
         (__acrt_iob_func(2))
               , "%s: Can't open output file `%s'.\n",
   program_name, out_name);
 exit (1);
      }
  }
  else {
    outfile = 
             (__acrt_iob_func(1))
                   ;
  }

  chartype_init ();
  if (!outfile)
    outfile = 
             (__acrt_iob_func(1))
                   ;



  while (optind < argc)
    {
      if (new_file (argv[optind]))
 {
   process_file ();
 }
      else
 {
   fprintf (
           (__acrt_iob_func(2))
                 , "%s: Can't open input file `%s'.\n",
     program_name, argv[optind]);
   exit (1);
 }
      optind++;
    }

  quit ();
  return 0;
}




void
as_abort(const char *file, int line, const char *fn) asm("_as_abort");
void
as_abort(const char *file, int line, const char *fn)
{
  fprintf (
          (__acrt_iob_func(2))
                , "Internal error, aborting at %s line %d", file, line);
  if (fn)
    fprintf (
            (__acrt_iob_func(2))
                  , " in %s", fn);
  fprintf (
          (__acrt_iob_func(2))
                , "\nPlease report this bug.\n");
  exit (1);
}

