// GNU C++98 host port; original algorithms retained. GPL-2.0-or-later.
// From gcc/cp/decl2.c
/* Process declarations and variables for C compiler.
   Copyright (C) 1988, 1992, 1993, 1994, 1995 Free Software Foundation, Inc.
   Hacked by Michael Tiemann (tiemann@cygnus.com)

This file is part of GNU CC.

GNU CC is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU CC is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU CC; see the file COPYING.  If not, write to
the Free Software Foundation, 59 Temple Place - Suite 330,
Boston, MA 02111-1307, USA.  */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <getopt.h>
extern "C" void bcopy(const void*,void*,size_t);
extern "C" int fork(void);
extern int error(...) asm("_error");
extern int warning(...) asm("_warning");
extern int pedwarn(...) asm("_pedwarn");
extern int cadillac_start_decl(...) asm("_cadillac_start_decl");
extern int sorry(...) asm("_sorry");
extern int expand_decl(...) asm("_expand_decl");
extern int simple_cst_equal(...) asm("_simple_cst_equal");
extern int expand_anon_union_decl(...) asm("_expand_anon_union_decl");
extern int cadillac_finish_anon_union(...) asm("_cadillac_finish_anon_union");
extern int rest_of_decl_compilation(...) asm("_rest_of_decl_compilation");
extern int dump_tree_statistics(...) asm("_dump_tree_statistics");
extern int get_run_time(...) asm("_get_run_time");
extern int register_exception_table(...) asm("_register_exception_table");
extern int free_temp_slots(...) asm("_free_temp_slots");
extern int expand_assignment(...) asm("_expand_assignment");
extern int expand_cleanups_to(...) asm("_expand_cleanups_to");
extern int synthesize_method(...) asm("_synthesize_method");
extern int temporary_allocation(...) asm("_temporary_allocation");
extern int output_inline_function(...) asm("_output_inline_function");
extern int emit_thunk(...) asm("_emit_thunk");
extern int finish_repo(...) asm("_finish_repo");
struct n64_tag_lang_decl;
struct n64_tag_lang_decl_flags;
struct n64_tag_lang_id2;
struct n64_tag_lang_identifier;
struct n64_tag_lang_type;
struct n64_tag_mips_args;
struct n64_tag_mips_frame_info;
struct n64_tag_pending_inline;
union n64_tag_real_extract;
union n64_tag_rtunion_def;
struct n64_tag_rtvec_def;
struct n64_tag_rtx_def;
struct n64_tag_template_info;
struct n64_tag_tinst_level;
struct n64_tag_tree_block;
struct n64_tag_tree_common;
struct n64_tag_tree_complex;
struct n64_tag_tree_decl;
struct n64_tag_tree_exp;
struct n64_tag_tree_identifier;
struct n64_tag_tree_int_cst;
struct n64_tag_tree_list;
union n64_tag_tree_node;
struct n64_tag_tree_real_cst;
struct n64_tag_tree_string;
struct n64_tag_tree_type;
struct n64_tag_tree_vec;

extern char *asm_file_name;
extern char call_used_regs[];
extern int current_function_calls_alloca;
extern int flag_omit_frame_pointer;
extern int frame_pointer_needed;
extern char *language_string;
extern int may_call_alloca;
extern int optimize;
extern char **save_argv;
extern int target_flags;
extern char *version_string;




enum n64_cpp_enum_cmp_type{
  CMP_SI,
  CMP_DI,
  CMP_SF,
  CMP_DF,
  CMP_MAX
};
typedef __underlying_type(enum n64_cpp_enum_cmp_type) n64_enum_cmp_type;



enum n64_cpp_enum_delay_type{
  DELAY_NONE,
  DELAY_LOAD,
  DELAY_HILO,
  DELAY_FCMP
};
typedef __underlying_type(enum n64_cpp_enum_delay_type) n64_enum_delay_type;







enum n64_cpp_enum_processor_type{
  PROCESSOR_DEFAULT,
  PROCESSOR_R3000,
  PROCESSOR_R6000,
  PROCESSOR_R4000,
  PROCESSOR_R4600,
  PROCESSOR_R4650,
  PROCESSOR_R8000
};
typedef __underlying_type(enum n64_cpp_enum_processor_type) n64_enum_processor_type;







enum n64_cpp_enum_mips_abicalls_type{
  MIPS_ABICALLS_NO,
  MIPS_ABICALLS_YES
};
typedef __underlying_type(enum n64_cpp_enum_mips_abicalls_type) n64_enum_mips_abicalls_type;








enum n64_cpp_enum_block_move_type{
  BLOCK_MOVE_NORMAL,
  BLOCK_MOVE_NOT_LAST,
  BLOCK_MOVE_LAST
};
typedef __underlying_type(enum n64_cpp_enum_block_move_type) n64_enum_block_move_type;


extern char mips_reg_names[][8];
extern char mips_print_operand_punct[];
extern char *current_function_file;
extern int num_source_filenames;
extern int inside_function;
extern int ignore_line_number;
extern int file_in_function_warning;
extern int sdb_label_count;
extern int sdb_begin_function_line;
extern int mips_section_threshold;
extern int g_switch_value;
extern int g_switch_set;
extern int sym_lineno;
extern int set_noreorder;
extern int set_nomacro;
extern int set_noat;
extern int set_volatile;
extern int mips_branch_likely;
extern int mips_dbx_regno[];
extern struct n64_tag_rtx_def *branch_cmp[2];
extern n64_enum_cmp_type branch_type;
extern n64_enum_processor_type mips_cpu;
extern n64_enum_mips_abicalls_type mips_abicalls;
extern int mips_isa;
extern char *mips_cpu_string;
extern char *mips_isa_string;
extern char *mips_abi_string;
extern int dslots_load_total;
extern int dslots_load_filled;
extern int dslots_jump_total;
extern int dslots_jump_filled;
extern int dslots_number_nops;
extern int num_refs[3];
extern struct n64_tag_rtx_def *mips_load_reg;
extern struct n64_tag_rtx_def *mips_load_reg2;
extern struct n64_tag_rtx_def *mips_load_reg3;
extern struct n64_tag_rtx_def *mips_load_reg4;
extern struct n64_tag_rtx_def *embedded_pic_fnaddr_rtx;



extern void abort_with_insn(...) asm("_abort_with_insn");
extern int arith32_operand(...) asm("_arith32_operand");
extern int arith_operand(...) asm("_arith_operand");
extern int cmp_op(...) asm("_cmp_op");
extern long compute_frame_size(...) asm("_compute_frame_size");
extern int epilogue_reg_mentioned_p(...) asm("_epilogue_reg_mentioned_p");
extern void expand_block_move(...) asm("_expand_block_move");
extern int equality_op(...) asm("_equality_op");
extern void final_prescan_insn(...) asm("_final_prescan_insn");
extern struct n64_tag_rtx_def * function_arg(...) asm("_function_arg");
extern void function_arg_advance(...) asm("_function_arg_advance");
extern int function_arg_partial_nregs(...) asm("_function_arg_partial_nregs");
extern void function_epilogue(...) asm("_function_epilogue");
extern void function_prologue(...) asm("_function_prologue");
extern void gen_conditional_branch(...) asm("_gen_conditional_branch");
extern struct n64_tag_rtx_def * gen_int_relational(...) asm("_gen_int_relational");
extern void init_cumulative_args(...) asm("_init_cumulative_args");
extern int large_int(...) asm("_large_int");
extern int mips_address_cost(...) asm("_mips_address_cost");
extern void mips_asm_file_end(...) asm("_mips_asm_file_end");
extern void mips_asm_file_start(...) asm("_mips_asm_file_start");
extern int mips_const_double_ok(...) asm("_mips_const_double_ok");
extern void mips_count_memory_refs(...) asm("_mips_count_memory_refs");
extern int mips_debugger_offset(...) asm("_mips_debugger_offset");
extern void mips_declare_object(...) asm("_mips_declare_object");
extern int mips_epilogue_delay_slots(void) asm("_mips_epilogue_delay_slots");
extern void mips_expand_epilogue(void) asm("_mips_expand_epilogue");
extern void mips_expand_prologue(void) asm("_mips_expand_prologue");
extern char *mips_fill_delay_slot(...) asm("_mips_fill_delay_slot");
extern char *mips_move_1word(...) asm("_mips_move_1word");
extern char *mips_move_2words(...) asm("_mips_move_2words");
extern void mips_output_double(...) asm("_mips_output_double");
extern int mips_output_external(...) asm("_mips_output_external");
extern void mips_output_float(...) asm("_mips_output_float");
extern void mips_output_filename(...) asm("_mips_output_filename");
extern void mips_output_lineno(...) asm("_mips_output_lineno");
extern char *output_block_move(...) asm("_output_block_move");
extern void override_options(void) asm("_override_options");
extern int pc_or_label_operand(...) asm("_pc_or_label_operand");
extern void print_operand_address(...) asm("_print_operand_address");
extern void print_operand(...) asm("_print_operand");
extern void print_options(...) asm("_print_options");
extern int reg_or_0_operand(...) asm("_reg_or_0_operand");
extern int simple_epilogue_p(void) asm("_simple_epilogue_p");
extern int simple_memory_operand(...) asm("_simple_memory_operand");
extern int small_int(...) asm("_small_int");
extern void trace(...) asm("_trace");
extern int uns_arith_operand(...) asm("_uns_arith_operand");
extern struct n64_tag_rtx_def * embedded_pic_offset(...) asm("_embedded_pic_offset");


extern int address_operand(...) asm("_address_operand");
extern int const_double_operand(...) asm("_const_double_operand");
extern int const_int_operand(...) asm("_const_int_operand");
extern int general_operand(...) asm("_general_operand");
extern int immediate_operand(...) asm("_immediate_operand");
extern int memory_address_p(...) asm("_memory_address_p");
extern int memory_operand(...) asm("_memory_operand");
extern int nonimmediate_operand(...) asm("_nonimmediate_operand");
extern int nonmemory_operand(...) asm("_nonmemory_operand");
extern int register_operand(...) asm("_register_operand");
extern int scratch_operand(...) asm("_scratch_operand");


extern void data_section(void) asm("_data_section");
extern void rdata_section(...) asm("_rdata_section");
extern void readonly_data_section(void) asm("_readonly_data_section");
extern void sdata_section(...) asm("_sdata_section");
extern void text_section(void) asm("_text_section");


extern void abort_with_insn(...) asm("_abort_with_insn");
extern void debug_rtx(...) asm("_debug_rtx");
extern void fatal_io_error(...) asm("_fatal_io_error");
extern int get_frame_size(void) asm("_get_frame_size");
extern int offsettable_address_p(...) asm("_offsettable_address_p");
extern void output_address(...) asm("_output_address");
extern char *permalloc(...) asm("_permalloc");
extern int reg_mentioned_p(...) asm("_reg_mentioned_p");


extern int atoi(...) asm("_atoi");
extern char *getenv(...) asm("_getenv");
extern char *mktemp(...) asm("_mktemp");
extern char mips_hard_regno_mode_ok[][68];
enum n64_cpp_enum_reg_class{
  NO_REGS,
  GR_REGS,
  FP_REGS,
  HI_REG,
  LO_REG,
  HILO_REG,
  MD_REGS,
  ST_REGS,
  ALL_REGS,
  LIM_REG_CLASSES
};
typedef __underlying_type(enum n64_cpp_enum_reg_class) n64_enum_reg_class;

extern n64_enum_reg_class mips_regno_to_class[];
extern n64_enum_reg_class mips_char_to_class[];
extern n64_enum_reg_class mips_secondary_reload_class(...) asm("_mips_secondary_reload_class");
struct n64_tag_mips_frame_info
{
  long total_size;
  long var_size;
  long args_size;
  long extra_size;
  int gp_reg_size;
  int fp_reg_size;
  long mask;
  long fmask;
  long gp_save_offset;
  long fp_save_offset;
  long gp_sp_offset;
  long fp_sp_offset;
  int initialized;
  int num_gp;
  int num_fp;
};

extern struct n64_tag_mips_frame_info current_frame_info;
typedef struct n64_tag_mips_args {
  int gp_reg_found;
  int arg_number;
  int arg_words;
  int num_adjusts;




  struct n64_tag_rtx_def *adjust[4*2];
} CUMULATIVE_ARGS;
extern void text_section(void) asm("_text_section");

enum n64_cpp_enum_machine_mode{
VOIDmode,

QImode,
HImode,



PSImode,
SImode,
PDImode,
DImode,
TImode,
OImode,

QFmode,
HFmode,
TQFmode,
SFmode,
DFmode,
XFmode,
TFmode,


SCmode,
DCmode,
XCmode,
TCmode,

CQImode,
CHImode,
CSImode,
CDImode,
CTImode,
COImode,



BLKmode,







CCmode,


  CC_EQmode, CC_FPmode, CC_0mode, CC_REV_FPmode,

MAX_MACHINE_MODE };
typedef __underlying_type(enum n64_cpp_enum_machine_mode) n64_enum_machine_mode;

extern char *mode_name[];


enum n64_cpp_enum_mode_class{ MODE_RANDOM, MODE_INT, MODE_FLOAT, MODE_PARTIAL_INT, MODE_CC,
    MODE_COMPLEX_INT, MODE_COMPLEX_FLOAT, MAX_MODE_CLASS};
typedef __underlying_type(enum n64_cpp_enum_mode_class) n64_enum_mode_class;





extern n64_enum_mode_class mode_class[];
extern int mode_size[];




extern int mode_unit_size[];
extern n64_enum_machine_mode mode_wider_mode[];






extern n64_enum_machine_mode mode_for_size (unsigned int, n64_enum_mode_class, int) asm("_mode_for_size");



extern n64_enum_machine_mode get_best_mode (int, int, int, n64_enum_machine_mode, int) asm("_get_best_mode");
extern n64_enum_machine_mode class_narrowest_mode[];





extern n64_enum_machine_mode byte_mode;
extern n64_enum_machine_mode word_mode;
extern n64_enum_machine_mode ptr_mode;


struct n64_tag_rtx_def;






enum n64_cpp_enum_tree_code{
ERROR_MARK,





IDENTIFIER_NODE,




OP_IDENTIFIER,






TREE_LIST,


TREE_VEC,
BLOCK,
VOID_TYPE,
INTEGER_TYPE,



REAL_TYPE,



COMPLEX_TYPE,
ENUMERAL_TYPE,



BOOLEAN_TYPE,



CHAR_TYPE,



POINTER_TYPE,





OFFSET_TYPE,



REFERENCE_TYPE,






METHOD_TYPE,


FILE_TYPE,
ARRAY_TYPE,





SET_TYPE,







RECORD_TYPE,





UNION_TYPE,





QUAL_UNION_TYPE,







FUNCTION_TYPE,





LANG_TYPE,
INTEGER_CST,


REAL_CST,




COMPLEX_CST,



STRING_CST,
FUNCTION_DECL,
LABEL_DECL,
CONST_DECL,
TYPE_DECL,
VAR_DECL,
PARM_DECL,
RESULT_DECL,
FIELD_DECL,






COMPONENT_REF,
BIT_FIELD_REF,


INDIRECT_REF,





OFFSET_REF,


BUFFER_REF,




ARRAY_REF,







CONSTRUCTOR,
COMPOUND_EXPR,


MODIFY_EXPR,



INIT_EXPR,




TARGET_EXPR,





COND_EXPR,
BIND_EXPR,






CALL_EXPR,




METHOD_CALL_EXPR,
WITH_CLEANUP_EXPR,
CLEANUP_POINT_EXPR,
PLACEHOLDER_EXPR,





WITH_RECORD_EXPR,



PLUS_EXPR,
MINUS_EXPR,
MULT_EXPR,






TRUNC_DIV_EXPR,


CEIL_DIV_EXPR,


FLOOR_DIV_EXPR,


ROUND_DIV_EXPR,


TRUNC_MOD_EXPR,
CEIL_MOD_EXPR,
FLOOR_MOD_EXPR,
ROUND_MOD_EXPR,





RDIV_EXPR,



EXACT_DIV_EXPR,






FIX_TRUNC_EXPR,
FIX_CEIL_EXPR,
FIX_FLOOR_EXPR,
FIX_ROUND_EXPR,


FLOAT_EXPR,



EXPON_EXPR,


NEGATE_EXPR,

MIN_EXPR,
MAX_EXPR,
ABS_EXPR,
FFS_EXPR,







LSHIFT_EXPR,
RSHIFT_EXPR,
LROTATE_EXPR,
RROTATE_EXPR,


BIT_IOR_EXPR,
BIT_XOR_EXPR,
BIT_AND_EXPR,
BIT_ANDTC_EXPR,
BIT_NOT_EXPR,






TRUTH_ANDIF_EXPR,
TRUTH_ORIF_EXPR,
TRUTH_AND_EXPR,
TRUTH_OR_EXPR,
TRUTH_XOR_EXPR,
TRUTH_NOT_EXPR,







LT_EXPR,
LE_EXPR,
GT_EXPR,
GE_EXPR,
EQ_EXPR,
NE_EXPR,


IN_EXPR,
SET_LE_EXPR,
CARD_EXPR,
RANGE_EXPR,




CONVERT_EXPR,


NOP_EXPR,


NON_LVALUE_EXPR,





SAVE_EXPR,





RTL_EXPR,



ADDR_EXPR,


REFERENCE_EXPR,



ENTRY_VALUE_EXPR,



COMPLEX_EXPR,



CONJ_EXPR,



REALPART_EXPR,
IMAGPART_EXPR,




PREDECREMENT_EXPR,
PREINCREMENT_EXPR,
POSTDECREMENT_EXPR,
POSTINCREMENT_EXPR,







LABEL_EXPR,



GOTO_EXPR,






RETURN_EXPR,



EXIT_EXPR,




LOOP_EXPR,

  LAST_AND_UNUSED_TREE_CODE

};
typedef __underlying_type(enum n64_cpp_enum_tree_code) n64_enum_tree_code;

extern char **tree_code_type;




extern int *tree_code_length;



extern char **tree_code_name;




enum n64_cpp_enum_built_in_function{
  NOT_BUILT_IN,
  BUILT_IN_ALLOCA,
  BUILT_IN_ABS,
  BUILT_IN_FABS,
  BUILT_IN_LABS,
  BUILT_IN_FFS,
  BUILT_IN_DIV,
  BUILT_IN_LDIV,
  BUILT_IN_FFLOOR,
  BUILT_IN_FCEIL,
  BUILT_IN_FMOD,
  BUILT_IN_FREM,
  BUILT_IN_MEMCPY,
  BUILT_IN_MEMCMP,
  BUILT_IN_MEMSET,
  BUILT_IN_STRCPY,
  BUILT_IN_STRCMP,
  BUILT_IN_STRLEN,
  BUILT_IN_FSQRT,
  BUILT_IN_SIN,
  BUILT_IN_COS,
  BUILT_IN_GETEXP,
  BUILT_IN_GETMAN,
  BUILT_IN_SAVEREGS,
  BUILT_IN_CLASSIFY_TYPE,
  BUILT_IN_NEXT_ARG,
  BUILT_IN_ARGS_INFO,
  BUILT_IN_CONSTANT_P,
  BUILT_IN_FRAME_ADDRESS,
  BUILT_IN_RETURN_ADDRESS,
  BUILT_IN_CALLER_RETURN_ADDRESS,
  BUILT_IN_APPLY_ARGS,
  BUILT_IN_APPLY,
  BUILT_IN_RETURN,


  BUILT_IN_NEW,
  BUILT_IN_VEC_NEW,
  BUILT_IN_DELETE,
  BUILT_IN_VEC_DELETE,


  END_BUILTINS
};
typedef __underlying_type(enum n64_cpp_enum_built_in_function) n64_enum_built_in_function;

typedef union n64_tag_tree_node *tree;






struct n64_tag_tree_common
{
  union n64_tag_tree_node *chain;
  union n64_tag_tree_node *type;

  unsigned int code : 8;




  unsigned side_effects_flag : 1;
  unsigned constant_flag : 1;
  unsigned permanent_flag : 1;
  unsigned addressable_flag : 1;
  unsigned volatile_flag : 1;
  unsigned readonly_flag : 1;
  unsigned unsigned_flag : 1;
  unsigned asm_written_flag: 1;

  unsigned used_flag : 1;
  unsigned raises_flag : 1;
  unsigned static_flag : 1;
  unsigned public_flag : 1;
  unsigned private_flag : 1;
  unsigned protected_flag : 1;

  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;

};
struct n64_tag_tree_int_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  int int_cst_low;
  int int_cst_high;
};

extern int significand_size (n64_enum_machine_mode) asm("_significand_size");
extern void earith (double *, int, double *, double *) asm("_earith")
                                                 ;
extern double etrunci (double) asm("_etrunci");
extern double etruncui (double) asm("_etruncui");
extern double ereal_atof (char *, n64_enum_machine_mode) asm("_ereal_atof");
extern double ereal_negate (double) asm("_ereal_negate");
extern int efixi (double) asm("_efixi");
extern unsigned int efixui (double) asm("_efixui");
extern void ereal_from_int (double *, int, int) asm("_ereal_from_int")
                                         ;
extern void ereal_from_uint (double *, unsigned int, unsigned int) asm("_ereal_from_uint")

                                   ;
extern void ereal_to_int (int *, int *, double) asm("_ereal_to_int")
                            ;
extern double ereal_ldexp (double, int) asm("_ereal_ldexp");

extern void etartdouble (double, long *) asm("_etartdouble");
extern void etarldouble (double, long *) asm("_etarldouble");
extern void etardouble (double, long *) asm("_etardouble");
extern long etarsingle (double) asm("_etarsingle");
extern void ereal_to_decimal (double, char *) asm("_ereal_to_decimal");
extern int ereal_cmp (double, double) asm("_ereal_cmp");
extern int ereal_isneg (double) asm("_ereal_isneg");
extern double ereal_from_float (int) asm("_ereal_from_float");
extern double ereal_from_double (int *) asm("_ereal_from_double");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double real_value_truncate(...) asm("_real_value_truncate");
extern double dconst0;
extern double dconst1;
extern double dconst2;
extern double dconstm1;




union n64_tag_real_extract
{
  double d;
  int i[sizeof (double) / sizeof (int)];
};
double real_value_from_int_cst(...) asm("_real_value_from_int_cst");
extern struct n64_tag_rtx_def *immed_real_const_1 (double, n64_enum_machine_mode) asm("_immed_real_const_1")
                                ;

struct n64_tag_tree_real_cst
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  double real_cst;
};





struct n64_tag_tree_string
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  int length;
  char *pointer;
};





struct n64_tag_tree_complex
{
  char common[sizeof (struct n64_tag_tree_common)];
  struct n64_tag_rtx_def *rtl;

  union n64_tag_tree_node *real;
  union n64_tag_tree_node *imag;
};






struct n64_tag_tree_identifier
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  char *pointer;
};





struct n64_tag_tree_list
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *purpose;
  union n64_tag_tree_node *value;
};






struct n64_tag_tree_vec
{
  char common[sizeof (struct n64_tag_tree_common)];
  int length;
  union n64_tag_tree_node *a[1];
};
struct n64_tag_tree_exp
{
  char common[sizeof (struct n64_tag_tree_common)];
  int complexity;
  union n64_tag_tree_node *operands[1];
};
struct n64_tag_tree_block
{
  char common[sizeof (struct n64_tag_tree_common)];

  unsigned handler_block_flag : 1;
  unsigned abstract_flag : 1;

  union n64_tag_tree_node *vars;
  union n64_tag_tree_node *type_tags;
  union n64_tag_tree_node *subblocks;
  union n64_tag_tree_node *supercontext;
  union n64_tag_tree_node *abstract_origin;
  struct n64_tag_rtx_def *end_note;
};
struct n64_tag_tree_type
{
  char common[sizeof (struct n64_tag_tree_common)];
  union n64_tag_tree_node *values;
  union n64_tag_tree_node *size;
  union n64_tag_tree_node *attributes;
  unsigned uid;

  unsigned char precision;

  int mode : 8;




  unsigned string_flag : 1;
  unsigned no_force_blk_flag : 1;
  unsigned needs_constructing_flag : 1;
  unsigned transparent_union_flag : 1;
  unsigned packed_flag : 1;
  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;


  unsigned int align;
  union n64_tag_tree_node *pointer_to;
  union n64_tag_tree_node *reference_to;
  union {int address; char *pointer; } symtab;
  union n64_tag_tree_node *name;
  union n64_tag_tree_node *minval;
  union n64_tag_tree_node *maxval;
  union n64_tag_tree_node *next_variant;
  union n64_tag_tree_node *main_variant;
  union n64_tag_tree_node *binfo;
  union n64_tag_tree_node *noncopied_parts;
  union n64_tag_tree_node *context;
  struct obstack *obstack;

  struct n64_tag_lang_type *lang_specific;
};
struct n64_tag_tree_decl
{
  char common[sizeof (struct n64_tag_tree_common)];
  char *filename;
  int linenum;
  union n64_tag_tree_node *size;
  unsigned int uid;

  int mode : 8;




  unsigned external_flag : 1;
  unsigned nonlocal_flag : 1;
  unsigned regdecl_flag : 1;
  unsigned inline_flag : 1;
  unsigned bit_field_flag : 1;
  unsigned virtual_flag : 1;
  unsigned ignored_flag : 1;
  unsigned abstract_flag : 1;

  unsigned in_system_header_flag : 1;
  unsigned common_flag : 1;
  unsigned defer_output : 1;
  unsigned transparent_union : 1;
  unsigned static_ctor_flag : 1;
  unsigned static_dtor_flag : 1;
  unsigned artificial_flag : 1;
  unsigned weak_flag : 1;


  unsigned lang_flag_0 : 1;
  unsigned lang_flag_1 : 1;
  unsigned lang_flag_2 : 1;
  unsigned lang_flag_3 : 1;
  unsigned lang_flag_4 : 1;
  unsigned lang_flag_5 : 1;
  unsigned lang_flag_6 : 1;
  unsigned lang_flag_7 : 1;

  union n64_tag_tree_node *name;
  union n64_tag_tree_node *context;
  union n64_tag_tree_node *arguments;
  union n64_tag_tree_node *result;
  union n64_tag_tree_node *initial;
  union n64_tag_tree_node *abstract_origin;
  union n64_tag_tree_node *assembler_name;
  union n64_tag_tree_node *section_name;
  union n64_tag_tree_node *machine_attributes;
  struct n64_tag_rtx_def *rtl;




  union {
    int i;
    unsigned int u;
    n64_enum_built_in_function f;
  } frame_size;



  union {
    struct n64_tag_rtx_def *r;
    int i;
  } saved_insns;
  union n64_tag_tree_node *vindex;

  struct n64_tag_lang_decl *lang_specific;
};





union n64_tag_tree_node
{
  struct n64_tag_tree_common common;
  struct n64_tag_tree_int_cst int_cst;
  struct n64_tag_tree_real_cst real_cst;
  struct n64_tag_tree_string string;
  struct n64_tag_tree_complex complex;
  struct n64_tag_tree_identifier identifier;
  struct n64_tag_tree_decl decl;
  struct n64_tag_tree_type type;
  struct n64_tag_tree_list list;
  struct n64_tag_tree_vec vec;
  struct n64_tag_tree_exp exp;
  struct n64_tag_tree_block block;
 };
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern char *savealloc (int) asm("_savealloc");
extern void free (void *) asm("_free");





extern tree make_node (n64_enum_tree_code) asm("_make_node");





extern tree copy_node (tree) asm("_copy_node");



extern tree copy_list (tree) asm("_copy_list");



extern tree make_tree_vec (int) asm("_make_tree_vec");




extern tree get_identifier (char *) asm("_get_identifier");






extern tree build (n64_enum_tree_code, tree, ...) asm("_build");
extern tree build_nt (n64_enum_tree_code, ...) asm("_build_nt");
extern tree build_parse_node (n64_enum_tree_code, ...) asm("_build_parse_node");

extern tree build_int_2_wide (int, int) asm("_build_int_2_wide");
extern tree build_real (tree, double) asm("_build_real");
extern tree build_real_from_int_cst (tree, tree) asm("_build_real_from_int_cst");
extern tree build_complex (tree, tree) asm("_build_complex");
extern tree build_string (int, char *) asm("_build_string");
extern tree build1 (n64_enum_tree_code, tree, tree) asm("_build1");
extern tree build_tree_list (tree, tree) asm("_build_tree_list");
extern tree build_decl_list (tree, tree) asm("_build_decl_list");
extern tree build_decl (n64_enum_tree_code, tree, tree) asm("_build_decl");
extern tree build_block (tree, tree, tree, tree, tree) asm("_build_block");



extern tree make_signed_type (int) asm("_make_signed_type");
extern tree make_unsigned_type (int) asm("_make_unsigned_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern void fixup_unsigned_type (tree) asm("_fixup_unsigned_type");
extern tree build_pointer_type (tree) asm("_build_pointer_type");
extern tree build_reference_type (tree) asm("_build_reference_type");
extern tree build_index_type (tree) asm("_build_index_type");
extern tree build_index_2_type (tree, tree) asm("_build_index_2_type");
extern tree build_array_type (tree, tree) asm("_build_array_type");
extern tree build_function_type (tree, tree) asm("_build_function_type");
extern tree build_method_type (tree, tree) asm("_build_method_type");
extern tree build_offset_type (tree, tree) asm("_build_offset_type");
extern tree build_complex_type (tree) asm("_build_complex_type");
extern tree array_type_nelts (tree) asm("_array_type_nelts");

extern tree value_member (tree, tree) asm("_value_member");
extern tree purpose_member (tree, tree) asm("_purpose_member");
extern tree binfo_member (tree, tree) asm("_binfo_member");
extern int attribute_hash_list (tree) asm("_attribute_hash_list");
extern int attribute_list_equal (tree, tree) asm("_attribute_list_equal");
extern int attribute_list_contained (tree, tree) asm("_attribute_list_contained");
extern int tree_int_cst_equal (tree, tree) asm("_tree_int_cst_equal");
extern int tree_int_cst_lt (tree, tree) asm("_tree_int_cst_lt");
extern int tree_int_cst_sgn (tree) asm("_tree_int_cst_sgn");
extern int index_type_equal (tree, tree) asm("_index_type_equal");





extern tree make_tree(...) asm("_make_tree");







extern tree build_type_attribute_variant (tree, tree) asm("_build_type_attribute_variant");
extern tree build_decl_attribute_variant (tree, tree) asm("_build_decl_attribute_variant");



int valid_machine_attribute (tree, tree, tree, tree) asm("_valid_machine_attribute");




int is_attribute_p (char *, tree) asm("_is_attribute_p");




tree lookup_attribute (char *, tree) asm("_lookup_attribute");
extern tree build_type_variant (tree, int, int) asm("_build_type_variant");



extern tree build_type_copy (tree) asm("_build_type_copy");






extern void layout_type (tree) asm("_layout_type");






extern tree type_hash_canon (int, tree) asm("_type_hash_canon");
extern void layout_decl (tree, unsigned) asm("_layout_decl");



extern tree non_lvalue (tree) asm("_non_lvalue");
extern tree pedantic_non_lvalue (tree) asm("_pedantic_non_lvalue");

extern tree convert (tree, tree) asm("_convert");
extern tree size_in_bytes (tree) asm("_size_in_bytes");
extern int int_size_in_bytes (tree) asm("_int_size_in_bytes");
extern tree size_binop (n64_enum_tree_code, tree, tree) asm("_size_binop");
extern tree size_int (unsigned int) asm("_size_int");
extern tree round_up (tree, int) asm("_round_up");
extern tree get_pending_sizes (void) asm("_get_pending_sizes");
extern void put_pending_sizes (tree) asm("_put_pending_sizes");



extern tree sizetype;


extern int maximum_field_alignment;


extern int set_alignment;





extern tree chainon (tree, tree) asm("_chainon");



extern tree tree_cons (tree, tree, tree) asm("_tree_cons");
extern tree perm_tree_cons (tree, tree, tree) asm("_perm_tree_cons");
extern tree temp_tree_cons (tree, tree, tree) asm("_temp_tree_cons");
extern tree saveable_tree_cons (tree, tree, tree) asm("_saveable_tree_cons");
extern tree decl_tree_cons (tree, tree, tree) asm("_decl_tree_cons");



extern tree tree_last (tree) asm("_tree_last");



extern tree nreverse (tree) asm("_nreverse");




extern int list_length (tree) asm("_list_length");



extern int integer_zerop (tree) asm("_integer_zerop");



extern int integer_onep (tree) asm("_integer_onep");




extern int integer_all_onesp (tree) asm("_integer_all_onesp");




extern int integer_pow2p (tree) asm("_integer_pow2p");




extern int staticp (tree) asm("_staticp");




extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");





extern tree save_expr (tree) asm("_save_expr");







extern int contains_placeholder_p (tree) asm("_contains_placeholder_p");






extern tree substitute_in_expr (tree, tree, tree) asm("_substitute_in_expr");





extern tree substitute_in_type (tree, tree, tree) asm("_substitute_in_type");







extern tree variable_size (tree) asm("_variable_size");





extern tree stabilize_reference (tree) asm("_stabilize_reference");





extern tree stabilize_reference_1 (tree) asm("_stabilize_reference_1");






extern tree get_unwidened (tree, tree) asm("_get_unwidened");






extern tree get_narrower (tree, int *) asm("_get_narrower");






extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");






extern tree type_for_size (unsigned, int) asm("_type_for_size");






extern tree unsigned_type (tree) asm("_unsigned_type");






extern tree signed_type (tree) asm("_signed_type");





extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");





extern tree get_inner_reference (tree, int *, int *, tree *, n64_enum_machine_mode *, int *, int *) asm("_get_inner_reference");



extern tree decl_function_context (tree) asm("_decl_function_context");



extern tree decl_type_context (tree) asm("_decl_type_context");






extern char *function_cannot_inline_p (tree) asm("_function_cannot_inline_p");


extern int real_zerop (tree) asm("_real_zerop");




extern tree integer_zero_node;


extern tree integer_one_node;


extern tree size_zero_node;


extern tree size_one_node;


extern tree null_pointer_node;


extern tree error_mark_node;


extern tree void_type_node;


extern tree integer_type_node;


extern tree unsigned_type_node;


extern tree char_type_node;



extern char *input_filename;


extern int lineno;



extern int pedantic;




extern int pedantic_lvalues;




extern int immediate_size_expand;



extern tree current_function_decl;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;



extern int all_types_permanent;



extern char *(*decl_printable_name)(...);




extern void (*incomplete_decl_finalize_hook)(...);


extern char *perm_calloc (int, long) asm("_perm_calloc");
extern tree get_set_constructor_bits (tree, char*, int) asm("_get_set_constructor_bits");
extern tree get_set_constructor_bytes (tree, unsigned char*, int) asm("_get_set_constructor_bytes")
                                  ;



extern void expand_fixups (struct n64_tag_rtx_def *) asm("_expand_fixups");
extern tree expand_start_stmt_expr (void) asm("_expand_start_stmt_expr");
extern tree expand_end_stmt_expr (tree) asm("_expand_end_stmt_expr");
extern void expand_expr_stmt (tree) asm("_expand_expr_stmt");
extern int warn_if_unused_value (tree) asm("_warn_if_unused_value");
extern void expand_decl_init (tree) asm("_expand_decl_init");
extern void clear_last_expr (void) asm("_clear_last_expr");
extern void expand_label (tree) asm("_expand_label");
extern void expand_goto (tree) asm("_expand_goto");
extern void expand_asm (tree) asm("_expand_asm");
extern void expand_start_cond (tree, int) asm("_expand_start_cond");
extern void expand_end_cond (void) asm("_expand_end_cond");
extern void expand_start_else (void) asm("_expand_start_else");
extern void expand_start_elseif (tree) asm("_expand_start_elseif");
extern struct nesting *expand_start_loop (int) asm("_expand_start_loop");
extern struct nesting *expand_start_loop_continue_elsewhere (int) asm("_expand_start_loop_continue_elsewhere");
extern void expand_loop_continue_here (void) asm("_expand_loop_continue_here");
extern void expand_end_loop (void) asm("_expand_end_loop");
extern int expand_continue_loop (struct nesting *) asm("_expand_continue_loop");
extern int expand_exit_loop (struct nesting *) asm("_expand_exit_loop");
extern int expand_exit_loop_if_false (struct nesting *, tree) asm("_expand_exit_loop_if_false")
                   ;
extern int expand_exit_something (void) asm("_expand_exit_something");

extern void expand_null_return (void) asm("_expand_null_return");
extern void expand_return (tree) asm("_expand_return");
extern void expand_start_bindings (int) asm("_expand_start_bindings");
extern void expand_end_bindings (tree, int, int) asm("_expand_end_bindings");
extern tree last_cleanup_this_contour (void) asm("_last_cleanup_this_contour");
extern void expand_start_case (int, tree, tree, char *) asm("_expand_start_case")
                     ;
extern void expand_end_case (tree) asm("_expand_end_case");
extern int pushcase (tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase")

                           ;
extern int pushcase_range (tree, tree, tree (*) (tree, tree), tree, tree *) asm("_pushcase_range")

                           ;
extern tree fold (tree) asm("_fold");

extern int force_fit_type (tree, int) asm("_force_fit_type");
extern int add_double (int, int, int, int, int *, int *) asm("_add_double")

                                             ;
extern int neg_double (int, int, int *, int *) asm("_neg_double")
                                             ;
extern int mul_double (int, int, int, int, int *, int *) asm("_mul_double")

                                             ;
extern void lshift_double (int, int, int, int, int *, int *, int) asm("_lshift_double")

                                 ;
extern void rshift_double (int, int, int, int, int *, int *, int) asm("_rshift_double")

                                                  ;
extern void lrotate_double (int, int, int, int, int *, int *) asm("_lrotate_double")

                            ;
extern void rrotate_double (int, int, int, int, int *, int *) asm("_rrotate_double")

                            ;
extern int operand_equal_p (tree, tree, int) asm("_operand_equal_p");
extern tree invert_truthvalue (tree) asm("_invert_truthvalue");




extern void init_lex (void) asm("_init_lex");

extern void init_decl_processing (void) asm("_init_decl_processing");



extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");


extern char *lang_identify (void) asm("_lang_identify");


extern void copy_lang_decl (tree) asm("_copy_lang_decl");


extern int yyparse (void) asm("_yyparse");



extern int lang_decode_option (char *) asm("_lang_decode_option");




extern void pushlevel (int) asm("_pushlevel");





extern tree poplevel (int, int, int) asm("_poplevel");

extern void set_block (tree) asm("_set_block");




extern tree pushdecl (tree) asm("_pushdecl");

extern tree getdecls (void) asm("_getdecls");

extern tree gettags (void) asm("_gettags");

extern tree build_range_type (tree, tree, tree) asm("_build_range_type");




extern int suspend_momentary (void) asm("_suspend_momentary");

extern int allocation_temporary_p (void) asm("_allocation_temporary_p");





extern void resume_momentary (int) asm("_resume_momentary");


extern void rest_of_type_compilation (tree, int) asm("_rest_of_type_compilation");


extern void push_obstacks_nochange (void) asm("_push_obstacks_nochange");

extern void permanent_allocation (int) asm("_permanent_allocation");

extern void push_momentary (void) asm("_push_momentary");

extern void clear_momentary (void) asm("_clear_momentary");

extern void pop_momentary (void) asm("_pop_momentary");

extern void end_temporary_allocation (void) asm("_end_temporary_allocation");


extern void pop_obstacks (void) asm("_pop_obstacks");
enum n64_cpp_enum_rtx_code{


UNKNOWN ,



NIL ,






EXPR_LIST ,



INSN_LIST ,
MATCH_OPERAND ,






MATCH_SCRATCH ,




MATCH_DUP ,







MATCH_OPERATOR ,
MATCH_PARALLEL ,




MATCH_OP_DUP ,




MATCH_PAR_DUP ,
DEFINE_INSN ,







DEFINE_PEEPHOLE ,
DEFINE_SPLIT ,



DEFINE_COMBINE ,
DEFINE_EXPAND ,
DEFINE_DELAY ,
DEFINE_FUNCTION_UNIT ,


DEFINE_ASM_ATTRIBUTES ,





SEQUENCE ,





ADDRESS ,
DEFINE_ATTR ,


ATTR ,







SET_ATTR ,
SET_ATTR_ALTERNATIVE ,




EQ_ATTR ,
ATTR_FLAG ,
INSN ,



JUMP_INSN ,






CALL_INSN ,


BARRIER ,







CODE_LABEL ,
NOTE ,





INLINE_HEADER ,






PARALLEL ,







ASM_INPUT ,
ASM_OPERANDS ,
UNSPEC ,


UNSPEC_VOLATILE ,



ADDR_VEC ,





ADDR_DIFF_VEC ,
SET ,




USE ,




CLOBBER ,





CALL ,



RETURN ,





TRAP_IF ,






CONST_INT ,
CONST_DOUBLE ,


CONST_STRING ,





CONST ,



PC ,




REG ,






SCRATCH ,
SUBREG ,
STRICT_LOW_PART ,





CONCAT ,



MEM ,





LABEL_REF ,





SYMBOL_REF ,






CC0 ,
QUEUED ,
IF_THEN_ELSE ,
COND ,


COMPARE ,


PLUS ,


MINUS ,


NEG ,

MULT ,


DIV ,

MOD ,


UDIV ,
UMOD ,


AND ,

IOR ,

XOR ,

NOT ,




ASHIFT ,
ROTATE ,




ASHIFTRT ,
LSHIFTRT ,
ROTATERT ,





SMIN ,
SMAX ,
UMIN ,
UMAX ,
PRE_DEC ,
PRE_INC ,
POST_DEC ,
POST_INC ,



NE ,
EQ ,
GE ,
GT ,
LE ,
LT ,
GEU ,
GTU ,
LEU ,
LTU ,




SIGN_EXTEND ,


ZERO_EXTEND ,


TRUNCATE ,


FLOAT_EXTEND ,
FLOAT_TRUNCATE ,


FLOAT ,







FIX ,


UNSIGNED_FLOAT ,




UNSIGNED_FIX ,


ABS ,


SQRT ,




FFS ,
SIGN_EXTRACT ,


ZERO_EXTRACT ,




HIGH ,



LO_SUM ,


  LAST_AND_UNUSED_RTX_CODE};
typedef __underlying_type(enum n64_cpp_enum_rtx_code) n64_enum_rtx_code;







extern int rtx_length[];


extern char *rtx_name[];


extern char *rtx_format[];


extern char rtx_class[];




typedef union n64_tag_rtunion_def
{
  int rtwint;
  int rtint;
  char *rtstr;
  struct n64_tag_rtx_def *rtx;
  struct n64_tag_rtvec_def *rtvec;
  n64_enum_machine_mode rttype;
} rtunion;



typedef struct n64_tag_rtx_def
{




  unsigned short code;







  int mode : 8;





  unsigned int jump : 1;

  unsigned int call : 1;
  unsigned int unchanging : 1;







  unsigned int volatil : 1;
  unsigned int in_struct : 1;






  unsigned int used : 1;



  unsigned integrated : 1;



  rtunion fld[1];
} *rtx;
typedef struct n64_tag_rtvec_def{
  unsigned num_elem;
  rtunion elem[1];
} *rtvec;
enum n64_cpp_enum_reg_note{ REG_DEAD = 1, REG_INC = 2, REG_EQUIV = 3, REG_WAS_0 = 4,
  REG_EQUAL = 5, REG_RETVAL = 6, REG_LIBCALL = 7,
  REG_NONNEG = 8, REG_NO_CONFLICT = 9, REG_UNUSED = 10,
  REG_CC_SETTER = 11, REG_CC_USER = 12, REG_LABEL = 13,
  REG_DEP_ANTI = 14, REG_DEP_OUTPUT = 15 };
typedef __underlying_type(enum n64_cpp_enum_reg_note) n64_enum_reg_note;








extern char *reg_note_name[];
extern char *note_insn_name[];
extern rtx plus_constant_wide (rtx, int) asm("_plus_constant_wide");
extern rtx plus_constant_for_output_wide (rtx, int) asm("_plus_constant_for_output_wide");



extern rtx bc_gen_rtx(...) asm("_bc_gen_rtx");

extern rtx gen_rtx (n64_enum_rtx_code, n64_enum_machine_mode, ...) asm("_gen_rtx")
                               ;
extern rtvec gen_rtvec (int, ...) asm("_gen_rtvec");

extern rtx read_rtx (FILE *) asm("_read_rtx");
extern char *xmalloc(...) asm("_xmalloc");
extern char *xrealloc(...) asm("_xrealloc");


extern char *oballoc (int) asm("_oballoc");
extern char *permalloc (int) asm("_permalloc");
extern void free (void *) asm("_free");
extern rtx rtx_alloc (n64_enum_rtx_code) asm("_rtx_alloc");
extern rtvec rtvec_alloc (int) asm("_rtvec_alloc");
extern rtx find_reg_note (rtx, n64_enum_reg_note, rtx) asm("_find_reg_note");
extern rtx find_regno_note (rtx, n64_enum_reg_note, int) asm("_find_regno_note");
extern int find_reg_fusage (rtx, n64_enum_rtx_code, rtx) asm("_find_reg_fusage");
extern int find_regno_fusage (rtx, n64_enum_rtx_code, int) asm("_find_regno_fusage");
extern int get_integer_term (rtx) asm("_get_integer_term");
extern rtx get_related_value (rtx) asm("_get_related_value");
extern rtx single_set (rtx) asm("_single_set");
extern rtx find_last_value (rtx, rtx *, rtx) asm("_find_last_value");
extern rtx copy_rtx (rtx) asm("_copy_rtx");
extern rtx copy_rtx_if_shared (rtx) asm("_copy_rtx_if_shared");
extern rtx copy_most_rtx (rtx, rtx) asm("_copy_most_rtx");
extern rtx replace_rtx (rtx, rtx, rtx) asm("_replace_rtx");
extern rtvec gen_rtvec_v (int, rtx *) asm("_gen_rtvec_v");
extern rtx gen_reg_rtx (n64_enum_machine_mode) asm("_gen_reg_rtx");
extern rtx gen_label_rtx (void) asm("_gen_label_rtx");
extern rtx gen_inline_header_rtx (rtx, rtx, int, int, int, int, int, int, rtx, rtx, int, int, rtvec, rtx) asm("_gen_inline_header_rtx")

                        ;
extern rtx gen_lowpart_common (n64_enum_machine_mode, rtx) asm("_gen_lowpart_common");
extern rtx gen_lowpart (n64_enum_machine_mode, rtx) asm("_gen_lowpart");
extern rtx gen_lowpart_if_possible (n64_enum_machine_mode, rtx) asm("_gen_lowpart_if_possible");
extern rtx gen_highpart (n64_enum_machine_mode, rtx) asm("_gen_highpart");
extern rtx gen_realpart (n64_enum_machine_mode, rtx) asm("_gen_realpart");
extern rtx gen_imagpart (n64_enum_machine_mode, rtx) asm("_gen_imagpart");
extern rtx operand_subword (rtx, int, int, n64_enum_machine_mode) asm("_operand_subword");
extern rtx operand_subword_force (rtx, int, n64_enum_machine_mode) asm("_operand_subword_force");
extern int subreg_lowpart_p (rtx) asm("_subreg_lowpart_p");
extern rtx make_safe_from (rtx, rtx) asm("_make_safe_from");
extern rtx convert_memory_address (n64_enum_machine_mode, rtx) asm("_convert_memory_address");
extern rtx memory_address (n64_enum_machine_mode, rtx) asm("_memory_address");
extern rtx get_insns (void) asm("_get_insns");
extern rtx get_last_insn (void) asm("_get_last_insn");
extern rtx get_last_insn_anywhere (void) asm("_get_last_insn_anywhere");
extern void start_sequence (void) asm("_start_sequence");
extern void push_to_sequence (rtx) asm("_push_to_sequence");
extern void end_sequence (void) asm("_end_sequence");
extern rtx gen_sequence (void) asm("_gen_sequence");
extern rtx immed_double_const (int, int, n64_enum_machine_mode) asm("_immed_double_const");
extern rtx force_const_mem (n64_enum_machine_mode, rtx) asm("_force_const_mem");
extern rtx force_reg (n64_enum_machine_mode, rtx) asm("_force_reg");
extern rtx get_pool_constant (rtx) asm("_get_pool_constant");
extern n64_enum_machine_mode get_pool_mode (rtx) asm("_get_pool_mode");
extern int get_pool_offset (rtx) asm("_get_pool_offset");
extern rtx simplify_subtraction (rtx) asm("_simplify_subtraction");
extern rtx assign_stack_local (n64_enum_machine_mode, int, int) asm("_assign_stack_local");
extern rtx assign_stack_temp (n64_enum_machine_mode, int, int) asm("_assign_stack_temp");
extern rtx protect_from_queue (rtx, int) asm("_protect_from_queue");
extern void emit_queue (void) asm("_emit_queue");
extern rtx emit_move_insn (rtx, rtx) asm("_emit_move_insn");
extern rtx emit_insn_before (rtx, rtx) asm("_emit_insn_before");
extern rtx emit_jump_insn_before (rtx, rtx) asm("_emit_jump_insn_before");
extern rtx emit_call_insn_before (rtx, rtx) asm("_emit_call_insn_before");
extern rtx emit_barrier_before (rtx) asm("_emit_barrier_before");
extern rtx emit_note_before (int, rtx) asm("_emit_note_before");
extern rtx emit_insn_after (rtx, rtx) asm("_emit_insn_after");
extern rtx emit_jump_insn_after (rtx, rtx) asm("_emit_jump_insn_after");
extern rtx emit_barrier_after (rtx) asm("_emit_barrier_after");
extern rtx emit_label_after (rtx, rtx) asm("_emit_label_after");
extern rtx emit_note_after (int, rtx) asm("_emit_note_after");
extern rtx emit_line_note_after (char *, int, rtx) asm("_emit_line_note_after");
extern rtx emit_insn (rtx) asm("_emit_insn");
extern rtx emit_insns (rtx) asm("_emit_insns");
extern rtx emit_insns_before (rtx, rtx) asm("_emit_insns_before");
extern rtx emit_insns_after (rtx, rtx) asm("_emit_insns_after");
extern rtx emit_jump_insn (rtx) asm("_emit_jump_insn");
extern rtx emit_call_insn (rtx) asm("_emit_call_insn");
extern rtx emit_label (rtx) asm("_emit_label");
extern rtx emit_barrier (void) asm("_emit_barrier");
extern rtx emit_line_note (char *, int) asm("_emit_line_note");
extern rtx emit_note (char *, int) asm("_emit_note");
extern rtx emit_line_note_force (char *, int) asm("_emit_line_note_force");
extern rtx make_insn_raw (rtx) asm("_make_insn_raw");
extern rtx previous_insn (rtx) asm("_previous_insn");
extern rtx next_insn (rtx) asm("_next_insn");
extern rtx prev_nonnote_insn (rtx) asm("_prev_nonnote_insn");
extern rtx next_nonnote_insn (rtx) asm("_next_nonnote_insn");
extern rtx prev_real_insn (rtx) asm("_prev_real_insn");
extern rtx next_real_insn (rtx) asm("_next_real_insn");
extern rtx prev_active_insn (rtx) asm("_prev_active_insn");
extern rtx next_active_insn (rtx) asm("_next_active_insn");
extern rtx prev_label (rtx) asm("_prev_label");
extern rtx next_label (rtx) asm("_next_label");
extern rtx next_cc0_user (rtx) asm("_next_cc0_user");
extern rtx prev_cc0_setter (rtx) asm("_prev_cc0_setter");
extern rtx reg_set_last (rtx, rtx) asm("_reg_set_last");
extern rtx next_nondeleted_insn (rtx) asm("_next_nondeleted_insn");
extern n64_enum_rtx_code reverse_condition (n64_enum_rtx_code) asm("_reverse_condition");
extern n64_enum_rtx_code swap_condition (n64_enum_rtx_code) asm("_swap_condition");
extern n64_enum_rtx_code unsigned_condition (n64_enum_rtx_code) asm("_unsigned_condition");
extern n64_enum_rtx_code signed_condition (n64_enum_rtx_code) asm("_signed_condition");
extern rtx find_equiv_reg (rtx, rtx, n64_enum_reg_class, int, short *, int, n64_enum_machine_mode) asm("_find_equiv_reg");
extern rtx squeeze_notes (rtx, rtx) asm("_squeeze_notes");
extern rtx delete_insn (rtx) asm("_delete_insn");
extern void delete_jump (rtx) asm("_delete_jump");
extern rtx get_label_before (rtx) asm("_get_label_before");
extern rtx get_label_after (rtx) asm("_get_label_after");
extern rtx follow_jumps (rtx) asm("_follow_jumps");
extern rtx adj_offsettable_operand (rtx, int) asm("_adj_offsettable_operand");
extern rtx try_split (rtx, rtx, int) asm("_try_split");
extern rtx split_insns (rtx, rtx) asm("_split_insns");
extern rtx simplify_unary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, n64_enum_machine_mode) asm("_simplify_unary_operation");
extern rtx simplify_binary_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_binary_operation");
extern rtx simplify_ternary_operation (n64_enum_rtx_code, n64_enum_machine_mode, n64_enum_machine_mode, rtx, rtx, rtx) asm("_simplify_ternary_operation");
extern rtx simplify_relational_operation (n64_enum_rtx_code, n64_enum_machine_mode, rtx, rtx) asm("_simplify_relational_operation");
extern rtx nonlocal_label_rtx_list (void) asm("_nonlocal_label_rtx_list");
extern rtx gen_move_insn (rtx, rtx) asm("_gen_move_insn");
extern rtx gen_jump (rtx) asm("_gen_jump");
extern rtx gen_beq (rtx) asm("_gen_beq");
extern rtx gen_bge (rtx) asm("_gen_bge");
extern rtx gen_ble (rtx) asm("_gen_ble");
extern rtx eliminate_constant_term (rtx, rtx *) asm("_eliminate_constant_term");
extern rtx expand_complex_abs (n64_enum_machine_mode, rtx, rtx, int) asm("_expand_complex_abs");
extern n64_enum_machine_mode choose_hard_reg_mode (int, int) asm("_choose_hard_reg_mode");





extern int max_parallel;

extern int asm_noperands (rtx) asm("_asm_noperands");
extern char *decode_asm_operands (rtx, rtx *, rtx **, char **, n64_enum_machine_mode *) asm("_decode_asm_operands");

extern n64_enum_reg_class reg_preferred_class (int) asm("_reg_preferred_class");
extern n64_enum_reg_class reg_alternate_class (int) asm("_reg_alternate_class");

extern rtx get_first_nonparm_insn (void) asm("_get_first_nonparm_insn");


extern rtx pc_rtx;
extern rtx cc0_rtx;
extern rtx const0_rtx;
extern rtx const1_rtx;
extern rtx const2_rtx;
extern rtx constm1_rtx;
extern rtx const_true_rtx;

extern rtx const_tiny_rtx[3][(int) MAX_MACHINE_MODE];
extern rtx stack_pointer_rtx;
extern rtx frame_pointer_rtx;
extern rtx hard_frame_pointer_rtx;
extern rtx arg_pointer_rtx;
extern rtx pic_offset_table_rtx;
extern rtx struct_value_rtx;
extern rtx struct_value_incoming_rtx;
extern rtx static_chain_rtx;
extern rtx static_chain_incoming_rtx;
extern rtx virtual_incoming_args_rtx;







extern rtx virtual_stack_vars_rtx;







extern rtx virtual_stack_dynamic_rtx;







extern rtx virtual_outgoing_args_rtx;





extern rtx find_next_ref (rtx, rtx) asm("_find_next_ref");
extern rtx *find_single_use (rtx, rtx, rtx *) asm("_find_single_use");




extern rtx expand_expr(...) asm("_expand_expr");

extern rtx output_constant_def (union n64_tag_tree_node *) asm("_output_constant_def");
extern rtx immed_real_const (union n64_tag_tree_node *) asm("_immed_real_const");
extern union n64_tag_tree_node *make_tree (union n64_tag_tree_node *, rtx) asm("_make_tree");


extern void fatal_insn_not_found (rtx) asm("_fatal_insn_not_found");
extern void fatal_insn (char *, rtx) asm("_fatal_insn");
extern int reload_completed;




extern int reload_in_progress;







extern int cse_not_expected;



extern rtx *regno_reg_rtx;





extern int rtx_to_tree_code (n64_enum_rtx_code) asm("_rtx_to_tree_code");
extern char *main_input_filename;

enum n64_cpp_enum_debug_info_type{
  NO_DEBUG,
  DBX_DEBUG,
  SDB_DEBUG,
  DWARF_DEBUG,
  XCOFF_DEBUG
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_type) n64_enum_debug_info_type;



extern n64_enum_debug_info_type write_symbols;

enum n64_cpp_enum_debug_info_level{
  DINFO_LEVEL_NONE,
  DINFO_LEVEL_TERSE,
  DINFO_LEVEL_NORMAL,
  DINFO_LEVEL_VERBOSE
};
typedef __underlying_type(enum n64_cpp_enum_debug_info_level) n64_enum_debug_info_level;



extern n64_enum_debug_info_level debug_info_level;



extern int use_gnu_debug_info_extensions;



extern int optimize;




extern int obey_regdecls;




extern int quiet_flag;



extern int inhibit_warnings;



extern int extra_warnings;



extern int warn_unused;



extern int warn_inline;



extern int warn_uninitialized;



extern int warn_shadow;



extern int warn_switch;




extern int warn_return_type;





extern int warn_cast_align;




extern int warn_template_debugging;




extern int warn_id_clash;
extern unsigned id_clash_len;





extern int warn_larger_than;
extern unsigned larger_than_size;




extern int warn_aggregate_return;



extern int profile_flag;



extern int profile_block_flag;




extern int pedantic;




extern int in_system_header;




extern int flag_print_asm_name;





extern int flag_signed_char;



extern int flag_short_enums;





extern int flag_caller_saves;



extern int flag_pcc_struct_return;




extern int flag_force_mem;




extern int flag_force_addr;




extern int flag_defer_pop;




extern int flag_float_store;



extern int flag_strength_reduce;






extern int flag_unroll_loops;




extern int flag_unroll_all_loops;




extern int flag_cse_follow_jumps;




extern int flag_cse_skip_blocks;



extern int flag_expensive_optimizations;




extern int flag_writable_strings;





extern int flag_no_function_cse;




extern int flag_omit_frame_pointer;



extern int flag_no_peephole;



extern int flag_volatile;



extern int flag_volatile_global;






extern int flag_fast_math;




extern int flag_inline_functions;





extern int flag_keep_inline_functions;







extern int flag_no_inline;



extern int flag_syntax_only;



extern int flag_gen_aux_info;



extern int flag_shared_data;






extern int flag_schedule_insns;
extern int flag_schedule_insns_after_reload;



extern int flag_delayed_branch;



extern int flag_short_temps;





extern int flag_pretend_float;




extern int flag_pedantic_errors;




extern int flag_pic;



extern int flag_no_common;





extern int flag_inhibit_size_directive;






extern int flag_verbose_asm;



extern int flag_gnu_linker;


extern int flag_pack_struct;







extern int frame_pointer_needed;




extern int can_reach_end;




extern int current_function_has_nonlocal_label;




extern int current_function_has_nonlocal_goto;
struct n64_tag_lang_identifier
{
  struct n64_tag_tree_identifier ignore;
  tree global_value, local_value;
  tree class_value;
  tree class_template_info;
  struct n64_tag_lang_id2 *x;
};

struct n64_tag_lang_id2
{
  tree label_value, implicit_decl;
  tree type_desc, as_list, error_locus;
};
extern int pedantic;
extern tree exception_throw_decl;

extern tree double_type_node, long_double_type_node, float_type_node;
extern tree char_type_node, unsigned_char_type_node, signed_char_type_node;
extern tree ptrdiff_type_node;

extern tree short_integer_type_node, short_unsigned_type_node;
extern tree long_integer_type_node, long_unsigned_type_node;
extern tree long_long_integer_type_node, long_long_unsigned_type_node;
extern tree unsigned_type_node;
extern tree string_type_node, char_array_type_node, int_array_type_node;
extern tree wchar_array_type_node;
extern tree wchar_type_node, signed_wchar_type_node, unsigned_wchar_type_node;
extern tree intQI_type_node, unsigned_intQI_type_node;
extern tree intHI_type_node, unsigned_intHI_type_node;
extern tree intSI_type_node, unsigned_intSI_type_node;
extern tree intDI_type_node, unsigned_intDI_type_node;

extern int current_function_returns_value;
extern int current_function_returns_null;
extern tree current_function_return_value;

extern tree ridpointers[];
extern tree ansi_opname[];
extern tree ansi_assopname[];



extern int dollars_in_ident;




extern int flag_cond_mismatch;



extern int flag_no_asm;



extern int flag_gnu_xref;



extern int flag_gnu_binutils;



extern int flag_no_ident;



extern int warn_implicit;




extern int warn_ctor_dtor_privacy;




extern int warn_return_type;





extern int warn_write_strings;




extern int warn_pointer_arith;



extern int warn_strict_prototypes;



extern int warn_parentheses;




extern int warn_redundant_decls;



extern int warn_missing_braces;



extern int warn_char_subscripts;




extern int warn_cast_qual;



extern int warn_traditional;



extern int warn_format;




extern int warn_nonvdtor;


extern int warn_extern_inline;



extern int flag_traditional;



extern int flag_signed_bitfields;
extern int write_virtuals;




extern int flag_vtable_thunks;






extern int interface_only, interface_unknown;



extern int flag_elide_constructors;




extern int flag_ansi;




extern int flag_handle_exceptions;



extern int flag_handle_signatures;




extern int flag_default_inline;



extern int flag_cadillac;



enum n64_cpp_enum_cplus_tree_code{
  __DUMMY = LAST_AND_UNUSED_TREE_CODE,
CP_OFFSET_REF,




DELETE_EXPR,
VEC_DELETE_EXPR,
UNSAVE_EXPR,





SCOPE_REF,




MEMBER_REF,



TYPE_EXPR,




NEW_EXPR,
VEC_NEW_EXPR,



THROW_EXPR,
TEMPLATE_DECL,



TEMPLATE_TYPE_PARM,



TEMPLATE_CONST_PARM,







UNINSTANTIATED_P_TYPE,
THUNK_DECL,


NAMESPACE_DECL,
  LAST_CPLUS_TREE_CODE
};
typedef __underlying_type(enum n64_cpp_enum_cplus_tree_code) n64_enum_cplus_tree_code;







enum n64_cpp_enum_languages{ lang_c, lang_cplusplus };
typedef __underlying_type(enum n64_cpp_enum_languages) n64_enum_languages;

struct n64_tag_lang_type
{
  struct
    {
      unsigned has_type_conversion : 1;
      unsigned has_int_conversion : 1;
      unsigned has_float_conversion : 1;
      unsigned has_init_ref : 1;
      unsigned gets_init_aggr : 1;
      unsigned has_assignment : 1;
      unsigned has_default_ctor : 1;
      unsigned uses_multiple_inheritance : 1;

      unsigned has_nonpublic_ctor : 2;
      unsigned has_nonpublic_assign_ref : 2;
      unsigned const_needs_init : 1;
      unsigned ref_needs_init : 1;
      unsigned has_const_assign_ref : 1;
      unsigned vtable_needs_writing : 1;

      unsigned has_assign_ref : 1;
      unsigned gets_new : 2;
      unsigned gets_delete : 2;
      unsigned has_call_overloaded : 1;
      unsigned has_array_ref_overloaded : 1;
      unsigned has_arrow_overloaded : 1;

      unsigned local_typedecls : 1;
      unsigned interface_only : 1;
      unsigned interface_unknown : 1;
      unsigned needs_virtual_reinit : 1;
      unsigned vec_delete_takes_size : 1;
      unsigned declared_class : 1;
      unsigned being_defined : 1;
      unsigned redefined : 1;

      unsigned no_globalize : 1;
      unsigned marked : 1;
      unsigned marked2 : 1;
      unsigned marked3 : 1;
      unsigned marked4 : 1;
      unsigned marked5 : 1;
      unsigned marked6 : 1;

      unsigned use_template : 2;
      unsigned debug_requested : 1;
      unsigned has_method_call_overloaded : 1;
      unsigned private_attr : 1;
      unsigned got_semicolon : 1;
      unsigned ptrmemfunc_flag : 1;
      unsigned is_signature : 1;
      unsigned is_signature_pointer : 1;

      unsigned is_signature_reference : 1;
      unsigned has_default_implementation : 1;
      unsigned grokking_typedef : 1;
      unsigned has_opaque_typedecls : 1;
      unsigned sigtable_has_been_generated : 1;
      unsigned was_anonymous : 1;
      unsigned has_real_assignment : 1;
      unsigned has_real_assign_ref : 1;

      unsigned has_const_init_ref : 1;
      unsigned has_complex_init_ref : 1;
      unsigned has_complex_assign_ref : 1;
      unsigned has_abstract_assign_ref : 1;
      unsigned non_aggregate : 1;




      unsigned dummy : 19;

      unsigned n_vancestors : 16;
    } type_flags;

  int cid;
  int n_ancestors;
  int vsize;
  int max_depth;
  int vfield_parent;

  union n64_tag_tree_node *vbinfo[2];
  union n64_tag_tree_node *baselink_vec;
  union n64_tag_tree_node *vfields;
  union n64_tag_tree_node *vbases;
  union n64_tag_tree_node *vbase_size;

  union n64_tag_tree_node *tags;
  char *memoized_table_entry;

  char *search_slot;


  unsigned int mode : 8;




  unsigned char size_unit;
  unsigned char align;
  unsigned char sep_unit;

  union n64_tag_tree_node *sep;
  union n64_tag_tree_node *size;

  union n64_tag_tree_node *base_init_list;
  union n64_tag_tree_node *abstract_virtuals;
  union n64_tag_tree_node *as_list;
  union n64_tag_tree_node *id_as_list;
  union n64_tag_tree_node *binfo_as_list;
  union n64_tag_tree_node *friend_classes;

  char *mi_matrix;

  union n64_tag_tree_node *rtti;

  union n64_tag_tree_node *methods;

  union n64_tag_tree_node *signature;
  union n64_tag_tree_node *signature_pointer_to;
  union n64_tag_tree_node *signature_reference_to;

  int linenum;
};
struct n64_tag_lang_decl_flags
{

  int language : 8;




  unsigned operator_attr : 1;
  unsigned constructor_attr : 1;
  unsigned returns_first_arg : 1;
  unsigned preserves_first_arg : 1;
  unsigned friend_attr : 1;
  unsigned static_function : 1;
  unsigned const_memfunc : 1;
  unsigned volatile_memfunc : 1;

  unsigned abstract_virtual : 1;
  unsigned permanent_attr : 1 ;
  unsigned constructor_for_vbase_attr : 1;
  unsigned mutable_flag : 1;
  unsigned is_default_implementation : 1;
  unsigned saved_inline : 1;
  unsigned use_template : 2;

  unsigned c_static : 1;
  unsigned nonconverting : 1;
  unsigned declared_inline : 1;
  unsigned not_really_extern : 1;
  unsigned dummy : 4;

  tree access;
  tree context;
  tree memfunc_pointer_to;
};

struct n64_tag_lang_decl
{
  struct n64_tag_lang_decl_flags decl_flags;

  struct n64_tag_template_info *template_info;
  tree main_decl_variant;
  struct n64_tag_pending_inline *pending_inline_info;
  tree next_method;
  tree chain;
};
extern int flag_new_for_scope;
enum n64_cpp_enum_tag_types{ record_type, class_type, union_type, enum_type,
     signature_type };
typedef __underlying_type(enum n64_cpp_enum_tag_types) n64_enum_tag_types;




extern int strict_prototype;
extern int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus;



extern int flag_labels_ok;



extern int flag_detailed_statistics;




extern int warn_overloaded_virtual;


extern void declare_function_name (void) asm("_declare_function_name");
extern void decl_attributes (tree, tree, tree) asm("_decl_attributes");
extern void init_function_format_info (void) asm("_init_function_format_info");
extern void record_function_format (tree, tree, int, int, int) asm("_record_function_format");
extern void check_function_format (tree, tree, tree) asm("_check_function_format");


extern void binary_op_error (n64_enum_tree_code) asm("_binary_op_error");
extern tree cp_build_type_variant (tree, int, int) asm("_cp_build_type_variant");
extern void c_expand_expr_stmt (tree) asm("_c_expand_expr_stmt");

extern tree check_case_value (tree) asm("_check_case_value");

extern tree combine_strings (tree) asm("_combine_strings");
extern void constant_expression_warning (tree) asm("_constant_expression_warning");
extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");

extern char *get_directive_line (FILE *) asm("_get_directive_line");



extern tree shorten_compare (tree *, tree *, tree *, n64_enum_tree_code *) asm("_shorten_compare");


extern tree truthvalue_conversion (tree) asm("_truthvalue_conversion");
extern tree type_for_mode (n64_enum_machine_mode, int) asm("_type_for_mode");
extern tree type_for_size (unsigned, int) asm("_type_for_size");


extern tree void_list_node;
extern tree void_zero_node;
extern tree default_function_type;
extern tree vtable_entry_type;
extern tree sigtable_entry_type;
extern tree __t_desc_type_node;
extern tree __tp_desc_type_node;
extern tree __access_mode_type_node;
extern tree __bltn_desc_type_node, __user_desc_type_node;
extern tree __class_desc_type_node, __attr_desc_type_node;
extern tree __ptr_desc_type_node, __func_desc_type_node;
extern tree __ptmf_desc_type_node, __ptmd_desc_type_node;
extern tree type_info_type_node;
extern tree class_star_type_node;
extern tree this_identifier;
extern tree pfn_identifier;
extern tree index_identifier;
extern tree delta_identifier;
extern tree delta2_identifier;
extern tree pfn_or_delta2_identifier;
extern tree tag_identifier;
extern tree vb_off_identifier;
extern tree vt_off_identifier;


extern tree error_mark_list;

extern tree ptr_type_node, const_ptr_type_node;
extern tree class_type_node, record_type_node, union_type_node, enum_type_node;
extern tree unknown_type_node;
extern tree opaque_type_node, signature_type_node;







extern tree vtbl_type_node;
extern tree delta_type_node;

extern tree long_long_integer_type_node, long_long_unsigned_type_node;

extern tree integer_two_node, integer_three_node;
extern tree boolean_type_node, boolean_true_node, boolean_false_node;





struct n64_tag_template_info {

  tree parm_vec;

  tree bindings;


  char *text;
  int length;

  char *filename;
  int lineno;


  tree aggr;
};
extern int processing_template_decl, processing_template_defn;



struct n64_tag_tinst_level
{
  tree classname;
  int line;
  char *file;
  struct n64_tag_tinst_level *next;
};


extern tree current_class_name;
extern tree current_class_type;
extern tree previous_class_type;

extern tree current_lang_name, lang_name_cplusplus, lang_name_c;



extern tree original_function_name;

extern tree current_class_name, current_class_type, current_class_decl, C_C_D;


extern tree global_base_init_list;
extern tree current_base_init_list, current_member_init_list;

extern int current_function_assigns_this;
extern int current_function_just_assigned_this;
extern int current_function_parms_stored;
enum n64_cpp_enum_access_type{
  access_default,
  access_public,
  access_protected,
  access_private,
  access_default_virtual,
  access_public_virtual,
  access_private_virtual
};
typedef __underlying_type(enum n64_cpp_enum_access_type) n64_enum_access_type;



extern tree current_unit_name, current_unit_language;



struct n64_tag_pending_inline
{
  struct n64_tag_pending_inline *next;
  int lineno;
  char *filename;
  tree fndecl;
  int token;
  int token_value;

  char *buf;
  int len;
  tree parm_vec, bindings;
  unsigned int can_free : 1;
  unsigned int deja_vu : 1;
  unsigned int interface : 2;
};


extern struct n64_tag_pending_inline *pending_inlines;






extern int flag_all_virtual;




extern int flag_this_is_variable;





extern int flag_int_enum_equivalence;



extern int flag_gc;



extern int flag_rtti;




extern int flag_implement_inlines;



extern int flag_external_templates;



extern int flag_alt_external_templates;



extern int flag_implicit_templates;



extern int current_function_obstack_index;



extern int current_function_obstack_usage;

enum n64_cpp_enum_overload_flags{ NO_SPECIAL = 0, DTOR_FLAG, OP_FLAG, TYPENAME_FLAG };
typedef __underlying_type(enum n64_cpp_enum_overload_flags) n64_enum_overload_flags;


extern tree current_class_decl, C_C_D;


extern tree current_class_name;
extern tree current_class_type;
extern char **opname_tab, **assignop_tab;


extern tree convert_and_check (tree, tree) asm("_convert_and_check");
extern void overflow_warning (tree) asm("_overflow_warning");
extern void unsigned_conversion_warning (tree, tree) asm("_unsigned_conversion_warning");


extern struct candidate *ansi_c_bullshit;

extern int rank_for_overload (struct candidate *, struct candidate *) asm("_rank_for_overload");
extern void compute_conversion_costs (tree, tree, struct candidate *, int) asm("_compute_conversion_costs");
extern int get_arglist_len_in_bytes (tree) asm("_get_arglist_len_in_bytes");
extern tree build_vfield_ref (tree, tree) asm("_build_vfield_ref");
extern tree find_scoped_type (tree, tree, tree) asm("_find_scoped_type");
extern tree resolve_scope_to_name (tree, tree) asm("_resolve_scope_to_name");
extern tree build_scoped_method_call (tree, tree, tree, tree) asm("_build_scoped_method_call");
extern tree build_method_call (tree, tree, tree, tree, int) asm("_build_method_call");
extern tree build_overload_call_real (tree, tree, int, struct candidate *, int) asm("_build_overload_call_real");
extern tree build_overload_call (tree, tree, int, struct candidate *) asm("_build_overload_call");
extern tree build_overload_call_maybe (tree, tree, int, struct candidate *) asm("_build_overload_call_maybe");


extern char *dont_allow_type_definitions;
extern tree build_vbase_pointer (tree, tree) asm("_build_vbase_pointer");
extern tree build_vbase_path (n64_enum_tree_code, tree, tree, tree, int) asm("_build_vbase_path");
extern tree build_vtable_entry (tree, tree) asm("_build_vtable_entry");
extern tree build_vfn_ref (tree *, tree, tree) asm("_build_vfn_ref");
extern void add_method (tree, tree *, tree) asm("_add_method");
extern tree get_vfield_offset (tree) asm("_get_vfield_offset");
extern void duplicate_tag_error (tree) asm("_duplicate_tag_error");
extern tree finish_struct (tree, tree, int) asm("_finish_struct");
extern int resolves_to_fixed_type_p (tree, int *) asm("_resolves_to_fixed_type_p");
extern void init_class_processing (void) asm("_init_class_processing");
extern void pushclass (tree, int) asm("_pushclass");
extern void popclass (int) asm("_popclass");
extern void push_nested_class (tree, int) asm("_push_nested_class");
extern void pop_nested_class (int) asm("_pop_nested_class");
extern void push_lang_context (tree) asm("_push_lang_context");
extern void pop_lang_context (void) asm("_pop_lang_context");
extern int root_lang_context_p (void) asm("_root_lang_context_p");
extern tree instantiate_type (tree, tree, int) asm("_instantiate_type");
extern void print_class_statistics (void) asm("_print_class_statistics");
extern void maybe_push_cache_obstack (void) asm("_maybe_push_cache_obstack");
extern unsigned int skip_rtti_stuff (tree *) asm("_skip_rtti_stuff");


extern tree convert_to_reference (tree, tree, int, int, tree) asm("_convert_to_reference");
extern tree convert_from_reference (tree) asm("_convert_from_reference");
extern tree convert_to_aggr (tree, tree, char **, int) asm("_convert_to_aggr");
extern tree convert_pointer_to (tree, tree) asm("_convert_pointer_to");
extern tree convert_pointer_to_real (tree, tree) asm("_convert_pointer_to_real");
extern tree convert_pointer_to_vbase (tree, tree) asm("_convert_pointer_to_vbase");
extern tree convert (tree, tree) asm("_convert");
extern tree cp_convert (tree, tree, int, int) asm("_cp_convert");
extern tree convert_force (tree, tree, int) asm("_convert_force");
extern tree build_type_conversion (n64_enum_tree_code, tree, tree, int) asm("_build_type_conversion");
extern tree build_expr_type_conversion (int, tree, int) asm("_build_expr_type_conversion");
extern int build_default_binary_type_conversion (n64_enum_tree_code, tree *, tree *) asm("_build_default_binary_type_conversion");
extern tree type_promotes_to (tree) asm("_type_promotes_to");


extern int global_bindings_p (void) asm("_global_bindings_p");
extern int toplevel_bindings_p (void) asm("_toplevel_bindings_p");
extern void keep_next_level (void) asm("_keep_next_level");
extern int kept_level_p (void) asm("_kept_level_p");
extern void declare_parm_level (void) asm("_declare_parm_level");
extern void declare_implicit_exception (void) asm("_declare_implicit_exception");
extern int have_exceptions_p (void) asm("_have_exceptions_p");
extern void declare_uninstantiated_type_level (void) asm("_declare_uninstantiated_type_level");
extern int uninstantiated_type_level_p (void) asm("_uninstantiated_type_level_p");
extern void declare_pseudo_global_level (void) asm("_declare_pseudo_global_level");
extern int pseudo_global_level_p (void) asm("_pseudo_global_level_p");
extern void pushlevel (int) asm("_pushlevel");
extern void pushlevel_temporary (int) asm("_pushlevel_temporary");
extern tree poplevel (int, int, int) asm("_poplevel");
extern void delete_block (tree) asm("_delete_block");
extern void insert_block (tree) asm("_insert_block");
extern void add_block_current_level (tree) asm("_add_block_current_level");
extern void set_block (tree) asm("_set_block");
extern void pushlevel_class (void) asm("_pushlevel_class");
extern tree poplevel_class (int) asm("_poplevel_class");

extern void print_binding_stack (void) asm("_print_binding_stack");
extern void push_to_top_level (void) asm("_push_to_top_level");
extern void pop_from_top_level (void) asm("_pop_from_top_level");
extern void set_identifier_type_value (tree, tree) asm("_set_identifier_type_value");
extern void pop_everything (void) asm("_pop_everything");
extern tree make_type_decl (tree, tree) asm("_make_type_decl");
extern void pushtag (tree, tree, int) asm("_pushtag");
extern tree make_anon_name (void) asm("_make_anon_name");
extern void clear_anon_tags (void) asm("_clear_anon_tags");
extern tree pushdecl (tree) asm("_pushdecl");
extern tree pushdecl_top_level (tree) asm("_pushdecl_top_level");
extern void push_class_level_binding (tree, tree) asm("_push_class_level_binding");
extern void push_overloaded_decl_top_level (tree, int) asm("_push_overloaded_decl_top_level");
extern tree pushdecl_class_level (tree) asm("_pushdecl_class_level");
extern tree pushdecl_nonclass_level (tree) asm("_pushdecl_nonclass_level");
extern int overloaded_globals_p (tree) asm("_overloaded_globals_p");
extern tree push_overloaded_decl (tree, int) asm("_push_overloaded_decl");
extern tree implicitly_declare (tree) asm("_implicitly_declare");
extern tree lookup_label (tree) asm("_lookup_label");
extern tree shadow_label (tree) asm("_shadow_label");
extern tree define_label (char *, int, tree) asm("_define_label");
extern void define_case_label (tree) asm("_define_case_label");
extern tree getdecls (void) asm("_getdecls");
extern tree gettags (void) asm("_gettags");
extern void set_current_level_tags_transparency (int) asm("_set_current_level_tags_transparency");
extern tree typedecl_for_tag (tree) asm("_typedecl_for_tag");
extern tree lookup_name (tree, int) asm("_lookup_name");
extern tree lookup_namespace_name (tree, tree) asm("_lookup_namespace_name");
extern tree lookup_name_current_level (tree) asm("_lookup_name_current_level");
extern void init_decl_processing (void) asm("_init_decl_processing");

extern void shadow_tag (tree) asm("_shadow_tag");
extern int grok_ctor_properties (tree, tree) asm("_grok_ctor_properties");
extern tree groktypename (tree) asm("_groktypename");
extern tree start_decl (tree, tree, int, tree) asm("_start_decl");
extern void cp_finish_decl (tree, tree, tree, int, int) asm("_cp_finish_decl");
extern void expand_static_init (tree, tree) asm("_expand_static_init");
extern int complete_array_type (tree, tree, int) asm("_complete_array_type");
extern tree build_ptrmemfunc_type (tree) asm("_build_ptrmemfunc_type");

extern int parmlist_is_exprlist (tree) asm("_parmlist_is_exprlist");
extern tree xref_tag (tree, tree, tree, int) asm("_xref_tag");
extern void xref_basetypes (tree, tree, tree, tree) asm("_xref_basetypes");
extern tree start_enum (tree) asm("_start_enum");
extern tree finish_enum (tree, tree) asm("_finish_enum");
extern tree build_enumerator (tree, tree) asm("_build_enumerator");
extern tree grok_enum_decls (tree, tree) asm("_grok_enum_decls");
extern int start_function (tree, tree, tree, tree, int) asm("_start_function");
extern void store_parm_decls (void) asm("_store_parm_decls");
extern void expand_start_early_try_stmts (void) asm("_expand_start_early_try_stmts");
extern void store_in_parms (struct n64_tag_rtx_def *) asm("_store_in_parms");
extern void store_return_init (tree, tree) asm("_store_return_init");
extern void finish_function (int, int, int) asm("_finish_function");
extern tree start_method (tree, tree, tree) asm("_start_method");
extern tree finish_method (tree) asm("_finish_method");
extern void hack_incomplete_structures (tree) asm("_hack_incomplete_structures");
extern tree maybe_build_cleanup (tree) asm("_maybe_build_cleanup");
extern void cplus_expand_expr_stmt (tree) asm("_cplus_expand_expr_stmt");
extern void finish_stmt (void) asm("_finish_stmt");
extern void pop_implicit_try_blocks (tree) asm("_pop_implicit_try_blocks");
extern void push_exception_cleanup (tree) asm("_push_exception_cleanup");
extern void revert_static_member_fn (tree *, tree *, tree *) asm("_revert_static_member_fn");


extern int lang_decode_option (char *) asm("_lang_decode_option");
extern tree grok_method_quals (tree, tree, tree) asm("_grok_method_quals");
extern void grokclassfn (tree, tree, tree, n64_enum_overload_flags, tree) asm("_grokclassfn");
extern tree grok_alignof (tree) asm("_grok_alignof");
extern tree grok_array_decl (tree, tree) asm("_grok_array_decl");
extern tree delete_sanity (tree, tree, int, int) asm("_delete_sanity");
extern tree check_classfn (tree, tree, tree) asm("_check_classfn");
extern tree grokfield (tree, tree, tree, tree, tree, tree) asm("_grokfield");
extern tree grokbitfield (tree, tree, tree) asm("_grokbitfield");
extern tree groktypefield (tree, tree) asm("_groktypefield");
extern tree grokoptypename (tree, tree) asm("_grokoptypename");
extern tree build_push_scope (tree, tree) asm("_build_push_scope");
extern void cplus_decl_attributes (tree, tree, tree) asm("_cplus_decl_attributes");
extern tree constructor_name_full (tree) asm("_constructor_name_full");
extern tree constructor_name (tree) asm("_constructor_name");
extern void setup_vtbl_ptr (void) asm("_setup_vtbl_ptr");
extern void mark_inline_for_output (tree) asm("_mark_inline_for_output");
extern void clear_temp_name (void) asm("_clear_temp_name");
extern tree get_temp_name (tree, int) asm("_get_temp_name");
extern tree get_temp_regvar (tree, tree) asm("_get_temp_regvar");
extern void finish_anon_union (tree) asm("_finish_anon_union");
extern tree finish_table (tree, tree, tree, int) asm("_finish_table");
extern void finish_builtin_type (tree, char *, tree *, int, tree) asm("_finish_builtin_type");
extern tree coerce_new_type (tree) asm("_coerce_new_type");
extern tree coerce_delete_type (tree) asm("_coerce_delete_type");
extern void walk_vtables (void (*)(...), void (*)(...)) asm("_walk_vtables");
extern void walk_sigtables (void (*)(...), void (*)(...)) asm("_walk_sigtables");
extern void finish_file (void) asm("_finish_file");
extern void warn_if_unknown_interface (tree) asm("_warn_if_unknown_interface");
extern tree grok_x_components (tree, tree) asm("_grok_x_components");
extern tree reparse_absdcl_as_expr (tree, tree) asm("_reparse_absdcl_as_expr");
extern tree reparse_absdcl_as_casts (tree, tree) asm("_reparse_absdcl_as_casts");
extern tree reparse_decl_as_expr (tree, tree) asm("_reparse_decl_as_expr");
extern tree finish_decl_parsing (tree) asm("_finish_decl_parsing");
extern tree lookup_name_nonclass (tree) asm("_lookup_name_nonclass");
extern tree check_cp_case_value (tree) asm("_check_cp_case_value");
extern tree do_toplevel_using_decl (tree) asm("_do_toplevel_using_decl");
extern tree do_class_using_decl (tree) asm("_do_class_using_decl");
extern tree current_namespace_id (tree) asm("_current_namespace_id");
extern tree get_namespace_id (void) asm("_get_namespace_id");
extern void check_default_args (tree) asm("_check_default_args");




extern tree protect_list;
extern void start_protect (void) asm("_start_protect");
extern void end_protect (tree) asm("_end_protect");
extern void end_protect_partials(void) asm("_end_protect_partials");
extern void expand_exception_blocks (void) asm("_expand_exception_blocks");
extern void expand_start_try_stmts (void) asm("_expand_start_try_stmts");
extern void expand_end_try_stmts (void) asm("_expand_end_try_stmts");
extern void expand_start_all_catch (void) asm("_expand_start_all_catch");
extern void expand_end_all_catch (void) asm("_expand_end_all_catch");
extern void start_catch_block (tree, tree) asm("_start_catch_block");
extern void end_catch_block (void) asm("_end_catch_block");
extern void expand_throw (tree) asm("_expand_throw");
extern int might_have_exceptions_p (void) asm("_might_have_exceptions_p");
extern void emit_exception_table (void) asm("_emit_exception_table");
extern tree build_throw (tree) asm("_build_throw");
extern void init_exception_processing (void) asm("_init_exception_processing");
extern void expand_builtin_throw (void) asm("_expand_builtin_throw");
extern void expand_start_eh_spec (void) asm("_expand_start_eh_spec");
extern void expand_end_eh_spec (tree) asm("_expand_end_eh_spec");



extern void init_cplus_expand (void) asm("_init_cplus_expand");
extern void fixup_result_decl (tree, struct n64_tag_rtx_def *) asm("_fixup_result_decl");
extern int decl_in_memory_p (tree) asm("_decl_in_memory_p");
extern tree unsave_expr_now (tree) asm("_unsave_expr_now");


extern int type_needs_gc_entry (tree) asm("_type_needs_gc_entry");
extern int value_safe_from_gc (tree, tree) asm("_value_safe_from_gc");
extern void build_static_gc_entry (tree, tree) asm("_build_static_gc_entry");
extern tree protect_value_from_gc (tree, tree) asm("_protect_value_from_gc");
extern tree build_headof (tree) asm("_build_headof");
extern tree build_classof (tree) asm("_build_classof");
extern tree build_t_desc (tree, int) asm("_build_t_desc");
extern tree build_i_desc (tree) asm("_build_i_desc");
extern tree build_m_desc (tree) asm("_build_m_desc");
extern void expand_gc_prologue_and_epilogue (void) asm("_expand_gc_prologue_and_epilogue");
extern void lang_expand_end_bindings (struct n64_tag_rtx_def *, struct n64_tag_rtx_def *) asm("_lang_expand_end_bindings");
extern void init_gc_processing (void) asm("_init_gc_processing");
extern tree build_typeid (tree) asm("_build_typeid");
extern tree get_typeid (tree) asm("_get_typeid");
extern tree build_dynamic_cast (tree, tree) asm("_build_dynamic_cast");


extern void emit_base_init (tree, int) asm("_emit_base_init");
extern void check_base_init (tree) asm("_check_base_init");
extern void expand_direct_vtbls_init (tree, tree, int, int, tree) asm("_expand_direct_vtbls_init");
extern void do_member_init (tree, tree, tree) asm("_do_member_init");
extern void expand_member_init (tree, tree, tree) asm("_expand_member_init");
extern void expand_aggr_init (tree, tree, int, int) asm("_expand_aggr_init");
extern int is_aggr_typedef (tree, int) asm("_is_aggr_typedef");
extern tree get_aggr_from_typedef (tree, int) asm("_get_aggr_from_typedef");
extern tree get_type_value (tree) asm("_get_type_value");
extern tree build_member_call (tree, tree, tree) asm("_build_member_call");
extern tree build_offset_ref (tree, tree) asm("_build_offset_ref");
extern tree get_member_function (tree *, tree, tree) asm("_get_member_function");
extern tree get_member_function_from_ptrfunc (tree *, tree) asm("_get_member_function_from_ptrfunc");
extern tree resolve_offset_ref (tree) asm("_resolve_offset_ref");
extern tree decl_constant_value (tree) asm("_decl_constant_value");
extern int is_friend_type (tree, tree) asm("_is_friend_type");
extern int is_friend (tree, tree) asm("_is_friend");
extern void make_friend_class (tree, tree) asm("_make_friend_class");
extern tree do_friend (tree, tree, tree, tree, n64_enum_overload_flags, tree) asm("_do_friend");
extern void embrace_waiting_friends (tree) asm("_embrace_waiting_friends");
extern tree build_builtin_call (tree, tree, tree) asm("_build_builtin_call");
extern tree build_new (tree, tree, tree, int) asm("_build_new");
extern tree expand_vec_init (tree, tree, tree, tree, int) asm("_expand_vec_init");
extern tree build_x_delete (tree, tree, int, tree) asm("_build_x_delete");
extern tree build_delete (tree, tree, tree, int, int) asm("_build_delete");
extern tree build_vbase_delete (tree, tree) asm("_build_vbase_delete");
extern tree build_vec_delete (tree, tree, tree, tree, tree, int) asm("_build_vec_delete");




extern tree make_pointer_declarator (tree, tree) asm("_make_pointer_declarator");
extern tree make_reference_declarator (tree, tree) asm("_make_reference_declarator");
extern char *operator_name_string (tree) asm("_operator_name_string");
extern void lang_init (void) asm("_lang_init");
extern void lang_finish (void) asm("_lang_finish");
extern void init_filename_times (void) asm("_init_filename_times");
extern void reinit_lang_specific (void) asm("_reinit_lang_specific");
extern void init_lex (void) asm("_init_lex");
extern void reinit_parse_for_function (void) asm("_reinit_parse_for_function");
extern int *init_parse (void) asm("_init_parse");
extern void print_parse_statistics (void) asm("_print_parse_statistics");
extern void extract_interface_info (void) asm("_extract_interface_info");
extern void set_vardecl_interface_info (tree, tree) asm("_set_vardecl_interface_info");
extern void do_pending_inlines (void) asm("_do_pending_inlines");
extern void process_next_inline (tree) asm("_process_next_inline");

extern void yyungetc (int, int) asm("_yyungetc");
extern void reinit_parse_for_method (int, tree) asm("_reinit_parse_for_method");



extern tree cons_up_default_function (tree, tree, int) asm("_cons_up_default_function");
extern void check_for_missing_semicolon (tree) asm("_check_for_missing_semicolon");
extern void note_got_semicolon (tree) asm("_note_got_semicolon");
extern void note_list_got_semicolon (tree) asm("_note_list_got_semicolon");
extern int check_newline (void) asm("_check_newline");
extern void dont_see_typename (void) asm("_dont_see_typename");
extern int identifier_type (tree) asm("_identifier_type");
extern void see_typename (void) asm("_see_typename");
extern tree do_identifier (tree) asm("_do_identifier");
extern tree identifier_typedecl_value (tree) asm("_identifier_typedecl_value");
extern int real_yylex (void) asm("_real_yylex");
extern tree build_lang_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_decl");
extern tree build_lang_field_decl (n64_enum_tree_code, tree, tree) asm("_build_lang_field_decl");
extern void copy_lang_decl (tree) asm("_copy_lang_decl");
extern tree make_lang_type (n64_enum_tree_code) asm("_make_lang_type");
extern void copy_decl_lang_specific (tree) asm("_copy_decl_lang_specific");
extern void dump_time_statistics (void) asm("_dump_time_statistics");

extern void compiler_error_with_decl (tree, char *) asm("_compiler_error_with_decl");
extern void yyerror (char *) asm("_yyerror");


extern void cp_error(...) asm("_cp_error");
extern void cp_error_at(...) asm("_cp_error_at");
extern void cp_warning(...) asm("_cp_warning");
extern void cp_warning_at(...) asm("_cp_warning_at");
extern void cp_pedwarn(...) asm("_cp_pedwarn");
extern void cp_pedwarn_at(...) asm("_cp_pedwarn_at");
extern void cp_compiler_error(...) asm("_cp_compiler_error");
extern void cp_sprintf(...) asm("_cp_sprintf");


extern void init_error (void) asm("_init_error");
extern char *fndecl_as_string (tree, tree, int) asm("_fndecl_as_string");
extern char *type_as_string (tree, int) asm("_type_as_string");
extern char *args_as_string (tree, int) asm("_args_as_string");
extern char *decl_as_string (tree, int) asm("_decl_as_string");
extern char *expr_as_string (tree, int) asm("_expr_as_string");
extern char *code_as_string (n64_enum_tree_code, int) asm("_code_as_string");
extern char *language_as_string (n64_enum_languages, int) asm("_language_as_string");
extern char *parm_as_string (int, int) asm("_parm_as_string");
extern char *op_as_string (n64_enum_tree_code, int) asm("_op_as_string");
extern char *cv_as_string (tree, int) asm("_cv_as_string");


extern void init_method (void) asm("_init_method");
extern tree make_anon_parm_name (void) asm("_make_anon_parm_name");
extern void clear_anon_parm_name (void) asm("_clear_anon_parm_name");
extern void do_inline_function_hair (tree, tree) asm("_do_inline_function_hair");

extern char *build_overload_name (tree, int, int) asm("_build_overload_name");
extern tree build_static_name (tree, tree) asm("_build_static_name");
extern tree cplus_exception_name (tree) asm("_cplus_exception_name");
extern tree build_decl_overload (tree, tree, int) asm("_build_decl_overload");
extern tree build_typename_overload (tree) asm("_build_typename_overload");
extern tree build_t_desc_overload (tree) asm("_build_t_desc_overload");
extern void declare_overloaded (tree) asm("_declare_overloaded");



extern tree build_opfncall (n64_enum_tree_code, int, tree, tree, tree) asm("_build_opfncall");
extern tree hack_identifier (tree, tree, int) asm("_hack_identifier");
extern tree build_component_type_expr (tree, tree, tree, int) asm("_build_component_type_expr");


extern tree tsubst (tree, tree*, int, tree) asm("_tsubst");
extern void begin_template_parm_list (void) asm("_begin_template_parm_list");
extern tree process_template_parm (tree, tree) asm("_process_template_parm");
extern tree end_template_parm_list (tree) asm("_end_template_parm_list");
extern void end_template_decl (tree, tree, tree, int) asm("_end_template_decl");
extern tree lookup_template_class (tree, tree, tree) asm("_lookup_template_class");
extern void push_template_decls (tree, tree, int) asm("_push_template_decls");
extern void pop_template_decls (tree, tree, int) asm("_pop_template_decls");
extern int uses_template_parms (tree) asm("_uses_template_parms");
extern void instantiate_member_templates (tree) asm("_instantiate_member_templates");
extern tree instantiate_class_template (tree, int) asm("_instantiate_class_template");
extern tree instantiate_template (tree, tree *) asm("_instantiate_template");
extern void undo_template_name_overload (tree, int) asm("_undo_template_name_overload");
extern void overload_template_name (tree, int) asm("_overload_template_name");
extern void end_template_instantiation (tree) asm("_end_template_instantiation");
extern void reinit_parse_for_template (int, tree, tree) asm("_reinit_parse_for_template");
extern int type_unification (tree, tree *, tree, tree, int *, int) asm("_type_unification");
extern int do_pending_expansions (void) asm("_do_pending_expansions");
extern void do_pending_templates (void) asm("_do_pending_templates");
struct n64_tag_tinst_level *tinst_for_decl (void) asm("_tinst_for_decl");
extern void do_function_instantiation (tree, tree, tree) asm("_do_function_instantiation");
extern void do_type_instantiation (tree, tree) asm("_do_type_instantiation");
extern tree create_nested_upt (tree, tree) asm("_create_nested_upt");


extern tree make_memoized_table_entry (tree, tree, int) asm("_make_memoized_table_entry");
extern void push_memoized_context (tree, int) asm("_push_memoized_context");
extern void pop_memoized_context (int) asm("_pop_memoized_context");
extern tree get_binfo (tree, tree, int) asm("_get_binfo");
extern int get_base_distance (tree, tree, int, tree *) asm("_get_base_distance");
extern n64_enum_access_type compute_access (tree, tree) asm("_compute_access");
extern tree lookup_field (tree, tree, int, int) asm("_lookup_field");
extern tree lookup_nested_field (tree, int) asm("_lookup_nested_field");
extern tree lookup_fnfields (tree, tree, int) asm("_lookup_fnfields");
extern tree lookup_nested_tag (tree, tree) asm("_lookup_nested_tag");
extern int breadth_first_search (tree, int (*)(...), int (*)(...)) asm("_breadth_first_search");
extern int tree_needs_constructor_p (tree, int) asm("_tree_needs_constructor_p");
extern int tree_has_any_destructor_p (tree, int) asm("_tree_has_any_destructor_p");
extern tree get_matching_virtual (tree, tree, int) asm("_get_matching_virtual");
extern tree get_abstract_virtuals (tree) asm("_get_abstract_virtuals");
extern tree get_baselinks (tree, tree, tree) asm("_get_baselinks");
extern tree next_baselink (tree) asm("_next_baselink");
extern tree init_vbase_pointers (tree, tree) asm("_init_vbase_pointers");
extern void expand_indirect_vtbls_init (tree, tree, tree, int) asm("_expand_indirect_vtbls_init");
extern void clear_search_slots (tree) asm("_clear_search_slots");
extern tree get_vbase_types (tree) asm("_get_vbase_types");
extern void build_mi_matrix (tree) asm("_build_mi_matrix");
extern void free_mi_matrix (void) asm("_free_mi_matrix");
extern void build_mi_virtuals (int, int) asm("_build_mi_virtuals");
extern void add_mi_virtuals (int, tree) asm("_add_mi_virtuals");
extern void report_ambiguous_mi_virtuals (int, tree) asm("_report_ambiguous_mi_virtuals");
extern void note_debug_info_needed (tree) asm("_note_debug_info_needed");
extern void push_class_decls (tree) asm("_push_class_decls");
extern void pop_class_decls (tree) asm("_pop_class_decls");
extern void unuse_fields (tree) asm("_unuse_fields");
extern void unmark_finished_struct (tree) asm("_unmark_finished_struct");
extern void print_search_statistics (void) asm("_print_search_statistics");
extern void init_search_processing (void) asm("_init_search_processing");
extern void reinit_search_statistics (void) asm("_reinit_search_statistics");
extern tree current_scope (void) asm("_current_scope");
extern tree lookup_conversions (tree) asm("_lookup_conversions");


extern tree build_signature_pointer_type (tree, int, int) asm("_build_signature_pointer_type");
extern tree build_signature_reference_type (tree, int, int) asm("_build_signature_reference_type");
extern tree build_signature_pointer_constructor (tree, tree) asm("_build_signature_pointer_constructor");
extern tree build_signature_method_call (tree, tree, tree, tree) asm("_build_signature_method_call");
extern tree build_optr_ref (tree) asm("_build_optr_ref");
extern tree build_sptr_ref (tree) asm("_build_sptr_ref");


extern void init_spew (void) asm("_init_spew");
extern int yylex (void) asm("_yylex");
extern tree arbitrate_lookup (tree, tree, tree) asm("_arbitrate_lookup");


extern int lvalue_p (tree) asm("_lvalue_p");
extern int lvalue_or_else (tree, char *) asm("_lvalue_or_else");
extern tree build_cplus_new (tree, tree, int) asm("_build_cplus_new");
extern tree break_out_cleanups (tree) asm("_break_out_cleanups");
extern tree break_out_calls (tree) asm("_break_out_calls");
extern tree build_cplus_method_type (tree, tree, tree) asm("_build_cplus_method_type");
extern tree build_cplus_staticfn_type (tree, tree, tree) asm("_build_cplus_staticfn_type");
extern tree build_cplus_array_type (tree, tree) asm("_build_cplus_array_type");
extern void propagate_binfo_offsets (tree, tree) asm("_propagate_binfo_offsets");
extern int layout_vbasetypes (tree, int) asm("_layout_vbasetypes");
extern tree layout_basetypes (tree, tree) asm("_layout_basetypes");
extern int list_hash (tree) asm("_list_hash");
extern tree list_hash_lookup (int, tree) asm("_list_hash_lookup");
extern void list_hash_add (int, tree) asm("_list_hash_add");
extern tree list_hash_canon (int, tree) asm("_list_hash_canon");
extern tree hash_tree_cons (int, int, int, tree, tree, tree) asm("_hash_tree_cons");
extern tree hash_tree_chain (tree, tree) asm("_hash_tree_chain");
extern tree hash_chainon (tree, tree) asm("_hash_chainon");
extern tree get_decl_list (tree) asm("_get_decl_list");
extern tree list_hash_lookup_or_cons (tree) asm("_list_hash_lookup_or_cons");
extern tree make_binfo (tree, tree, tree, tree, tree) asm("_make_binfo");
extern tree binfo_value (tree, tree) asm("_binfo_value");
extern tree reverse_path (tree) asm("_reverse_path");
extern tree virtual_member (tree, tree) asm("_virtual_member");
extern void debug_binfo (tree) asm("_debug_binfo");
extern int decl_list_length (tree) asm("_decl_list_length");
extern int count_functions (tree) asm("_count_functions");
extern tree decl_value_member (tree, tree) asm("_decl_value_member");
extern int is_overloaded_fn (tree) asm("_is_overloaded_fn");
extern tree get_first_fn (tree) asm("_get_first_fn");
extern tree fnaddr_from_vtable_entry (tree) asm("_fnaddr_from_vtable_entry");
extern void set_fnaddr_from_vtable_entry (tree, tree) asm("_set_fnaddr_from_vtable_entry");
extern tree function_arg_chain (tree) asm("_function_arg_chain");
extern int promotes_to_aggr_type (tree, n64_enum_tree_code) asm("_promotes_to_aggr_type");
extern int is_aggr_type_2 (tree, tree) asm("_is_aggr_type_2");
extern void message_2_types (void (*)(...), char *, tree, tree) asm("_message_2_types");
extern char *lang_printable_name (tree) asm("_lang_printable_name");
extern tree build_exception_variant (tree, tree) asm("_build_exception_variant");
extern tree copy_to_permanent (tree) asm("_copy_to_permanent");
extern void print_lang_statistics (void) asm("_print_lang_statistics");

extern tree array_type_nelts_total (tree) asm("_array_type_nelts_total");
extern tree array_type_nelts_top (tree) asm("_array_type_nelts_top");
extern tree break_out_target_exprs (tree) asm("_break_out_target_exprs");
extern tree build_unsave_expr (tree) asm("_build_unsave_expr");
extern int cp_expand_decl_cleanup (tree, tree) asm("_cp_expand_decl_cleanup");


extern tree condition_conversion (tree) asm("_condition_conversion");
extern tree target_type (tree) asm("_target_type");
extern tree require_complete_type (tree) asm("_require_complete_type");
extern int type_unknown_p (tree) asm("_type_unknown_p");
extern int fntype_p (tree) asm("_fntype_p");
extern tree require_instantiated_type (tree, tree, tree) asm("_require_instantiated_type");
extern tree commonparms (tree, tree) asm("_commonparms");
extern tree common_type (tree, tree) asm("_common_type");
extern int compexcepttypes (tree, tree, int) asm("_compexcepttypes");
extern int comptypes (tree, tree, int) asm("_comptypes");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern tree common_base_types (tree, tree) asm("_common_base_types");
extern int compparms (tree, tree, int) asm("_compparms");
extern int comp_target_types (tree, tree, int) asm("_comp_target_types");
extern int self_promoting_args_p (tree) asm("_self_promoting_args_p");
extern tree unsigned_type (tree) asm("_unsigned_type");
extern tree signed_type (tree) asm("_signed_type");
extern tree signed_or_unsigned_type (int, tree) asm("_signed_or_unsigned_type");
extern tree c_sizeof (tree) asm("_c_sizeof");
extern tree c_sizeof_nowarn (tree) asm("_c_sizeof_nowarn");
extern tree c_alignof (tree) asm("_c_alignof");
extern tree decay_conversion (tree) asm("_decay_conversion");
extern tree default_conversion (tree) asm("_default_conversion");
extern tree build_object_ref (tree, tree, tree) asm("_build_object_ref");
extern tree build_component_ref_1 (tree, tree, int) asm("_build_component_ref_1");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_x_indirect_ref (tree, char *) asm("_build_x_indirect_ref");
extern tree build_indirect_ref (tree, char *) asm("_build_indirect_ref");
extern tree build_x_array_ref (tree, tree) asm("_build_x_array_ref");
extern tree build_array_ref (tree, tree) asm("_build_array_ref");
extern tree build_x_function_call (tree, tree, tree) asm("_build_x_function_call");
extern tree build_function_call_real (tree, tree, int, int) asm("_build_function_call_real");
extern tree build_function_call (tree, tree) asm("_build_function_call");
extern tree build_function_call_maybe (tree, tree) asm("_build_function_call_maybe");
extern tree convert_arguments (tree, tree, tree, tree, int) asm("_convert_arguments");
extern tree build_x_binary_op (n64_enum_tree_code, tree, tree) asm("_build_x_binary_op");
extern tree build_binary_op (n64_enum_tree_code, tree, tree, int) asm("_build_binary_op");
extern tree build_binary_op_nodefault (n64_enum_tree_code, tree, tree, n64_enum_tree_code) asm("_build_binary_op_nodefault");
extern tree build_component_addr (tree, tree, char *) asm("_build_component_addr");
extern tree build_x_unary_op (n64_enum_tree_code, tree) asm("_build_x_unary_op");
extern tree build_unary_op (n64_enum_tree_code, tree, int) asm("_build_unary_op");
extern tree unary_complex_lvalue (n64_enum_tree_code, tree) asm("_unary_complex_lvalue");
extern int mark_addressable (tree) asm("_mark_addressable");
extern tree build_x_conditional_expr (tree, tree, tree) asm("_build_x_conditional_expr");
extern tree build_conditional_expr (tree, tree, tree) asm("_build_conditional_expr");
extern tree build_x_compound_expr (tree) asm("_build_x_compound_expr");
extern tree build_compound_expr (tree) asm("_build_compound_expr");
extern tree build_static_cast (tree, tree) asm("_build_static_cast");
extern tree build_reinterpret_cast (tree, tree) asm("_build_reinterpret_cast");
extern tree build_const_cast (tree, tree) asm("_build_const_cast");
extern tree build_c_cast (tree, tree, int) asm("_build_c_cast");
extern tree build_modify_expr (tree, n64_enum_tree_code, tree) asm("_build_modify_expr");
extern int language_lvalue_valid (tree) asm("_language_lvalue_valid");
extern void warn_for_assignment (char *, char *, char *, tree, int, int) asm("_warn_for_assignment");
extern tree convert_for_initialization (tree, tree, tree, int, char *, tree, int) asm("_convert_for_initialization");
extern void c_expand_asm_operands (tree, tree, tree, tree, int, char *, int) asm("_c_expand_asm_operands");
extern void c_expand_return (tree) asm("_c_expand_return");
extern tree c_expand_start_case (tree) asm("_c_expand_start_case");
extern tree build_component_ref (tree, tree, tree, int) asm("_build_component_ref");
extern tree build_ptrmemfunc (tree, tree, int) asm("_build_ptrmemfunc");


extern tree error_not_base_type (tree, tree) asm("_error_not_base_type");
extern tree binfo_or_else (tree, tree) asm("_binfo_or_else");
extern void error_with_aggr_type(...) asm("_error_with_aggr_type");
extern void readonly_error (tree, char *, int) asm("_readonly_error");
extern void abstract_virtuals_error (tree, tree) asm("_abstract_virtuals_error");
extern void incomplete_type_error (tree, tree) asm("_incomplete_type_error");
extern void my_friendly_abort (int) asm("_my_friendly_abort");
extern void my_friendly_assert (int, int) asm("_my_friendly_assert");
extern tree store_init_value (tree, tree) asm("_store_init_value");
extern tree digest_init (tree, tree, tree *) asm("_digest_init");
extern tree build_scoped_ref (tree, tree) asm("_build_scoped_ref");
extern tree build_x_arrow (tree) asm("_build_x_arrow");
extern tree build_m_component_ref (tree, tree) asm("_build_m_component_ref");
extern tree build_functional_cast (tree, tree) asm("_build_functional_cast");
extern char *enum_name_string (tree, tree) asm("_enum_name_string");
extern void report_case_error (int, tree, tree, tree) asm("_report_case_error");


extern void GNU_xref_begin (char *) asm("_GNU_xref_begin");
extern void GNU_xref_end (int) asm("_GNU_xref_end");
extern void GNU_xref_file (char *) asm("_GNU_xref_file");
extern void GNU_xref_start_scope (int) asm("_GNU_xref_start_scope");
extern void GNU_xref_end_scope (int, int, int, int, int) asm("_GNU_xref_end_scope");
extern void GNU_xref_ref (tree, char *) asm("_GNU_xref_ref");
extern void GNU_xref_decl (tree, tree) asm("_GNU_xref_decl");
extern void GNU_xref_call (tree, char *) asm("_GNU_xref_call");
extern void GNU_xref_function (tree, tree) asm("_GNU_xref_function");
extern void GNU_xref_assign (tree) asm("_GNU_xref_assign");
extern void GNU_xref_hier (char *, char *, int, int, int) asm("_GNU_xref_hier");
extern void GNU_xref_member (tree, tree) asm("_GNU_xref_member");
enum n64_cpp_enum_decl_context{ NORMAL,
  FUNCDEF,
  PARM,
  CATCHPARM,
  FIELD,
  BITFIELD,
  TYPENAME,
  MEMFUNCDEF
};
typedef __underlying_type(enum n64_cpp_enum_decl_context) n64_enum_decl_context;



extern tree grokdeclarator (tree, tree, n64_enum_decl_context, int, tree, tree) asm("_grokdeclarator");




extern tree this_identifier, in_charge_identifier;



extern tree last_function_parms;




extern tree pending_statics;





extern tree static_aggregates;
enum n64_cpp_enum_rid{
  RID_UNUSED,
  RID_INT,
  RID_BOOL,
  RID_CHAR,
  RID_WCHAR,
  RID_FLOAT,
  RID_DOUBLE,
  RID_VOID,


  RID_CLASS,
  RID_RECORD,
  RID_UNION,
  RID_ENUM,
  RID_LONGLONG,





  RID_EXTERN,
  RID_CONST,
  RID_LONG,
  RID_TYPEDEF,
  RID_UNSIGNED,
  RID_SHORT,
  RID_INLINE,

  RID_STATIC,

  RID_REGISTER,
  RID_VOLATILE,
  RID_FRIEND,
  RID_VIRTUAL,
  RID_EXPLICIT,
  RID_SIGNED,
  RID_AUTO,
  RID_MUTABLE,



  RID_PUBLIC,
  RID_PRIVATE,
  RID_PROTECTED,
  RID_EXCEPTION,
  RID_TEMPLATE,
  RID_SIGNATURE,


  RID_MAX
};
typedef __underlying_type(enum n64_cpp_enum_rid) n64_enum_rid;

typedef struct { unsigned long idata[2]; }
     RID_BIT_TYPE;
extern tree ridpointers[(int) RID_MAX];





extern tree lastiddecl;

extern char *token_buffer;


extern int looking_for_typename;
extern int looking_for_template;


extern tree got_scope;
extern tree got_object;



extern int pending_lang_change;

extern tree make_pointer_declarator (...) asm("_make_pointer_declarator"), make_reference_declarator (...) asm("_make_reference_declarator");
extern void reinit_parse_for_function(void) asm("_reinit_parse_for_function");
extern void reinit_parse_for_method(...) asm("_reinit_parse_for_method");
extern int yylex(void) asm("_yylex");
extern void init_final (char *) asm("_init_final");



extern void end_final (char *) asm("_end_final");



extern void app_enable (void) asm("_app_enable");



extern void app_disable (void) asm("_app_disable");




extern int dbr_sequence_length (void) asm("_dbr_sequence_length");


extern void init_insn_lengths (void) asm("_init_insn_lengths");




extern int get_attr_length (rtx) asm("_get_attr_length");



extern void shorten_branches (rtx) asm("_shorten_branches");






extern void final_start_function (rtx, FILE *, int) asm("_final_start_function");




extern void final_end_function (rtx, FILE *, int) asm("_final_end_function");


extern void final (rtx, FILE *, int, int) asm("_final");




extern rtx final_scan_insn (rtx, FILE *, int, int, int) asm("_final_scan_insn");



extern rtx alter_subreg (rtx) asm("_alter_subreg");



extern void output_operand_lossage (char *) asm("_output_operand_lossage");



extern void output_asm_insn (char *, rtx *) asm("_output_asm_insn");


extern void output_asm_label (rtx) asm("_output_asm_label");



extern void output_address (rtx) asm("_output_address");




extern void output_addr_const (FILE *, rtx) asm("_output_addr_const");



extern void asm_fprintf (FILE *file, char *p, ...) asm("_asm_fprintf")
                          ;



extern void split_double (rtx, rtx *, rtx *) asm("_split_double");


extern int leaf_function_p (void) asm("_leaf_function_p");



extern int only_leaf_regs_used (void) asm("_only_leaf_regs_used");



extern void leaf_renumber_regs_insn (rtx) asm("_leaf_renumber_regs_insn");





extern void text_section (void) asm("_text_section");


extern void data_section (void) asm("_data_section");



extern void readonly_data_section (void) asm("_readonly_data_section");


extern int in_text_section (void) asm("_in_text_section");





extern void named_section (tree, char *) asm("_named_section");


extern void function_section (tree) asm("_function_section");




extern void make_function_rtl (tree) asm("_make_function_rtl");
extern int decode_reg_name (char *) asm("_decode_reg_name");
extern void make_decl_rtl (tree, char *, int) asm("_make_decl_rtl");



extern void make_var_volatile (tree) asm("_make_var_volatile");


extern void assemble_constant_align (tree) asm("_assemble_constant_align");



extern void assemble_asm (tree) asm("_assemble_asm");







extern void assemble_destructor (char *) asm("_assemble_destructor");


extern void assemble_constructor (char *) asm("_assemble_constructor");



extern void assemble_gc_entry (char *) asm("_assemble_gc_entry");





extern void assemble_start_function (tree, char *) asm("_assemble_start_function");



extern void assemble_end_function (tree, char *) asm("_assemble_end_function");


extern void assemble_zeros (int) asm("_assemble_zeros");


extern void assemble_align (int) asm("_assemble_align");


extern void assemble_string (char *, int) asm("_assemble_string");
extern void assemble_variable (tree, int, int, int) asm("_assemble_variable");


extern void bc_output_constructor (tree, int) asm("_bc_output_constructor");


extern void bc_output_data_constructor (tree) asm("_bc_output_data_constructor");




extern void assemble_external (tree) asm("_assemble_external");




extern void assemble_external_libcall (rtx) asm("_assemble_external_libcall");



extern void assemble_global (char *) asm("_assemble_global");


extern void assemble_label (char *) asm("_assemble_label");






extern void assemble_name (FILE *, char *) asm("_assemble_name");







extern int assemble_integer (rtx, int, int) asm("_assemble_integer");
extern void clear_const_double_mem (void) asm("_clear_const_double_mem");


extern void defer_addressed_constants (void) asm("_defer_addressed_constants");



extern void output_deferred_addressed_constants (void) asm("_output_deferred_addressed_constants");


extern void init_const_rtx_hash_table (void) asm("_init_const_rtx_hash_table");


extern int get_pool_size (void) asm("_get_pool_size");



extern void output_constant_pool (char *, tree) asm("_output_constant_pool");







extern void output_constant (tree, int) asm("_output_constant");




extern int which_alternative;
extern rtx final_sequence;






extern int current_function_pops_args;




extern int current_function_returns_struct;




extern int current_function_returns_pcc_struct;



extern int current_function_needs_context;



extern int current_function_calls_setjmp;



extern int current_function_calls_longjmp;




extern int current_function_calls_alloca;




extern int current_function_has_nonlocal_label;



extern int current_function_contains_functions;



extern int current_function_returns_pointer;





extern int current_function_args_size;




extern int current_function_pretend_args_size;





extern int current_function_outgoing_args_size;




extern int current_function_varargs;




extern int current_function_stdarg;




extern CUMULATIVE_ARGS current_function_args_info;



extern char *current_function_name;






extern rtx current_function_return_rtx;




extern rtx current_function_epilogue_delay_list;





extern int flag_pic;


extern int current_function_uses_pic_offset_table;


extern int current_function_uses_const_pool;
extern FILE *asm_out_file;

extern tree get_file_function_name(...) asm("_get_file_function_name");
extern tree cleanups_this_call;
static void grok_function_init(...) asm("_grok_function_init");


tree pending_vtables;




tree pending_statics;



static tree saved_inlines;




int temp_name_counter;



static int global_temp_name_counter;



extern int spew_debug;



tree static_ctors, static_dtors;






int flag_cond_mismatch;



int flag_short_double;



int flag_no_asm;



int flag_no_gnu_keywords;



int flag_no_builtin;




int flag_no_nonansi_builtin;



int flag_traditional;



int flag_signed_bitfields = 1;



int flag_no_ident;




int flag_ansi;




int flag_implement_inlines = 1;




int flag_external_templates;





int flag_alt_external_templates;



int flag_implicit_templates = 1;



int warn_implicit = 1;




int warn_ctor_dtor_privacy = 1;




int flag_vtable_thunks;



int flag_use_repository;





int warn_write_strings;




int warn_cast_qual;




int warn_template_debugging;



int warn_traditional;




int warn_pointer_arith;




int warn_strict_prototypes;



int warn_missing_prototypes;




int warn_redundant_decls;



int warn_missing_braces;



int warn_format;



int warn_char_subscripts;



int warn_conversion;



int warn_parentheses;




int warn_overloaded_virtual;



int warn_nonvdtor;


int warn_extern_inline;


int warn_reorder;


int warn_synth;







int dollars_in_ident = 1;




int flag_strict_prototype = 2;
int strict_prototype = 1;
int strict_prototypes_lang_c, strict_prototypes_lang_cplusplus = 1;



int flag_labels_ok;



int flag_detailed_statistics;







int flag_all_virtual;





int flag_this_is_variable;



int flag_memoize_lookups; int flag_save_memoized_contexts;
int write_virtuals;



int flag_elide_constructors;




int flag_handle_exceptions;



int flag_handle_signatures;




int flag_default_inline = 1;




int flag_int_enum_equivalence;



int flag_cadillac;



int flag_gc;



int flag_rtti;



extern int flag_gnu_xref;
int flag_assume_nonnull_objects = 1;




int flag_huge_objects;






int flag_conserve_space;



int flag_access_control = 1;



int flag_operator_names;




int flag_check_new;
int flag_new_for_scope = 1;







static struct { char *string; int *variable; int on_value;} lang_f_options[] =
{
  {"signed-char", &flag_signed_char, 1},
  {"unsigned-char", &flag_signed_char, 0},
  {"signed-bitfields", &flag_signed_bitfields, 1},
  {"unsigned-bitfields", &flag_signed_bitfields, 0},
  {"short-enums", &flag_short_enums, 1},
  {"short-double", &flag_short_double, 1},
  {"cond-mismatch", &flag_cond_mismatch, 1},
  {"asm", &flag_no_asm, 0},
  {"builtin", &flag_no_builtin, 0},
  {"ident", &flag_no_ident, 0},
  {"labels-ok", &flag_labels_ok, 1},
  {"stats", &flag_detailed_statistics, 1},
  {"this-is-variable", &flag_this_is_variable, 1},
  {"strict-prototype", &flag_strict_prototype, 1},
  {"all-virtual", &flag_all_virtual, 1},
  {"memoize-lookups", &flag_memoize_lookups, 1},
  {"elide-constructors", &flag_elide_constructors, 1},
  {"handle-exceptions", &flag_handle_exceptions, 1},
  {"handle-signatures", &flag_handle_signatures, 1},
  {"default-inline", &flag_default_inline, 1},
  {"dollars-in-identifiers", &dollars_in_ident, 1},
  {"enum-int-equiv", &flag_int_enum_equivalence, 1},
  {"gc", &flag_gc, 1},
  {"rtti", &flag_rtti, 1},
  {"xref", &flag_gnu_xref, 1},
  {"nonnull-objects", &flag_assume_nonnull_objects, 1},
  {"implement-inlines", &flag_implement_inlines, 1},
  {"external-templates", &flag_external_templates, 1},
  {"implicit-templates", &flag_implicit_templates, 1},
  {"huge-objects", &flag_huge_objects, 1},
  {"conserve-space", &flag_conserve_space, 1},
  {"vtable-thunks", &flag_vtable_thunks, 1},
  {"short-temps", &flag_short_temps, 1},
  {"access-control", &flag_access_control, 1},
  {"nonansi-builtins", &flag_no_nonansi_builtin, 0},
  {"gnu-keywords", &flag_no_gnu_keywords, 0},
  {"operator-names", &flag_operator_names, 1},
  {"check-new", &flag_check_new, 1},
  {"repo", &flag_use_repository, 1},
  {"for-scope", &flag_new_for_scope, 2}
};





int
lang_decode_option(char *p) asm("_lang_decode_option");
int
lang_decode_option(char *p)
{
  if (!strcmp (p, "-ftraditional") || !strcmp (p, "-traditional"))
    flag_traditional = 1, dollars_in_ident = 1, flag_writable_strings = 1,
    flag_this_is_variable = 1, flag_new_for_scope = 0;


  else if (p[0] == '-' && p[1] == '+' && p[2] == 'e')
    {
      int old_write_virtuals = write_virtuals;
      if (p[3] == '1')
 write_virtuals = 1;
      else if (p[3] == '0')
 write_virtuals = -1;
      else if (p[3] == '2')
 write_virtuals = 2;
      else error ("invalid +e option");
      if (old_write_virtuals != 0
   && write_virtuals != old_write_virtuals)
 error ("conflicting +e options given");
    }
  else if (p[0] == '-' && p[1] == 'f')
    {



      int found = 0, j;

      p += 2;


      if (!strcmp (p, "save-memoized"))
 {
   flag_memoize_lookups = 1;
   flag_save_memoized_contexts = 1;
   found = 1;
 }
      if (!strcmp (p, "no-save-memoized"))
 {
   flag_memoize_lookups = 0;
   flag_save_memoized_contexts = 0;
   found = 1;
 }
      else if (! strncmp (p, "cadillac", 8))
 {
   flag_cadillac = atoi (p+9);
   found = 1;
 }
      else if (! strncmp (p, "no-cadillac", 11))
 {
   flag_cadillac = 0;
   found = 1;
 }
      else if (! strcmp (p, "gc"))
 {
   flag_gc = 1;

   flag_rtti = 1;
   found = 1;
 }
      else if (! strcmp (p, "no-gc"))
 {
   flag_gc = 0;

   flag_rtti = 0;
   found = 1;
 }
      else if (! strcmp (p, "alt-external-templates"))
 {
   flag_external_templates = 1;
   flag_alt_external_templates = 1;
   found = 1;
 }
      else if (! strcmp (p, "no-alt-external-templates"))
 {
   flag_alt_external_templates = 0;
   found = 1;
 }
      else if (!strcmp (p, "ansi-overloading"))
 {
   warning ("-fansi-overloading is no longer meaningful");
   found = 1;
 }
      else if (!strcmp (p, "repo"))
 {
   flag_use_repository = 1;
   flag_implicit_templates = 0;
   found = 1;
 }
      else for (j = 0;
  !found && j < sizeof (lang_f_options) / sizeof (lang_f_options[0]);
  j++)
 {
   if (!strcmp (p, lang_f_options[j].string))
     {
       *lang_f_options[j].variable = lang_f_options[j].on_value;


       found = 1;
     }
   if (p[0] == 'n' && p[1] == 'o' && p[2] == '-'
       && ! strcmp (p+3, lang_f_options[j].string))
     {
       *lang_f_options[j].variable = ! lang_f_options[j].on_value;
       found = 1;
     }
 }
      return found;
    }
  else if (p[0] == '-' && p[1] == 'W')
    {
      int setting = 1;


      p += 2;

      if (p[0] == 'n' && p[1] == 'o' && p[2] == '-')
 setting = 0, p += 3;

      if (!strcmp (p, "implicit"))
 warn_implicit = setting;
      else if (!strcmp (p, "return-type"))
 warn_return_type = setting;
      else if (!strcmp (p, "ctor-dtor-privacy"))
 warn_ctor_dtor_privacy = setting;
      else if (!strcmp (p, "write-strings"))
 warn_write_strings = setting;
      else if (!strcmp (p, "cast-qual"))
 warn_cast_qual = setting;
      else if (!strcmp (p, "traditional"))
 warn_traditional = setting;
      else if (!strcmp (p, "char-subscripts"))
 warn_char_subscripts = setting;
      else if (!strcmp (p, "pointer-arith"))
 warn_pointer_arith = setting;
      else if (!strcmp (p, "strict-prototypes"))
 warn_strict_prototypes = setting;
      else if (!strcmp (p, "missing-prototypes"))
 warn_missing_prototypes = setting;
      else if (!strcmp (p, "redundant-decls"))
 warn_redundant_decls = setting;
      else if (!strcmp (p, "missing-braces"))
 warn_missing_braces = setting;
      else if (!strcmp (p, "format"))
 warn_format = setting;
      else if (!strcmp (p, "conversion"))
 warn_conversion = setting;
      else if (!strcmp (p, "parentheses"))
 warn_parentheses = setting;
      else if (!strcmp (p, "non-virtual-dtor"))
 warn_nonvdtor = setting;
      else if (!strcmp (p, "extern-inline"))
 warn_extern_inline = setting;
      else if (!strcmp (p, "reorder"))
 warn_reorder = setting;
      else if (!strcmp (p, "synth"))
 warn_synth = setting;
      else if (!strcmp (p, "comment"))
 ;
      else if (!strcmp (p, "comments"))
 ;
      else if (!strcmp (p, "trigraphs"))
 ;
      else if (!strcmp (p, "import"))
 ;
      else if (!strcmp (p, "all"))
 {
   extra_warnings = setting;
   warn_return_type = setting;
   warn_unused = setting;
   warn_implicit = setting;
   warn_ctor_dtor_privacy = setting;
   warn_switch = setting;
   warn_format = setting;
   warn_parentheses = setting;
   warn_missing_braces = setting;
   warn_extern_inline = setting;
   warn_nonvdtor = setting;



   if (warn_uninitialized != 1)
     warn_uninitialized = (setting ? 2 : 0);
   warn_template_debugging = setting;
   warn_reorder = setting;
 }

      else if (!strcmp (p, "overloaded-virtual"))
 warn_overloaded_virtual = setting;
      else return 0;
    }
  else if (!strcmp (p, "-ansi"))
    dollars_in_ident = 0, flag_no_nonansi_builtin = 1, flag_ansi = 1,
    flag_no_gnu_keywords = 1, flag_operator_names = 1;







  else
    return 0;

  return 1;
}




tree
grok_method_quals(tree ctype, tree function, tree quals) asm("_grok_method_quals");
tree
grok_method_quals(tree ctype, tree function, tree quals)
{
  tree fntype = ((function)->common.type);
  tree raises = ((fntype)->type.noncopied_parts);

  do
    {
      extern tree ridpointers[];

      if (((quals)->list.value) == ridpointers[(int)RID_CONST])
 {
   if (((ctype)->common.readonly_flag))
     error ("duplicate `%s' %s",
     ((((quals)->list.value))->identifier.pointer),
     (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL
      ? "for member function" : "in type declaration"));
   ctype = build_type_variant (ctype, 1, ((ctype)->common.volatile_flag));
   build_pointer_type (ctype);
 }
      else if (((quals)->list.value) == ridpointers[(int)RID_VOLATILE])
 {
   if (((ctype)->common.volatile_flag))
     error ("duplicate `%s' %s",
     ((((quals)->list.value))->identifier.pointer),
     (((n64_enum_tree_code) (function)->common.code) == FUNCTION_DECL
      ? "for member function" : "in type declaration"));
   ctype = build_type_variant (ctype, ((ctype)->common.readonly_flag), 1);
   build_pointer_type (ctype);
 }
      else
 my_friendly_abort (20);
      quals = ((quals)->common.chain);
    }
  while (quals);
  fntype = build_cplus_method_type (ctype, ((fntype)->common.type),
        (((n64_enum_tree_code) (fntype)->common.code) == METHOD_TYPE
         ? ((((fntype)->type.values))->common.chain)
         : ((fntype)->type.values)));
  if (raises)
    fntype = build_exception_variant (fntype, raises);

  ((function)->common.type) = fntype;
  return ctype;
}
void
warn_if_unknown_interface(tree decl) asm("_warn_if_unknown_interface");
void
warn_if_unknown_interface(tree decl)
{
  static int already_warned = 0;
  if (already_warned++)
    return;

  if (flag_alt_external_templates)
    {
      struct n64_tag_tinst_level *til = tinst_for_decl ();
      int sl = lineno;
      char *sf = input_filename;

      if (til)
 {
   lineno = til->line;
   input_filename = til->file;
 }
      cp_warning ("template `%#D' instantiated in file without #pragma interface",
    decl);
      lineno = sl;
      input_filename = sf;
    }
  else
    cp_warning_at ("template `%#D' defined in file without #pragma interface",
     decl);
}


tree
grok_x_components(tree specs, tree components) asm("_grok_x_components");
tree
grok_x_components(tree specs, tree components)
{
  register tree t, x, tcode;


  if (components == void_type_node)
    return (tree) 
          ((void *)0)
                   ;

  if (components == (tree) 
                   ((void *)0)
                            )
    {
      t = groktypename (build_decl_list (specs, (tree) 
                                               ((void *)0)
                                                        ));

      if (t == (tree) 
              ((void *)0)
                       )
 {
   error ("error in component specification");
   return (tree) 
         ((void *)0)
                  ;
 }

      switch (((n64_enum_tree_code) (t)->common.code))
 {
 case VAR_DECL:

   if (((n64_enum_tree_code) (((t)->common.type))->common.code) == UNION_TYPE
       && ((((((((((t)->common.type))->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((((t)->common.type))->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
     return t;




   return specs;
   break;

 case RECORD_TYPE:


   tcode = record_type_node;
   if ((((t)->type.lang_specific)->type_flags.declared_class))
     tcode = class_type_node;
   else if ((((t)->type.lang_specific)?((t)->type.lang_specific)->type_flags.is_signature:0))
     tcode = signature_type_node;

   t = xref_tag (tcode, (((((t)->type.name))->decl.name)), (tree) 
                                            ((void *)0)
                                                     , 0);
   if (((t)->type.context))
     (((t)->type.lang_specific)->type_flags.no_globalize) = 1;
   return (tree) 
         ((void *)0)
                  ;
   break;

 case UNION_TYPE:
 case ENUMERAL_TYPE:
   if (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE)
     tcode = union_type_node;
   else
     tcode = enum_type_node;

   t = xref_tag (tcode, (((((t)->type.name))->decl.name)), (tree) 
                                            ((void *)0)
                                                     , 0);
   if (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE && ((t)->type.context))
     (((t)->type.lang_specific)->type_flags.no_globalize) = 1;
   if (((n64_enum_tree_code) (t)->common.code) == UNION_TYPE
       && ((((((((t)->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((t)->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
     {
       struct n64_tag_pending_inline **p;
       x = build_lang_field_decl (FIELD_DECL, (tree) 
                                             ((void *)0)
                                                      , t);


       (((t)->type.lang_flag_1)) = 0;
       (((t)->type.lang_specific)->type_flags.has_default_ctor) = 0;
       (((t)->type.lang_specific)->type_flags.has_init_ref) = 0;
       (((t)->type.lang_specific)->type_flags.has_const_init_ref) = 0;
       (((t)->type.lang_specific)->type_flags.has_assign_ref) = 0;
       (((t)->type.lang_specific)->type_flags.has_assignment) = 0;
       (((t)->type.lang_specific)->type_flags.has_const_assign_ref) = 0;

       p = &pending_inlines;
       for (; *p; *p = (*p)->next)
  if ((((*p)->fndecl)->decl.context) != t)
    break;
     }
   else if (((n64_enum_tree_code) (t)->common.code) == ENUMERAL_TYPE)
     x = grok_enum_decls (t, (tree) 
                            ((void *)0)
                                     );
   else
     x = (tree) 
        ((void *)0)
                 ;
   return x;
   break;

 default:
   if (t != void_type_node)
     error ("empty component declaration");
   return (tree) 
         ((void *)0)
                  ;
 }
    }
  else
    {
      t = ((components)->common.type);
      if (((n64_enum_tree_code) (t)->common.code) == ENUMERAL_TYPE && (((t)->common.lang_flag_0)))
 return grok_enum_decls (t, components);
      else
 return components;
    }
}
void
grokclassfn(tree ctype, tree cname, tree function, n64_enum_overload_flags flags, tree quals) asm("_grokclassfn");
void
grokclassfn(tree ctype, tree cname, tree function, n64_enum_overload_flags flags, tree quals)
{
  tree fn_name = ((function)->decl.name);
  tree arg_types;
  tree parm;
  tree qualtype;
  tree fntype = ((function)->common.type);
  tree raises = ((fntype)->type.noncopied_parts);

  if (fn_name == (tree) 
                ((void *)0)
                         )
    {
      error ("name missing for member function");
      fn_name = get_identifier ("<anonymous>");
      ((function)->decl.name) = fn_name;
    }

  if (quals)
    qualtype = grok_method_quals (ctype, function, quals);
  else
    qualtype = ctype;

  arg_types = ((((function)->common.type))->type.values);
  if (((n64_enum_tree_code) (((function)->common.type))->common.code) == METHOD_TYPE)
    {



      tree type = ((arg_types)->list.value);
      int constp = 1;

      if ((flag_this_is_variable > 0)
   && (flags == DTOR_FLAG || (((function)->decl.lang_specific)->decl_flags.constructor_attr)))
 constp = 0;

      if ((((function)->decl.lang_specific)->decl_flags.constructor_attr))
 {
   if ((((ctype)->common.lang_flag_3)))
     {
       (((function)->decl.lang_specific)->decl_flags.constructor_for_vbase_attr) = 1;



       parm = build_decl (PARM_DECL, in_charge_identifier, integer_type_node);

       (((parm)->decl.artificial_flag) = 1);
       ((parm)->decl.initial) = integer_type_node;
       ((parm)->decl.regdecl_flag) = 1;
       ((parm)->common.chain) = last_function_parms;
       last_function_parms = parm;
     }
 }

      parm = build_decl (PARM_DECL, this_identifier, type);

      (((parm)->decl.artificial_flag) = 1);
      ((parm)->decl.initial) = type;


      ((parm)->decl.regdecl_flag) = 1;
      if (constp)
 ((parm)->common.readonly_flag) = 1;
      ((parm)->common.chain) = last_function_parms;
      last_function_parms = parm;
    }

  if (flags == DTOR_FLAG)
    {
      char *buf, *dbuf;
      tree const_integer_type = build_type_variant (integer_type_node, 1, 0);
      int len = sizeof ("_._")-1;

      arg_types = hash_tree_chain (const_integer_type, void_list_node);
      ((arg_types)->common.side_effects_flag) = 1;

      if ((((cname)->common.type)))
 dbuf = build_overload_name ((((cname)->common.type)), 1, 1);
      else if ((((struct n64_tag_lang_identifier *)(cname))->local_value))
 dbuf = build_overload_name ((((((struct n64_tag_lang_identifier *)(cname))->local_value))->common.type), 1, 1);
      else



 dbuf = build_overload_name (ctype, 1, 1);
      buf = (char *) 
                    __builtin_alloca((
                    strlen (dbuf) + sizeof ("_._")
                    ))
                                                                            ;
      memcpy (buf,"_._",len);
      buf[len] = '\0';
      strcat (buf, dbuf);
      ((function)->decl.assembler_name) = get_identifier (buf);
      parm = build_decl (PARM_DECL, in_charge_identifier, const_integer_type);

      (((parm)->decl.artificial_flag) = 1);
      ((parm)->common.used_flag) = 1;







      ((parm)->decl.initial) = const_integer_type;

      ((last_function_parms)->common.chain) = parm;

      fntype = build_cplus_method_type (qualtype, void_type_node,
     arg_types);
      if (raises)
 {
   fntype = build_exception_variant (fntype, raises);
 }
      ((function)->common.type) = fntype;
      (((ctype)->type.lang_flag_2)) = 1;
    }
  else
    {
      tree these_arg_types;

      if ((((function)->decl.lang_specific)->decl_flags.constructor_for_vbase_attr))
 {
   arg_types = hash_tree_chain (integer_type_node,
           ((arg_types)->common.chain));
   fntype = build_cplus_method_type (qualtype,
         ((((function)->common.type))->common.type),
         arg_types);
   if (raises)
     {
       fntype = build_exception_variant (fntype, raises);
     }
   ((function)->common.type) = fntype;
   arg_types = ((((function)->common.type))->type.values);
 }

      these_arg_types = arg_types;

      if (((n64_enum_tree_code) (((function)->common.type))->common.code) == FUNCTION_TYPE)

 these_arg_types = hash_tree_chain (build_pointer_type (qualtype),
        arg_types);

      ((function)->decl.assembler_name)
 = build_decl_overload (fn_name, these_arg_types,
          1 + (((function)->decl.lang_specific)->decl_flags.constructor_attr));
    }

  ((function)->decl.arguments) = last_function_parms;

  ((function)->decl.context) = ctype;
  (((function)->decl.lang_specific)->decl_flags.context) = ctype;
}


tree
grok_alignof(tree expr) asm("_grok_alignof");
tree
grok_alignof(tree expr)
{
  tree best, t;
  int bestalign;

  if (((n64_enum_tree_code) (expr)->common.code) == COMPONENT_REF
      && ((((expr)->exp.operands[1]))->decl.bit_field_flag))
    error ("`__alignof__' applied to a bit-field");

  if (((n64_enum_tree_code) (expr)->common.code) == INDIRECT_REF)
    {
      best = t = ((expr)->exp.operands[0]);
      bestalign = ((((((t)->common.type))->common.type))->type.align);

      while (((n64_enum_tree_code) (t)->common.code) == NOP_EXPR
      && ((n64_enum_tree_code) (((((t)->exp.operands[0]))->common.type))->common.code) == POINTER_TYPE)
 {
   int thisalign;
   t = ((t)->exp.operands[0]);
   thisalign = ((((((t)->common.type))->common.type))->type.align);
   if (thisalign > bestalign)
     best = t, bestalign = thisalign;
 }
      return c_alignof (((((best)->common.type))->common.type));
    }
  else
    {




      if (((n64_enum_tree_code) (expr)->common.code) == COMPOUND_EXPR
   && (((n64_enum_tree_code) (((expr)->common.type))->common.code) == ARRAY_TYPE
       || ((n64_enum_tree_code) (((expr)->common.type))->common.code) == FUNCTION_TYPE))
 expr = default_conversion (expr);
      return c_alignof (((expr)->common.type));
    }
}



tree
grok_array_decl(tree array_expr, tree index_exp) asm("_grok_array_decl");
tree
grok_array_decl(tree array_expr, tree index_exp)
{
  tree type = ((array_expr)->common.type);
  tree p1, p2, i1, i2;

  if (type == error_mark_node || index_exp == error_mark_node)
    return error_mark_node;
  if (type == (tree) 
             ((void *)0)
                      )
    {


      error ("parser may be lost: is there a '{' missing somewhere?");
      return (tree) 
            ((void *)0)
                     ;
    }

  if (((n64_enum_tree_code) (type)->common.code) == OFFSET_TYPE
      || ((n64_enum_tree_code) (type)->common.code) == REFERENCE_TYPE)
    type = ((type)->common.type);


  if (((type)->type.lang_specific)
      && (((type)->type.lang_specific)->type_flags.has_array_ref_overloaded))
    return build_opfncall (ARRAY_REF, (3),
      array_expr, index_exp, (tree) 
                            ((void *)0)
                                     );



  if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
    p1 = array_expr;
  else
    p1 = build_expr_type_conversion (8, array_expr, 0);

  if (((n64_enum_tree_code) (((index_exp)->common.type))->common.code) == ARRAY_TYPE)
    p2 = index_exp;
  else
    p2 = build_expr_type_conversion (8, index_exp, 0);

  i1 = build_expr_type_conversion (1 | 4, array_expr, 0);
  i2 = build_expr_type_conversion (1 | 4, index_exp, 0);

  if ((p1 && i2) && (i1 && p2))
    error ("ambiguous conversion for array subscript");

  if (p1 && i2)
    array_expr = p1, index_exp = i2;
  else if (i1 && p2)
    array_expr = p2, index_exp = i1;
  else
    {
      cp_error ("invalid types `%T[%T]' for array subscript",
  type, ((index_exp)->common.type));
      return error_mark_node;
    }

  if (array_expr == error_mark_node || index_exp == error_mark_node)
    error ("ambiguous conversion for array subscript");

  return build_array_ref (array_expr, index_exp);
}
tree
delete_sanity(tree exp, tree size, int doing_vec, int use_global_delete) asm("_delete_sanity");
tree
delete_sanity(tree exp, tree size, int doing_vec, int use_global_delete)
{
  tree t = stabilize_reference (convert_from_reference (exp));
  tree type = ((t)->common.type);
  n64_enum_tree_code code = ((n64_enum_tree_code) (type)->common.code);


  tree maxindex = (tree) 
                 ((void *)0)
                          ;

  tree elt_size;

  switch (doing_vec)
    {
    case 2:
      maxindex = build_binary_op (MINUS_EXPR, size, integer_one_node, 1);
      if (! flag_traditional)
 pedwarn ("anachronistic use of array size in vector delete");

    case 1:
      elt_size = c_sizeof (type);
      break;
    default:
      if (code != POINTER_TYPE)
 {
   cp_error ("type `%#T' argument given to `delete', expected pointer",
      type);
   return error_mark_node;
 }


      if (integer_zerop (t))
 return build1 (NOP_EXPR, void_type_node, t);
    }

  if (code == POINTER_TYPE)
    {
      if (((n64_enum_tree_code) (((type)->common.type))->common.code) == FUNCTION_TYPE)
 {
   error ("cannot delete a function");
   return error_mark_node;
 }
    }
  if (doing_vec)
    return build_vec_delete (t, maxindex, elt_size, integer_one_node,
        integer_two_node, use_global_delete);
  else
    {
      if ((((((type)->common.type))->type.lang_flag_5))
   && ((((((type)->common.type))->type.lang_specific)->type_flags.gets_delete) & 1))
 {


   tree tmp = build_opfncall (DELETE_EXPR, (3), t,
         size_zero_node, (tree) 
                        ((void *)0)
                                 );
   if (tmp == error_mark_node)
     return error_mark_node;
 }

      return build_delete (type, t, integer_three_node,
      (3)|(32),
      use_global_delete);
    }
}





tree
check_classfn(tree ctype, tree cname, tree function) asm("_check_classfn");
tree
check_classfn(tree ctype, tree cname, tree function)
{
  tree fn_name = ((function)->decl.name);
  tree fndecl;
  tree method_vec = ((ctype)->type.maxval);
  tree *methods = 0;
  tree *end = 0;

  if (method_vec != 0)
    {
      methods = &((method_vec)->vec.a[0]);
      end = (&((method_vec)->vec.a[(method_vec)->vec.length]));


      if (*methods && fn_name == ((*methods)->decl.name))
 goto got_it;

      while (++methods != end)
 {
   if (fn_name == ((*methods)->decl.name))
     {
     got_it:
       fndecl = *methods;
       while (fndecl)
  {
    if (((function)->decl.assembler_name) == ((fndecl)->decl.assembler_name))
      return fndecl;
    if (((function)->decl.name) == ((fndecl)->decl.name))
      {
        tree p1 = ((((function)->common.type))->type.values);
        tree p2 = ((((fndecl)->common.type))->type.values);



        if ((((fndecl)->decl.lang_specific)->decl_flags.static_function)
     && ((n64_enum_tree_code) (((function)->common.type))->common.code) == METHOD_TYPE)
   p1 = ((p1)->common.chain);

        if (comptypes (((((function)->common.type))->common.type),
         ((((fndecl)->common.type))->common.type), 1)
     && compparms (p1, p2, 3))
   {
     if ((((fndecl)->decl.lang_specific)->decl_flags.static_function)
         && ((n64_enum_tree_code) (((function)->common.type))->common.code) == METHOD_TYPE)
       revert_static_member_fn (&function, 
                                          ((void *)0)
                                              , 
                                                ((void *)0)
                                                    );
     return fndecl;
   }
      }

    fndecl = (((fndecl)->decl.lang_specific)->chain);
  }
       break;
     }
 }
    }

  if (methods != end)
    {
      tree fndecl = *methods;
      cp_error ("prototype for `%#D' does not match any in class `%T'",
  function, ctype);
      cp_error_at ("candidate%s: %+#D", (((fndecl)->decl.lang_specific)->chain) ? "s are" : " is",
     fndecl);
      while (fndecl = (((fndecl)->decl.lang_specific)->chain), fndecl)
 cp_error_at ("                %#D", fndecl);
    }
  else
    {
      methods = 0;
      cp_error ("no `%#D' member function declared in class `%T'",
  function, ctype);
    }



  add_method (ctype, methods, function);
  return (tree) 
        ((void *)0)
                 ;
}
tree
grokfield(tree declarator, tree declspecs, tree raises, tree init, tree asmspec_tree, tree attrlist) asm("_grokfield");
tree
grokfield(tree declarator, tree declspecs, tree raises, tree init, tree asmspec_tree, tree attrlist)
{
  register tree value;
  char *asmspec = 0;
  int flags = (128);


  if (init == (tree) 
             ((void *)0) 
                       && declarator != (tree) 
                                        ((void *)0)
      
     && ((n64_enum_tree_code) (declarator)->common.code) == CALL_EXPR
      && ((declarator)->exp.operands[0])
      && (((n64_enum_tree_code) (((declarator)->exp.operands[0]))->common.code) == IDENTIFIER_NODE
   || ((n64_enum_tree_code) (((declarator)->exp.operands[0]))->common.code) == SCOPE_REF)
      && parmlist_is_exprlist (((declarator)->exp.operands[1])))
    {
      init = ((declarator)->exp.operands[1]);
      declarator = ((declarator)->exp.operands[0]);
      flags = 0;
    }

  if (init
      && ((n64_enum_tree_code) (init)->common.code) == TREE_LIST
      && ((init)->list.value) == error_mark_node
      && ((init)->common.chain) == (tree) 
                             ((void *)0)
                                      )
 init = (tree) 
       ((void *)0)
                ;

  value = grokdeclarator (declarator, declspecs, FIELD, init != 0,
     raises, attrlist);
  if (! value)
    return value;


  if (((n64_enum_tree_code) (value)->common.code) == VOID_TYPE)
    return void_type_node;

  if (((value)->decl.name) != (tree) 
                          ((void *)0)
      
     && ((((value)->decl.name))->identifier.pointer)[0] == '_'
      && ! strcmp (((((value)->decl.name))->identifier.pointer), "_vptr"))
    cp_error ("member `%D' conflicts with virtual function table field name", value);


  if (((n64_enum_tree_code) (value)->common.code) == TYPE_DECL)
    {
      ((value)->decl.nonlocal_flag) = 1;
      ((value)->decl.context) = current_class_type;
      (((value)->decl.lang_specific)->decl_flags.context) = current_class_type;
      (((current_class_type)->type.lang_specific)->type_flags.local_typedecls) = 1;



      if (((((value)->common.type))->type.name)
   && ((n64_enum_tree_code) (((((value)->common.type))->type.name))->common.code) == TYPE_DECL
   && ((((((((((value)->common.type))->type.name))->decl.name)))->identifier.pointer)[0] == '.' && (((((((((value)->common.type))->type.name))->decl.name)))->identifier.pointer)[1] == '_'))
 {
   ((((value)->common.type))->type.name) = value;
   (((((value)->common.type))->common.chain)) = value;
 }

      pushdecl_class_level (value);
      return value;
    }

  if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
      && ((n64_enum_tree_code) (value)->common.code) != FUNCTION_DECL)
    {
      error ("field declaration not allowed in signature");
      return void_type_node;
    }

  if ((((value)->decl.lang_flag_3)))
    {
      cp_error ("`%D' is already defined in the class %T", value,
    ((value)->decl.context));
      return void_type_node;
    }

  if (flag_cadillac)
    cadillac_start_decl (value);

  if (asmspec_tree)
    asmspec = ((asmspec_tree)->string.pointer);

  if (init)
    {
      if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0)
   && ((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL)
 {
   error ("function declarations cannot have initializers in signature");
   init = (tree) 
         ((void *)0)
                  ;
 }
      else if (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL)
 {
   grok_function_init (value, init);
   init = (tree) 
         ((void *)0)
                  ;
 }
      else if (pedantic && ((n64_enum_tree_code) (value)->common.code) != VAR_DECL)

 init = (tree) 
       ((void *)0)
                ;
      else
 {


   if (((n64_enum_tree_code) (init)->common.code) == TREE_LIST)
     {
       if (((init)->common.chain) == (tree) 
                               ((void *)0)
                                        )
  init = ((init)->list.value);
       else
  init = digest_init (((value)->common.type), init, (tree *)0);
     }

   if (((n64_enum_tree_code) (init)->common.code) == CONST_DECL)
     init = ((init)->decl.initial);
   else if ((((init)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (init)->common.code))]) == 'd'))
     init = decl_constant_value (init);
   else if (((n64_enum_tree_code) (init)->common.code) == CONSTRUCTOR)
     init = digest_init (((value)->common.type), init, (tree *)0);
   my_friendly_assert (((init)->common.permanent_flag), 192);
   if (init == error_mark_node)



     init = build1 (NOP_EXPR, ((value)->common.type), init);
   else if (! ((init)->common.constant_flag))
     {


       if (((n64_enum_tree_code) (((value)->common.type))->common.code) != REFERENCE_TYPE
    || (((init)->common.static_flag) == 0
        && ((*tree_code_type[(int) (((n64_enum_tree_code) (init)->common.code))]) != 'd'
     || ((init)->decl.external_flag) == 0)))
  {
    error ("field initializer is not constant");
    init = error_mark_node;
  }
     }
 }
    }


  push_obstacks_nochange ();

  if (((n64_enum_tree_code) (value)->common.code) == VAR_DECL)
    {




      if (((value)->common.public_flag))
 {

   if (asmspec == 0 && current_class_type)
     {
       ((value)->common.public_flag) = 1;
       ((value)->decl.initial) = error_mark_node;
       ((value)->decl.assembler_name)
  = build_static_name (current_class_type, ((value)->decl.name));
     }
   pending_statics = perm_tree_cons ((tree) 
                                    ((void *)0)
                                             , value, pending_statics);


   if (init != (tree) 
              ((void *)0) 
                        && ((((value)->common.type))->type.needs_constructing_flag))
     {
       static int explanation = 0;

       error ("initializer invalid for static member with constructor");
       if (explanation++ == 0)
  error ("(you really want to initialize it separately)");
       init = 0;
     }


   if (((value)->common.readonly_flag) && init == 0)
     ((value)->common.used_flag) = 1;
 }
      ((value)->decl.initial) = init;
      (((value)->decl.lang_flag_3)) = 1;

      cp_finish_decl (value, init, asmspec_tree, 1, flags);
      pushdecl_class_level (value);
      return value;
    }
  if (((n64_enum_tree_code) (value)->common.code) == FIELD_DECL)
    {
      if (asmspec)
 {


   ((value)->decl.rtl) = (rtx) 0;
   ((value)->decl.assembler_name) = get_identifier (asmspec);
 }
      if (((value)->decl.initial) == error_mark_node)
 init = error_mark_node;
      cp_finish_decl (value, init, asmspec_tree, 1, flags);
      ((value)->decl.initial) = init;
      (((value)->decl.lang_flag_3)) = 1;
      return value;
    }
  if (((n64_enum_tree_code) (value)->common.code) == FUNCTION_DECL)
    {
      check_default_args (value);
      if ((((value)->decl.lang_specific)->chain) != (tree) 
                               ((void *)0)
                                        )
 {


   value = copy_node (value);

   my_friendly_assert (init == (tree) 
                              ((void *)0)
                                       , 193);
 }
      if (asmspec)
 {


   ((value)->decl.rtl) = (rtx) 0;
   ((value)->decl.assembler_name) = get_identifier (asmspec);
 }
      cp_finish_decl (value, init, asmspec_tree, 1, flags);


      if ((((value)->decl.lang_specific)->decl_flags.friend_attr))
 return void_type_node;







      (((value)->decl.lang_flag_3)) = 1;
      return value;
    }
  my_friendly_abort (21);

  return (tree) 
        ((void *)0)
                 ;
}




tree
grokbitfield(tree declarator, tree declspecs, tree width) asm("_grokbitfield");
tree
grokbitfield(tree declarator, tree declspecs, tree width)
{
  register tree value = grokdeclarator (declarator, declspecs, BITFIELD,
     0, (tree) 
       ((void *)0)
                , (tree) 
                  ((void *)0)
                           );

  if (! value) return (tree) 
                     ((void *)0)
                              ;


  if (((n64_enum_tree_code) (value)->common.code) == VOID_TYPE)
    return void_type_node;

  if (((n64_enum_tree_code) (value)->common.code) == TYPE_DECL)
    {
      cp_error ("cannot declare `%D' to be a bitfield type", value);
      return (tree) 
            ((void *)0)
                     ;
    }

  if ((((current_class_type)->type.lang_specific)?((current_class_type)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("field declaration not allowed in signature");
      return void_type_node;
    }

  if ((((value)->decl.lang_flag_3)))
    {
      cp_error ("`%D' is already defined in the class %T", value,
    ((value)->decl.context));
      return void_type_node;
    }

  GNU_xref_member (current_class_name, value);

  if (((value)->common.static_flag))
    {
      cp_error ("static member `%D' cannot be a bitfield", value);
      return (tree) 
            ((void *)0)
                     ;
    }
  cp_finish_decl (value, (tree) 
                        ((void *)0)
                                 , (tree) 
                                   ((void *)0)
                                            , 0, 0);

  if (width != error_mark_node)
    {

      if (((n64_enum_tree_code) (width)->common.code) == CONST_DECL)
 width = ((width)->decl.initial);
      else if ((((width)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (width)->common.code))]) == 'd'))
 width = decl_constant_value (width);
      if (((n64_enum_tree_code) (width)->common.code) != INTEGER_CST)
 {
   cp_error ("structure field `%D' width not an integer constant",
        value);
   ((value)->decl.initial) = (tree) 
                         ((void *)0)
                                  ;
 }
      else
 {
   constant_expression_warning (width);
   ((value)->decl.initial) = width;
   ((value)->decl.bit_field_flag) = 1;
 }
    }

  (((value)->decl.lang_flag_3)) = 1;
  return value;
}
tree
grokoptypename(tree declspecs, tree declarator) asm("_grokoptypename");
tree
grokoptypename(tree declspecs, tree declarator)
{
  tree t = grokdeclarator (declarator, declspecs, TYPENAME, 0,
      (tree) 
     ((void *)0)
              , (tree) 
                ((void *)0)
                         );
  return build_typename_overload (t);
}
int
copy_assignment_arg_p(tree parmtype, int virtualp) asm("_copy_assignment_arg_p");
int
copy_assignment_arg_p(tree parmtype, int virtualp)
{
  if (((n64_enum_tree_code) (parmtype)->common.code) == REFERENCE_TYPE)
    parmtype = ((parmtype)->common.type);

  if ((((parmtype)->type.main_variant) == current_class_type)
      || (virtualp && (get_base_distance (parmtype, current_class_type, 0, (tree *)0) != -1)))
    return 1;

  return 0;
}

static void
grok_function_init(tree decl, tree init) asm("_grok_function_init");
static void
grok_function_init(tree decl, tree init)
{


  tree type = ((decl)->common.type);

  if (((n64_enum_tree_code) (type)->common.code) == FUNCTION_TYPE)
    cp_error ("initializer specified for non-member function `%D'", decl);
  else if (((decl)->decl.vindex) == (tree) 
                                ((void *)0)
                                         )
    cp_error ("initializer specified for non-virtual method `%D'", decl);
  else if (integer_zerop (init))
    {
      (((decl)->decl.lang_specific)->decl_flags.abstract_virtual) = 1;
      if (((decl)->decl.name) == ansi_opname [(int) MODIFY_EXPR])
 {
   tree parmtype
     = ((((((((decl)->common.type))->type.values))->common.chain))->list.value);

   if (copy_assignment_arg_p (parmtype, 1))
     (((current_class_type)->type.lang_specific)->type_flags.has_abstract_assign_ref) = 1;
 }
    }
  else if (((n64_enum_tree_code) (init)->common.code) == CP_OFFSET_REF
    && ((init)->exp.operands[0]) == (tree) 
                                ((void *)0)
    
   && ((n64_enum_tree_code) (((init)->common.type))->common.code) == METHOD_TYPE)
    {
      tree basetype = (((init)->decl.lang_specific)->decl_flags.context);
      tree basefn = ((init)->exp.operands[1]);
      if (((n64_enum_tree_code) (basefn)->common.code) != FUNCTION_DECL)
 cp_error ("non-method initializer invalid for method `%D'", decl);
      else if (! (((((((((basefn)->decl.lang_specific)->decl_flags.context))->type.binfo)))->vec.a[1]) == integer_zero_node))
 sorry ("base member function from other than first base class");
      else
 {
   tree binfo = get_binfo (basetype, ((type)->type.maxval), 1);
   if (binfo == error_mark_node)
     ;
   else if (binfo == 0)
     error_not_base_type (((((init)->common.type))->type.maxval),
     ((type)->type.maxval));
   else
     {


       ((decl)->decl.initial) = error_mark_node;
       ((decl)->decl.rtl) = ((basefn)->decl.rtl);
     }
 }
    }
  else
    cp_error ("invalid initializer for virtual method `%D'", decl);
}
tree
build_push_scope(tree cname, tree name) asm("_build_push_scope");
tree
build_push_scope(tree cname, tree name)
{
  extern int current_class_depth;
  tree ctype, rval;
  int is_ttp = 0;

  if (cname == error_mark_node)
    return error_mark_node;

  ctype = (((cname)->common.type));

  if (((n64_enum_tree_code) (ctype)->common.code) == TEMPLATE_TYPE_PARM)
    is_ttp = 1;
  else if (ctype == (tree) 
                   ((void *)0) 
                             || ! (((ctype)->type.lang_flag_5)))
    {
      cp_error ("`%T' not defined as aggregate type", cname);
      return name;
    }
  else if ((((ctype)->type.lang_specific)?((ctype)->type.lang_specific)->type_flags.is_signature:0))
    {
      error ("cannot push into signature scope, scope resolution operator ignored");
      return name;
    }

  rval = build_parse_node (SCOPE_REF, cname, name);




  if (ctype == current_class_type || ((n64_enum_tree_code) (name)->common.code) != IDENTIFIER_NODE
      || is_ttp)
    return rval;




  push_nested_class (ctype, 3);
  ((rval)->exp.complexity) = current_class_depth;
  return rval;
}

void
cplus_decl_attributes(tree decl, tree attributes, tree prefix_attributes) asm("_cplus_decl_attributes");
void
cplus_decl_attributes(tree decl, tree attributes, tree prefix_attributes)
{
  if (decl == (tree) 
             ((void *)0) 
                       || decl == void_type_node)
    return;

  if (((n64_enum_tree_code) (decl)->common.code) == TEMPLATE_DECL)
    decl = ((decl)->decl.result);

  decl_attributes (decl, attributes, prefix_attributes);

  if (((n64_enum_tree_code) (decl)->common.code) == TYPE_DECL)
    (((((decl)->decl.name))->common.type) = ((decl)->common.type));
}






tree
constructor_name_full(tree thing) asm("_constructor_name_full");
tree
constructor_name_full(tree thing)
{
  if (((n64_enum_tree_code) (thing)->common.code) == UNINSTANTIATED_P_TYPE)
    return ((((((thing)->type.values))->list.purpose))->decl.name);
  if ((((n64_enum_tree_code) (thing)->common.code) == RECORD_TYPE || ((n64_enum_tree_code) (thing)->common.code) == UNION_TYPE || ((n64_enum_tree_code) (thing)->common.code) == UNINSTANTIATED_P_TYPE))
    {
      if ((((thing)->type.lang_specific)->type_flags.was_anonymous) && (((thing)->type.lang_flag_1)))
 thing = ((((((thing)->type.maxval))->vec.a[0]))->decl.name);
      else
 thing = ((thing)->type.name);
    }
  if (((n64_enum_tree_code) (thing)->common.code) == TYPE_DECL
      || (((n64_enum_tree_code) (thing)->common.code) == TEMPLATE_DECL
   && (((thing)->decl.result) == (tree) 
     ((void *)0)
     )))
    thing = ((thing)->decl.name);
  my_friendly_assert (((n64_enum_tree_code) (thing)->common.code) == IDENTIFIER_NODE, 197);
  return thing;
}






tree
constructor_name(tree thing) asm("_constructor_name");
tree
constructor_name(tree thing)
{
  tree t;
  thing = constructor_name_full (thing);
  t = (((struct n64_tag_lang_identifier *)(thing))->class_template_info);
  if (!t)
    return thing;
  t = ((t)->list.purpose);
  return ((t)->decl.name);
}




void
setup_vtbl_ptr(void) asm("_setup_vtbl_ptr");
void
setup_vtbl_ptr(void)
{
  extern tree base_init_expr;

  if (base_init_expr == 0
      && (((current_function_decl)->decl.lang_specific)->decl_flags.constructor_attr))
    emit_base_init (current_class_type, 0);
}


void
mark_inline_for_output(tree decl) asm("_mark_inline_for_output");
void
mark_inline_for_output(tree decl)
{
  decl = (((decl)->decl.lang_specific)->main_decl_variant);
  if ((((decl)->decl.lang_specific)->decl_flags.saved_inline))
    return;
  my_friendly_assert (((decl)->common.permanent_flag), 363);
  (((decl)->decl.lang_specific)->decl_flags.saved_inline) = 1;
  saved_inlines = perm_tree_cons ((tree) 
                                 ((void *)0)
                                          , decl, saved_inlines);
}

void
clear_temp_name(void) asm("_clear_temp_name");
void
clear_temp_name(void)
{
  temp_name_counter = 0;
}
tree
get_temp_name(tree type, int staticp) asm("_get_temp_name");
tree
get_temp_name(tree type, int staticp)
{
  char buf[sizeof ("_.tmp_%d") + 20];
  tree decl;
  int toplev = toplevel_bindings_p ();

  push_obstacks_nochange ();
  if (toplev || staticp)
    {
      end_temporary_allocation ();
      sprintf (buf, "_.tmp_%d", global_temp_name_counter++);
      decl = pushdecl_top_level (build_decl (VAR_DECL, get_identifier (buf), type));
    }
  else
    {
      sprintf (buf, "_.tmp_%d", temp_name_counter++);
      decl = pushdecl (build_decl (VAR_DECL, get_identifier (buf), type));
    }
  ((decl)->common.used_flag) = 1;
  ((decl)->common.static_flag) = staticp;




  if (! toplev)
    {
      expand_decl (decl);
      expand_decl_init (decl);
    }
  pop_obstacks ();

  return decl;
}





tree
get_temp_regvar(tree type, tree init) asm("_get_temp_regvar");
tree
get_temp_regvar(tree type, tree init)
{
  static char buf[sizeof ("_.tmp_%d") + 20] = { '_' };
  tree decl;

  sprintf (buf+1, "_.tmp_%d", temp_name_counter++);
  decl = build_decl (VAR_DECL, get_identifier (buf), type);
  ((decl)->common.used_flag) = 1;
  ((decl)->decl.regdecl_flag) = 1;

  if (init)
    store_init_value (decl, init);



  expand_decl (decl);
  expand_decl_init (decl);

  if (type_needs_gc_entry (type))
    ((decl)->decl.result) = size_int (++current_function_obstack_index);

  return decl;
}



int
temp_name_p(tree decl) asm("_temp_name_p");
int
temp_name_p(tree decl)
{
  return (!strncmp (((decl)->identifier.pointer), "_.tmp_", sizeof ("_.tmp_")-1));
}







void
finish_anon_union(tree anon_union_decl) asm("_finish_anon_union");
void
finish_anon_union(tree anon_union_decl)
{
  tree type = ((anon_union_decl)->common.type);
  tree field, main_decl = (tree) 
                         ((void *)0)
                                  ;
  tree elems = (tree) 
              ((void *)0)
                       ;
  int public_p = ((anon_union_decl)->common.public_flag);
  int static_p = ((anon_union_decl)->common.static_flag);
  int external_p = ((anon_union_decl)->decl.external_flag);

  if ((field = ((type)->type.values)) == (tree) 
                                     ((void *)0)
                                              )
    return;

  if (public_p)
    {
      error ("global anonymous unions must be declared static");
      return;
    }

  for (; field; field = ((field)->common.chain))
    {
      tree decl;
      if (((n64_enum_tree_code) (field)->common.code) != FIELD_DECL)
 continue;

      if (((field)->common.private_flag))
 cp_pedwarn_at ("private member `%#D' in anonymous union", field);
      else if (((field)->common.protected_flag))
 cp_pedwarn_at ("protected member `%#D' in anonymous union", field);

      decl = build_decl (VAR_DECL, ((field)->decl.name), ((field)->common.type));

      ((decl)->decl.initial) = error_mark_node;
      ((decl)->common.public_flag) = public_p;
      ((decl)->common.static_flag) = static_p;
      ((decl)->decl.external_flag) = external_p;
      decl = pushdecl (decl);



      if (main_decl == (tree) 
                      ((void *)0)
   
  && 1 == simple_cst_equal (((decl)->decl.size),
        ((anon_union_decl)->decl.size)))
 {
   main_decl = decl;
 }
      else
 {


   ((decl)->common.asm_written_flag) = 1;
 }

      ((decl)->decl.initial) = (tree) 
                           ((void *)0)
                                    ;


      elems = tree_cons ((tree) 
                        ((void *)0)
                                 , decl, elems);
      ((elems)->common.type) = type;
    }
  if (static_p)
    {
      if (main_decl)
 {
   make_decl_rtl (main_decl, 0, toplevel_bindings_p ());
   ((anon_union_decl)->decl.rtl) = ((main_decl)->decl.rtl);
 }
      else
 {
   warning ("anonymous union with no members");
   return;
 }
    }



  expand_anon_union_decl (anon_union_decl, (tree) 
                                          ((void *)0)
                                                   , elems);

  if (flag_cadillac)
    cadillac_finish_anon_union (anon_union_decl);
}






tree
finish_table(tree name, tree type, tree init, int publicp) asm("_finish_table");
tree
finish_table(tree name, tree type, tree init, int publicp)
{
  tree itype, atype, decl;
  static tree empty_table;
  int is_empty = 0;
  tree asmspec;

  itype = build_index_type (size_int (list_length (init) - 1));
  atype = build_cplus_array_type (type, itype);
  layout_type (atype);

  if (((init)->list.value) == integer_zero_node
      && ((init)->common.chain) == (tree) 
                             ((void *)0)
                                      )
    {



 {
   empty_table = get_temp_name (atype, 1);
   init = build (CONSTRUCTOR, atype, (tree) 
                                    ((void *)0)
                                             , init);
   ((init)->common.constant_flag) = 1;
   ((init)->common.static_flag) = 1;
   ((empty_table)->decl.initial) = init;
   asmspec = build_string (((((empty_table)->decl.name))->identifier.length),
      ((((empty_table)->decl.name))->identifier.pointer));
   cp_finish_decl (empty_table, (tree) 
                               ((void *)0)
                                        , asmspec, 0, 0);
 }
      is_empty = 1;
    }

  if (name == (tree) 
             ((void *)0)
                      )
    {
      if (is_empty)
 return empty_table;
      decl = get_temp_name (atype, 1);
    }
  else
    {
      decl = build_decl (VAR_DECL, name, atype);
      decl = pushdecl (decl);
      ((decl)->common.static_flag) = 1;
    }

  if (is_empty == 0)
    {
      ((decl)->common.public_flag) = publicp;
      init = build (CONSTRUCTOR, atype, (tree) 
                                       ((void *)0)
                                                , init);
      ((init)->common.constant_flag) = 1;
      ((init)->common.static_flag) = 1;
      ((decl)->decl.initial) = init;
      asmspec = build_string (((((decl)->decl.name))->identifier.length),
         ((((decl)->decl.name))->identifier.pointer));
    }
  else
    {

      ((decl)->decl.external_flag) = 1;
      ((decl)->common.static_flag) = 0;
      init = 0;
      asmspec = build_string (((((empty_table)->decl.name))->identifier.length),
         ((((empty_table)->decl.name))->identifier.pointer));
    }

  cp_finish_decl (decl, (tree) 
                       ((void *)0)
                                , asmspec, 0, 0);
  return decl;
}







void
finish_builtin_type(tree type, char *name, tree *fields, int len, tree align_type) asm("_finish_builtin_type");
void
finish_builtin_type(tree type, char *name, tree *fields, int len, tree align_type)
{
  register int i;

  ((type)->type.values) = fields[0];
  for (i = 0; i < len; i++)
    {
      layout_type (((fields[i])->common.type));
      ((fields[i])->decl.context) = type;
      ((fields[i])->common.chain) = fields[i+1];
    }
  ((fields[i])->decl.context) = type;
  (((fields[i])->decl.lang_specific)->decl_flags.context) = type;
  ((type)->type.align) = ((align_type)->type.align);
  layout_type (type);



  ((type)->type.name) = build_decl (TYPE_DECL, get_identifier (name), type);

  layout_decl (((type)->type.name), 0);
}





extern tree sizetype;

tree
coerce_new_type(tree type) asm("_coerce_new_type");
tree
coerce_new_type(tree type)
{
  int e1 = 0, e2 = 0;

  if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
    type = build_function_type (((type)->common.type), ((((type)->type.values))->common.chain));
  if (((type)->common.type) != ptr_type_node)
    e1 = 1, error ("`operator new' must return type `void *'");



  if (((type)->type.values) == (tree) 
                              ((void *)0)
                                       )
    e1 = 1, error ("`operator new' takes type `size_t' parameter");
  else if (((n64_enum_tree_code) (((((type)->type.values))->list.value))->common.code) != INTEGER_TYPE
    || ((((((type)->type.values))->list.value))->type.precision) != ((sizetype)->type.precision))
    e2 = 1, error ("`operator new' takes type `size_t' as first parameter");
  if (e2)
    type = build_function_type (ptr_type_node, tree_cons ((tree) 
                                                         ((void *)0)
                                                                  , sizetype, ((((type)->type.values))->common.chain)));
  else if (e1)
    type = build_function_type (ptr_type_node, ((type)->type.values));
  return type;
}

tree
coerce_delete_type(tree type) asm("_coerce_delete_type");
tree
coerce_delete_type(tree type)
{
  int e1 = 0, e2 = 0, e3 = 0;
  tree arg_types = ((type)->type.values);

  if (((n64_enum_tree_code) (type)->common.code) == METHOD_TYPE)
    {
      type = build_function_type (((type)->common.type), ((arg_types)->common.chain));
      arg_types = ((arg_types)->common.chain);
    }
  if (((type)->common.type) != void_type_node)
    e1 = 1, error ("`operator delete' must return type `void'");
  if (arg_types == (tree) 
                  ((void *)0)
      
     || ((arg_types)->list.value) != ptr_type_node)
    e2 = 1, error ("`operator delete' takes type `void *' as first parameter");

  if (arg_types
      && ((arg_types)->common.chain)
      && ((arg_types)->common.chain) != void_list_node)
    {


      tree t2 = ((((arg_types)->common.chain))->list.value);
      if (((n64_enum_tree_code) (t2)->common.code) != INTEGER_TYPE
   || ((t2)->type.precision) != ((sizetype)->type.precision))
 e3 = 1, error ("second argument to `operator delete' must be of type `size_t'");
      else if (((((arg_types)->common.chain))->common.chain) != void_list_node)
 {
   e3 = 1;
   if (((((arg_types)->common.chain))->common.chain))
     error ("too many arguments in declaration of `operator delete'");
   else
     error ("`...' invalid in specification of `operator delete'");
 }
    }
  if (e3)
    arg_types = tree_cons ((tree) 
                          ((void *)0)
                                   , ptr_type_node, build_tree_list ((tree) 
                                                                     ((void *)0)
                                                                              , sizetype));
  else if (e3 |= e2)
    {
      if (arg_types == (tree) 
                      ((void *)0)
                               )
 arg_types = tree_cons ((tree) 
                       ((void *)0)
                                , ptr_type_node, void_list_node);
      else
 arg_types = tree_cons ((tree) 
                       ((void *)0)
                                , ptr_type_node, ((arg_types)->common.chain));
    }
  else e3 |= e1;

  if (e3)
    type = build_function_type (void_type_node, arg_types);

  return type;
}

static void
mark_vtable_entries(tree decl) asm("_mark_vtable_entries");
static void
mark_vtable_entries(tree decl)
{
  tree entries = ((((decl)->decl.initial))->exp.operands[1]);

  skip_rtti_stuff (&entries);

  for (; entries; entries = ((entries)->common.chain))
    {
      tree fnaddr = (!flag_vtable_thunks ? ((((((((((entries)->list.value))->exp.operands[1]))->common.chain))->common.chain))->list.value) : ((n64_enum_tree_code) ((((((entries)->list.value)))->exp.operands[0]))->common.code) != THUNK_DECL ? (((entries)->list.value)) : (((((((entries)->list.value)))->exp.operands[0]))->decl.initial));
      tree fn = ((fnaddr)->exp.operands[0]);
      ((fn)->common.addressable_flag) = 1;
      if ((((fn)->decl.lang_specific)->decl_flags.abstract_virtual))
 {
   extern tree abort_fndecl;
   if (flag_vtable_thunks)
     fnaddr = ((entries)->list.value);
   ((fnaddr)->exp.operands[0]) = fn = abort_fndecl;
 }
      assemble_external (fn);
    }
}







void
import_export_vtable(tree decl, tree type, int final) asm("_import_export_vtable");
void
import_export_vtable(tree decl, tree type, int final)
{
  if (((decl)->decl.lang_flag_5))
    return;


  if (write_virtuals < 2 && write_virtuals != 0)
    {
      ((decl)->common.public_flag) = 1;
      if (write_virtuals < 0)
 ((decl)->decl.external_flag) = 1;
      ((decl)->decl.lang_flag_5) = 1;
    }
  else if ((((type)->type.lang_specific)->type_flags.interface_unknown == 0))
    {
      ((decl)->common.public_flag) = 1;
      ((decl)->decl.external_flag) = ! (((type)->type.lang_specific)->type_flags.vtable_needs_writing);
      ((decl)->decl.lang_flag_5) = 1;
    }
  else
    {



      int found = ((((type)->type.lang_specific)->type_flags.use_template) & 1);

      if (! found && ! final)
 {
   tree method;
   for (method = (((type)->type.lang_specific)->methods); method != (tree) 
                                                    ((void *)0)
                                                             ;
        method = (((method)->decl.lang_specific)->next_method))
     if (((method)->decl.vindex) != (tree) 
                                ((void *)0)
  
 && ! (((method)->decl.lang_specific)->decl_flags.declared_inline)
  && ! (((method)->decl.lang_specific)->decl_flags.abstract_virtual))
       {
  found = 1;
  break;
       }
 }

      if (final || ! found)
 {




   if (1)
     ((decl)->decl.weak_flag) = 1;
   else
     ((decl)->common.public_flag) = 0;
   ((decl)->decl.external_flag) = 0;
 }
      else
 {
   ((decl)->common.public_flag) = 1;
   ((decl)->decl.external_flag) = 1;
 }
    }
}

static void
import_export_template(tree type) asm("_import_export_template");
static void
import_export_template(tree type)
{
  if (((((type)->type.lang_specific)->type_flags.use_template) == 1)
      && ! flag_implicit_templates
      && (((type)->type.lang_specific)->type_flags.interface_unknown))
    {
      (((type)->type.lang_specific)->type_flags.interface_unknown = 0);
      (((type)->type.lang_specific)->type_flags.interface_only) = 1;
      (((type)->type.lang_specific)->type_flags.vtable_needs_writing) = 0;
    }
}

static void
finish_prevtable_vardecl(tree prev, tree vars) asm("_finish_prevtable_vardecl");
static void
finish_prevtable_vardecl(tree prev, tree vars)
{
  tree ctype = ((vars)->decl.context);
  import_export_template (ctype);

  if ((((ctype)->type.lang_specific)->type_flags.interface_unknown) && (((ctype)->common.lang_flag_2))
      && ! ((((ctype)->type.lang_specific)->type_flags.use_template) & 1))
    {
      tree method;
      for (method = (((ctype)->type.lang_specific)->methods); method != (tree) 
                                                        ((void *)0)
                                                                 ;
    method = (((method)->decl.lang_specific)->next_method))
 {
   if (((method)->decl.vindex) != (tree) 
                              ((void *)0)
       
      && !(((method)->decl.lang_specific)->decl_flags.declared_inline)
       && !(((method)->decl.lang_specific)->decl_flags.abstract_virtual))
     {
       (((ctype)->type.lang_specific)->type_flags.interface_unknown = 0);
       (((ctype)->type.lang_specific)->type_flags.vtable_needs_writing) = ! ((method)->decl.external_flag);
       (((ctype)->type.lang_specific)->type_flags.interface_only) = ((method)->decl.external_flag);
       break;
     }
 }
    }

  import_export_vtable (vars, ctype, 1);





  if (flag_rtti && write_virtuals >= 0
      && ! ((vars)->decl.external_flag) && (((vars)->common.public_flag) || 1 || ((vars)->common.used_flag)))
    {




      build_t_desc (ctype, 1);
    }
}

static void
finish_vtable_vardecl(tree prev, tree vars) asm("_finish_vtable_vardecl");
static void
finish_vtable_vardecl(tree prev, tree vars)
{
  if (write_virtuals >= 0
      && ! ((vars)->decl.external_flag) && (((vars)->common.public_flag) || ((vars)->common.used_flag)))
    {
      mark_vtable_entries (vars);
      if (((((vars)->decl.initial))->common.type) == 0)
 store_init_value (vars, ((vars)->decl.initial));


      if (write_symbols == DWARF_DEBUG)
 {
   ((vars)->decl.ignored_flag) = 1;
 }


      rest_of_decl_compilation (vars, ((void *)0), 1, 1);
    }
  else if (! ((vars)->common.used_flag))

    return;


  ((prev)->common.chain) = ((vars)->common.chain);
}

static void
prune_vtable_vardecl(tree prev, tree vars) asm("_prune_vtable_vardecl");
static void
prune_vtable_vardecl(tree prev, tree vars)
{

  ((prev)->common.chain) = ((vars)->common.chain);
}

void
walk_vtables(register void (*typedecl_fn) (...), register void (*vardecl_fn) (...)) asm("_walk_vtables");
void
walk_vtables(register void (*typedecl_fn) (...), register void (*vardecl_fn) (...))
{
  tree prev, vars;

  for (prev = 0, vars = getdecls (); vars; vars = ((vars)->common.chain))
    {
      register tree type = ((vars)->common.type);

      if (((n64_enum_tree_code) (vars)->common.code) == VAR_DECL && ((vars)->decl.virtual_flag))
 {
   if (vardecl_fn) (*vardecl_fn) (prev, vars);

   if (prev && ((prev)->common.chain) != vars)
     continue;
 }
      else if (((n64_enum_tree_code) (vars)->common.code) == TYPE_DECL
        && type != error_mark_node
        && ((type)->type.lang_specific)
        && (((type)->type.lang_specific)->vsize))
 {
   if (typedecl_fn) (*typedecl_fn) (prev, vars);
 }

      prev = vars;
    }
}

static void
finish_sigtable_vardecl(tree prev, tree vars) asm("_finish_sigtable_vardecl");
static void
finish_sigtable_vardecl(tree prev, tree vars)
{




  rest_of_decl_compilation (vars, ((void *)0), 1, 1);


  ((prev)->common.chain) = ((vars)->common.chain);
}

void
walk_sigtables(register void (*typedecl_fn) (...), register void (*vardecl_fn) (...)) asm("_walk_sigtables");
void
walk_sigtables(register void (*typedecl_fn) (...), register void (*vardecl_fn) (...))
{
  tree prev, vars;

  for (prev = 0, vars = getdecls (); vars; vars = ((vars)->common.chain))
    {
      register tree type = ((vars)->common.type);

      if (((n64_enum_tree_code) (vars)->common.code) == TYPE_DECL
   && type != error_mark_node
   && (((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
 {
   if (typedecl_fn) (*typedecl_fn) (prev, vars);
 }
      else if (((n64_enum_tree_code) (vars)->common.code) == VAR_DECL
        && ((vars)->common.type) != error_mark_node
        && (((((vars)->common.type))->type.lang_specific)?((((vars)->common.type))->type.lang_specific)->type_flags.is_signature:0))
 {
   if (vardecl_fn) (*vardecl_fn) (prev, vars);
 }
      else
 prev = vars;
    }
}




void
import_export_inline(tree decl) asm("_import_export_inline");
void
import_export_inline(tree decl)
{
  if (((decl)->decl.lang_flag_5))
    return;

  if (((((decl)->decl.lang_specific)->decl_flags.use_template) & 1))
    {
      if (((((decl)->decl.lang_specific)->decl_flags.use_template) == 1) && flag_implicit_templates)
 {
   if (1)
     ((decl)->decl.weak_flag) = 1;
   else
     ((decl)->common.public_flag) = 0;
 }
      else
 (((decl)->decl.lang_specific)->decl_flags.not_really_extern) = 0;
    }
  else if ((((n64_enum_tree_code) (((decl)->common.type))->common.code) == METHOD_TYPE || (((decl)->decl.lang_specific)->decl_flags.static_function)))
    {
      tree ctype = (((decl)->decl.lang_specific)->decl_flags.context);
      if ((((ctype)->type.lang_specific)->type_flags.interface_unknown == 0) && ! ((decl)->decl.artificial_flag))
 {
   (((decl)->decl.lang_specific)->decl_flags.not_really_extern)
     = ! ((((ctype)->type.lang_specific)->type_flags.interface_only)
   || ((((decl)->decl.lang_specific)->decl_flags.declared_inline) && ! flag_implement_inlines));
 }
      else if (1)
 ((decl)->decl.weak_flag) = 1;
      else
 ((decl)->common.public_flag) = 0;
    }
  else if ((((decl)->decl.lang_specific)->decl_flags.c_static))
    ((decl)->common.public_flag) = 0;
  else if (1)
    ((decl)->decl.weak_flag) = 1;
  else
    ((decl)->common.public_flag) = 0;

  ((decl)->decl.lang_flag_5) = 1;
}

extern int parse_time, varconst_time;
void
finish_file(void) asm("_finish_file");
void
finish_file(void)
{
  extern int lineno;
  int start_time, this_time;

  tree fnname;
  tree vars;
  int needs_cleaning = 0, needs_messing_up = 0;

  if (flag_detailed_statistics)
    dump_tree_statistics ();


  if (! global_bindings_p () || current_class_type)
    return;

  start_time = get_run_time ();



  push_lang_context (lang_name_c);



  lineno -= 1;

  interface_unknown = 1;
  interface_only = 0;
  vars = build_decl (TYPE_DECL, get_identifier (" @%$#@!"), integer_type_node);

  ((vars)->decl.ignored_flag) = 1;
  (((vars)->decl.artificial_flag) = 1);
  pushdecl (vars);




  walk_vtables ((void (*)(...))0, finish_prevtable_vardecl);

  vars = static_aggregates;

  if (static_ctors || vars || might_have_exceptions_p ())
    needs_messing_up = 1;
  if (static_dtors)
    needs_cleaning = 1;


  while (vars && needs_cleaning == 0)
    {
      tree decl = ((vars)->list.value);
      tree type = ((decl)->common.type);
      if ((((type)->type.lang_flag_4)))
 {
   needs_cleaning = 1;
   needs_messing_up = 1;
   break;
 }
      else
 needs_messing_up |= ((type)->type.needs_constructing_flag);
      vars = ((vars)->common.chain);
    }

  if (needs_cleaning == 0)
    goto mess_up;

  fnname = get_file_function_name ('D');
  start_function (void_list_node,
    build_parse_node (CALL_EXPR, fnname, void_list_node,
        (tree) 
       ((void *)0)
                ),
    (tree) 
   ((void *)0)
            , (tree) 
              ((void *)0)
                       , 0);
  fnname = ((current_function_decl)->decl.assembler_name);
  store_parm_decls ();

  pushlevel (0);
  clear_last_expr ();
  push_momentary ();
  expand_start_bindings (0);



  for (vars = static_aggregates; vars; vars = ((vars)->common.chain))
    {
      tree decl = ((vars)->list.value);
      tree type = ((decl)->common.type);
      tree temp = ((vars)->list.purpose);

      if ((((type)->type.lang_flag_4)))
 {
   if (((vars)->common.static_flag))
     expand_start_cond (build_binary_op (NE_EXPR, temp, integer_zero_node, 1), 0);
   if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE)
     temp = decl;
   else
     {
       mark_addressable (decl);
       temp = build1 (ADDR_EXPR, build_pointer_type (type), decl);
     }
   temp = build_delete (((temp)->common.type), temp,
          integer_two_node, (3)|(8)|(512), 0);
   expand_expr_stmt (temp);

   if (((vars)->common.static_flag))
     expand_end_cond ();
 }
    }

  for (; static_dtors; static_dtors = ((static_dtors)->common.chain))
    expand_expr_stmt (build_function_call (((static_dtors)->list.value),
        (tree) 
       ((void *)0)
                ));

  expand_end_bindings (getdecls(), 1, 0);
  poplevel (1, 0, 0);
  pop_momentary ();

  finish_function (lineno, 0, 0);

  assemble_destructor (((fnname)->identifier.pointer));



 mess_up:

  vars = nreverse (static_aggregates);
  if (needs_messing_up)
    {
      fnname = get_file_function_name ('I');
      start_function (void_list_node,
        build_parse_node (CALL_EXPR, fnname,
     void_list_node, (tree) 
                    ((void *)0)
                             ),
        (tree) 
       ((void *)0)
                , (tree) 
                  ((void *)0)
                           , 0);
      fnname = ((current_function_decl)->decl.assembler_name);
      store_parm_decls ();

      pushlevel (0);
      clear_last_expr ();
      push_momentary ();
      expand_start_bindings (0);

      if (might_have_exceptions_p ())
 register_exception_table ();

      while (vars)
 {
   tree decl = ((vars)->list.value);
   tree init = ((vars)->list.purpose);
   tree old_cleanups = cleanups_this_call;




   if (((vars)->common.static_flag)
       || (init && ((n64_enum_tree_code) (init)->common.code) == TREE_LIST
    && value_member (error_mark_node, init)))
     {
       vars = ((vars)->common.chain);
       continue;
     }

   if (((n64_enum_tree_code) (decl)->common.code) == VAR_DECL)
     {


       input_filename = ((decl)->decl.filename);
       lineno = ((decl)->decl.linenum);
       emit_note (input_filename, lineno);



       (((current_function_decl)->decl.lang_specific)->decl_flags.context) = ((decl)->decl.context);
       (((current_function_decl)->decl.lang_specific)->decl_flags.static_function) = 1;

       if ((((((decl)->common.type))->type.lang_flag_5))
    || ((n64_enum_tree_code) (((decl)->common.type))->common.code) == ARRAY_TYPE)
  expand_aggr_init (decl, init, 0, 0);
       else if (((n64_enum_tree_code) (init)->common.code) == TREE_VEC)
  {
    expand_expr (expand_vec_init (decl, ((init)->vec.a[0]),
      ((init)->vec.a[1]),
      ((init)->vec.a[2]), 0),
          const0_rtx, VOIDmode, 0);
    free_temp_slots ();
  }
       else
  expand_assignment (decl, init, 0, 0);

       (((current_function_decl)->decl.lang_specific)->decl_flags.context) = (tree) 
                                                   ((void *)0)
                                                            ;
     }
   else if (((n64_enum_tree_code) (decl)->common.code) == SAVE_EXPR)
     {
       if (! (((decl)->common.lang_flag_2)))
  {

    expand_expr (decl, const0_rtx, VOIDmode, 0);
    free_temp_slots ();
    if (((n64_enum_tree_code) (init)->common.code) == TREE_VEC)
      {
        expand_expr (expand_vec_init (decl, ((init)->vec.a[0]),
          ((init)->vec.a[1]),
          ((init)->vec.a[2]), 0),
       const0_rtx, VOIDmode, 0);
        free_temp_slots ();
      }
    else
      expand_aggr_init (build_indirect_ref (decl, ((void *)0)), init, 0, 0);
  }
     }
   else if (decl == error_mark_node)
     ;
   else my_friendly_abort (22);
   vars = ((vars)->common.chain);

   expand_cleanups_to (old_cleanups);
 }

      for (; static_ctors; static_ctors = ((static_ctors)->common.chain))
 expand_expr_stmt (build_function_call (((static_ctors)->list.value),
            (tree) 
           ((void *)0)
                    ));

      expand_end_bindings (getdecls(), 1, 0);
      poplevel (1, 0, 0);
      pop_momentary ();

      finish_function (lineno, 0, 0);
      assemble_constructor (((fnname)->identifier.pointer));
    }

  expand_builtin_throw ();

  permanent_allocation (1);


  pop_lang_context ();



  while (pending_statics)
    {
      tree decl = ((pending_statics)->list.value);
      if (((decl)->common.used_flag) == 1
   || ((decl)->common.readonly_flag) == 0
   || ((decl)->decl.initial) == 0)
 rest_of_decl_compilation (decl, ((((decl)->decl.assembler_name))->identifier.pointer), 1, 1);
      pending_statics = ((pending_statics)->common.chain);
    }

  this_time = get_run_time ();
  parse_time -= this_time - start_time;
  varconst_time += this_time - start_time;

  start_time = get_run_time ();

  if (flag_handle_signatures)
    walk_sigtables ((void (*)(...))0, finish_sigtable_vardecl);

  for (fnname = saved_inlines; fnname; fnname = ((fnname)->common.chain))
    {
      tree decl = ((fnname)->list.value);
      import_export_inline (decl);
      if (((decl)->decl.artificial_flag) && ! ((decl)->decl.initial)
   && ((decl)->common.public_flag) && ! ((decl)->decl.weak_flag)
   && (((decl)->decl.lang_specific)->decl_flags.not_really_extern))
 synthesize_method (decl);
    }




  {
    int reconsider = 1;

    while (reconsider)
      {
 tree last = saved_inlines = tree_cons ((tree) 
                                       ((void *)0)
                                                , (tree) 
                                                  ((void *)0)
                                                           ,
            saved_inlines);
 tree last_head = last;
 tree place = ((saved_inlines)->common.chain);
 reconsider = 0;

 walk_vtables ((void (*)(...))0, finish_vtable_vardecl);

 for (; place; place = ((place)->common.chain))
   {
     tree decl = ((place)->list.value);



     if (decl == (tree) 
                ((void *)0)
                         )
       {
  ((last)->common.chain) = ((place)->common.chain);
  continue;
       }

     if (((decl)->decl.artificial_flag) && ! ((decl)->decl.initial))
       {
  if (((decl)->common.used_flag))
    {
      synthesize_method (decl);
      if (((decl)->common.asm_written_flag))
        reconsider = 1;
    }
  else
    {
      last = place;
      continue;
    }
       }

     if (((decl)->common.asm_written_flag) || ((decl)->decl.saved_insns.r) == 0)
       {
  ((last)->common.chain) = ((place)->common.chain);
  continue;
       }

     if ((((decl)->common.public_flag) && ! ((decl)->decl.weak_flag))
  || ((((decl)->decl.assembler_name))->common.static_flag)
  || flag_keep_inline_functions)
       {
  ((last)->common.chain) = ((place)->common.chain);

  if ((((decl)->decl.lang_specific)->decl_flags.not_really_extern))
    {
      ((decl)->decl.external_flag) = 0;
      reconsider = 1;
      temporary_allocation ();
      output_inline_function (decl);
      permanent_allocation (1);
    }

  continue;
       }

     last = place;
   }
      }
  }




  walk_vtables ((void (*)(...))0, prune_vtable_vardecl);

  for (vars = getdecls (); vars; vars = ((vars)->common.chain))
    {
      if (((n64_enum_tree_code) (vars)->common.code) == THUNK_DECL)
 emit_thunk (vars);
      else if (((n64_enum_tree_code) (vars)->common.code) == FUNCTION_DECL
        && ! ((vars)->decl.lang_flag_5)
        && (((vars)->decl.lang_specific)->decl_flags.c_static))
 ((vars)->common.public_flag) = 0;
    }

  if (might_have_exceptions_p ())
    emit_exception_table ();

  if (write_virtuals == 2)
    {


      while (pending_vtables)
 {
   if (((pending_vtables)->list.purpose) == (tree) 
                                        ((void *)0)
                                                 )
     error ("virtual function table for `%s' not defined",
     ((((pending_vtables)->list.value))->identifier.pointer));
   pending_vtables = ((pending_vtables)->common.chain);
 }
    }

  finish_repo ();

  this_time = get_run_time ();
  parse_time -= this_time - start_time;
  varconst_time += this_time - start_time;

  if (flag_detailed_statistics)
    dump_time_statistics ();
}
tree
reparse_absdcl_as_expr(tree type, tree decl) asm("_reparse_absdcl_as_expr");
tree
reparse_absdcl_as_expr(tree type, tree decl)
{

  if (((decl)->exp.operands[0]) == (tree) 
                               ((void *)0)
                                        )
    return build_functional_cast (type, (tree) 
                                       ((void *)0)
                                                );


  decl = reparse_decl_as_expr (type, ((decl)->exp.operands[0]));

  decl = build_x_function_call (decl, (tree) 
                                     ((void *)0)
                                              , current_class_decl);

  if (((n64_enum_tree_code) (decl)->common.code) == CALL_EXPR && ((decl)->common.type) != void_type_node)
    decl = require_complete_type (decl);

  return decl;
}
tree
reparse_absdcl_as_casts(tree decl, tree expr) asm("_reparse_absdcl_as_casts");
tree
reparse_absdcl_as_casts(tree decl, tree expr)
{
  tree type;

  if (((n64_enum_tree_code) (expr)->common.code) == CONSTRUCTOR)
    {
      type = groktypename (((((decl)->exp.operands[1]))->list.value));
      decl = ((decl)->exp.operands[0]);

      if ((((type)->type.lang_specific)?((type)->type.lang_specific)->type_flags.is_signature:0))
 {
   error ("cast specifies signature type");
   return error_mark_node;
 }

      expr = digest_init (type, expr, (tree *) 0);
      if (((n64_enum_tree_code) (type)->common.code) == ARRAY_TYPE && ((type)->type.size) == 0)
 {
   int failure = complete_array_type (type, expr, 1);
   if (failure)
     my_friendly_abort (78);
 }
    }

  while (decl)
    {
      type = groktypename (((((decl)->exp.operands[1]))->list.value));
      decl = ((decl)->exp.operands[0]);
      expr = build_c_cast (type, expr, 0);
    }

  return expr;
}



static tree
reparse_decl_as_expr1(tree decl) asm("_reparse_decl_as_expr1");
static tree
reparse_decl_as_expr1(tree decl)
{
  switch (((n64_enum_tree_code) (decl)->common.code))
    {
    case IDENTIFIER_NODE:
      return do_identifier (decl);
    case INDIRECT_REF:
      return build_x_indirect_ref
 (reparse_decl_as_expr1 (((decl)->exp.operands[0])), "unary *");
    case ADDR_EXPR:
      return build_x_unary_op (ADDR_EXPR,
          reparse_decl_as_expr1 (((decl)->exp.operands[0])));
    case BIT_NOT_EXPR:
      return build_x_unary_op (BIT_NOT_EXPR,
          reparse_decl_as_expr1 (((decl)->exp.operands[0])));
    case SCOPE_REF:
      return build_offset_ref (((decl)->exp.operands[0]), ((decl)->exp.operands[1]));
    case ARRAY_REF:
      return grok_array_decl (reparse_decl_as_expr1 (((decl)->exp.operands[0])),
         ((decl)->exp.operands[1]));
    default:
      my_friendly_abort (5);
      return (tree) 
            ((void *)0)
                     ;
    }
}







tree
reparse_decl_as_expr(tree type, tree decl) asm("_reparse_decl_as_expr");
tree
reparse_decl_as_expr(tree type, tree decl)
{
  decl = reparse_decl_as_expr1 (decl);
  if (type)
    return build_functional_cast (type, build_tree_list ((tree) 
                                                        ((void *)0)
                                                                 , decl));
  else
    return decl;
}





tree
finish_decl_parsing(tree decl) asm("_finish_decl_parsing");
tree
finish_decl_parsing(tree decl)
{
  extern int current_class_depth;

  switch (((n64_enum_tree_code) (decl)->common.code))
    {
    case IDENTIFIER_NODE:
      return decl;
    case INDIRECT_REF:
      return make_pointer_declarator
 ((tree) 
 ((void *)0)
          , finish_decl_parsing (((decl)->exp.operands[0])));
    case ADDR_EXPR:
      return make_reference_declarator
 ((tree) 
 ((void *)0)
          , finish_decl_parsing (((decl)->exp.operands[0])));
    case BIT_NOT_EXPR:
      ((decl)->exp.operands[0]) = finish_decl_parsing (((decl)->exp.operands[0]));
      return decl;
    case SCOPE_REF:
      push_nested_class (((((decl)->exp.operands[0]))->common.type), 3);
      ((decl)->exp.complexity) = current_class_depth;
      return decl;
    case ARRAY_REF:
      ((decl)->exp.operands[0]) = finish_decl_parsing (((decl)->exp.operands[0]));
      return decl;
    default:
      my_friendly_abort (5);
      return (tree) 
            ((void *)0)
                     ;
    }
}

tree
check_cp_case_value(tree value) asm("_check_cp_case_value");
tree
check_cp_case_value(tree value)
{
  if (value == (tree) 
              ((void *)0)
                       )
    return value;



  if (((n64_enum_tree_code) (value)->common.code) == NOP_EXPR
      && ((value)->common.type) == ((((value)->exp.operands[0]))->common.type))
    value = ((value)->exp.operands[0]);

  if ((((value)->common.readonly_flag) && (*tree_code_type[(int) (((n64_enum_tree_code) (value)->common.code))]) == 'd'))
    {
      value = decl_constant_value (value);


      if (((n64_enum_tree_code) (value)->common.code) == NOP_EXPR
   && ((value)->common.type) == ((((value)->exp.operands[0]))->common.type))
 value = ((value)->exp.operands[0]);
    }
  value = fold (value);

  if (((n64_enum_tree_code) (value)->common.code) != INTEGER_CST
      && value != error_mark_node)
    {
      cp_error ("case label `%E' does not reduce to an integer constant",
  value);
      value = error_mark_node;
    }
  else

    value = default_conversion (value);

  constant_expression_warning (value);

  return value;
}

tree current_namespace;



tree
get_namespace_id(void) asm("_get_namespace_id");
tree
get_namespace_id(void)
{
  tree x = current_namespace;
  if (x)
    x = ((x)->list.purpose);
  return x;
}


tree
current_namespace_id(tree name) asm("_current_namespace_id");
tree
current_namespace_id(tree name)
{
  tree old_id = get_namespace_id ();
  char *buf;


  if (! old_id)
    return name;

  buf = (char *) 
                __builtin_alloca((
                8 + ((old_id)->identifier.length) + ((name)->identifier.length)
                ))
                               
                              ;
  sprintf (buf, "__ns_%s_%s", ((old_id)->identifier.pointer),
    ((name)->identifier.pointer));
  return get_identifier (buf);
}

void
do_namespace_alias(tree alias, tree cxx_namespace) asm("_do_namespace_alias");
void
do_namespace_alias(tree alias, tree cxx_namespace)
{
}

tree
do_toplevel_using_decl(tree decl) asm("_do_toplevel_using_decl");
tree
do_toplevel_using_decl(tree decl)
{
  if (decl == (tree) 
             ((void *)0) 
                       || decl == error_mark_node)
    return 0;

  if (((n64_enum_tree_code) (decl)->common.code) == SCOPE_REF)
    decl = resolve_scope_to_name ((tree) 
                                 ((void *)0)
                                          , decl);


  if (((n64_enum_tree_code) (decl)->common.code) != TREE_LIST)
    {
      pushdecl (decl);
    }
  else
    while (decl)
      {
 pushdecl (((decl)->list.value));
 decl = ((decl)->common.chain);
      }

  return 0;
}

tree
do_class_using_decl(tree decl) asm("_do_class_using_decl");
tree
do_class_using_decl(tree decl)
{
  tree type;


  return (tree) 
        ((void *)0)
                 ;
}

void
do_using_directive(tree cxx_namespace) asm("_do_using_directive");
void
do_using_directive(tree cxx_namespace)
{
}

void
check_default_args(tree x) asm("_check_default_args");
void
check_default_args(tree x)
{
  tree arg = ((((x)->common.type))->type.values);
  int saw_def = 0, i = 0 - (((n64_enum_tree_code) (((x)->common.type))->common.code) == METHOD_TYPE);
  for (; arg && arg != void_list_node; arg = ((arg)->common.chain), ++i)
    {
      if (((arg)->list.purpose))
 saw_def = 1;
      else if (saw_def)
 {
   cp_error ("default argument missing for parameter %P of `%#D'",
      i, x);
   break;
 }
    }
}

